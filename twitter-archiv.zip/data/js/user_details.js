var user_details =  {
  "screen_name" : "nicidienase",
  "location" : "Karlsruhe",
  "full_name" : "Felix",
  "bio" : "Nerd, Informatikstudent, Fachschaftler, Ex-Physikstudent, Hacker, Serienjunkie ...",
  "id" : "22396883",
  "created_at" : "Sun Mar 01 19:37:33 +0000 2009"
}