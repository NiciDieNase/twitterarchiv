var payload_details =  {
  "tweets" : 1367,
  "created_at" : "Sat Apr 13 21:15:50 +0000 2013",
  "lang" : "de"
}