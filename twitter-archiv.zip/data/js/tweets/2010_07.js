Grailbird.data.tweets_2010_07 = 
 [ {
  "source" : "<a href=\"http://tweed.pivotallabs.com\" rel=\"nofollow\">Tweed webOS</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mario Sixtus",
      "screen_name" : "sixtus",
      "indices" : [ 3, 10 ],
      "id_str" : "9334352",
      "id" : 9334352
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "19833579962",
  "text" : "RT @sixtus: Was muss man eigentlich in die robots.txt schreiben, damit die Googlebots einem den Nacken crawlen?",
  "retweeted_status" : {
    "source" : "web",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : {
    },
    "id_str" : "19825446829",
    "text" : "Was muss man eigentlich in die robots.txt schreiben, damit die Googlebots einem den Nacken crawlen?",
    "id" : 19825446829,
    "created_at" : "Thu Jul 29 13:25:25 +0000 2010",
    "user" : {
      "name" : "Mario Sixtus",
      "screen_name" : "sixtus",
      "protected" : false,
      "id_str" : "9334352",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/274542155/mario_normal.gif",
      "id" : 9334352,
      "verified" : true
    }
  },
  "id" : 19833579962,
  "created_at" : "Thu Jul 29 15:19:57 +0000 2010",
  "user" : {
    "name" : "Felix",
    "screen_name" : "nicidienase",
    "protected" : false,
    "id_str" : "22396883",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3125784966/8223a4c5c9535be22d15c82ec829c2df_normal.jpeg",
    "id" : 22396883,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://tweed.pivotallabs.com\" rel=\"nofollow\">Tweed webOS</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jan Piotrowski",
      "screen_name" : "Sujan",
      "indices" : [ 0, 6 ],
      "id_str" : "1751051",
      "id" : 1751051
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "19353483691",
  "geo" : {
  },
  "id_str" : "19416495111",
  "in_reply_to_user_id" : 1751051,
  "text" : "@Sujan Es bilden sich Schlangen weil immer nur ein Drehkreuz zum rausgehen da ist und die Drehkr. funktionieren bei jedem 2. nicht richtig.",
  "id" : 19416495111,
  "in_reply_to_status_id" : 19353483691,
  "created_at" : "Sat Jul 24 12:08:51 +0000 2010",
  "in_reply_to_screen_name" : "Sujan",
  "in_reply_to_user_id_str" : "1751051",
  "user" : {
    "name" : "Felix",
    "screen_name" : "nicidienase",
    "protected" : false,
    "id_str" : "22396883",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3125784966/8223a4c5c9535be22d15c82ec829c2df_normal.jpeg",
    "id" : 22396883,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://tweed.pivotallabs.com\" rel=\"nofollow\">Tweed webOS</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Fest",
      "indices" : [ 32, 37 ]
    }, {
      "text" : "fail",
      "indices" : [ 39, 44 ]
    }, {
      "text" : "Karlsruhe",
      "indices" : [ 45, 55 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "19353391229",
  "text" : "Barcode-Scanner-Einlass auf dem #Fest: #fail #Karlsruhe",
  "id" : 19353391229,
  "created_at" : "Fri Jul 23 16:47:20 +0000 2010",
  "user" : {
    "name" : "Felix",
    "screen_name" : "nicidienase",
    "protected" : false,
    "id_str" : "22396883",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3125784966/8223a4c5c9535be22d15c82ec829c2df_normal.jpeg",
    "id" : 22396883,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://tweed.pivotallabs.com\" rel=\"nofollow\">Tweed webOS</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sunday8pm",
      "screen_name" : "sunday_8pm",
      "indices" : [ 0, 11 ],
      "id_str" : "80762004",
      "id" : 80762004
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "19338754357",
  "geo" : {
  },
  "id_str" : "19343350208",
  "in_reply_to_user_id" : 80762004,
  "text" : "@Sunday_8pm Hier in KA schiffts jetzt, und es sieht nicht so aus als w\u00FCrde es heute noch gro\u00DFartig besser werde.",
  "id" : 19343350208,
  "in_reply_to_status_id" : 19338754357,
  "created_at" : "Fri Jul 23 14:27:57 +0000 2010",
  "in_reply_to_screen_name" : "sunday_8pm",
  "in_reply_to_user_id_str" : "80762004",
  "user" : {
    "name" : "Felix",
    "screen_name" : "nicidienase",
    "protected" : false,
    "id_str" : "22396883",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3125784966/8223a4c5c9535be22d15c82ec829c2df_normal.jpeg",
    "id" : 22396883,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://tweed.pivotallabs.com\" rel=\"nofollow\">Tweed webOS</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sunday8pm",
      "screen_name" : "sunday_8pm",
      "indices" : [ 0, 11 ],
      "id_str" : "80762004",
      "id" : 80762004
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "19331207881",
  "geo" : {
  },
  "id_str" : "19332395935",
  "in_reply_to_user_id" : 80762004,
  "text" : "@Sunday_8pm Siehst du auch ob der H\u00FCgel total durchweicht ist oder ob bei hoffentl.  ausbleibendem Regen halbwegs trockenes feiern m\u00F6gl ist?",
  "id" : 19332395935,
  "in_reply_to_status_id" : 19331207881,
  "created_at" : "Fri Jul 23 11:42:22 +0000 2010",
  "in_reply_to_screen_name" : "sunday_8pm",
  "in_reply_to_user_id_str" : "80762004",
  "user" : {
    "name" : "Felix",
    "screen_name" : "nicidienase",
    "protected" : false,
    "id_str" : "22396883",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3125784966/8223a4c5c9535be22d15c82ec829c2df_normal.jpeg",
    "id" : 22396883,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://tweed.pivotallabs.com\" rel=\"nofollow\">Tweed webOS</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sunday8pm",
      "screen_name" : "sunday_8pm",
      "indices" : [ 0, 11 ],
      "id_str" : "80762004",
      "id" : 80762004
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "19322078458",
  "geo" : {
  },
  "id_str" : "19332054692",
  "in_reply_to_user_id" : 80762004,
  "text" : "@Sunday_8pm Im Moment is es trocken. Aber so wie der Himmel aussieht is es net unwahrscheinlich das es noch regnet heute.",
  "id" : 19332054692,
  "in_reply_to_status_id" : 19322078458,
  "created_at" : "Fri Jul 23 11:35:32 +0000 2010",
  "in_reply_to_screen_name" : "sunday_8pm",
  "in_reply_to_user_id_str" : "80762004",
  "user" : {
    "name" : "Felix",
    "screen_name" : "nicidienase",
    "protected" : false,
    "id_str" : "22396883",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3125784966/8223a4c5c9535be22d15c82ec829c2df_normal.jpeg",
    "id" : 22396883,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://tweed.pivotallabs.com\" rel=\"nofollow\">Tweed webOS</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Waldhornbar",
      "indices" : [ 22, 34 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "18947175720",
  "text" : "Nerdiger Abend in der #Waldhornbar. Mit Super Nintendo/N64 auf dem Beamer.",
  "id" : 18947175720,
  "created_at" : "Mon Jul 19 22:17:24 +0000 2010",
  "user" : {
    "name" : "Felix",
    "screen_name" : "nicidienase",
    "protected" : false,
    "id_str" : "22396883",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3125784966/8223a4c5c9535be22d15c82ec829c2df_normal.jpeg",
    "id" : 22396883,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitpic.com\" rel=\"nofollow\">Twitpic</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "18864173880",
  "text" : "I buildz me my own ceilingcat! http://twitpic.com/26lf9o",
  "id" : 18864173880,
  "created_at" : "Sun Jul 18 21:02:09 +0000 2010",
  "user" : {
    "name" : "Felix",
    "screen_name" : "nicidienase",
    "protected" : false,
    "id_str" : "22396883",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3125784966/8223a4c5c9535be22d15c82ec829c2df_normal.jpeg",
    "id" : 22396883,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.bravenewcode.com/products/wordtwit\" rel=\"nofollow\">WordTwit Plugin</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "18833630482",
  "text" : "Neuer Blog-Beitrag, Videos [18.7.2010] - http://tinyurl.com/34sn8fh",
  "id" : 18833630482,
  "created_at" : "Sun Jul 18 11:16:48 +0000 2010",
  "user" : {
    "name" : "Felix",
    "screen_name" : "nicidienase",
    "protected" : false,
    "id_str" : "22396883",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3125784966/8223a4c5c9535be22d15c82ec829c2df_normal.jpeg",
    "id" : 22396883,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://tweed.pivotallabs.com\" rel=\"nofollow\">Tweed webOS</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "18832191818",
  "text" : "WTF Es fehlt nur noch der schwarze Anzug dann wird Dick Cheney wirklich zu Darth Vader. http://blog.fefe.de/?ts=b2bc8f58",
  "id" : 18832191818,
  "created_at" : "Sun Jul 18 10:40:14 +0000 2010",
  "user" : {
    "name" : "Felix",
    "screen_name" : "nicidienase",
    "protected" : false,
    "id_str" : "22396883",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3125784966/8223a4c5c9535be22d15c82ec829c2df_normal.jpeg",
    "id" : 22396883,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://tweed.pivotallabs.com\" rel=\"nofollow\">Tweed webOS</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Pre",
      "indices" : [ 32, 36 ]
    }, {
      "text" : "Linux",
      "indices" : [ 114, 120 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "18792367473",
  "text" : "Hab grade festgestellt das mein #Pre auch Uptime kann und schon seit \u00FCber 6 Tagen nicht mehr neu gestartet wurde. #Linux ist einfach toll!!",
  "id" : 18792367473,
  "created_at" : "Sat Jul 17 21:27:31 +0000 2010",
  "user" : {
    "name" : "Felix",
    "screen_name" : "nicidienase",
    "protected" : false,
    "id_str" : "22396883",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3125784966/8223a4c5c9535be22d15c82ec829c2df_normal.jpeg",
    "id" : 22396883,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.bravenewcode.com/products/wordtwit\" rel=\"nofollow\">WordTwit Plugin</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "18688908856",
  "text" : "Neuer Blog-Beitrag, Yeah, mein Blog ist wieder erreichbar! - http://tinyurl.com/38ku82r",
  "id" : 18688908856,
  "created_at" : "Fri Jul 16 14:17:38 +0000 2010",
  "user" : {
    "name" : "Felix",
    "screen_name" : "nicidienase",
    "protected" : false,
    "id_str" : "22396883",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3125784966/8223a4c5c9535be22d15c82ec829c2df_normal.jpeg",
    "id" : 22396883,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://tweed.pivotallabs.com\" rel=\"nofollow\">Tweed webOS</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Marcus Anh\u00E4user",
      "screen_name" : "Anhaeuser",
      "indices" : [ 3, 13 ],
      "id_str" : "69048734",
      "id" : 69048734
    }, {
      "name" : "BILDblog",
      "screen_name" : "BILDblog",
      "indices" : [ 105, 114 ],
      "id_str" : "68511500",
      "id" : 68511500
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "18586647767",
  "text" : "RT @Anhaeuser: Sehr sch\u00F6n: Da steht ein Mann mit einer Kamera vor dem Haus ... http://bit.ly/a4ObtD (via @bildblog)",
  "retweeted_status" : {
    "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Tweetie for Mac</a>",
    "entities" : {
      "user_mentions" : [ {
        "name" : "BILDblog",
        "screen_name" : "BILDblog",
        "indices" : [ 90, 99 ],
        "id_str" : "68511500",
        "id" : 68511500
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : {
    },
    "id_str" : "18501777325",
    "text" : "Sehr sch\u00F6n: Da steht ein Mann mit einer Kamera vor dem Haus ... http://bit.ly/a4ObtD (via @bildblog)",
    "id" : 18501777325,
    "created_at" : "Wed Jul 14 07:11:54 +0000 2010",
    "user" : {
      "name" : "Marcus Anh\u00E4user",
      "screen_name" : "Anhaeuser",
      "protected" : false,
      "id_str" : "69048734",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/382851399/viewimg.php_normal.jpeg",
      "id" : 69048734,
      "verified" : false
    }
  },
  "id" : 18586647767,
  "created_at" : "Thu Jul 15 08:13:26 +0000 2010",
  "user" : {
    "name" : "Felix",
    "screen_name" : "nicidienase",
    "protected" : false,
    "id_str" : "22396883",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3125784966/8223a4c5c9535be22d15c82ec829c2df_normal.jpeg",
    "id" : 22396883,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://tweed.pivotallabs.com\" rel=\"nofollow\">Tweed webOS</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 49.008119, 8.411494 ]
  },
  "id_str" : "18542070658",
  "text" : "... Es macht keinen Spa\u00DF wenn das halbe Zimmer unter Wasser steht.",
  "id" : 18542070658,
  "created_at" : "Wed Jul 14 19:12:09 +0000 2010",
  "user" : {
    "name" : "Felix",
    "screen_name" : "nicidienase",
    "protected" : false,
    "id_str" : "22396883",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3125784966/8223a4c5c9535be22d15c82ec829c2df_normal.jpeg",
    "id" : 22396883,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://tweed.pivotallabs.com\" rel=\"nofollow\">Tweed webOS</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 49.008119, 8.411494 ]
  },
  "id_str" : "18542022765",
  "text" : "Wenn man aus dem Haus geht und es sieht aus als k\u00F6nnte es vielleicht regnen, macht im Zweifel immer das Fenster zu. ...",
  "id" : 18542022765,
  "created_at" : "Wed Jul 14 19:11:18 +0000 2010",
  "user" : {
    "name" : "Felix",
    "screen_name" : "nicidienase",
    "protected" : false,
    "id_str" : "22396883",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3125784966/8223a4c5c9535be22d15c82ec829c2df_normal.jpeg",
    "id" : 22396883,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.bravenewcode.com/products/wordtwit\" rel=\"nofollow\">WordTwit Plugin</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "18116249958",
  "text" : "Neuer Blog-Beitrag, Twilight: For Guys! - http://tinyurl.com/32qjorn",
  "id" : 18116249958,
  "created_at" : "Fri Jul 09 13:05:36 +0000 2010",
  "user" : {
    "name" : "Felix",
    "screen_name" : "nicidienase",
    "protected" : false,
    "id_str" : "22396883",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3125784966/8223a4c5c9535be22d15c82ec829c2df_normal.jpeg",
    "id" : 22396883,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://tweed.pivotallabs.com\" rel=\"nofollow\">Tweed webOS</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Aristro King",
      "screen_name" : "kingaristro",
      "indices" : [ 0, 12 ],
      "id_str" : "91132566",
      "id" : 91132566
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "17818152514",
  "geo" : {
  },
  "id_str" : "17818363376",
  "in_reply_to_user_id" : 91132566,
  "text" : "@kingaristro hab dich!",
  "id" : 17818363376,
  "in_reply_to_status_id" : 17818152514,
  "created_at" : "Mon Jul 05 21:31:02 +0000 2010",
  "in_reply_to_screen_name" : "kingaristro",
  "in_reply_to_user_id_str" : "91132566",
  "user" : {
    "name" : "Felix",
    "screen_name" : "nicidienase",
    "protected" : false,
    "id_str" : "22396883",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3125784966/8223a4c5c9535be22d15c82ec829c2df_normal.jpeg",
    "id" : 22396883,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://tweed.pivotallabs.com\" rel=\"nofollow\">Tweed webOS</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mark Jacobs",
      "screen_name" : "Mark_S_J",
      "indices" : [ 3, 12 ],
      "id_str" : "16372863",
      "id" : 16372863
    }, {
      "name" : "Cory Doctorow",
      "screen_name" : "doctorow",
      "indices" : [ 14, 23 ],
      "id_str" : "2729061",
      "id" : 2729061
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "17731465030",
  "text" : "RT @Mark_S_J: @doctorow \"If copyright infringement is theft, photographing someone is kidnapping?\"",
  "retweeted_status" : {
    "source" : "web",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Cory Doctorow",
        "screen_name" : "doctorow",
        "indices" : [ 0, 9 ],
        "id_str" : "2729061",
        "id" : 2729061
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : {
    },
    "id_str" : "17712835866",
    "in_reply_to_user_id" : 2729061,
    "text" : "@doctorow \"If copyright infringement is theft, photographing someone is kidnapping?\"",
    "id" : 17712835866,
    "created_at" : "Sun Jul 04 10:33:44 +0000 2010",
    "in_reply_to_screen_name" : "doctorow",
    "in_reply_to_user_id_str" : "2729061",
    "user" : {
      "name" : "Mark Jacobs",
      "screen_name" : "Mark_S_J",
      "protected" : false,
      "id_str" : "16372863",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/143588654/bongos_normal.jpg",
      "id" : 16372863,
      "verified" : false
    }
  },
  "id" : 17731465030,
  "created_at" : "Sun Jul 04 16:40:28 +0000 2010",
  "user" : {
    "name" : "Felix",
    "screen_name" : "nicidienase",
    "protected" : false,
    "id_str" : "22396883",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3125784966/8223a4c5c9535be22d15c82ec829c2df_normal.jpeg",
    "id" : 22396883,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://tweed.pivotallabs.com\" rel=\"nofollow\">Tweed webOS</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "17678462390",
  "text" : "Test http://twitpic.com/2261la",
  "id" : 17678462390,
  "created_at" : "Sat Jul 03 21:38:39 +0000 2010",
  "user" : {
    "name" : "Felix",
    "screen_name" : "nicidienase",
    "protected" : false,
    "id_str" : "22396883",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3125784966/8223a4c5c9535be22d15c82ec829c2df_normal.jpeg",
    "id" : 22396883,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://dev.twitter.com/\" rel=\"nofollow\">API</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Gerd Eist",
      "screen_name" : "erdgeist",
      "indices" : [ 3, 12 ],
      "id_str" : "16701619",
      "id" : 16701619
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "17675564278",
  "text" : "RT @erdgeist: Wenn sich Mama-Raupe und Papa-Raupe ganz doll lieb haben, dann wird da eine s\u00FC\u00DFe kleine Raupkopie draus!",
  "retweeted_status" : {
    "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter</a>",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : {
    },
    "id_str" : "17667930606",
    "text" : "Wenn sich Mama-Raupe und Papa-Raupe ganz doll lieb haben, dann wird da eine s\u00FC\u00DFe kleine Raupkopie draus!",
    "id" : 17667930606,
    "created_at" : "Sat Jul 03 18:15:58 +0000 2010",
    "user" : {
      "name" : "Gerd Eist",
      "screen_name" : "erdgeist",
      "protected" : false,
      "id_str" : "16701619",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/61748149/ta_normal.jpg",
      "id" : 16701619,
      "verified" : false
    }
  },
  "id" : 17675564278,
  "created_at" : "Sat Jul 03 20:34:13 +0000 2010",
  "user" : {
    "name" : "Felix",
    "screen_name" : "nicidienase",
    "protected" : false,
    "id_str" : "22396883",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3125784966/8223a4c5c9535be22d15c82ec829c2df_normal.jpeg",
    "id" : 22396883,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://pivotallabs.com/landing/tweed\" rel=\"nofollow\">Tweed</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "17666893136",
  "text" : ".... der Bahn.",
  "id" : 17666893136,
  "created_at" : "Sat Jul 03 17:57:11 +0000 2010",
  "user" : {
    "name" : "Felix",
    "screen_name" : "nicidienase",
    "protected" : false,
    "id_str" : "22396883",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3125784966/8223a4c5c9535be22d15c82ec829c2df_normal.jpeg",
    "id" : 22396883,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://pivotallabs.com/landing/tweed\" rel=\"nofollow\">Tweed</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "17666862939",
  "text" : "Ist das eine Hitze heute. Grade vorhin erst geduscht und ich k\u00F6nnte schon wieder duschen. Wenigsten hab ich nen Platz mit Fahrtwind in d",
  "id" : 17666862939,
  "created_at" : "Sat Jul 03 17:56:38 +0000 2010",
  "user" : {
    "name" : "Felix",
    "screen_name" : "nicidienase",
    "protected" : false,
    "id_str" : "22396883",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3125784966/8223a4c5c9535be22d15c82ec829c2df_normal.jpeg",
    "id" : 22396883,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.bravenewcode.com/products/wordtwit\" rel=\"nofollow\">WordTwit Plugin</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "17486674826",
  "text" : "Neuer Blog-Beitrag, Festwochenende - http://tinyurl.com/2aq63q3",
  "id" : 17486674826,
  "created_at" : "Thu Jul 01 11:43:12 +0000 2010",
  "user" : {
    "name" : "Felix",
    "screen_name" : "nicidienase",
    "protected" : false,
    "id_str" : "22396883",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3125784966/8223a4c5c9535be22d15c82ec829c2df_normal.jpeg",
    "id" : 22396883,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://pivotallabs.com/landing/tweed\" rel=\"nofollow\">Tweed</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "17460013443",
  "text" : "Kleiner Tipp am Rande: Beim L\u00F6ten immer hingucken wenn man den L\u00F6tkolben in die Hand nimmt. Das hei\u00DFe Ende ist nicht zum Anfassen gedacht!!",
  "id" : 17460013443,
  "created_at" : "Thu Jul 01 02:24:15 +0000 2010",
  "user" : {
    "name" : "Felix",
    "screen_name" : "nicidienase",
    "protected" : false,
    "id_str" : "22396883",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3125784966/8223a4c5c9535be22d15c82ec829c2df_normal.jpeg",
    "id" : 22396883,
    "verified" : false
  }
} ]