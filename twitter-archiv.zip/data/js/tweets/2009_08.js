Grailbird.data.tweets_2009_08 = 
 [ {
  "source" : "<a href=\"https://launchpad.net/gwibber/\" rel=\"nofollow\">Gwibber</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "hotellazur",
      "screen_name" : "hotellazur",
      "indices" : [ 50, 61 ],
      "id_str" : "43773405",
      "id" : 43773405
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "3653351714",
  "text" : "Wow, ich wurde heute das erste mal retweeted (von @hotellazur)",
  "id" : 3653351714,
  "created_at" : "Sun Aug 30 22:29:22 +0000 2009",
  "user" : {
    "name" : "Felix",
    "screen_name" : "nicidienase",
    "protected" : false,
    "id_str" : "22396883",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3125784966/8223a4c5c9535be22d15c82ec829c2df_normal.jpeg",
    "id" : 22396883,
    "verified" : false
  }
}, {
  "source" : "<a href=\"https://launchpad.net/gwibber/\" rel=\"nofollow\">Gwibber</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ihre Wahl!",
      "screen_name" : "ihrewahl",
      "indices" : [ 0, 9 ],
      "id_str" : "52745722",
      "id" : 52745722
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "3652167692",
  "in_reply_to_user_id" : 52745722,
  "text" : "@ihrewahl: Mal wieder typisch, Internetzensur ist Fu\u00DFnote am Ende und v.d. Leyen erz\u00E4hl wieder falsche Fakten.",
  "id" : 3652167692,
  "created_at" : "Sun Aug 30 21:17:30 +0000 2009",
  "in_reply_to_screen_name" : "ihrewahl",
  "in_reply_to_user_id_str" : "52745722",
  "user" : {
    "name" : "Felix",
    "screen_name" : "nicidienase",
    "protected" : false,
    "id_str" : "22396883",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3125784966/8223a4c5c9535be22d15c82ec829c2df_normal.jpeg",
    "id" : 22396883,
    "verified" : false
  }
}, {
  "source" : "<a href=\"https://launchpad.net/gwibber/\" rel=\"nofollow\">Gwibber</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ihre Wahl!",
      "screen_name" : "ihrewahl",
      "indices" : [ 0, 9 ],
      "id_str" : "52745722",
      "id" : 52745722
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "3651319334",
  "in_reply_to_user_id" : 52745722,
  "text" : "@ihrewahl: Warum hat Fr. von der Leyen 3Jahre lang nichts gegen KiPo unternommen und dann ineff. und GG-widrige Ma\u00DFnahmen?",
  "id" : 3651319334,
  "created_at" : "Sun Aug 30 20:26:26 +0000 2009",
  "in_reply_to_screen_name" : "ihrewahl",
  "in_reply_to_user_id_str" : "52745722",
  "user" : {
    "name" : "Felix",
    "screen_name" : "nicidienase",
    "protected" : false,
    "id_str" : "22396883",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3125784966/8223a4c5c9535be22d15c82ec829c2df_normal.jpeg",
    "id" : 22396883,
    "verified" : false
  }
}, {
  "source" : "<a href=\"https://launchpad.net/gwibber/\" rel=\"nofollow\">Gwibber</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Zensursula",
      "indices" : [ 0, 11 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "3651189488",
  "text" : "#Zensursula auf Sat1, bin mal gespannt ob Internetzensur auch Thema wird",
  "id" : 3651189488,
  "created_at" : "Sun Aug 30 20:18:24 +0000 2009",
  "user" : {
    "name" : "Felix",
    "screen_name" : "nicidienase",
    "protected" : false,
    "id_str" : "22396883",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3125784966/8223a4c5c9535be22d15c82ec829c2df_normal.jpeg",
    "id" : 22396883,
    "verified" : false
  }
}, {
  "source" : "<a href=\"https://launchpad.net/gwibber/\" rel=\"nofollow\">Gwibber</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "thebigbangtheory",
      "indices" : [ 83, 100 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "3617559867",
  "text" : "Sheldon totaly looks like Mirror-Spock. Can't wait for Season 3 http://is.gd/2F0Zc #thebigbangtheory",
  "id" : 3617559867,
  "created_at" : "Sat Aug 29 02:44:07 +0000 2009",
  "user" : {
    "name" : "Felix",
    "screen_name" : "nicidienase",
    "protected" : false,
    "id_str" : "22396883",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3125784966/8223a4c5c9535be22d15c82ec829c2df_normal.jpeg",
    "id" : 22396883,
    "verified" : false
  }
}, {
  "source" : "<a href=\"https://launchpad.net/gwibber/\" rel=\"nofollow\">Gwibber</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "3414564879",
  "text" : "LOL: http://is.gd/2oUX6",
  "id" : 3414564879,
  "created_at" : "Wed Aug 19 22:26:13 +0000 2009",
  "user" : {
    "name" : "Felix",
    "screen_name" : "nicidienase",
    "protected" : false,
    "id_str" : "22396883",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3125784966/8223a4c5c9535be22d15c82ec829c2df_normal.jpeg",
    "id" : 22396883,
    "verified" : false
  }
}, {
  "source" : "<a href=\"https://launchpad.net/gwibber/\" rel=\"nofollow\">Gwibber</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "memo",
      "screen_name" : "memo42",
      "indices" : [ 0, 7 ],
      "id_str" : "55311456",
      "id" : 55311456
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "3307482109",
  "geo" : {
  },
  "id_str" : "3308051383",
  "in_reply_to_user_id" : 55311456,
  "text" : "@memo42 keine ahnung warum die replys nich im Buschfunk angezeigt werden, eingestellt hab ich da nix.",
  "id" : 3308051383,
  "in_reply_to_status_id" : 3307482109,
  "created_at" : "Fri Aug 14 14:14:49 +0000 2009",
  "in_reply_to_screen_name" : "memo42",
  "in_reply_to_user_id_str" : "55311456",
  "user" : {
    "name" : "Felix",
    "screen_name" : "nicidienase",
    "protected" : false,
    "id_str" : "22396883",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3125784966/8223a4c5c9535be22d15c82ec829c2df_normal.jpeg",
    "id" : 22396883,
    "verified" : false
  }
}, {
  "source" : "<a href=\"https://launchpad.net/gwibber/\" rel=\"nofollow\">Gwibber</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "memo",
      "screen_name" : "memo42",
      "indices" : [ 0, 7 ],
      "id_str" : "55311456",
      "id" : 55311456
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "3303956793",
  "geo" : {
  },
  "id_str" : "3304879296",
  "in_reply_to_user_id" : 55311456,
  "text" : "@memo42 was is den los in KA?",
  "id" : 3304879296,
  "in_reply_to_status_id" : 3303956793,
  "created_at" : "Fri Aug 14 09:25:45 +0000 2009",
  "in_reply_to_screen_name" : "memo42",
  "in_reply_to_user_id_str" : "55311456",
  "user" : {
    "name" : "Felix",
    "screen_name" : "nicidienase",
    "protected" : false,
    "id_str" : "22396883",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3125784966/8223a4c5c9535be22d15c82ec829c2df_normal.jpeg",
    "id" : 22396883,
    "verified" : false
  }
}, {
  "source" : "<a href=\"https://launchpad.net/gwibber/\" rel=\"nofollow\">Gwibber</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tim Pritlove",
      "screen_name" : "timpritlove",
      "indices" : [ 4, 16 ],
      "id_str" : "11268812",
      "id" : 11268812
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "3242303203",
  "geo" : {
  },
  "id_str" : "3243134519",
  "in_reply_to_user_id" : 11268812,
  "text" : "RT: @timpritlove \"Ich bin Pirat\" Sehr professioneller Werbespot f\u00FCr die Piratenpartei http://bit.ly/nDlX3",
  "id" : 3243134519,
  "in_reply_to_status_id" : 3242303203,
  "created_at" : "Tue Aug 11 10:00:20 +0000 2009",
  "in_reply_to_screen_name" : "timpritlove",
  "in_reply_to_user_id_str" : "11268812",
  "user" : {
    "name" : "Felix",
    "screen_name" : "nicidienase",
    "protected" : false,
    "id_str" : "22396883",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3125784966/8223a4c5c9535be22d15c82ec829c2df_normal.jpeg",
    "id" : 22396883,
    "verified" : false
  }
}, {
  "source" : "<a href=\"https://launchpad.net/gwibber/\" rel=\"nofollow\">Gwibber</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "3227576995",
  "text" : "Bis Sa noch in SHA bei meiner Tante zu Besuch",
  "id" : 3227576995,
  "created_at" : "Mon Aug 10 16:28:29 +0000 2009",
  "user" : {
    "name" : "Felix",
    "screen_name" : "nicidienase",
    "protected" : false,
    "id_str" : "22396883",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3125784966/8223a4c5c9535be22d15c82ec829c2df_normal.jpeg",
    "id" : 22396883,
    "verified" : false
  }
}, {
  "source" : "<a href=\"https://launchpad.net/gwibber/\" rel=\"nofollow\">Gwibber</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "saber",
      "indices" : [ 43, 49 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "3070103864",
  "text" : "Greatest Barfight ever: http://is.gd/1XGaR #saber",
  "id" : 3070103864,
  "created_at" : "Sat Aug 01 13:58:45 +0000 2009",
  "user" : {
    "name" : "Felix",
    "screen_name" : "nicidienase",
    "protected" : false,
    "id_str" : "22396883",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3125784966/8223a4c5c9535be22d15c82ec829c2df_normal.jpeg",
    "id" : 22396883,
    "verified" : false
  }
} ]