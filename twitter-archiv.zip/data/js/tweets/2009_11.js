Grailbird.data.tweets_2009_11 = 
 [ {
  "source" : "<a href=\"http://pivotallabs.com/landing/tweed\" rel=\"nofollow\">Tweed</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "KITbrennt",
      "indices" : [ 44, 54 ]
    }, {
      "text" : "KAbrennt",
      "indices" : [ 55, 64 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "6177814699",
  "text" : "Um 21.30Uhr Vortrag zum Thema Recht/R\u00E4umung #KITbrennt #KAbrennt",
  "id" : 6177814699,
  "created_at" : "Sun Nov 29 19:44:34 +0000 2009",
  "user" : {
    "name" : "Felix",
    "screen_name" : "nicidienase",
    "protected" : false,
    "id_str" : "22396883",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3125784966/8223a4c5c9535be22d15c82ec829c2df_normal.jpeg",
    "id" : 22396883,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://pivotallabs.com/landing/tweed\" rel=\"nofollow\">Tweed</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "KITbrennt",
      "indices" : [ 84, 94 ]
    }, {
      "text" : "KAbrennt",
      "indices" : [ 95, 104 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "6174923094",
  "text" : "Nicht sehr viel los im Plenum heute. Hoffentlich sinds sp\u00E4ter im Sonderplenum mehr. #KITbrennt #KAbrennt",
  "id" : 6174923094,
  "created_at" : "Sun Nov 29 17:41:20 +0000 2009",
  "user" : {
    "name" : "Felix",
    "screen_name" : "nicidienase",
    "protected" : false,
    "id_str" : "22396883",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3125784966/8223a4c5c9535be22d15c82ec829c2df_normal.jpeg",
    "id" : 22396883,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://pivotallabs.com/landing/tweed\" rel=\"nofollow\">Tweed</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "druckerei",
      "screen_name" : "druckerei_de",
      "indices" : [ 47, 60 ],
      "id_str" : "81800720",
      "id" : 81800720
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "6109783135",
  "text" : "Ich m\u00F6chte einen Twitter-Wandkalender 2010 von @druckerei_de bekommen. Zur Aktion von www.druckerei.de -&gt; http://bit.ly/4vTob5",
  "id" : 6109783135,
  "created_at" : "Fri Nov 27 11:43:08 +0000 2009",
  "user" : {
    "name" : "Felix",
    "screen_name" : "nicidienase",
    "protected" : false,
    "id_str" : "22396883",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3125784966/8223a4c5c9535be22d15c82ec829c2df_normal.jpeg",
    "id" : 22396883,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://pivotallabs.com/landing/tweed\" rel=\"nofollow\">Tweed</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Erik Wismeijer",
      "screen_name" : "Wish78",
      "indices" : [ 0, 7 ],
      "id_str" : "164622698",
      "id" : 164622698
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "6081191896",
  "geo" : {
  },
  "id_str" : "6097111096",
  "in_reply_to_user_id" : 25104719,
  "text" : "@Wish78 thx",
  "id" : 6097111096,
  "in_reply_to_status_id" : 6081191896,
  "created_at" : "Fri Nov 27 00:21:57 +0000 2009",
  "in_reply_to_screen_name" : "StephanR78",
  "in_reply_to_user_id_str" : "25104719",
  "user" : {
    "name" : "Felix",
    "screen_name" : "nicidienase",
    "protected" : false,
    "id_str" : "22396883",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3125784966/8223a4c5c9535be22d15c82ec829c2df_normal.jpeg",
    "id" : 22396883,
    "verified" : false
  }
}, {
  "source" : "<a href=\"https://launchpad.net/gwibber/\" rel=\"nofollow\">Gwibber</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "KITbrennt",
      "indices" : [ 101, 111 ]
    }, {
      "text" : "KAbrennt",
      "indices" : [ 112, 121 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "6089448997",
  "text" : "@scdrka Niemand hat etwas von R\u00E4umung gesagt, Hippler will nur regul\u00E4ren Vorlesungsbetrieb ab Montag #KITbrennt #KAbrennt",
  "id" : 6089448997,
  "created_at" : "Thu Nov 26 18:58:04 +0000 2009",
  "user" : {
    "name" : "Felix",
    "screen_name" : "nicidienase",
    "protected" : false,
    "id_str" : "22396883",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3125784966/8223a4c5c9535be22d15c82ec829c2df_normal.jpeg",
    "id" : 22396883,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "KIT brennt",
      "screen_name" : "KITbrennt",
      "indices" : [ 3, 13 ],
      "id_str" : "91079620",
      "id" : 91079620
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "KAbrennt",
      "indices" : [ 113, 122 ]
    }, {
      "text" : "unsereuni",
      "indices" : [ 123, 133 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "6089337465",
  "text" : "RT @KITbrennt: Rektor Hippler stellt Ultimatum: Bis Montag soll der Vorlesungsbetrieb wieder regul\u00E4r stattfinden #KAbrennt #unsereuni",
  "retweeted_status" : {
    "source" : "web",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "KAbrennt",
        "indices" : [ 98, 107 ]
      }, {
        "text" : "unsereuni",
        "indices" : [ 108, 118 ]
      } ],
      "urls" : [ ]
    },
    "geo" : {
    },
    "id_str" : "6089298521",
    "text" : "Rektor Hippler stellt Ultimatum: Bis Montag soll der Vorlesungsbetrieb wieder regul\u00E4r stattfinden #KAbrennt #unsereuni",
    "id" : 6089298521,
    "created_at" : "Thu Nov 26 18:51:59 +0000 2009",
    "user" : {
      "name" : "KIT brennt",
      "screen_name" : "KITbrennt",
      "protected" : false,
      "id_str" : "91079620",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/533892180/KIT_Brennt__normal.png",
      "id" : 91079620,
      "verified" : false
    }
  },
  "id" : 6089337465,
  "created_at" : "Thu Nov 26 18:53:34 +0000 2009",
  "user" : {
    "name" : "Felix",
    "screen_name" : "nicidienase",
    "protected" : false,
    "id_str" : "22396883",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3125784966/8223a4c5c9535be22d15c82ec829c2df_normal.jpeg",
    "id" : 22396883,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Rudi Dutschke",
      "screen_name" : "dutschke_rudi",
      "indices" : [ 3, 17 ],
      "id_str" : "91354727",
      "id" : 91354727
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "kabrennt",
      "indices" : [ 73, 82 ]
    }, {
      "text" : "kitbrennt",
      "indices" : [ 83, 93 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "6089335632",
  "text" : "RT @dutschke_rudi: Prof. Hippler droht ab Montag mit R\u00E4umung des HMU/HMO #kabrennt #kitbrennt",
  "retweeted_status" : {
    "source" : "<a href=\"http://adium.im\" rel=\"nofollow\">Adium</a>",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "kabrennt",
        "indices" : [ 54, 63 ]
      }, {
        "text" : "kitbrennt",
        "indices" : [ 64, 74 ]
      } ],
      "urls" : [ ]
    },
    "geo" : {
    },
    "id_str" : "6089300035",
    "text" : "Prof. Hippler droht ab Montag mit R\u00E4umung des HMU/HMO #kabrennt #kitbrennt",
    "id" : 6089300035,
    "created_at" : "Thu Nov 26 18:52:03 +0000 2009",
    "user" : {
      "name" : "Rudi Dutschke",
      "screen_name" : "dutschke_rudi",
      "protected" : false,
      "id_str" : "91354727",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/535621942/images_normal.jpeg",
      "id" : 91354727,
      "verified" : false
    }
  },
  "id" : 6089335632,
  "created_at" : "Thu Nov 26 18:53:29 +0000 2009",
  "user" : {
    "name" : "Felix",
    "screen_name" : "nicidienase",
    "protected" : false,
    "id_str" : "22396883",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3125784966/8223a4c5c9535be22d15c82ec829c2df_normal.jpeg",
    "id" : 22396883,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://pivotallabs.com/landing/tweed\" rel=\"nofollow\">Tweed</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "KAbrennt",
      "indices" : [ 72, 81 ]
    }, {
      "text" : "KITbrennt",
      "indices" : [ 82, 92 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "6089310021",
  "text" : "Hippler stellt Ultimatum. Ab Montag wieder regul\u00E4rer Vorlesungsbetrieb. #KAbrennt #KITbrennt",
  "id" : 6089310021,
  "created_at" : "Thu Nov 26 18:52:27 +0000 2009",
  "user" : {
    "name" : "Felix",
    "screen_name" : "nicidienase",
    "protected" : false,
    "id_str" : "22396883",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3125784966/8223a4c5c9535be22d15c82ec829c2df_normal.jpeg",
    "id" : 22396883,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Rudi Dutschke",
      "screen_name" : "dutschke_rudi",
      "indices" : [ 3, 17 ],
      "id_str" : "91354727",
      "id" : 91354727
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "kabren",
      "indices" : [ 129, 136 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "6089259158",
  "text" : "RT @dutschke_rudi: Prof. Hippler spricht, wer nicht da ist jetzt ab in den live-stream: http://www.ustream.tv/channel/kitbrennt2 #kabren ...",
  "retweeted_status" : {
    "source" : "<a href=\"http://adium.im\" rel=\"nofollow\">Adium</a>",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "kabrennt",
        "indices" : [ 110, 119 ]
      }, {
        "text" : "kitbrennt",
        "indices" : [ 120, 130 ]
      } ],
      "urls" : [ ]
    },
    "geo" : {
    },
    "id_str" : "6089226394",
    "text" : "Prof. Hippler spricht, wer nicht da ist jetzt ab in den live-stream: http://www.ustream.tv/channel/kitbrennt2 #kabrennt #kitbrennt",
    "id" : 6089226394,
    "created_at" : "Thu Nov 26 18:49:05 +0000 2009",
    "user" : {
      "name" : "Rudi Dutschke",
      "screen_name" : "dutschke_rudi",
      "protected" : false,
      "id_str" : "91354727",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/535621942/images_normal.jpeg",
      "id" : 91354727,
      "verified" : false
    }
  },
  "id" : 6089259158,
  "created_at" : "Thu Nov 26 18:50:24 +0000 2009",
  "user" : {
    "name" : "Felix",
    "screen_name" : "nicidienase",
    "protected" : false,
    "id_str" : "22396883",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3125784966/8223a4c5c9535be22d15c82ec829c2df_normal.jpeg",
    "id" : 22396883,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "KIT brennt",
      "screen_name" : "KITbrennt",
      "indices" : [ 3, 13 ],
      "id_str" : "91079620",
      "id" : 91079620
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "6089254501",
  "text" : "RT @KITbrennt: Die Vorhut Prorektor Becker und Rektor Hippler haben soeben den HMU betreten. Sind anscheinend \u00FCberrascht von der Mensche ...",
  "retweeted_status" : {
    "source" : "web",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "KAbrennt",
        "indices" : [ 128, 137 ]
      } ],
      "urls" : [ ]
    },
    "geo" : {
    },
    "id_str" : "6089044851",
    "text" : "Die Vorhut Prorektor Becker und Rektor Hippler haben soeben den HMU betreten. Sind anscheinend \u00FCberrascht von der Menschenmasse #KAbrennt",
    "id" : 6089044851,
    "created_at" : "Thu Nov 26 18:41:54 +0000 2009",
    "user" : {
      "name" : "KIT brennt",
      "screen_name" : "KITbrennt",
      "protected" : false,
      "id_str" : "91079620",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/533892180/KIT_Brennt__normal.png",
      "id" : 91079620,
      "verified" : false
    }
  },
  "id" : 6089254501,
  "created_at" : "Thu Nov 26 18:50:13 +0000 2009",
  "user" : {
    "name" : "Felix",
    "screen_name" : "nicidienase",
    "protected" : false,
    "id_str" : "22396883",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3125784966/8223a4c5c9535be22d15c82ec829c2df_normal.jpeg",
    "id" : 22396883,
    "verified" : false
  }
}, {
  "source" : "<a href=\"https://launchpad.net/gwibber/\" rel=\"nofollow\">Gwibber</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "KITbrennt",
      "indices" : [ 56, 66 ]
    }, {
      "text" : "KAbrennt",
      "indices" : [ 67, 76 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "6087251682",
  "text" : "Heute gibts wohl nur den Videostream http://is.gd/54a0t #KITbrennt #KAbrennt",
  "id" : 6087251682,
  "created_at" : "Thu Nov 26 17:31:37 +0000 2009",
  "user" : {
    "name" : "Felix",
    "screen_name" : "nicidienase",
    "protected" : false,
    "id_str" : "22396883",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3125784966/8223a4c5c9535be22d15c82ec829c2df_normal.jpeg",
    "id" : 22396883,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://pivotallabs.com/landing/tweed\" rel=\"nofollow\">Tweed</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "KITbrennt",
      "indices" : [ 77, 87 ]
    }, {
      "text" : "KAbrennt",
      "indices" : [ 88, 97 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "6086512142",
  "text" : "HMU deutlich voller als gestern. Bestimmt 400 Leute. Plenum f\u00E4ngt gleich an. #KITbrennt #KAbrennt",
  "id" : 6086512142,
  "created_at" : "Thu Nov 26 17:04:02 +0000 2009",
  "user" : {
    "name" : "Felix",
    "screen_name" : "nicidienase",
    "protected" : false,
    "id_str" : "22396883",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3125784966/8223a4c5c9535be22d15c82ec829c2df_normal.jpeg",
    "id" : 22396883,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://pivotallabs.com/landing/tweed\" rel=\"nofollow\">Tweed</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "bundestag",
      "indices" : [ 129, 139 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "6081295890",
  "text" : "In welcher Welt lebt dieser Ruprecht eigentlich. \"Soziales Bildungssystem in Deutschland\", der Mann hat nen interessanten Humor. #bundestag",
  "id" : 6081295890,
  "created_at" : "Thu Nov 26 13:36:04 +0000 2009",
  "user" : {
    "name" : "Felix",
    "screen_name" : "nicidienase",
    "protected" : false,
    "id_str" : "22396883",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3125784966/8223a4c5c9535be22d15c82ec829c2df_normal.jpeg",
    "id" : 22396883,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://pivotallabs.com/landing/tweed\" rel=\"nofollow\">Tweed</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "KIT brennt",
      "screen_name" : "KITbrennt",
      "indices" : [ 3, 13 ],
      "id_str" : "91079620",
      "id" : 91079620
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "KITbrennt",
      "indices" : [ 116, 126 ]
    }, {
      "text" : "KAbrennt",
      "indices" : [ 127, 136 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "6080389832",
  "text" : "RT @KITbrennt: Aktuelle Stunde im Bundestag zum Thema \"Bildung f\u00FCr alle - Geb\u00FChrenfrei\" Livestream auf Bundestag.de #KITbrennt #KAbrennt",
  "id" : 6080389832,
  "created_at" : "Thu Nov 26 12:50:19 +0000 2009",
  "user" : {
    "name" : "Felix",
    "screen_name" : "nicidienase",
    "protected" : false,
    "id_str" : "22396883",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3125784966/8223a4c5c9535be22d15c82ec829c2df_normal.jpeg",
    "id" : 22396883,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://pivotallabs.com/landing/tweed\" rel=\"nofollow\">Tweed</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Antonia I.",
      "screen_name" : "soophie",
      "indices" : [ 0, 8 ],
      "id_str" : "14309904",
      "id" : 14309904
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "6079641545",
  "geo" : {
  },
  "id_str" : "6079902940",
  "in_reply_to_user_id" : 14309904,
  "text" : "@soophie thx",
  "id" : 6079902940,
  "in_reply_to_status_id" : 6079641545,
  "created_at" : "Thu Nov 26 12:23:34 +0000 2009",
  "in_reply_to_screen_name" : "soophie",
  "in_reply_to_user_id_str" : "14309904",
  "user" : {
    "name" : "Felix",
    "screen_name" : "nicidienase",
    "protected" : false,
    "id_str" : "22396883",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3125784966/8223a4c5c9535be22d15c82ec829c2df_normal.jpeg",
    "id" : 22396883,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://pivotallabs.com/landing/tweed\" rel=\"nofollow\">Tweed</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Erik Wismeijer",
      "screen_name" : "Wish78",
      "indices" : [ 0, 7 ],
      "id_str" : "164622698",
      "id" : 164622698
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "6079633711",
  "in_reply_to_user_id" : 25104719,
  "text" : "@Wish78 Wenn du noch ne Wave-Invite \u00FCbrig hast, ich h\u00E4tte auch gerne eine. nicidienase@googlemail.com",
  "id" : 6079633711,
  "created_at" : "Thu Nov 26 12:07:44 +0000 2009",
  "in_reply_to_screen_name" : "StephanR78",
  "in_reply_to_user_id_str" : "25104719",
  "user" : {
    "name" : "Felix",
    "screen_name" : "nicidienase",
    "protected" : false,
    "id_str" : "22396883",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3125784966/8223a4c5c9535be22d15c82ec829c2df_normal.jpeg",
    "id" : 22396883,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://pivotallabs.com/landing/tweed\" rel=\"nofollow\">Tweed</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Antonia I.",
      "screen_name" : "soophie",
      "indices" : [ 0, 8 ],
      "id_str" : "14309904",
      "id" : 14309904
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "6079620221",
  "in_reply_to_user_id" : 14309904,
  "text" : "@soophie: Wenn du noch ne Wave-Invite \u00FCbrig hast, ich h\u00E4tte auch gerne eine. nicidienase@googlemail.com",
  "id" : 6079620221,
  "created_at" : "Thu Nov 26 12:06:55 +0000 2009",
  "in_reply_to_screen_name" : "soophie",
  "in_reply_to_user_id_str" : "14309904",
  "user" : {
    "name" : "Felix",
    "screen_name" : "nicidienase",
    "protected" : false,
    "id_str" : "22396883",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3125784966/8223a4c5c9535be22d15c82ec829c2df_normal.jpeg",
    "id" : 22396883,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://pivotallabs.com/landing/tweed\" rel=\"nofollow\">Tweed</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "KITbrennt",
      "indices" : [ 51, 61 ]
    }, {
      "text" : "KAbrennt",
      "indices" : [ 62, 71 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "6055296306",
  "text" : "Plenum hat begonnen, leider etwas wenig los heute. #KITbrennt #KAbrennt",
  "id" : 6055296306,
  "created_at" : "Wed Nov 25 17:19:09 +0000 2009",
  "user" : {
    "name" : "Felix",
    "screen_name" : "nicidienase",
    "protected" : false,
    "id_str" : "22396883",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3125784966/8223a4c5c9535be22d15c82ec829c2df_normal.jpeg",
    "id" : 22396883,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://pivotallabs.com/landing/tweed\" rel=\"nofollow\">Tweed</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "stefan",
      "screen_name" : "stefan005",
      "indices" : [ 24, 34 ],
      "id_str" : "49648872",
      "id" : 49648872
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "6007855686",
  "text" : "Ich will auch eine!! RT @stefan005: jawoll ich hab ne google wave einladung:-)",
  "id" : 6007855686,
  "created_at" : "Tue Nov 24 13:36:31 +0000 2009",
  "user" : {
    "name" : "Felix",
    "screen_name" : "nicidienase",
    "protected" : false,
    "id_str" : "22396883",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3125784966/8223a4c5c9535be22d15c82ec829c2df_normal.jpeg",
    "id" : 22396883,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://pivotallabs.com/landing/tweed\" rel=\"nofollow\">Tweed</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "KIT brennt",
      "screen_name" : "KITbrennt",
      "indices" : [ 3, 13 ],
      "id_str" : "91079620",
      "id" : 91079620
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "KAbrennt",
      "indices" : [ 130, 139 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "6007839750",
  "text" : "RT @KITbrennt: kleiner Geburtstag! HMU/HMO seit einer Woche erfolgreich besetzt. Dazu um 15:00 Uhr ein R\u00FCckblick der ersten Woche #KAbrennt",
  "id" : 6007839750,
  "created_at" : "Tue Nov 24 13:35:48 +0000 2009",
  "user" : {
    "name" : "Felix",
    "screen_name" : "nicidienase",
    "protected" : false,
    "id_str" : "22396883",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3125784966/8223a4c5c9535be22d15c82ec829c2df_normal.jpeg",
    "id" : 22396883,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://pivotallabs.com/landing/tweed\" rel=\"nofollow\">Tweed</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Piratenpartei",
      "screen_name" : "Piratenpartei",
      "indices" : [ 3, 17 ],
      "id_str" : "14341194",
      "id" : 14341194
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "5995098830",
  "text" : "RT @Piratenpartei: Chuck Norris ... http://is.gd/52dSW",
  "id" : 5995098830,
  "created_at" : "Tue Nov 24 01:52:59 +0000 2009",
  "user" : {
    "name" : "Felix",
    "screen_name" : "nicidienase",
    "protected" : false,
    "id_str" : "22396883",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3125784966/8223a4c5c9535be22d15c82ec829c2df_normal.jpeg",
    "id" : 22396883,
    "verified" : false
  }
}, {
  "source" : "<a href=\"https://launchpad.net/gwibber/\" rel=\"nofollow\">Gwibber</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "robinro",
      "screen_name" : "robinro",
      "indices" : [ 0, 8 ],
      "id_str" : "14897479",
      "id" : 14897479
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "5990320104",
  "in_reply_to_user_id" : 14897479,
  "text" : "@robinro Das sind ja fast mehr Viewer im Stream als noch Leute im HS sitzen.",
  "id" : 5990320104,
  "created_at" : "Mon Nov 23 22:51:24 +0000 2009",
  "in_reply_to_screen_name" : "robinro",
  "in_reply_to_user_id_str" : "14897479",
  "user" : {
    "name" : "Felix",
    "screen_name" : "nicidienase",
    "protected" : false,
    "id_str" : "22396883",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3125784966/8223a4c5c9535be22d15c82ec829c2df_normal.jpeg",
    "id" : 22396883,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://pivotallabs.com/landing/tweed\" rel=\"nofollow\">Tweed</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "KITbrennt",
      "indices" : [ 84, 94 ]
    }, {
      "text" : "KAbrennt",
      "indices" : [ 95, 104 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "5989873595",
  "text" : "Plenum tagt jetzt schon \u00FCber 6h. Bin mal gespannt ob wir noch vor 12 fertig werden. #KITbrennt #KAbrennt",
  "id" : 5989873595,
  "created_at" : "Mon Nov 23 22:34:54 +0000 2009",
  "user" : {
    "name" : "Felix",
    "screen_name" : "nicidienase",
    "protected" : false,
    "id_str" : "22396883",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3125784966/8223a4c5c9535be22d15c82ec829c2df_normal.jpeg",
    "id" : 22396883,
    "verified" : false
  }
}, {
  "source" : "<a href=\"https://launchpad.net/gwibber/\" rel=\"nofollow\">Gwibber</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "punycode",
      "screen_name" : "punycode",
      "indices" : [ 0, 9 ],
      "id_str" : "14328131",
      "id" : 14328131
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "5978909781",
  "in_reply_to_user_id" : 14328131,
  "text" : "@punycode try the office in HMO (Tel: 0721-608 - 19164) bildungsstreik.ka@googlemail.com",
  "id" : 5978909781,
  "created_at" : "Mon Nov 23 15:25:31 +0000 2009",
  "in_reply_to_screen_name" : "punycode",
  "in_reply_to_user_id_str" : "14328131",
  "user" : {
    "name" : "Felix",
    "screen_name" : "nicidienase",
    "protected" : false,
    "id_str" : "22396883",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3125784966/8223a4c5c9535be22d15c82ec829c2df_normal.jpeg",
    "id" : 22396883,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://pivotallabs.com/landing/tweed\" rel=\"nofollow\">Tweed</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "WebOS",
      "indices" : [ 21, 27 ]
    }, {
      "text" : "Update",
      "indices" : [ 28, 35 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "5972289265",
  "text" : "Yeah, endlich is das #WebOS #Update auf #1.3.1 da.",
  "id" : 5972289265,
  "created_at" : "Mon Nov 23 09:23:06 +0000 2009",
  "user" : {
    "name" : "Felix",
    "screen_name" : "nicidienase",
    "protected" : false,
    "id_str" : "22396883",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3125784966/8223a4c5c9535be22d15c82ec829c2df_normal.jpeg",
    "id" : 22396883,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://pivotallabs.com/landing/tweed\" rel=\"nofollow\">Tweed</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "kitbrennt",
      "indices" : [ 88, 98 ]
    }, {
      "text" : "kabrennt",
      "indices" : [ 99, 108 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "5960348389",
  "text" : "Kaum noch jemand wach im HMO. Ich glaube ich geselle mich auch bald zu den schlafenden. #kitbrennt #kabrennt",
  "id" : 5960348389,
  "created_at" : "Mon Nov 23 00:20:22 +0000 2009",
  "user" : {
    "name" : "Felix",
    "screen_name" : "nicidienase",
    "protected" : false,
    "id_str" : "22396883",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3125784966/8223a4c5c9535be22d15c82ec829c2df_normal.jpeg",
    "id" : 22396883,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://pivotallabs.com/landing/tweed\" rel=\"nofollow\">Tweed</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Piratenpartei",
      "screen_name" : "Piratenpartei",
      "indices" : [ 3, 17 ],
      "id_str" : "14341194",
      "id" : 14341194
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "5959590668",
  "text" : "RT @Piratenpartei: Anti-Terror-Einheit sprengt falsch geparktes Auto: http://tinyurl.com/ybt96so",
  "id" : 5959590668,
  "created_at" : "Sun Nov 22 23:49:30 +0000 2009",
  "user" : {
    "name" : "Felix",
    "screen_name" : "nicidienase",
    "protected" : false,
    "id_str" : "22396883",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3125784966/8223a4c5c9535be22d15c82ec829c2df_normal.jpeg",
    "id" : 22396883,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://pivotallabs.com/landing/tweed\" rel=\"nofollow\">Tweed</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "KIT brennt",
      "screen_name" : "KITbrennt",
      "indices" : [ 3, 13 ],
      "id_str" : "91079620",
      "id" : 91079620
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "kitbrennt",
      "indices" : [ 129, 139 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "5950743096",
  "text" : "RT @KITbrennt: Rektor Hippler spricht sich gegen eine Zwangsr\u00E4umung aus und m\u00F6chte die Probleme zusammen mit den Studenten l\u00F6sen #kitbrennt",
  "id" : 5950743096,
  "created_at" : "Sun Nov 22 17:45:53 +0000 2009",
  "user" : {
    "name" : "Felix",
    "screen_name" : "nicidienase",
    "protected" : false,
    "id_str" : "22396883",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3125784966/8223a4c5c9535be22d15c82ec829c2df_normal.jpeg",
    "id" : 22396883,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://pivotallabs.com/landing/tweed\" rel=\"nofollow\">Tweed</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "stefan",
      "screen_name" : "stefan005",
      "indices" : [ 52, 62 ],
      "id_str" : "49648872",
      "id" : 49648872
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "google",
      "indices" : [ 80, 87 ]
    }, {
      "text" : "wave",
      "indices" : [ 88, 93 ]
    }, {
      "text" : "Einladung",
      "indices" : [ 94, 104 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "5946856771",
  "text" : "H\u00E4tte auch gerne eine nicidienase (\u00E4t) gmail.com RT @stefan005: Wartet auf eine #google #wave #Einladung :) :: stefan.kraus05(at)gmail.com",
  "id" : 5946856771,
  "created_at" : "Sun Nov 22 14:39:11 +0000 2009",
  "user" : {
    "name" : "Felix",
    "screen_name" : "nicidienase",
    "protected" : false,
    "id_str" : "22396883",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3125784966/8223a4c5c9535be22d15c82ec829c2df_normal.jpeg",
    "id" : 22396883,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "ichmachPolitik.at",
      "screen_name" : "ichmachpolitik",
      "indices" : [ 3, 18 ],
      "id_str" : "29987799",
      "id" : 29987799
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "unibrennt",
      "indices" : [ 107, 117 ]
    }, {
      "text" : "unsereuni",
      "indices" : [ 118, 128 ]
    }, {
      "text" : "bildun",
      "indices" : [ 129, 136 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "5899113367",
  "text" : "RT @ichmachpolitik: Live: Soli-Demo DE Botschaft Wien gegen Polizeigewalt gegen Studis. http://is.gd/4ZS9z #unibrennt #unsereuni #bildun ...",
  "retweeted_status" : {
    "source" : "web",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "unibrennt",
        "indices" : [ 87, 97 ]
      }, {
        "text" : "unsereuni",
        "indices" : [ 98, 108 ]
      }, {
        "text" : "bildungsstreik",
        "indices" : [ 109, 124 ]
      } ],
      "urls" : [ ]
    },
    "geo" : {
    },
    "id_str" : "5899052961",
    "text" : "Live: Soli-Demo DE Botschaft Wien gegen Polizeigewalt gegen Studis. http://is.gd/4ZS9z #unibrennt #unsereuni #bildungsstreik",
    "id" : 5899052961,
    "created_at" : "Fri Nov 20 20:10:57 +0000 2009",
    "user" : {
      "name" : "ichmachPolitik",
      "screen_name" : "ichmachepolitik",
      "protected" : false,
      "id_str" : "71516670",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/398417889/iStock_000002640222XSmall_normal.jpg",
      "id" : 71516670,
      "verified" : false
    }
  },
  "id" : 5899113367,
  "created_at" : "Fri Nov 20 20:13:27 +0000 2009",
  "user" : {
    "name" : "Felix",
    "screen_name" : "nicidienase",
    "protected" : false,
    "id_str" : "22396883",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3125784966/8223a4c5c9535be22d15c82ec829c2df_normal.jpeg",
    "id" : 22396883,
    "verified" : false
  }
}, {
  "source" : "<a href=\"https://launchpad.net/gwibber/\" rel=\"nofollow\">Gwibber</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "KITbrennt",
      "indices" : [ 87, 97 ]
    }, {
      "text" : "UNIbrennt",
      "indices" : [ 98, 108 ]
    }, {
      "text" : "Freiburgbrennt",
      "indices" : [ 109, 124 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "5898582500",
  "text" : "Besetzeraustausch Karlsruhe-Freiburg wird gerade per Skype-Konferenz ins Leben gerufen #KITbrennt #UNIbrennt #Freiburgbrennt",
  "id" : 5898582500,
  "created_at" : "Fri Nov 20 19:51:26 +0000 2009",
  "user" : {
    "name" : "Felix",
    "screen_name" : "nicidienase",
    "protected" : false,
    "id_str" : "22396883",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3125784966/8223a4c5c9535be22d15c82ec829c2df_normal.jpeg",
    "id" : 22396883,
    "verified" : false
  }
}, {
  "source" : "<a href=\"https://launchpad.net/gwibber/\" rel=\"nofollow\">Gwibber</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "liveschalte",
      "indices" : [ 48, 60 ]
    }, {
      "text" : "KAbrennt",
      "indices" : [ 61, 70 ]
    }, {
      "text" : "UNIbrennt",
      "indices" : [ 71, 81 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "5898476416",
  "text" : "Stimmung in KA definitiv besser als in Freiburg #liveschalte #KAbrennt #UNIbrennt",
  "id" : 5898476416,
  "created_at" : "Fri Nov 20 19:46:59 +0000 2009",
  "user" : {
    "name" : "Felix",
    "screen_name" : "nicidienase",
    "protected" : false,
    "id_str" : "22396883",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3125784966/8223a4c5c9535be22d15c82ec829c2df_normal.jpeg",
    "id" : 22396883,
    "verified" : false
  }
}, {
  "source" : "<a href=\"https://launchpad.net/gwibber/\" rel=\"nofollow\">Gwibber</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "kabrennt",
      "indices" : [ 45, 54 ]
    }, {
      "text" : "kitbrennt",
      "indices" : [ 55, 65 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "5898388218",
  "text" : "Liveschalte nach Freiburg ein bisschen buggy #kabrennt #kitbrennt",
  "id" : 5898388218,
  "created_at" : "Fri Nov 20 19:43:18 +0000 2009",
  "user" : {
    "name" : "Felix",
    "screen_name" : "nicidienase",
    "protected" : false,
    "id_str" : "22396883",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3125784966/8223a4c5c9535be22d15c82ec829c2df_normal.jpeg",
    "id" : 22396883,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "KITbrennt",
      "indices" : [ 79, 89 ]
    }, {
      "text" : "KAbrennt",
      "indices" : [ 90, 99 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "5898071262",
  "text" : "Ba/Ma Debatte findet am Mo ohne Begrenzung der Diskussionszeit ab 17 Uhr statt #KITbrennt #KAbrennt",
  "id" : 5898071262,
  "created_at" : "Fri Nov 20 19:30:15 +0000 2009",
  "user" : {
    "name" : "Felix",
    "screen_name" : "nicidienase",
    "protected" : false,
    "id_str" : "22396883",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3125784966/8223a4c5c9535be22d15c82ec829c2df_normal.jpeg",
    "id" : 22396883,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "KIT brennt",
      "screen_name" : "KITbrennt",
      "indices" : [ 3, 13 ],
      "id_str" : "91079620",
      "id" : 91079620
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "kitbrennt",
      "indices" : [ 68, 78 ]
    }, {
      "text" : "kabrennt",
      "indices" : [ 79, 88 ]
    }, {
      "text" : "unibrennt",
      "indices" : [ 89, 99 ]
    }, {
      "text" : "bildungsstreik",
      "indices" : [ 100, 115 ]
    }, {
      "text" : "unsereuni",
      "indices" : [ 116, 126 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "5897074781",
  "text" : "RT @KITbrennt: Bitte unsere Telefonnummer retweeten: 0721-698-19164 #kitbrennt #kabrennt #unibrennt #bildungsstreik #unsereuni",
  "retweeted_status" : {
    "source" : "web",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "kitbrennt",
        "indices" : [ 53, 63 ]
      }, {
        "text" : "kabrennt",
        "indices" : [ 64, 73 ]
      }, {
        "text" : "unibrennt",
        "indices" : [ 74, 84 ]
      }, {
        "text" : "bildungsstreik",
        "indices" : [ 85, 100 ]
      }, {
        "text" : "unsereuni",
        "indices" : [ 101, 111 ]
      } ],
      "urls" : [ ]
    },
    "geo" : {
    },
    "id_str" : "5896949545",
    "text" : "Bitte unsere Telefonnummer retweeten: 0721-698-19164 #kitbrennt #kabrennt #unibrennt #bildungsstreik #unsereuni",
    "id" : 5896949545,
    "created_at" : "Fri Nov 20 18:44:09 +0000 2009",
    "user" : {
      "name" : "KIT brennt",
      "screen_name" : "KITbrennt",
      "protected" : false,
      "id_str" : "91079620",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/533892180/KIT_Brennt__normal.png",
      "id" : 91079620,
      "verified" : false
    }
  },
  "id" : 5897074781,
  "created_at" : "Fri Nov 20 18:49:15 +0000 2009",
  "user" : {
    "name" : "Felix",
    "screen_name" : "nicidienase",
    "protected" : false,
    "id_str" : "22396883",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3125784966/8223a4c5c9535be22d15c82ec829c2df_normal.jpeg",
    "id" : 22396883,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://pivotallabs.com/landing/tweed\" rel=\"nofollow\">Tweed</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "kitbrennt",
      "indices" : [ 61, 71 ]
    }, {
      "text" : "kabrennt",
      "indices" : [ 72, 81 ]
    }, {
      "text" : "unibrennt",
      "indices" : [ 82, 92 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "5893522529",
  "text" : "Das B\u00FCro im HMO hat jetzt einen sch\u00F6nen gro\u00DFen Schreibtisch. #kitbrennt #kabrennt #unibrennt",
  "id" : 5893522529,
  "created_at" : "Fri Nov 20 16:30:21 +0000 2009",
  "user" : {
    "name" : "Felix",
    "screen_name" : "nicidienase",
    "protected" : false,
    "id_str" : "22396883",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3125784966/8223a4c5c9535be22d15c82ec829c2df_normal.jpeg",
    "id" : 22396883,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "5890252034",
  "text" : "@scdrka ... weil die Dozenten absolut unflexibel waren. Ansonsten hatten wir bisher f\u00FCr jede Vorlesung einen ad\u00E4quaten Ersatz-H\u00F6rsaal.",
  "id" : 5890252034,
  "created_at" : "Fri Nov 20 14:27:09 +0000 2009",
  "user" : {
    "name" : "Felix",
    "screen_name" : "nicidienase",
    "protected" : false,
    "id_str" : "22396883",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3125784966/8223a4c5c9535be22d15c82ec829c2df_normal.jpeg",
    "id" : 22396883,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "5890223924",
  "text" : "@scdrka Wir bem\u00FChen uns f\u00FCr alle Vorlesungen einen Ersatz-H\u00F6rsaal zu finden,hat auch immer geklappt bisher. Wenn eine Vorl. ausfiel dann...",
  "id" : 5890223924,
  "created_at" : "Fri Nov 20 14:26:06 +0000 2009",
  "user" : {
    "name" : "Felix",
    "screen_name" : "nicidienase",
    "protected" : false,
    "id_str" : "22396883",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3125784966/8223a4c5c9535be22d15c82ec829c2df_normal.jpeg",
    "id" : 22396883,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://pivotallabs.com/landing/tweed\" rel=\"nofollow\">Tweed</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "KAbrennt",
      "indices" : [ 124, 133 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "5889638535",
  "text" : "@scdrka Es wurde von uns ein ad\u00E4quater Ersatzh\u00F6rsaal organisiert, welcher leider vom betreffenden Dozenten abgelehnt wurde. #KAbrennt",
  "id" : 5889638535,
  "created_at" : "Fri Nov 20 14:04:29 +0000 2009",
  "user" : {
    "name" : "Felix",
    "screen_name" : "nicidienase",
    "protected" : false,
    "id_str" : "22396883",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3125784966/8223a4c5c9535be22d15c82ec829c2df_normal.jpeg",
    "id" : 22396883,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitpic.com/\" rel=\"nofollow\">TwitPic</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "kitbrennt",
      "indices" : [ 45, 55 ]
    }, {
      "text" : "kabrennt",
      "indices" : [ 56, 65 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "5888368391",
  "text" : "http://twitpic.com/q80tn - Diskussion um HMO #kitbrennt #kabrennt",
  "id" : 5888368391,
  "created_at" : "Fri Nov 20 13:08:05 +0000 2009",
  "user" : {
    "name" : "Felix",
    "screen_name" : "nicidienase",
    "protected" : false,
    "id_str" : "22396883",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3125784966/8223a4c5c9535be22d15c82ec829c2df_normal.jpeg",
    "id" : 22396883,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://pivotallabs.com/landing/tweed\" rel=\"nofollow\">Tweed</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "kitbrennt",
      "indices" : [ 108, 118 ]
    }, {
      "text" : "kabrennt",
      "indices" : [ 119, 128 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "5888238283",
  "text" : "Im HMO wird gerade diskutiert ob vielleicht doch TM-\u00DCbung statt finden soll. ENTGEGEN DEM PLENUMSBESCHLUSS. #kitbrennt #kabrennt",
  "id" : 5888238283,
  "created_at" : "Fri Nov 20 13:02:07 +0000 2009",
  "user" : {
    "name" : "Felix",
    "screen_name" : "nicidienase",
    "protected" : false,
    "id_str" : "22396883",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3125784966/8223a4c5c9535be22d15c82ec829c2df_normal.jpeg",
    "id" : 22396883,
    "verified" : false
  }
}, {
  "source" : "<a href=\"https://launchpad.net/gwibber/\" rel=\"nofollow\">Gwibber</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Bildungsstreik K\u00F6ln",
      "screen_name" : "koelnbrennt",
      "indices" : [ 10, 22 ],
      "id_str" : "90485030",
      "id" : 90485030
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "unibrennt",
      "indices" : [ 57, 67 ]
    }, {
      "text" : "bildungsstreik",
      "indices" : [ 68, 83 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "5883180553",
  "text" : "Uni K\u00F6ln (@koelnbrennt) wird ger\u00E4umt! http://is.gd/4Zp8O #unibrennt #bildungsstreik",
  "id" : 5883180553,
  "created_at" : "Fri Nov 20 07:20:51 +0000 2009",
  "user" : {
    "name" : "Felix",
    "screen_name" : "nicidienase",
    "protected" : false,
    "id_str" : "22396883",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3125784966/8223a4c5c9535be22d15c82ec829c2df_normal.jpeg",
    "id" : 22396883,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://pivotallabs.com/landing/tweed\" rel=\"nofollow\">Tweed</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "KAbrennt",
      "indices" : [ 73, 82 ]
    }, {
      "text" : "KITbrennt",
      "indices" : [ 83, 93 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "5882626278",
  "text" : "Auf in den HMU, in 15min beginnt der Vortrag \u00FCber \"One Laptop per Child\" #KAbrennt #KITbrennt",
  "id" : 5882626278,
  "created_at" : "Fri Nov 20 06:42:52 +0000 2009",
  "user" : {
    "name" : "Felix",
    "screen_name" : "nicidienase",
    "protected" : false,
    "id_str" : "22396883",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3125784966/8223a4c5c9535be22d15c82ec829c2df_normal.jpeg",
    "id" : 22396883,
    "verified" : false
  }
}, {
  "source" : "<a href=\"https://launchpad.net/gwibber/\" rel=\"nofollow\">Gwibber</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Florian Spitzohr",
      "screen_name" : "spitzohr",
      "indices" : [ 3, 12 ],
      "id_str" : "17292603",
      "id" : 17292603
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "polizeigewalt",
      "indices" : [ 108, 122 ]
    }, {
      "text" : "unibrennt",
      "indices" : [ 123, 133 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "5872238932",
  "text" : "RT @spitzohr: Polizei-Irrsinn: Junge wird bei Demo wegen Shirt verhaftet: http://weltkritiker.blogspot.com/ #polizeigewalt #unibrennt",
  "id" : 5872238932,
  "created_at" : "Thu Nov 19 23:16:10 +0000 2009",
  "user" : {
    "name" : "Felix",
    "screen_name" : "nicidienase",
    "protected" : false,
    "id_str" : "22396883",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3125784966/8223a4c5c9535be22d15c82ec829c2df_normal.jpeg",
    "id" : 22396883,
    "verified" : false
  }
}, {
  "source" : "<a href=\"https://launchpad.net/gwibber/\" rel=\"nofollow\">Gwibber</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dsch\u00E4ikop",
      "screen_name" : "jakob_bl",
      "indices" : [ 0, 9 ],
      "id_str" : "75007992",
      "id" : 75007992
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "5872169084",
  "in_reply_to_user_id" : 75007992,
  "text" : "@jakob_bl Laut http://is.gd/4Zaq6 insgesammt 83 Hochschulen",
  "id" : 5872169084,
  "created_at" : "Thu Nov 19 23:13:34 +0000 2009",
  "in_reply_to_screen_name" : "jakob_bl",
  "in_reply_to_user_id_str" : "75007992",
  "user" : {
    "name" : "Felix",
    "screen_name" : "nicidienase",
    "protected" : false,
    "id_str" : "22396883",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3125784966/8223a4c5c9535be22d15c82ec829c2df_normal.jpeg",
    "id" : 22396883,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitpic.com/\" rel=\"nofollow\">TwitPic</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "KAbrennt",
      "indices" : [ 49, 58 ]
    }, {
      "text" : "KITbrennt",
      "indices" : [ 59, 69 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "5869174614",
  "text" : "http://twitpic.com/q5760 - Schmitz' Katze im HMU #KAbrennt #KITbrennt",
  "id" : 5869174614,
  "created_at" : "Thu Nov 19 21:21:31 +0000 2009",
  "user" : {
    "name" : "Felix",
    "screen_name" : "nicidienase",
    "protected" : false,
    "id_str" : "22396883",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3125784966/8223a4c5c9535be22d15c82ec829c2df_normal.jpeg",
    "id" : 22396883,
    "verified" : false
  }
}, {
  "source" : "<a href=\"https://launchpad.net/gwibber/\" rel=\"nofollow\">Gwibber</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "KAbrennt",
      "indices" : [ 109, 118 ]
    }, {
      "text" : "KITbrennt",
      "indices" : [ 119, 129 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "5867371338",
  "text" : "So, Plenum offiziell beendet, jetzt treffen sich noch verschiedene AKs und gleich spielt noch Schmitz' Katze #KAbrennt #KITbrennt",
  "id" : 5867371338,
  "created_at" : "Thu Nov 19 20:11:58 +0000 2009",
  "user" : {
    "name" : "Felix",
    "screen_name" : "nicidienase",
    "protected" : false,
    "id_str" : "22396883",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3125784966/8223a4c5c9535be22d15c82ec829c2df_normal.jpeg",
    "id" : 22396883,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitpic.com/\" rel=\"nofollow\">TwitPic</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "KITbrennt",
      "indices" : [ 77, 87 ]
    }, {
      "text" : "KAbre",
      "indices" : [ 88, 94 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "5866379316",
  "text" : "http://twitpic.com/q4rbe - Die gesammelten Probleme mit dem BA/Master-System #KITbrennt #KAbre nnt",
  "id" : 5866379316,
  "created_at" : "Thu Nov 19 19:33:12 +0000 2009",
  "user" : {
    "name" : "Felix",
    "screen_name" : "nicidienase",
    "protected" : false,
    "id_str" : "22396883",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3125784966/8223a4c5c9535be22d15c82ec829c2df_normal.jpeg",
    "id" : 22396883,
    "verified" : false
  }
}, {
  "source" : "<a href=\"https://launchpad.net/gwibber/\" rel=\"nofollow\">Gwibber</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "KAbrennt",
      "indices" : [ 39, 48 ]
    }, {
      "text" : "KITbrennt",
      "indices" : [ 49, 59 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "5865291788",
  "text" : "Plenum findet auch am Sa und So statt! #KAbrennt #KITbrennt",
  "id" : 5865291788,
  "created_at" : "Thu Nov 19 18:50:54 +0000 2009",
  "user" : {
    "name" : "Felix",
    "screen_name" : "nicidienase",
    "protected" : false,
    "id_str" : "22396883",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3125784966/8223a4c5c9535be22d15c82ec829c2df_normal.jpeg",
    "id" : 22396883,
    "verified" : false
  }
}, {
  "source" : "<a href=\"https://launchpad.net/gwibber/\" rel=\"nofollow\">Gwibber</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "KAbrennt",
      "indices" : [ 65, 74 ]
    }, {
      "text" : "KITbrennt",
      "indices" : [ 75, 85 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "5865200327",
  "text" : "Am Wochenende bleibt die Heizung an, trotz einer Gegenstimme *g* #KAbrennt #KITbrennt",
  "id" : 5865200327,
  "created_at" : "Thu Nov 19 18:47:20 +0000 2009",
  "user" : {
    "name" : "Felix",
    "screen_name" : "nicidienase",
    "protected" : false,
    "id_str" : "22396883",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3125784966/8223a4c5c9535be22d15c82ec829c2df_normal.jpeg",
    "id" : 22396883,
    "verified" : false
  }
}, {
  "source" : "<a href=\"https://launchpad.net/gwibber/\" rel=\"nofollow\">Gwibber</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "KAbrennt",
      "indices" : [ 41, 50 ]
    }, {
      "text" : "KITbrennt",
      "indices" : [ 51, 61 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "5864914973",
  "text" : "AK Server nach dem Plenum im HMO am Pult #KAbrennt #KITbrennt",
  "id" : 5864914973,
  "created_at" : "Thu Nov 19 18:36:09 +0000 2009",
  "user" : {
    "name" : "Felix",
    "screen_name" : "nicidienase",
    "protected" : false,
    "id_str" : "22396883",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3125784966/8223a4c5c9535be22d15c82ec829c2df_normal.jpeg",
    "id" : 22396883,
    "verified" : false
  }
}, {
  "source" : "<a href=\"https://launchpad.net/gwibber/\" rel=\"nofollow\">Gwibber</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "KAbrennt",
      "indices" : [ 63, 72 ]
    }, {
      "text" : "KITbrennt",
      "indices" : [ 73, 83 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "5864810093",
  "text" : "AK Vernetzung trifft sich nach dem Plenum im HMO hinten rechts #KAbrennt #KITbrennt",
  "id" : 5864810093,
  "created_at" : "Thu Nov 19 18:32:04 +0000 2009",
  "user" : {
    "name" : "Felix",
    "screen_name" : "nicidienase",
    "protected" : false,
    "id_str" : "22396883",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3125784966/8223a4c5c9535be22d15c82ec829c2df_normal.jpeg",
    "id" : 22396883,
    "verified" : false
  }
}, {
  "source" : "<a href=\"https://launchpad.net/gwibber/\" rel=\"nofollow\">Gwibber</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "KAbrennt",
      "indices" : [ 43, 52 ]
    }, {
      "text" : "KITbrennt",
      "indices" : [ 53, 63 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "5864649119",
  "text" : "Liveschalte nach Freiburg doch erst morgen #KAbrennt #KITbrennt",
  "id" : 5864649119,
  "created_at" : "Thu Nov 19 18:25:49 +0000 2009",
  "user" : {
    "name" : "Felix",
    "screen_name" : "nicidienase",
    "protected" : false,
    "id_str" : "22396883",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3125784966/8223a4c5c9535be22d15c82ec829c2df_normal.jpeg",
    "id" : 22396883,
    "verified" : false
  }
}, {
  "source" : "<a href=\"https://launchpad.net/gwibber/\" rel=\"nofollow\">Gwibber</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "KAbrennt",
      "indices" : [ 61, 70 ]
    }, {
      "text" : "KITbrennt",
      "indices" : [ 71, 81 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "5864635715",
  "text" : "AG Infostand trifft sich nach dem Plenum vorne rechts im HMU #KAbrennt #KITbrennt",
  "id" : 5864635715,
  "created_at" : "Thu Nov 19 18:25:17 +0000 2009",
  "user" : {
    "name" : "Felix",
    "screen_name" : "nicidienase",
    "protected" : false,
    "id_str" : "22396883",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3125784966/8223a4c5c9535be22d15c82ec829c2df_normal.jpeg",
    "id" : 22396883,
    "verified" : false
  }
}, {
  "source" : "<a href=\"https://launchpad.net/gwibber/\" rel=\"nofollow\">Gwibber</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "KITbrennt",
      "indices" : [ 67, 77 ]
    }, {
      "text" : "KAbrennt",
      "indices" : [ 78, 87 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "5864557303",
  "text" : "AG Erstatzh\u00F6rs\u00E4le trifft sich nach dem Plenum am mittleren Ausgang #KITbrennt #KAbrennt",
  "id" : 5864557303,
  "created_at" : "Thu Nov 19 18:22:13 +0000 2009",
  "user" : {
    "name" : "Felix",
    "screen_name" : "nicidienase",
    "protected" : false,
    "id_str" : "22396883",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3125784966/8223a4c5c9535be22d15c82ec829c2df_normal.jpeg",
    "id" : 22396883,
    "verified" : false
  }
}, {
  "source" : "<a href=\"https://launchpad.net/gwibber/\" rel=\"nofollow\">Gwibber</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "KITbrennt",
      "indices" : [ 90, 100 ]
    }, {
      "text" : "KAbrennt",
      "indices" : [ 101, 110 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "5863579435",
  "text" : "Heute Nacht wird plakatiert, jetzt gehts weiter mit einem Breif an die Professorenschaft. #KITbrennt #KAbrennt",
  "id" : 5863579435,
  "created_at" : "Thu Nov 19 17:43:44 +0000 2009",
  "user" : {
    "name" : "Felix",
    "screen_name" : "nicidienase",
    "protected" : false,
    "id_str" : "22396883",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3125784966/8223a4c5c9535be22d15c82ec829c2df_normal.jpeg",
    "id" : 22396883,
    "verified" : false
  }
}, {
  "source" : "<a href=\"https://launchpad.net/gwibber/\" rel=\"nofollow\">Gwibber</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "KAbrennt",
      "indices" : [ 87, 96 ]
    }, {
      "text" : "KITbrennt",
      "indices" : [ 97, 107 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "5863212705",
  "text" : "Dem neuen Flyer (http://is.gd/4YVZO) wurde zugestimmt. Er wird morgen wieder verteilt. #KAbrennt #KITbrennt",
  "id" : 5863212705,
  "created_at" : "Thu Nov 19 17:29:25 +0000 2009",
  "user" : {
    "name" : "Felix",
    "screen_name" : "nicidienase",
    "protected" : false,
    "id_str" : "22396883",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3125784966/8223a4c5c9535be22d15c82ec829c2df_normal.jpeg",
    "id" : 22396883,
    "verified" : false
  }
}, {
  "source" : "<a href=\"https://launchpad.net/gwibber/\" rel=\"nofollow\">Gwibber</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "KITbrennt",
      "indices" : [ 49, 59 ]
    }, {
      "text" : "KAbrennt",
      "indices" : [ 60, 69 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "5862696846",
  "text" : "Um 20Uhr gibts Liveschalte vom HMU nach Freiburg #KITbrennt #KAbrennt",
  "id" : 5862696846,
  "created_at" : "Thu Nov 19 17:09:16 +0000 2009",
  "user" : {
    "name" : "Felix",
    "screen_name" : "nicidienase",
    "protected" : false,
    "id_str" : "22396883",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3125784966/8223a4c5c9535be22d15c82ec829c2df_normal.jpeg",
    "id" : 22396883,
    "verified" : false
  }
}, {
  "source" : "<a href=\"https://launchpad.net/gwibber/\" rel=\"nofollow\">Gwibber</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "KITbrennt",
      "indices" : [ 42, 52 ]
    }, {
      "text" : "KAbrennt",
      "indices" : [ 53, 62 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "5862462847",
  "text" : "Der HMU wir immer voller. 18Uhr is Plenum #KITbrennt #KAbrennt",
  "id" : 5862462847,
  "created_at" : "Thu Nov 19 17:00:21 +0000 2009",
  "user" : {
    "name" : "Felix",
    "screen_name" : "nicidienase",
    "protected" : false,
    "id_str" : "22396883",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3125784966/8223a4c5c9535be22d15c82ec829c2df_normal.jpeg",
    "id" : 22396883,
    "verified" : false
  }
}, {
  "source" : "<a href=\"https://launchpad.net/gwibber/\" rel=\"nofollow\">Gwibber</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "KITbrennt",
      "indices" : [ 51, 61 ]
    }, {
      "text" : "KAbrennt",
      "indices" : [ 62, 71 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "5857256104",
  "text" : "Keine 20 Leute im besetzten HMU. Wo seid ihr alle? #KITbrennt #KAbrennt",
  "id" : 5857256104,
  "created_at" : "Thu Nov 19 13:30:27 +0000 2009",
  "user" : {
    "name" : "Felix",
    "screen_name" : "nicidienase",
    "protected" : false,
    "id_str" : "22396883",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3125784966/8223a4c5c9535be22d15c82ec829c2df_normal.jpeg",
    "id" : 22396883,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://pivotallabs.com/landing/tweed\" rel=\"nofollow\">Tweed</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sunday8pm",
      "screen_name" : "sunday_8pm",
      "indices" : [ 0, 11 ],
      "id_str" : "80762004",
      "id" : 80762004
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "5832093152",
  "geo" : {
  },
  "id_str" : "5832754416",
  "in_reply_to_user_id" : 80762004,
  "text" : "@Sunday_8pm Ne, nur im \u00FCbertragenen Sinne.",
  "id" : 5832754416,
  "in_reply_to_status_id" : 5832093152,
  "created_at" : "Wed Nov 18 18:05:51 +0000 2009",
  "in_reply_to_screen_name" : "sunday_8pm",
  "in_reply_to_user_id_str" : "80762004",
  "user" : {
    "name" : "Felix",
    "screen_name" : "nicidienase",
    "protected" : false,
    "id_str" : "22396883",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3125784966/8223a4c5c9535be22d15c82ec829c2df_normal.jpeg",
    "id" : 22396883,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://pivotallabs.com/landing/tweed\" rel=\"nofollow\">Tweed</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "5831024145",
  "text" : "Wohnheimnetz down. Naja ich wollt ja eh noch einkaufen gehen.",
  "id" : 5831024145,
  "created_at" : "Wed Nov 18 16:56:48 +0000 2009",
  "user" : {
    "name" : "Felix",
    "screen_name" : "nicidienase",
    "protected" : false,
    "id_str" : "22396883",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3125784966/8223a4c5c9535be22d15c82ec829c2df_normal.jpeg",
    "id" : 22396883,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://pivotallabs.com/landing/tweed\" rel=\"nofollow\">Tweed</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Grumpy old Man",
      "screen_name" : "grmpyoldman",
      "indices" : [ 3, 15 ],
      "id_str" : "538227504",
      "id" : 538227504
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Bankers",
      "indices" : [ 39, 47 ]
    }, {
      "text" : "Pirates",
      "indices" : [ 52, 60 ]
    }, {
      "text" : "ppi",
      "indices" : [ 79, 83 ]
    }, {
      "text" : "pp",
      "indices" : [ 84, 87 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "5830096090",
  "text" : "RT @GrmpyOldMan The Difference between #Bankers and #Pirates http://u.nu/9iaw3 #ppi #pp !piratenpartei",
  "id" : 5830096090,
  "created_at" : "Wed Nov 18 16:20:44 +0000 2009",
  "user" : {
    "name" : "Felix",
    "screen_name" : "nicidienase",
    "protected" : false,
    "id_str" : "22396883",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3125784966/8223a4c5c9535be22d15c82ec829c2df_normal.jpeg",
    "id" : 22396883,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://pivotallabs.com/landing/tweed\" rel=\"nofollow\">Tweed</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Holger Klein",
      "screen_name" : "holgi",
      "indices" : [ 3, 9 ],
      "id_str" : "3068271",
      "id" : 3068271
    }, {
      "name" : "Andreas Schepers",
      "screen_name" : "AndreasSchepers",
      "indices" : [ 15, 31 ],
      "id_str" : "12321512",
      "id" : 12321512
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "5830052910",
  "text" : "RT @holgi: RT: @AndreasSchepers: ISS passes in front of the Moon http://post.ly/CtbV",
  "id" : 5830052910,
  "created_at" : "Wed Nov 18 16:19:03 +0000 2009",
  "user" : {
    "name" : "Felix",
    "screen_name" : "nicidienase",
    "protected" : false,
    "id_str" : "22396883",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3125784966/8223a4c5c9535be22d15c82ec829c2df_normal.jpeg",
    "id" : 22396883,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitpic.com/\" rel=\"nofollow\">TwitPic</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "kitbrennt",
      "indices" : [ 81, 91 ]
    }, {
      "text" : "u",
      "indices" : [ 92, 94 ]
    }, {
      "text" : "karlsruhe",
      "indices" : [ 104, 114 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "5827817303",
  "text" : "http://twitpic.com/pzjlt - Nach der Pause is es irgendwie leerer geworden im HMU #kitbrennt #u nibrennt #karlsruhe",
  "id" : 5827817303,
  "created_at" : "Wed Nov 18 14:49:07 +0000 2009",
  "user" : {
    "name" : "Felix",
    "screen_name" : "nicidienase",
    "protected" : false,
    "id_str" : "22396883",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3125784966/8223a4c5c9535be22d15c82ec829c2df_normal.jpeg",
    "id" : 22396883,
    "verified" : false
  }
}, {
  "source" : "<a href=\"https://launchpad.net/gwibber/\" rel=\"nofollow\">Gwibber</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "kitbrennt",
      "indices" : [ 0, 10 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "5827250828",
  "text" : "#kitbrennt: Pause vorbei, es geht weiter!",
  "id" : 5827250828,
  "created_at" : "Wed Nov 18 14:24:56 +0000 2009",
  "user" : {
    "name" : "Felix",
    "screen_name" : "nicidienase",
    "protected" : false,
    "id_str" : "22396883",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3125784966/8223a4c5c9535be22d15c82ec829c2df_normal.jpeg",
    "id" : 22396883,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://pivotallabs.com/landing/tweed\" rel=\"nofollow\">Tweed</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "kitbrennt",
      "indices" : [ 12, 22 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "5824664156",
  "text" : "Offizieller #kitbrennt -stream http://experimentalworks.net:8000/stream.mp3",
  "id" : 5824664156,
  "created_at" : "Wed Nov 18 12:15:51 +0000 2009",
  "user" : {
    "name" : "Felix",
    "screen_name" : "nicidienase",
    "protected" : false,
    "id_str" : "22396883",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3125784966/8223a4c5c9535be22d15c82ec829c2df_normal.jpeg",
    "id" : 22396883,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://pivotallabs.com/landing/tweed\" rel=\"nofollow\">Tweed</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "kitbrennt",
      "indices" : [ 17, 27 ]
    }, {
      "text" : "unibrennt",
      "indices" : [ 43, 53 ]
    }, {
      "text" : "karlsruhe",
      "indices" : [ 57, 67 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "5823803916",
  "text" : "irc.freenode.net #kitbrennt IRC-Channel zu #unibrennt in #karlsruhe",
  "id" : 5823803916,
  "created_at" : "Wed Nov 18 11:21:19 +0000 2009",
  "user" : {
    "name" : "Felix",
    "screen_name" : "nicidienase",
    "protected" : false,
    "id_str" : "22396883",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3125784966/8223a4c5c9535be22d15c82ec829c2df_normal.jpeg",
    "id" : 22396883,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitpic.com/\" rel=\"nofollow\">TwitPic</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "kitbrennt",
      "indices" : [ 41, 51 ]
    }, {
      "text" : "karlsruhe",
      "indices" : [ 52, 62 ]
    }, {
      "text" : "unibrennt",
      "indices" : [ 63, 73 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "5799430787",
  "text" : "http://twitpic.com/pvkzh - Besetzter HMU #kitbrennt #karlsruhe #unibrennt",
  "id" : 5799430787,
  "created_at" : "Tue Nov 17 16:18:12 +0000 2009",
  "user" : {
    "name" : "Felix",
    "screen_name" : "nicidienase",
    "protected" : false,
    "id_str" : "22396883",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3125784966/8223a4c5c9535be22d15c82ec829c2df_normal.jpeg",
    "id" : 22396883,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://pivotallabs.com/landing/tweed\" rel=\"nofollow\">Tweed</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Edward",
      "screen_name" : "twitgeridoo",
      "indices" : [ 3, 15 ],
      "id_str" : "46379961",
      "id" : 46379961
    }, {
      "name" : "Kai",
      "screen_name" : "KaWie",
      "indices" : [ 106, 112 ],
      "id_str" : "16042394",
      "id" : 16042394
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Piraten",
      "indices" : [ 113, 121 ]
    }, {
      "text" : "FDP",
      "indices" : [ 122, 126 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "5765250657",
  "text" : "RT @Twitgeridoo Yeah! :D \"Guido Westerwelle \u00FCber die Piratenpartei\" http://j.mp/1b3YBR L\u00E4ssiger Remix von @KaWie #Piraten #FDP",
  "id" : 5765250657,
  "created_at" : "Mon Nov 16 13:52:09 +0000 2009",
  "user" : {
    "name" : "Felix",
    "screen_name" : "nicidienase",
    "protected" : false,
    "id_str" : "22396883",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3125784966/8223a4c5c9535be22d15c82ec829c2df_normal.jpeg",
    "id" : 22396883,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://pivotallabs.com/landing/tweed\" rel=\"nofollow\">Tweed</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Max Winde",
      "screen_name" : "343max",
      "indices" : [ 3, 10 ],
      "id_str" : "2284151",
      "id" : 2284151
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "5708033657",
  "text" : "RT @343max: Warum gabs zum Mauerfall-Jubil\u00E4um eigentlich keine Cheesebefehl-Wochen bei McDonalds?",
  "id" : 5708033657,
  "created_at" : "Sat Nov 14 12:44:31 +0000 2009",
  "user" : {
    "name" : "Felix",
    "screen_name" : "nicidienase",
    "protected" : false,
    "id_str" : "22396883",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3125784966/8223a4c5c9535be22d15c82ec829c2df_normal.jpeg",
    "id" : 22396883,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://pivotallabs.com/landing/tweed\" rel=\"nofollow\">Tweed</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "5619674583",
  "text" : "Musste grad in de Programmier\u00FCbung mein Prog auf Englisch erkl\u00E4ren. Und hab gemerkt das mein Vokabular nicht so gut ist wie ich gedacht hab.",
  "id" : 5619674583,
  "created_at" : "Wed Nov 11 14:26:21 +0000 2009",
  "user" : {
    "name" : "Felix",
    "screen_name" : "nicidienase",
    "protected" : false,
    "id_str" : "22396883",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3125784966/8223a4c5c9535be22d15c82ec829c2df_normal.jpeg",
    "id" : 22396883,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://pivotallabs.com/landing/tweed\" rel=\"nofollow\">Tweed</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Holger Klein",
      "screen_name" : "holgi",
      "indices" : [ 3, 9 ],
      "id_str" : "3068271",
      "id" : 3068271
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "5605168760",
  "text" : "RT @holgi: \"Liebes Tagebuch, ich schreibe dir heute aus dem Reisezentrum der deutschen Bahn\" http://bit.ly/sAPoV",
  "id" : 5605168760,
  "created_at" : "Wed Nov 11 00:54:52 +0000 2009",
  "user" : {
    "name" : "Felix",
    "screen_name" : "nicidienase",
    "protected" : false,
    "id_str" : "22396883",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3125784966/8223a4c5c9535be22d15c82ec829c2df_normal.jpeg",
    "id" : 22396883,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://pivotallabs.com/landing/tweed\" rel=\"nofollow\">Tweed</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Max Winde",
      "screen_name" : "343max",
      "indices" : [ 3, 10 ],
      "id_str" : "2284151",
      "id" : 2284151
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "5595797340",
  "text" : "RT @343max: Sehr coole Wassertropfenslomo. http://bit.ly/2QjPMb",
  "id" : 5595797340,
  "created_at" : "Tue Nov 10 18:40:43 +0000 2009",
  "user" : {
    "name" : "Felix",
    "screen_name" : "nicidienase",
    "protected" : false,
    "id_str" : "22396883",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3125784966/8223a4c5c9535be22d15c82ec829c2df_normal.jpeg",
    "id" : 22396883,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://pivotallabs.com/landing/tweed\" rel=\"nofollow\">Tweed</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lars Fischer",
      "screen_name" : "Fischblog",
      "indices" : [ 3, 13 ],
      "id_str" : "14700783",
      "id" : 14700783
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "5560995827",
  "text" : "RT @Fischblog: Petition - kostenloser Erwerb wissenschaftlicher Publikationen http://tinyurl.com/y8qcxdo Pls RT & zeichnen",
  "id" : 5560995827,
  "created_at" : "Mon Nov 09 15:28:30 +0000 2009",
  "user" : {
    "name" : "Felix",
    "screen_name" : "nicidienase",
    "protected" : false,
    "id_str" : "22396883",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3125784966/8223a4c5c9535be22d15c82ec829c2df_normal.jpeg",
    "id" : 22396883,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://pivotallabs.com/landing/tweed\" rel=\"nofollow\">Tweed</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Darth Vader",
      "screen_name" : "darthvader",
      "indices" : [ 3, 14 ],
      "id_str" : "618593",
      "id" : 618593
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "5531286385",
  "text" : "RT @darthvader: The boys in R&D seem to be improving. I especially approve of the ICH (Imperial Candy Hatch\u2122) on top - http://bit.ly/4Az882",
  "id" : 5531286385,
  "created_at" : "Sun Nov 08 13:06:42 +0000 2009",
  "user" : {
    "name" : "Felix",
    "screen_name" : "nicidienase",
    "protected" : false,
    "id_str" : "22396883",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3125784966/8223a4c5c9535be22d15c82ec829c2df_normal.jpeg",
    "id" : 22396883,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://pivotallabs.com/landing/tweed\" rel=\"nofollow\">Tweed</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Barney Stinson",
      "screen_name" : "Broslife",
      "indices" : [ 3, 12 ],
      "id_str" : "69382909",
      "id" : 69382909
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "5459914330",
  "text" : "RT @Broslife: How picking out scotch is similar to picking out women:\nIf it's 18 years or older, it's good to go.",
  "id" : 5459914330,
  "created_at" : "Thu Nov 05 21:08:24 +0000 2009",
  "user" : {
    "name" : "Felix",
    "screen_name" : "nicidienase",
    "protected" : false,
    "id_str" : "22396883",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3125784966/8223a4c5c9535be22d15c82ec829c2df_normal.jpeg",
    "id" : 22396883,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://pivotallabs.com/landing/tweed\" rel=\"nofollow\">Tweed</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Holger Klein",
      "screen_name" : "holgi",
      "indices" : [ 3, 9 ],
      "id_str" : "3068271",
      "id" : 3068271
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "5366178857",
  "text" : "RT @holgi: Grosses Kino: \"Planet Wissen\" erkl\u00E4rt das Zustandekommen der Finanzkrise mittels Playmobilm\u00E4nnchen http://bit.ly/4m51Kw",
  "id" : 5366178857,
  "created_at" : "Mon Nov 02 16:06:37 +0000 2009",
  "user" : {
    "name" : "Felix",
    "screen_name" : "nicidienase",
    "protected" : false,
    "id_str" : "22396883",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3125784966/8223a4c5c9535be22d15c82ec829c2df_normal.jpeg",
    "id" : 22396883,
    "verified" : false
  }
} ]