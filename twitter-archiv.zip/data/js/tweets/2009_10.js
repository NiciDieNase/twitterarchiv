Grailbird.data.tweets_2009_10 = 
 [ {
  "source" : "<a href=\"http://pivotallabs.com/landing/tweed\" rel=\"nofollow\">Tweed</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sunday8pm",
      "screen_name" : "sunday_8pm",
      "indices" : [ 0, 11 ],
      "id_str" : "80762004",
      "id" : 80762004
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "5239146128",
  "in_reply_to_user_id" : 80762004,
  "text" : "@Sunday_8pm: Hast gar nichts mehr getwittert in letzter Zeit. Erste Twitter-Euphorie verflogen?",
  "id" : 5239146128,
  "created_at" : "Wed Oct 28 20:07:19 +0000 2009",
  "in_reply_to_screen_name" : "sunday_8pm",
  "in_reply_to_user_id_str" : "80762004",
  "user" : {
    "name" : "Felix",
    "screen_name" : "nicidienase",
    "protected" : false,
    "id_str" : "22396883",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3125784966/8223a4c5c9535be22d15c82ec829c2df_normal.jpeg",
    "id" : 22396883,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://pivotallabs.com/landing/tweed\" rel=\"nofollow\">Tweed</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Pre",
      "indices" : [ 65, 69 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "5233314246",
  "text" : "Grade beim heimlaufen von der Uni Tweets gelesen. Ich mag meinen #Pre.",
  "id" : 5233314246,
  "created_at" : "Wed Oct 28 15:51:29 +0000 2009",
  "user" : {
    "name" : "Felix",
    "screen_name" : "nicidienase",
    "protected" : false,
    "id_str" : "22396883",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3125784966/8223a4c5c9535be22d15c82ec829c2df_normal.jpeg",
    "id" : 22396883,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://pivotallabs.com/landing/tweed\" rel=\"nofollow\">Tweed</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Max Winde",
      "screen_name" : "343max",
      "indices" : [ 3, 10 ],
      "id_str" : "2284151",
      "id" : 2284151
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "5228153029",
  "text" : "RT @343max: Versteckte Botschaft in Brief von Arnold Schwarzenegger http://bit.ly/34XBTq",
  "id" : 5228153029,
  "created_at" : "Wed Oct 28 11:44:38 +0000 2009",
  "user" : {
    "name" : "Felix",
    "screen_name" : "nicidienase",
    "protected" : false,
    "id_str" : "22396883",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3125784966/8223a4c5c9535be22d15c82ec829c2df_normal.jpeg",
    "id" : 22396883,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://pivotallabs.com/landing/tweed\" rel=\"nofollow\">Tweed</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "fail",
      "indices" : [ 36, 41 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "5205884500",
  "text" : "LOL: http://amish-online-dating.com #fail",
  "id" : 5205884500,
  "created_at" : "Tue Oct 27 17:27:31 +0000 2009",
  "user" : {
    "name" : "Felix",
    "screen_name" : "nicidienase",
    "protected" : false,
    "id_str" : "22396883",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3125784966/8223a4c5c9535be22d15c82ec829c2df_normal.jpeg",
    "id" : 22396883,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://pivotallabs.com/landing/tweed\" rel=\"nofollow\">Tweed</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Felicia Day",
      "screen_name" : "feliciaday",
      "indices" : [ 3, 14 ],
      "id_str" : "7861312",
      "id" : 7861312
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "5205101082",
  "text" : "RT @feliciaday: The Guild Season 3 - Bonus Episode: Halloween! (S3 EP9 out next week) http://bit.ly/tr1Ck",
  "id" : 5205101082,
  "created_at" : "Tue Oct 27 16:54:22 +0000 2009",
  "user" : {
    "name" : "Felix",
    "screen_name" : "nicidienase",
    "protected" : false,
    "id_str" : "22396883",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3125784966/8223a4c5c9535be22d15c82ec829c2df_normal.jpeg",
    "id" : 22396883,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://pivotallabs.com/landing/tweed\" rel=\"nofollow\">Tweed</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Fefes Blog",
      "screen_name" : "fefesblog",
      "indices" : [ 3, 13 ],
      "id_str" : "16079787",
      "id" : 16079787
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "5170458688",
  "text" : "RT @fefesblog: Wie viele FDP-Anh\u00E4nger braucht man, um eine Gl\u00FChlampe zu wechseln? http://bit.ly/3rYJmz",
  "id" : 5170458688,
  "created_at" : "Mon Oct 26 11:08:38 +0000 2009",
  "user" : {
    "name" : "Felix",
    "screen_name" : "nicidienase",
    "protected" : false,
    "id_str" : "22396883",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3125784966/8223a4c5c9535be22d15c82ec829c2df_normal.jpeg",
    "id" : 22396883,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://pivotallabs.com/landing/tweed\" rel=\"nofollow\">Tweed</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Arbeitskreis Zensur",
      "screen_name" : "akzensur",
      "indices" : [ 3, 12 ],
      "id_str" : "34256245",
      "id" : 34256245
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "zensur",
      "indices" : [ 86, 93 ]
    }, {
      "text" : "meinungsfreiheit",
      "indices" : [ 94, 111 ]
    }, {
      "text" : "internetsperren",
      "indices" : [ 112, 128 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "5169527350",
  "text" : "RT @akzensur: Die beste Telepolis-Satire seit langer Zeit: http://tinyurl.com/ygemn7h #zensur #meinungsfreiheit #internetsperren",
  "id" : 5169527350,
  "created_at" : "Mon Oct 26 09:50:35 +0000 2009",
  "user" : {
    "name" : "Felix",
    "screen_name" : "nicidienase",
    "protected" : false,
    "id_str" : "22396883",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3125784966/8223a4c5c9535be22d15c82ec829c2df_normal.jpeg",
    "id" : 22396883,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://funkatron.com/spaz\" rel=\"nofollow\">Spaz</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Bulo",
      "screen_name" : "DerBulo",
      "indices" : [ 3, 11 ],
      "id_str" : "42403765",
      "id" : 42403765
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Windows",
      "indices" : [ 60, 68 ]
    }, {
      "text" : "Microsoft",
      "indices" : [ 96, 106 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "5065558266",
  "text" : "RT @DerBulo: http://twitpic.com/mg9wf - So gut ist das neue #Windows 7: \"Herr Kruse\" (Seite 80) #Microsoft",
  "id" : 5065558266,
  "created_at" : "Thu Oct 22 09:28:41 +0000 2009",
  "user" : {
    "name" : "Felix",
    "screen_name" : "nicidienase",
    "protected" : false,
    "id_str" : "22396883",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3125784966/8223a4c5c9535be22d15c82ec829c2df_normal.jpeg",
    "id" : 22396883,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://funkatron.com/spaz\" rel=\"nofollow\">Spaz</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "4920022563",
  "text" : "Seit Ewigkeiten mal wieder Schwimmen. Muss mich noch dran gew\u00F6hnen, dass man lange Haare f\u00F6nen muss.",
  "id" : 4920022563,
  "created_at" : "Fri Oct 16 16:44:25 +0000 2009",
  "user" : {
    "name" : "Felix",
    "screen_name" : "nicidienase",
    "protected" : false,
    "id_str" : "22396883",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3125784966/8223a4c5c9535be22d15c82ec829c2df_normal.jpeg",
    "id" : 22396883,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://funkatron.com/spaz\" rel=\"nofollow\">Spaz</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Pre",
      "indices" : [ 94, 98 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "4890094915",
  "text" : "Und mit Spaz hab ich auch schon nen auf den ersten Eindruck ganz guten Twitter-Client f\u00FCr den #Pre gefunden.",
  "id" : 4890094915,
  "created_at" : "Thu Oct 15 14:49:13 +0000 2009",
  "user" : {
    "name" : "Felix",
    "screen_name" : "nicidienase",
    "protected" : false,
    "id_str" : "22396883",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3125784966/8223a4c5c9535be22d15c82ec829c2df_normal.jpeg",
    "id" : 22396883,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://funkatron.com/spaz\" rel=\"nofollow\">Spaz</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Palm",
      "indices" : [ 14, 19 ]
    }, {
      "text" : "Pre",
      "indices" : [ 20, 24 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "4890056424",
  "text" : "So mein neuer #Palm #Pre ist eingerichtet und l\u00E4uft schneller als das Vorf\u00FChrger\u00E4t am Montag.",
  "id" : 4890056424,
  "created_at" : "Thu Oct 15 14:47:32 +0000 2009",
  "user" : {
    "name" : "Felix",
    "screen_name" : "nicidienase",
    "protected" : false,
    "id_str" : "22396883",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3125784966/8223a4c5c9535be22d15c82ec829c2df_normal.jpeg",
    "id" : 22396883,
    "verified" : false
  }
}, {
  "source" : "<a href=\"https://launchpad.net/gwibber/\" rel=\"nofollow\">Gwibber</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Palm",
      "indices" : [ 12, 17 ]
    }, {
      "text" : "Pre",
      "indices" : [ 18, 22 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "4887275280",
  "text" : "Yuchuu mein #Palm #Pre is grade gekommen, jetzt gehts ans aktivieren und einrichten",
  "id" : 4887275280,
  "created_at" : "Thu Oct 15 12:25:14 +0000 2009",
  "user" : {
    "name" : "Felix",
    "screen_name" : "nicidienase",
    "protected" : false,
    "id_str" : "22396883",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3125784966/8223a4c5c9535be22d15c82ec829c2df_normal.jpeg",
    "id" : 22396883,
    "verified" : false
  }
}, {
  "source" : "<a href=\"https://launchpad.net/gwibber/\" rel=\"nofollow\">Gwibber</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "pre",
      "indices" : [ 42, 46 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "4807626671",
  "text" : "War grad im O2 Laden und hab mir den Palm #pre angeguckt, war irgendwie bissl langsam, hoffe das lag nur an der Demo",
  "id" : 4807626671,
  "created_at" : "Mon Oct 12 12:40:41 +0000 2009",
  "user" : {
    "name" : "Felix",
    "screen_name" : "nicidienase",
    "protected" : false,
    "id_str" : "22396883",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3125784966/8223a4c5c9535be22d15c82ec829c2df_normal.jpeg",
    "id" : 22396883,
    "verified" : false
  }
}, {
  "source" : "<a href=\"https://launchpad.net/gwibber/\" rel=\"nofollow\">Gwibber</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Bill Prady",
      "screen_name" : "billprady",
      "indices" : [ 3, 13 ],
      "id_str" : "59524045",
      "id" : 59524045
    }, {
      "name" : "Steve Molaro",
      "screen_name" : "SteveMolaro",
      "indices" : [ 76, 88 ],
      "id_str" : "77244813",
      "id" : 77244813
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "bigbangtheory",
      "indices" : [ 54, 68 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "4719783811",
  "geo" : {
  },
  "id_str" : "4719960262",
  "in_reply_to_user_id" : 59524045,
  "text" : "RT @billprady Honey, what's for dinner? Aw, left over #bigbangtheory writer @stevemolaro again?! http://twitpic.com/krl4l",
  "id" : 4719960262,
  "in_reply_to_status_id" : 4719783811,
  "created_at" : "Thu Oct 08 23:20:37 +0000 2009",
  "in_reply_to_screen_name" : "billprady",
  "in_reply_to_user_id_str" : "59524045",
  "user" : {
    "name" : "Felix",
    "screen_name" : "nicidienase",
    "protected" : false,
    "id_str" : "22396883",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3125784966/8223a4c5c9535be22d15c82ec829c2df_normal.jpeg",
    "id" : 22396883,
    "verified" : false
  }
}, {
  "source" : "<a href=\"https://launchpad.net/gwibber/\" rel=\"nofollow\">Gwibber</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sunday8pm",
      "screen_name" : "sunday_8pm",
      "indices" : [ 0, 11 ],
      "id_str" : "80762004",
      "id" : 80762004
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "4709741397",
  "geo" : {
  },
  "id_str" : "4711471491",
  "in_reply_to_user_id" : 80762004,
  "text" : "@Sunday_8pm Sobald man sich mal mit Twitter besch\u00E4ftigt kann man nicht mehr ohne ;-)",
  "id" : 4711471491,
  "in_reply_to_status_id" : 4709741397,
  "created_at" : "Thu Oct 08 16:03:17 +0000 2009",
  "in_reply_to_screen_name" : "sunday_8pm",
  "in_reply_to_user_id_str" : "80762004",
  "user" : {
    "name" : "Felix",
    "screen_name" : "nicidienase",
    "protected" : false,
    "id_str" : "22396883",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3125784966/8223a4c5c9535be22d15c82ec829c2df_normal.jpeg",
    "id" : 22396883,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://mine.icanhascheezburger.com/\" rel=\"nofollow\">ichc</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "lol",
      "indices" : [ 42, 46 ]
    }, {
      "text" : "celebrity",
      "indices" : [ 47, 57 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "4707275438",
  "text" : "\"SCIENCE\" - http://twlol.com/tw/?v8-27584 #lol #celebrity",
  "id" : 4707275438,
  "created_at" : "Thu Oct 08 12:05:51 +0000 2009",
  "user" : {
    "name" : "Felix",
    "screen_name" : "nicidienase",
    "protected" : false,
    "id_str" : "22396883",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3125784966/8223a4c5c9535be22d15c82ec829c2df_normal.jpeg",
    "id" : 22396883,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sunday8pm",
      "screen_name" : "sunday_8pm",
      "indices" : [ 0, 11 ],
      "id_str" : "80762004",
      "id" : 80762004
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "4707087593",
  "in_reply_to_user_id" : 80762004,
  "text" : "@Sunday_8pm Hey, Willkommen bei Twitter. Twitterst du nur vom PC oder hast du auch nen Twitter-Client f\u00FCr deinen BlackBerry?",
  "id" : 4707087593,
  "created_at" : "Thu Oct 08 11:53:07 +0000 2009",
  "in_reply_to_screen_name" : "sunday_8pm",
  "in_reply_to_user_id_str" : "80762004",
  "user" : {
    "name" : "Felix",
    "screen_name" : "nicidienase",
    "protected" : false,
    "id_str" : "22396883",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3125784966/8223a4c5c9535be22d15c82ec829c2df_normal.jpeg",
    "id" : 22396883,
    "verified" : false
  }
}, {
  "source" : "<a href=\"https://launchpad.net/gwibber/\" rel=\"nofollow\">Gwibber</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Bulo",
      "screen_name" : "DerBulo",
      "indices" : [ 3, 11 ],
      "id_str" : "42403765",
      "id" : 42403765
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "4706778503",
  "text" : "RT @DerBulo http://twitpic.com/kp4v5 - Der Schei\u00DF des Jahrhunderts: Nordic Walking ... \"Herr Kruse\" (Seite 73)",
  "id" : 4706778503,
  "created_at" : "Thu Oct 08 11:31:11 +0000 2009",
  "user" : {
    "name" : "Felix",
    "screen_name" : "nicidienase",
    "protected" : false,
    "id_str" : "22396883",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3125784966/8223a4c5c9535be22d15c82ec829c2df_normal.jpeg",
    "id" : 22396883,
    "verified" : false
  }
}, {
  "source" : "<a href=\"https://launchpad.net/gwibber/\" rel=\"nofollow\">Gwibber</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kunal Nayyar",
      "screen_name" : "kunalnayyar",
      "indices" : [ 0, 12 ],
      "id_str" : "24202701",
      "id" : 24202701
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "4658660782",
  "geo" : {
  },
  "id_str" : "4659536720",
  "in_reply_to_user_id" : 24202701,
  "text" : "@kunalnayyar I'm from Germany and over here it's 7pm, so most of my day is allready over.",
  "id" : 4659536720,
  "in_reply_to_status_id" : 4658660782,
  "created_at" : "Tue Oct 06 17:02:40 +0000 2009",
  "in_reply_to_screen_name" : "kunalnayyar",
  "in_reply_to_user_id_str" : "24202701",
  "user" : {
    "name" : "Felix",
    "screen_name" : "nicidienase",
    "protected" : false,
    "id_str" : "22396883",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3125784966/8223a4c5c9535be22d15c82ec829c2df_normal.jpeg",
    "id" : 22396883,
    "verified" : false
  }
}, {
  "source" : "<a href=\"https://launchpad.net/gwibber/\" rel=\"nofollow\">Gwibber</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "4627657772",
  "text" : "Darth Vader hat eine Panne in R2-D2s Mercedes http://is.gd/3YwoG",
  "id" : 4627657772,
  "created_at" : "Mon Oct 05 13:23:03 +0000 2009",
  "user" : {
    "name" : "Felix",
    "screen_name" : "nicidienase",
    "protected" : false,
    "id_str" : "22396883",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3125784966/8223a4c5c9535be22d15c82ec829c2df_normal.jpeg",
    "id" : 22396883,
    "verified" : false
  }
}, {
  "source" : "<a href=\"https://launchpad.net/gwibber/\" rel=\"nofollow\">Gwibber</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Piratenpartei",
      "screen_name" : "Piratenpartei",
      "indices" : [ 2, 16 ],
      "id_str" : "14341194",
      "id" : 14341194
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "4553040497",
  "text" : "RT@Piratenpartei: ACHTUNG die Lage ist ernst: \u00C4u\u00DFerst wichtige Handlungsanweisung f\u00FCr den Fall eines Terroranschlags: http://is.gd/3SliY",
  "id" : 4553040497,
  "created_at" : "Fri Oct 02 14:00:23 +0000 2009",
  "user" : {
    "name" : "Felix",
    "screen_name" : "nicidienase",
    "protected" : false,
    "id_str" : "22396883",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3125784966/8223a4c5c9535be22d15c82ec829c2df_normal.jpeg",
    "id" : 22396883,
    "verified" : false
  }
} ]