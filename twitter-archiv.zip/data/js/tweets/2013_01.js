Grailbird.data.tweets_2013_01 = 
 [ {
  "source" : "<a href=\"http://www.tweetlanes.com\" rel=\"nofollow\">Tweet Lanes for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "lexi",
      "screen_name" : "satans_keksdose",
      "indices" : [ 3, 19 ],
      "id_str" : "226617153",
      "id" : 226617153
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 99, 119 ],
      "url" : "http://t.co/zxnrwzj2",
      "expanded_url" : "http://serverfault.com/q/293217?stw=2",
      "display_url" : "serverfault.com/q/293217?stw=2"
    } ]
  },
  "geo" : {
  },
  "id_str" : "296964947156553729",
  "text" : "RT @satans_keksdose: Our security auditor is an idiot. How do I give him the information he wants? http://t.co/zxnrwzj2",
  "retweeted_status" : {
    "source" : "<a href=\"http://twitter.com/tweetbutton\" rel=\"nofollow\">Tweet Button</a>",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 78, 98 ],
        "url" : "http://t.co/zxnrwzj2",
        "expanded_url" : "http://serverfault.com/q/293217?stw=2",
        "display_url" : "serverfault.com/q/293217?stw=2"
      } ]
    },
    "geo" : {
    },
    "id_str" : "296562854931345408",
    "text" : "Our security auditor is an idiot. How do I give him the information he wants? http://t.co/zxnrwzj2",
    "id" : 296562854931345408,
    "created_at" : "Wed Jan 30 10:17:49 +0000 2013",
    "user" : {
      "name" : "lexi",
      "screen_name" : "satans_keksdose",
      "protected" : false,
      "id_str" : "226617153",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/1190536314/lexi-logo_normal.png",
      "id" : 226617153,
      "verified" : false
    }
  },
  "id" : 296964947156553729,
  "created_at" : "Thu Jan 31 12:55:35 +0000 2013",
  "user" : {
    "name" : "Felix",
    "screen_name" : "nicidienase",
    "protected" : false,
    "id_str" : "22396883",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3125784966/8223a4c5c9535be22d15c82ec829c2df_normal.jpeg",
    "id" : 22396883,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.tweetlanes.com\" rel=\"nofollow\">Tweet Lanes for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Trollcon",
      "screen_name" : "trollcon",
      "indices" : [ 3, 12 ],
      "id_str" : "609572829",
      "id" : 609572829
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "296446500345618432",
  "text" : "RT @trollcon: Haltet euch mal den 26. und 27. Oktober frei. Haben geh\u00F6rt, da k\u00F6nnte ein nettes, kleines Event stattfinden.",
  "retweeted_status" : {
    "source" : "<a href=\"http://tapbots.com/software/tweetbot/mac\" rel=\"nofollow\">Tweetbot for Mac</a>",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : {
    },
    "id_str" : "296345824265396226",
    "text" : "Haltet euch mal den 26. und 27. Oktober frei. Haben geh\u00F6rt, da k\u00F6nnte ein nettes, kleines Event stattfinden.",
    "id" : 296345824265396226,
    "created_at" : "Tue Jan 29 19:55:25 +0000 2013",
    "user" : {
      "name" : "Trollcon",
      "screen_name" : "trollcon",
      "protected" : false,
      "id_str" : "609572829",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/3443779314/3f4b4a4654f92bbc11789a4e623b5a36_normal.jpeg",
      "id" : 609572829,
      "verified" : false
    }
  },
  "id" : 296446500345618432,
  "created_at" : "Wed Jan 30 02:35:28 +0000 2013",
  "user" : {
    "name" : "Felix",
    "screen_name" : "nicidienase",
    "protected" : false,
    "id_str" : "22396883",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3125784966/8223a4c5c9535be22d15c82ec829c2df_normal.jpeg",
    "id" : 22396883,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "295222147893317632",
  "text" : "OH: \"Im Real kann man diese Eich.., Ein.., Einh\u00F6rnchen kaufen!\"",
  "id" : 295222147893317632,
  "created_at" : "Sat Jan 26 17:30:19 +0000 2013",
  "user" : {
    "name" : "Felix",
    "screen_name" : "nicidienase",
    "protected" : false,
    "id_str" : "22396883",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3125784966/8223a4c5c9535be22d15c82ec829c2df_normal.jpeg",
    "id" : 22396883,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.tweetlanes.com\" rel=\"nofollow\">Tweet Lanes for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tim Weber",
      "screen_name" : "scy",
      "indices" : [ 3, 7 ],
      "id_str" : "8308632",
      "id" : 8308632
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 112, 133 ],
      "url" : "https://t.co/XpmZw7Da",
      "expanded_url" : "https://www.youtube.com/watch?v=qkM6RJf15cg",
      "display_url" : "youtube.com/watch?v=qkM6RJ\u2026"
    } ]
  },
  "geo" : {
  },
  "id_str" : "294795970825297921",
  "text" : "RT @scy: Der Internet\u00A0Explorer h\u00E4tte gern eine zweite Chance bei euch und hat ein r\u00FChrendes Imagevideo gemacht. https://t.co/XpmZw7Da (v ...",
  "retweeted_status" : {
    "source" : "<a href=\"http://www.tweetdeck.com\" rel=\"nofollow\">TweetDeck</a>",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Frank M.",
        "screen_name" : "B00N",
        "indices" : [ 130, 135 ],
        "id_str" : "18940999",
        "id" : 18940999
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 103, 124 ],
        "url" : "https://t.co/XpmZw7Da",
        "expanded_url" : "https://www.youtube.com/watch?v=qkM6RJf15cg",
        "display_url" : "youtube.com/watch?v=qkM6RJ\u2026"
      } ]
    },
    "geo" : {
    },
    "id_str" : "294577070451863552",
    "text" : "Der Internet\u00A0Explorer h\u00E4tte gern eine zweite Chance bei euch und hat ein r\u00FChrendes Imagevideo gemacht. https://t.co/XpmZw7Da (via @B00N)",
    "id" : 294577070451863552,
    "created_at" : "Thu Jan 24 22:47:01 +0000 2013",
    "user" : {
      "name" : "Tim Weber",
      "screen_name" : "scy",
      "protected" : false,
      "id_str" : "8308632",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/424137519/avatar184_normal.jpg",
      "id" : 8308632,
      "verified" : false
    }
  },
  "id" : 294795970825297921,
  "created_at" : "Fri Jan 25 13:16:51 +0000 2013",
  "user" : {
    "name" : "Felix",
    "screen_name" : "nicidienase",
    "protected" : false,
    "id_str" : "22396883",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3125784966/8223a4c5c9535be22d15c82ec829c2df_normal.jpeg",
    "id" : 22396883,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.tweetlanes.com\" rel=\"nofollow\">Tweet Lanes for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Bastian Greshake",
      "screen_name" : "gedankenstuecke",
      "indices" : [ 3, 19 ],
      "id_str" : "14286491",
      "id" : 14286491
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 51, 71 ],
      "url" : "http://t.co/gOpmfoSU",
      "expanded_url" : "http://boingboing.net/2013/01/24/worlds-funniest-video-about.html?utm_source=feedburner&utm_medium=feed&utm_campaign=Feed%3A+boingboing%2FiBag+%28Boing+Boing%29",
      "display_url" : "boingboing.net/2013/01/24/wor\u2026"
    } ]
  },
  "geo" : {
  },
  "id_str" : "294795186373025795",
  "text" : "RT @gedankenstuecke: How (not) to build a rail gun http://t.co/gOpmfoSU",
  "retweeted_status" : {
    "source" : "<a href=\"http://tapbots.com/software/tweetbot/mac\" rel=\"nofollow\">Tweetbot for Mac</a>",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 30, 50 ],
        "url" : "http://t.co/gOpmfoSU",
        "expanded_url" : "http://boingboing.net/2013/01/24/worlds-funniest-video-about.html?utm_source=feedburner&utm_medium=feed&utm_campaign=Feed%3A+boingboing%2FiBag+%28Boing+Boing%29",
        "display_url" : "boingboing.net/2013/01/24/wor\u2026"
      } ]
    },
    "geo" : {
    },
    "id_str" : "294566935104983040",
    "text" : "How (not) to build a rail gun http://t.co/gOpmfoSU",
    "id" : 294566935104983040,
    "created_at" : "Thu Jan 24 22:06:44 +0000 2013",
    "user" : {
      "name" : "Bastian Greshake",
      "screen_name" : "gedankenstuecke",
      "protected" : false,
      "id_str" : "14286491",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/2466316198/7D66C55E-2643-4F71-8115-B524A7B8E72F_normal",
      "id" : 14286491,
      "verified" : false
    }
  },
  "id" : 294795186373025795,
  "created_at" : "Fri Jan 25 13:13:44 +0000 2013",
  "user" : {
    "name" : "Felix",
    "screen_name" : "nicidienase",
    "protected" : false,
    "id_str" : "22396883",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3125784966/8223a4c5c9535be22d15c82ec829c2df_normal.jpeg",
    "id" : 22396883,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.tweetlanes.com\" rel=\"nofollow\">Tweet Lanes for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mike Perham",
      "screen_name" : "mperham",
      "indices" : [ 3, 11 ],
      "id_str" : "14060922",
      "id" : 14060922
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 40, 61 ],
      "url" : "https://t.co/AlFmv95N",
      "expanded_url" : "https://github.com/search?q=path%3A.ssh%2Fid_rsa&type=Code&ref=searchresults",
      "display_url" : "github.com/search?q=path%\u2026"
    } ]
  },
  "geo" : {
  },
  "id_str" : "294369283654447104",
  "text" : "RT @mperham: Free private keys for all! https://t.co/AlFmv95N",
  "retweeted_status" : {
    "source" : "<a href=\"http://twitterrific.com\" rel=\"nofollow\">Twitterrific for Mac</a>",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 27, 48 ],
        "url" : "https://t.co/AlFmv95N",
        "expanded_url" : "https://github.com/search?q=path%3A.ssh%2Fid_rsa&type=Code&ref=searchresults",
        "display_url" : "github.com/search?q=path%\u2026"
      } ]
    },
    "geo" : {
    },
    "id_str" : "294187500648407042",
    "text" : "Free private keys for all! https://t.co/AlFmv95N",
    "id" : 294187500648407042,
    "created_at" : "Wed Jan 23 20:59:00 +0000 2013",
    "user" : {
      "name" : "Mike Perham",
      "screen_name" : "mperham",
      "protected" : false,
      "id_str" : "14060922",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/1531638646/headshot_normal.jpg",
      "id" : 14060922,
      "verified" : false
    }
  },
  "id" : 294369283654447104,
  "created_at" : "Thu Jan 24 09:01:20 +0000 2013",
  "user" : {
    "name" : "Felix",
    "screen_name" : "nicidienase",
    "protected" : false,
    "id_str" : "22396883",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3125784966/8223a4c5c9535be22d15c82ec829c2df_normal.jpeg",
    "id" : 22396883,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sput",
      "screen_name" : "Sput",
      "indices" : [ 0, 5 ],
      "id_str" : "8725542",
      "id" : 8725542
    }, {
      "name" : "Uwe Lancier",
      "screen_name" : "Ulan_ka",
      "indices" : [ 11, 19 ],
      "id_str" : "379173142",
      "id" : 379173142
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "293468001804619777",
  "in_reply_to_user_id" : 8725542,
  "text" : "@Sput Laut @Ulan_ka haben wir dir unseren neuen Trockner zu verdanken. DANKE \\o/",
  "id" : 293468001804619777,
  "created_at" : "Mon Jan 21 21:19:58 +0000 2013",
  "in_reply_to_screen_name" : "Sput",
  "in_reply_to_user_id_str" : "8725542",
  "user" : {
    "name" : "Felix",
    "screen_name" : "nicidienase",
    "protected" : false,
    "id_str" : "22396883",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3125784966/8223a4c5c9535be22d15c82ec829c2df_normal.jpeg",
    "id" : 22396883,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.tweetlanes.com\" rel=\"nofollow\">Tweet Lanes for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Del Angharad",
      "screen_name" : "WelshPixie",
      "indices" : [ 3, 14 ],
      "id_str" : "25035622",
      "id" : 25035622
    } ],
    "media" : [ {
      "expanded_url" : "http://twitter.com/WelshPixie/status/291957241974779906/photo/1",
      "indices" : [ 91, 111 ],
      "url" : "http://t.co/XI8GA4Cu",
      "media_url" : "http://pbs.twimg.com/media/BA09kJICcAALBdY.jpg",
      "id_str" : "291957241983168512",
      "id" : 291957241983168512,
      "media_url_https" : "https://pbs.twimg.com/media/BA09kJICcAALBdY.jpg",
      "sizes" : [ {
        "h" : 419,
        "resize" : "fit",
        "w" : 525
      }, {
        "h" : 419,
        "resize" : "fit",
        "w" : 525
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 419,
        "resize" : "fit",
        "w" : 525
      }, {
        "h" : 271,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com/XI8GA4Cu"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "292416174334046208",
  "text" : "RT @WelshPixie: I'm tweeting this again because I made it, and dammit, I think it's funny. http://t.co/XI8GA4Cu",
  "retweeted_status" : {
    "source" : "web",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "http://twitter.com/WelshPixie/status/291957241974779906/photo/1",
        "indices" : [ 75, 95 ],
        "url" : "http://t.co/XI8GA4Cu",
        "media_url" : "http://pbs.twimg.com/media/BA09kJICcAALBdY.jpg",
        "id_str" : "291957241983168512",
        "id" : 291957241983168512,
        "media_url_https" : "https://pbs.twimg.com/media/BA09kJICcAALBdY.jpg",
        "sizes" : [ {
          "h" : 419,
          "resize" : "fit",
          "w" : 525
        }, {
          "h" : 419,
          "resize" : "fit",
          "w" : 525
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 419,
          "resize" : "fit",
          "w" : 525
        }, {
          "h" : 271,
          "resize" : "fit",
          "w" : 340
        } ],
        "display_url" : "pic.twitter.com/XI8GA4Cu"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : {
    },
    "id_str" : "291957241974779906",
    "text" : "I'm tweeting this again because I made it, and dammit, I think it's funny. http://t.co/XI8GA4Cu",
    "id" : 291957241974779906,
    "created_at" : "Thu Jan 17 17:16:45 +0000 2013",
    "user" : {
      "name" : "Del Angharad",
      "screen_name" : "WelshPixie",
      "protected" : false,
      "id_str" : "25035622",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/2629468201/3d885be2c8c1c1fe8703f7d487e8deda_normal.jpeg",
      "id" : 25035622,
      "verified" : false
    }
  },
  "id" : 292416174334046208,
  "created_at" : "Fri Jan 18 23:40:23 +0000 2013",
  "user" : {
    "name" : "Felix",
    "screen_name" : "nicidienase",
    "protected" : false,
    "id_str" : "22396883",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3125784966/8223a4c5c9535be22d15c82ec829c2df_normal.jpeg",
    "id" : 22396883,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.tweetlanes.com\" rel=\"nofollow\">Tweet Lanes for Android</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http://twitter.com/nicidienase/status/292352843124453376/photo/1",
      "indices" : [ 30, 50 ],
      "url" : "http://t.co/IUKBdDIS",
      "media_url" : "http://pbs.twimg.com/media/BA6lXKQCMAAc9yD.jpg",
      "id_str" : "292352843132841984",
      "id" : 292352843132841984,
      "media_url_https" : "https://pbs.twimg.com/media/BA6lXKQCMAAc9yD.jpg",
      "sizes" : [ {
        "h" : 450,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 1920,
        "resize" : "fit",
        "w" : 2560
      }, {
        "h" : 768,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 255,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com/IUKBdDIS"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "292352843124453376",
  "text" : "Wie, der Griff is abgegangen? http://t.co/IUKBdDIS",
  "id" : 292352843124453376,
  "created_at" : "Fri Jan 18 19:28:45 +0000 2013",
  "user" : {
    "name" : "Felix",
    "screen_name" : "nicidienase",
    "protected" : false,
    "id_str" : "22396883",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3125784966/8223a4c5c9535be22d15c82ec829c2df_normal.jpeg",
    "id" : 22396883,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.tweetlanes.com\" rel=\"nofollow\">Tweet Lanes for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tim Weber",
      "screen_name" : "scy",
      "indices" : [ 3, 7 ],
      "id_str" : "8308632",
      "id" : 8308632
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "292321440684978176",
  "text" : "RT @scy: Kennt sich hier jemand mit Metafragen aus?",
  "retweeted_status" : {
    "source" : "<a href=\"http://www.tweetdeck.com\" rel=\"nofollow\">TweetDeck</a>",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : {
    },
    "id_str" : "292254166120816640",
    "text" : "Kennt sich hier jemand mit Metafragen aus?",
    "id" : 292254166120816640,
    "created_at" : "Fri Jan 18 12:56:37 +0000 2013",
    "user" : {
      "name" : "Tim Weber",
      "screen_name" : "scy",
      "protected" : false,
      "id_str" : "8308632",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/424137519/avatar184_normal.jpg",
      "id" : 8308632,
      "verified" : false
    }
  },
  "id" : 292321440684978176,
  "created_at" : "Fri Jan 18 17:23:57 +0000 2013",
  "user" : {
    "name" : "Felix",
    "screen_name" : "nicidienase",
    "protected" : false,
    "id_str" : "22396883",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3125784966/8223a4c5c9535be22d15c82ec829c2df_normal.jpeg",
    "id" : 22396883,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.tweetlanes.com\" rel=\"nofollow\">Tweet Lanes for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tim Weber",
      "screen_name" : "scy",
      "indices" : [ 0, 4 ],
      "id_str" : "8308632",
      "id" : 8308632
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "292056901791920128",
  "geo" : {
  },
  "id_str" : "292074939022970880",
  "in_reply_to_user_id" : 8308632,
  "text" : "@scy Ich kenn Leute die ham da eine 0900-Fax-to-Mail Nummer angegeben.",
  "id" : 292074939022970880,
  "in_reply_to_status_id" : 292056901791920128,
  "created_at" : "Fri Jan 18 01:04:26 +0000 2013",
  "in_reply_to_screen_name" : "scy",
  "in_reply_to_user_id_str" : "8308632",
  "user" : {
    "name" : "Felix",
    "screen_name" : "nicidienase",
    "protected" : false,
    "id_str" : "22396883",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3125784966/8223a4c5c9535be22d15c82ec829c2df_normal.jpeg",
    "id" : 22396883,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.tweetlanes.com\" rel=\"nofollow\">Tweet Lanes for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Daniel Weblauscher",
      "screen_name" : "der_weblauscher",
      "indices" : [ 3, 19 ],
      "id_str" : "24051360",
      "id" : 24051360
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "291927380958797826",
  "text" : "RT @der_weblauscher: \u200E+++EILMELDUNG+++ Chuck Norris \u00FCbernimmt die Leitung des Flughafens Berlin Brandenburg. Er\u00F6ffnung ist morgen fr\u00FCh,  ...",
  "retweeted_status" : {
    "source" : "<a href=\"http://www.hootsuite.com\" rel=\"nofollow\">HootSuite</a>",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "ber",
        "indices" : [ 125, 129 ]
      } ],
      "urls" : [ ]
    },
    "geo" : {
    },
    "id_str" : "291894829296779265",
    "text" : "\u200E+++EILMELDUNG+++ Chuck Norris \u00FCbernimmt die Leitung des Flughafens Berlin Brandenburg. Er\u00F6ffnung ist morgen fr\u00FCh, 6:30 Uhr. #ber",
    "id" : 291894829296779265,
    "created_at" : "Thu Jan 17 13:08:45 +0000 2013",
    "user" : {
      "name" : "Daniel Weblauscher",
      "screen_name" : "der_weblauscher",
      "protected" : false,
      "id_str" : "24051360",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/1578250425/daniel_normal.png",
      "id" : 24051360,
      "verified" : false
    }
  },
  "id" : 291927380958797826,
  "created_at" : "Thu Jan 17 15:18:06 +0000 2013",
  "user" : {
    "name" : "Felix",
    "screen_name" : "nicidienase",
    "protected" : false,
    "id_str" : "22396883",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3125784966/8223a4c5c9535be22d15c82ec829c2df_normal.jpeg",
    "id" : 22396883,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "WarFrog",
      "screen_name" : "WarFrog123",
      "indices" : [ 0, 11 ],
      "id_str" : "604042793",
      "id" : 604042793
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "291636441568669696",
  "geo" : {
  },
  "id_str" : "291708133489922048",
  "in_reply_to_user_id" : 604042793,
  "text" : "@WarFrog123 er hatte nach 8h noch 30% und eigentlich h\u00E4tte er beim zu klappen in Standby gehen sollen. Aber das ACPI-Skript war ja kaputt.",
  "id" : 291708133489922048,
  "in_reply_to_status_id" : 291636441568669696,
  "created_at" : "Thu Jan 17 00:46:53 +0000 2013",
  "in_reply_to_screen_name" : "WarFrog123",
  "in_reply_to_user_id_str" : "604042793",
  "user" : {
    "name" : "Felix",
    "screen_name" : "nicidienase",
    "protected" : false,
    "id_str" : "22396883",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3125784966/8223a4c5c9535be22d15c82ec829c2df_normal.jpeg",
    "id" : 22396883,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.tweetlanes.com\" rel=\"nofollow\">Tweet Lanes for Android</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "291634662789500929",
  "text" : "Fuck! Eine Zeile zu viel im ACPI-Skript auskommentiert und den ganzen Tag den laufenden Laptop im Rucksack herum getragen.",
  "id" : 291634662789500929,
  "created_at" : "Wed Jan 16 19:54:56 +0000 2013",
  "user" : {
    "name" : "Felix",
    "screen_name" : "nicidienase",
    "protected" : false,
    "id_str" : "22396883",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3125784966/8223a4c5c9535be22d15c82ec829c2df_normal.jpeg",
    "id" : 22396883,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.tweetlanes.com\" rel=\"nofollow\">Tweet Lanes for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tobias Wolter",
      "screen_name" : "towo",
      "indices" : [ 3, 8 ],
      "id_str" : "14095571",
      "id" : 14095571
    }, {
      "name" : "tante",
      "screen_name" : "tante",
      "indices" : [ 128, 134 ],
      "id_str" : "14179278",
      "id" : 14179278
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 68, 89 ],
      "url" : "https://t.co/KM8yEulH",
      "expanded_url" : "https://www.wolframalpha.com/input/?i=hitler+curve",
      "display_url" : "wolframalpha.com/input/?i=hitle\u2026"
    } ]
  },
  "geo" : {
  },
  "id_str" : "291373844269240320",
  "text" : "RT @towo: WTF des Tages: Wolfram Alpha nach 'Hitler curve' fragen - https://t.co/KM8yEulH | Klappt auch mit anderen Namen. (via @tante)",
  "retweeted_status" : {
    "source" : "web",
    "entities" : {
      "user_mentions" : [ {
        "name" : "tante",
        "screen_name" : "tante",
        "indices" : [ 118, 124 ],
        "id_str" : "14179278",
        "id" : 14179278
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 58, 79 ],
        "url" : "https://t.co/KM8yEulH",
        "expanded_url" : "https://www.wolframalpha.com/input/?i=hitler+curve",
        "display_url" : "wolframalpha.com/input/?i=hitle\u2026"
      } ]
    },
    "geo" : {
    },
    "id_str" : "291160143935188992",
    "text" : "WTF des Tages: Wolfram Alpha nach 'Hitler curve' fragen - https://t.co/KM8yEulH | Klappt auch mit anderen Namen. (via @tante)",
    "id" : 291160143935188992,
    "created_at" : "Tue Jan 15 12:29:22 +0000 2013",
    "user" : {
      "name" : "Tobias Wolter",
      "screen_name" : "towo",
      "protected" : false,
      "id_str" : "14095571",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/2928571431/00c131893b78f2934383aebdec551034_normal.jpeg",
      "id" : 14095571,
      "verified" : false
    }
  },
  "id" : 291373844269240320,
  "created_at" : "Wed Jan 16 02:38:32 +0000 2013",
  "user" : {
    "name" : "Felix",
    "screen_name" : "nicidienase",
    "protected" : false,
    "id_str" : "22396883",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3125784966/8223a4c5c9535be22d15c82ec829c2df_normal.jpeg",
    "id" : 22396883,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.tweetlanes.com\" rel=\"nofollow\">Tweet Lanes for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Hacker News 20",
      "screen_name" : "newsyc20",
      "indices" : [ 3, 12 ],
      "id_str" : "148969874",
      "id" : 148969874
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 63, 83 ],
      "url" : "http://t.co/bhkful7Y",
      "expanded_url" : "http://bit.ly/TVfvXN",
      "display_url" : "bit.ly/TVfvXN"
    }, {
      "indices" : [ 85, 105 ],
      "url" : "http://t.co/il5zyQIB",
      "expanded_url" : "http://bit.ly/TVfyTz",
      "display_url" : "bit.ly/TVfyTz"
    } ]
  },
  "geo" : {
  },
  "id_str" : "290999408273797121",
  "text" : "RT @newsyc20: A Linux users' perspective of Microsoft Windows. http://t.co/bhkful7Y (http://t.co/il5zyQIB)",
  "retweeted_status" : {
    "source" : "<a href=\"http://news.ycombinator.com\" rel=\"nofollow\">newsyc</a>",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 49, 69 ],
        "url" : "http://t.co/bhkful7Y",
        "expanded_url" : "http://bit.ly/TVfvXN",
        "display_url" : "bit.ly/TVfvXN"
      }, {
        "indices" : [ 71, 91 ],
        "url" : "http://t.co/il5zyQIB",
        "expanded_url" : "http://bit.ly/TVfyTz",
        "display_url" : "bit.ly/TVfyTz"
      } ]
    },
    "geo" : {
    },
    "id_str" : "290825608278179841",
    "text" : "A Linux users' perspective of Microsoft Windows. http://t.co/bhkful7Y (http://t.co/il5zyQIB)",
    "id" : 290825608278179841,
    "created_at" : "Mon Jan 14 14:20:02 +0000 2013",
    "user" : {
      "name" : "Hacker News 20",
      "screen_name" : "newsyc20",
      "protected" : false,
      "id_str" : "148969874",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/1081970640/yclogo_normal.gif",
      "id" : 148969874,
      "verified" : false
    }
  },
  "id" : 290999408273797121,
  "created_at" : "Tue Jan 15 01:50:40 +0000 2013",
  "user" : {
    "name" : "Felix",
    "screen_name" : "nicidienase",
    "protected" : false,
    "id_str" : "22396883",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3125784966/8223a4c5c9535be22d15c82ec829c2df_normal.jpeg",
    "id" : 22396883,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.tweetlanes.com\" rel=\"nofollow\">Tweet Lanes for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tim Weber",
      "screen_name" : "scy",
      "indices" : [ 0, 4 ],
      "id_str" : "8308632",
      "id" : 8308632
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "290722911688482816",
  "geo" : {
  },
  "id_str" : "290756292375629824",
  "in_reply_to_user_id" : 8308632,
  "text" : "@scy Liegt vielleicht daran das die die letzten Jahre vor Erwerb der Hochschulreife jeden Kleinkram mit dem Taschenrechner rechnen.",
  "id" : 290756292375629824,
  "in_reply_to_status_id" : 290722911688482816,
  "created_at" : "Mon Jan 14 09:44:36 +0000 2013",
  "in_reply_to_screen_name" : "scy",
  "in_reply_to_user_id_str" : "8308632",
  "user" : {
    "name" : "Felix",
    "screen_name" : "nicidienase",
    "protected" : false,
    "id_str" : "22396883",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3125784966/8223a4c5c9535be22d15c82ec829c2df_normal.jpeg",
    "id" : 22396883,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.tweetlanes.com\" rel=\"nofollow\">Tweet Lanes for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "F. Nord",
      "screen_name" : "rettetdieborg",
      "indices" : [ 21, 35 ],
      "id_str" : "905841942",
      "id" : 905841942
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "290755457079975936",
  "text" : "Ich sekundiere das! \"@rettetdieborg: Ich muss mehr Gelegenheiten finden, mit dem Labcoat rauszugehen.\"",
  "id" : 290755457079975936,
  "created_at" : "Mon Jan 14 09:41:17 +0000 2013",
  "user" : {
    "name" : "Felix",
    "screen_name" : "nicidienase",
    "protected" : false,
    "id_str" : "22396883",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3125784966/8223a4c5c9535be22d15c82ec829c2df_normal.jpeg",
    "id" : 22396883,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.tweetlanes.com\" rel=\"nofollow\">Tweet Lanes for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Bonnie Burton",
      "screen_name" : "bonniegrrl",
      "indices" : [ 3, 14 ],
      "id_str" : "7081402",
      "id" : 7081402
    }, {
      "name" : "Amy Berg",
      "screen_name" : "bergopolis",
      "indices" : [ 111, 122 ],
      "id_str" : "15495464",
      "id" : 15495464
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "StarWars",
      "indices" : [ 123, 132 ]
    } ],
    "urls" : [ {
      "indices" : [ 85, 105 ],
      "url" : "http://t.co/K5NCKdDM",
      "expanded_url" : "http://1.usa.gov/11ohHeR",
      "display_url" : "1.usa.gov/11ohHeR"
    } ]
  },
  "geo" : {
  },
  "id_str" : "290092074676662273",
  "text" : "RT @bonniegrrl: Official White House response to the petition to build a Death Star! http://t.co/K5NCKdDM /via @bergopolis #StarWars",
  "retweeted_status" : {
    "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Amy Berg",
        "screen_name" : "bergopolis",
        "indices" : [ 95, 106 ],
        "id_str" : "15495464",
        "id" : 15495464
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "StarWars",
        "indices" : [ 107, 116 ]
      } ],
      "urls" : [ {
        "indices" : [ 69, 89 ],
        "url" : "http://t.co/K5NCKdDM",
        "expanded_url" : "http://1.usa.gov/11ohHeR",
        "display_url" : "1.usa.gov/11ohHeR"
      } ]
    },
    "geo" : {
    },
    "id_str" : "289960692029718528",
    "text" : "Official White House response to the petition to build a Death Star! http://t.co/K5NCKdDM /via @bergopolis #StarWars",
    "id" : 289960692029718528,
    "created_at" : "Sat Jan 12 05:03:10 +0000 2013",
    "user" : {
      "name" : "Bonnie Burton",
      "screen_name" : "bonniegrrl",
      "protected" : false,
      "id_str" : "7081402",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/66494978/twitterlunchbox_normal.jpg",
      "id" : 7081402,
      "verified" : true
    }
  },
  "id" : 290092074676662273,
  "created_at" : "Sat Jan 12 13:45:14 +0000 2013",
  "user" : {
    "name" : "Felix",
    "screen_name" : "nicidienase",
    "protected" : false,
    "id_str" : "22396883",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3125784966/8223a4c5c9535be22d15c82ec829c2df_normal.jpeg",
    "id" : 22396883,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.tweetlanes.com\" rel=\"nofollow\">Tweet Lanes for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "psy",
      "screen_name" : "psycon",
      "indices" : [ 0, 7 ],
      "id_str" : "87286054",
      "id" : 87286054
    }, {
      "name" : "Sturzelchen.",
      "screen_name" : "randsturz",
      "indices" : [ 8, 18 ],
      "id_str" : "73659102",
      "id" : 73659102
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "289713795264307200",
  "geo" : {
  },
  "id_str" : "289747565518405633",
  "in_reply_to_user_id" : 87286054,
  "text" : "@psycon @randsturz Ich w\u00E4r nicht \u00FCberrascht wenn wir diesen Winter in KA gar keinen Schnee mehr sehen.",
  "id" : 289747565518405633,
  "in_reply_to_status_id" : 289713795264307200,
  "created_at" : "Fri Jan 11 14:56:17 +0000 2013",
  "in_reply_to_screen_name" : "psycon",
  "in_reply_to_user_id_str" : "87286054",
  "user" : {
    "name" : "Felix",
    "screen_name" : "nicidienase",
    "protected" : false,
    "id_str" : "22396883",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3125784966/8223a4c5c9535be22d15c82ec829c2df_normal.jpeg",
    "id" : 22396883,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.tweetlanes.com\" rel=\"nofollow\">Tweet Lanes for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tinuq*in",
      "screen_name" : "tinuqin",
      "indices" : [ 3, 11 ],
      "id_str" : "49586295",
      "id" : 49586295
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 13, 33 ],
      "url" : "http://t.co/HJZIJlOJ",
      "expanded_url" : "http://tinuqin.tumblr.com/post/40011173462/advantages-of-being-a-female-computer-science-student",
      "display_url" : "tinuqin.tumblr.com/post/400111734\u2026"
    } ]
  },
  "geo" : {
  },
  "id_str" : "288739545963442177",
  "text" : "RT @tinuqin: http://t.co/HJZIJlOJ ein paar Gedanken \u00FCber das Leben als weibliche Informatikstudentin",
  "retweeted_status" : {
    "source" : "web",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 0, 20 ],
        "url" : "http://t.co/HJZIJlOJ",
        "expanded_url" : "http://tinuqin.tumblr.com/post/40011173462/advantages-of-being-a-female-computer-science-student",
        "display_url" : "tinuqin.tumblr.com/post/400111734\u2026"
      } ]
    },
    "geo" : {
    },
    "id_str" : "288645202359484416",
    "text" : "http://t.co/HJZIJlOJ ein paar Gedanken \u00FCber das Leben als weibliche Informatikstudentin",
    "id" : 288645202359484416,
    "created_at" : "Tue Jan 08 13:55:53 +0000 2013",
    "user" : {
      "name" : "Tinuq*in",
      "screen_name" : "tinuqin",
      "protected" : false,
      "id_str" : "49586295",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/3472444186/0716f93353681380b42f9d2441409ef1_normal.jpeg",
      "id" : 49586295,
      "verified" : false
    }
  },
  "id" : 288739545963442177,
  "created_at" : "Tue Jan 08 20:10:46 +0000 2013",
  "user" : {
    "name" : "Felix",
    "screen_name" : "nicidienase",
    "protected" : false,
    "id_str" : "22396883",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3125784966/8223a4c5c9535be22d15c82ec829c2df_normal.jpeg",
    "id" : 22396883,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.tweetlanes.com\" rel=\"nofollow\">Tweet Lanes for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tim Weber",
      "screen_name" : "scy",
      "indices" : [ 3, 7 ],
      "id_str" : "8308632",
      "id" : 8308632
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "288586738685853696",
  "text" : "RT @scy: Inline-PGP muss sterben.",
  "retweeted_status" : {
    "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : {
      "type" : "Point",
      "coordinates" : [ 50.1075999, 8.6705784 ]
    },
    "id_str" : "288567590555615232",
    "text" : "Inline-PGP muss sterben.",
    "id" : 288567590555615232,
    "created_at" : "Tue Jan 08 08:47:29 +0000 2013",
    "user" : {
      "name" : "Tim Weber",
      "screen_name" : "scy",
      "protected" : false,
      "id_str" : "8308632",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/424137519/avatar184_normal.jpg",
      "id" : 8308632,
      "verified" : false
    }
  },
  "id" : 288586738685853696,
  "created_at" : "Tue Jan 08 10:03:34 +0000 2013",
  "user" : {
    "name" : "Felix",
    "screen_name" : "nicidienase",
    "protected" : false,
    "id_str" : "22396883",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3125784966/8223a4c5c9535be22d15c82ec829c2df_normal.jpeg",
    "id" : 22396883,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.tweetlanes.com\" rel=\"nofollow\">Tweet Lanes for Android</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "288404239720542208",
  "text" : "Hm, noch 42 Tweets bis zu den 1337 :-)",
  "id" : 288404239720542208,
  "created_at" : "Mon Jan 07 21:58:23 +0000 2013",
  "user" : {
    "name" : "Felix",
    "screen_name" : "nicidienase",
    "protected" : false,
    "id_str" : "22396883",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3125784966/8223a4c5c9535be22d15c82ec829c2df_normal.jpeg",
    "id" : 22396883,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.tweetlanes.com\" rel=\"nofollow\">Tweet Lanes for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Not Safe For Work",
      "screen_name" : "me_nsfw",
      "indices" : [ 0, 8 ],
      "id_str" : "198895800",
      "id" : 198895800
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "288395153687863297",
  "geo" : {
  },
  "id_str" : "288400471280984064",
  "in_reply_to_user_id" : 198895800,
  "text" : "@me_nsfw Ich find da keinen MP3-Feed. Bin ich blind?",
  "id" : 288400471280984064,
  "in_reply_to_status_id" : 288395153687863297,
  "created_at" : "Mon Jan 07 21:43:25 +0000 2013",
  "in_reply_to_screen_name" : "me_nsfw",
  "in_reply_to_user_id_str" : "198895800",
  "user" : {
    "name" : "Felix",
    "screen_name" : "nicidienase",
    "protected" : false,
    "id_str" : "22396883",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3125784966/8223a4c5c9535be22d15c82ec829c2df_normal.jpeg",
    "id" : 22396883,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.tweetlanes.com\" rel=\"nofollow\">Tweet Lanes for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "m.",
      "screen_name" : "ohaimareiki",
      "indices" : [ 0, 12 ],
      "id_str" : "14732096",
      "id" : 14732096
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "288374768586084353",
  "geo" : {
  },
  "id_str" : "288375942345273344",
  "in_reply_to_user_id" : 14732096,
  "text" : "@ohaimareiki \u201EBildung kommt von Bildschirm und nicht von Buch, sonst hie\u00DFe es ja Buchung.\u201C\nDieter Hildebrandt",
  "id" : 288375942345273344,
  "in_reply_to_status_id" : 288374768586084353,
  "created_at" : "Mon Jan 07 20:05:57 +0000 2013",
  "in_reply_to_screen_name" : "ohaimareiki",
  "in_reply_to_user_id_str" : "14732096",
  "user" : {
    "name" : "Felix",
    "screen_name" : "nicidienase",
    "protected" : false,
    "id_str" : "22396883",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3125784966/8223a4c5c9535be22d15c82ec829c2df_normal.jpeg",
    "id" : 22396883,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.tweetlanes.com\" rel=\"nofollow\">Tweet Lanes for Android</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "288345249049370624",
  "text" : "Da trinkt man ein paar Tage kein Koffein und schon wird man von nem Kaffee und ner Mate total hibbelig.",
  "id" : 288345249049370624,
  "created_at" : "Mon Jan 07 18:03:59 +0000 2013",
  "user" : {
    "name" : "Felix",
    "screen_name" : "nicidienase",
    "protected" : false,
    "id_str" : "22396883",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3125784966/8223a4c5c9535be22d15c82ec829c2df_normal.jpeg",
    "id" : 22396883,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.tweetlanes.com\" rel=\"nofollow\">Tweet Lanes for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "plastikstuhl",
      "screen_name" : "plastikstuhl",
      "indices" : [ 3, 16 ],
      "id_str" : "8439572",
      "id" : 8439572
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "25c3",
      "indices" : [ 55, 60 ]
    }, {
      "text" : "wikileaksfilm",
      "indices" : [ 81, 95 ]
    } ],
    "urls" : [ {
      "indices" : [ 96, 116 ],
      "url" : "http://t.co/VyZLUUFH",
      "expanded_url" : "http://flic.kr/p/dJAkzG",
      "display_url" : "flic.kr/p/dJAkzG"
    } ]
  },
  "geo" : {
  },
  "id_str" : "288321056924635136",
  "text" : "RT @plastikstuhl: Bald im Kino: Julian Assange auf dem #25c3 (Abbildung \u00E4hnlich) #wikileaksfilm http://t.co/VyZLUUFH",
  "retweeted_status" : {
    "source" : "<a href=\"http://flickr.com/services/twitter/\" rel=\"nofollow\">Flickr</a>",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "25c3",
        "indices" : [ 37, 42 ]
      }, {
        "text" : "wikileaksfilm",
        "indices" : [ 63, 77 ]
      } ],
      "urls" : [ {
        "indices" : [ 78, 98 ],
        "url" : "http://t.co/VyZLUUFH",
        "expanded_url" : "http://flic.kr/p/dJAkzG",
        "display_url" : "flic.kr/p/dJAkzG"
      } ]
    },
    "geo" : {
    },
    "id_str" : "288301101780983809",
    "text" : "Bald im Kino: Julian Assange auf dem #25c3 (Abbildung \u00E4hnlich) #wikileaksfilm http://t.co/VyZLUUFH",
    "id" : 288301101780983809,
    "created_at" : "Mon Jan 07 15:08:33 +0000 2013",
    "user" : {
      "name" : "plastikstuhl",
      "screen_name" : "plastikstuhl",
      "protected" : false,
      "id_str" : "8439572",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/2853191368/c1f8002da374fe4bc9a08ac1bec8f22c_normal.jpeg",
      "id" : 8439572,
      "verified" : false
    }
  },
  "id" : 288321056924635136,
  "created_at" : "Mon Jan 07 16:27:51 +0000 2013",
  "user" : {
    "name" : "Felix",
    "screen_name" : "nicidienase",
    "protected" : false,
    "id_str" : "22396883",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3125784966/8223a4c5c9535be22d15c82ec829c2df_normal.jpeg",
    "id" : 22396883,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.tweetlanes.com\" rel=\"nofollow\">Tweet Lanes for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "neingeist",
      "screen_name" : "neingeist",
      "indices" : [ 3, 13 ],
      "id_str" : "11193712",
      "id" : 11193712
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 100, 120 ],
      "url" : "http://t.co/dGnCer8L",
      "expanded_url" : "http://de.wikipedia.org/wiki/Figuren_aus_James-Bond-Filmen#Felix_Leiter",
      "display_url" : "de.wikipedia.org/wiki/Figuren_a\u2026"
    } ]
  },
  "geo" : {
  },
  "id_str" : "288302659268653058",
  "text" : "RT @neingeist: \"Felix Leiter ist ein Mitarbeiter des US-amerikanischen Auslands-Geheimdienstes CIA\" http://t.co/dGnCer8L",
  "retweeted_status" : {
    "source" : "web",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 85, 105 ],
        "url" : "http://t.co/dGnCer8L",
        "expanded_url" : "http://de.wikipedia.org/wiki/Figuren_aus_James-Bond-Filmen#Felix_Leiter",
        "display_url" : "de.wikipedia.org/wiki/Figuren_a\u2026"
      } ]
    },
    "geo" : {
    },
    "id_str" : "288300878203609088",
    "text" : "\"Felix Leiter ist ein Mitarbeiter des US-amerikanischen Auslands-Geheimdienstes CIA\" http://t.co/dGnCer8L",
    "id" : 288300878203609088,
    "created_at" : "Mon Jan 07 15:07:40 +0000 2013",
    "user" : {
      "name" : "neingeist",
      "screen_name" : "neingeist",
      "protected" : false,
      "id_str" : "11193712",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/3506751329/a8c317b7b69ff0f8eef00b9cb842cbc0_normal.png",
      "id" : 11193712,
      "verified" : false
    }
  },
  "id" : 288302659268653058,
  "created_at" : "Mon Jan 07 15:14:45 +0000 2013",
  "user" : {
    "name" : "Felix",
    "screen_name" : "nicidienase",
    "protected" : false,
    "id_str" : "22396883",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3125784966/8223a4c5c9535be22d15c82ec829c2df_normal.jpeg",
    "id" : 22396883,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.tweetlanes.com\" rel=\"nofollow\">Tweet Lanes for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "AnSu",
      "screen_name" : "gigasube",
      "indices" : [ 3, 12 ],
      "id_str" : "199200448",
      "id" : 199200448
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "BER",
      "indices" : [ 58, 62 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "288259543199281153",
  "text" : "RT @gigasube: Wer hat Vorschl\u00E4ge f\u00FCr eine Umbennenung des #BER? Ich h\u00E4tte \"Duke Nukem International\" oder \"Amelia Pond Airport\"",
  "retweeted_status" : {
    "source" : "<a href=\"http://turpial.org.ve\" rel=\"nofollow\">Turpial1.6</a>",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "BER",
        "indices" : [ 44, 48 ]
      } ],
      "urls" : [ ]
    },
    "geo" : {
    },
    "id_str" : "288248936559423489",
    "text" : "Wer hat Vorschl\u00E4ge f\u00FCr eine Umbennenung des #BER? Ich h\u00E4tte \"Duke Nukem International\" oder \"Amelia Pond Airport\"",
    "id" : 288248936559423489,
    "created_at" : "Mon Jan 07 11:41:16 +0000 2013",
    "user" : {
      "name" : "AnSu",
      "screen_name" : "gigasube",
      "protected" : false,
      "id_str" : "199200448",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/1195585898/Photo_on_2010-08-07_at_13.01__3_normal.jpg",
      "id" : 199200448,
      "verified" : false
    }
  },
  "id" : 288259543199281153,
  "created_at" : "Mon Jan 07 12:23:25 +0000 2013",
  "user" : {
    "name" : "Felix",
    "screen_name" : "nicidienase",
    "protected" : false,
    "id_str" : "22396883",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3125784966/8223a4c5c9535be22d15c82ec829c2df_normal.jpeg",
    "id" : 22396883,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.tweetlanes.com\" rel=\"nofollow\">Tweet Lanes for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kati K\u00FCrsch",
      "screen_name" : "KatiKuersch",
      "indices" : [ 0, 12 ],
      "id_str" : "46991038",
      "id" : 46991038
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "288221622006059008",
  "in_reply_to_user_id" : 46991038,
  "text" : "@KatiKuersch Leute die Kinder mit sich herumtragen werden nicht so schr\u00E4g angeschaut wie Leute die das mit Katzen machen.",
  "id" : 288221622006059008,
  "created_at" : "Mon Jan 07 09:52:44 +0000 2013",
  "in_reply_to_screen_name" : "KatiKuersch",
  "in_reply_to_user_id_str" : "46991038",
  "user" : {
    "name" : "Felix",
    "screen_name" : "nicidienase",
    "protected" : false,
    "id_str" : "22396883",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3125784966/8223a4c5c9535be22d15c82ec829c2df_normal.jpeg",
    "id" : 22396883,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.tweetlanes.com\" rel=\"nofollow\">Tweet Lanes for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "psy",
      "screen_name" : "psycon",
      "indices" : [ 0, 7 ],
      "id_str" : "87286054",
      "id" : 87286054
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "288214402233151488",
  "in_reply_to_user_id" : 87286054,
  "text" : "@psycon Bist du immer noch auf der Suche nach nem Twitter-Client? Ich probier grade Tweet Lanes aus. Der schaut ganz nett aus.",
  "id" : 288214402233151488,
  "created_at" : "Mon Jan 07 09:24:02 +0000 2013",
  "in_reply_to_screen_name" : "psycon",
  "in_reply_to_user_id_str" : "87286054",
  "user" : {
    "name" : "Felix",
    "screen_name" : "nicidienase",
    "protected" : false,
    "id_str" : "22396883",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3125784966/8223a4c5c9535be22d15c82ec829c2df_normal.jpeg",
    "id" : 22396883,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.tweetlanes.com\" rel=\"nofollow\">Tweet Lanes for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "$(RandomName)",
      "screen_name" : "Ik4ru5",
      "indices" : [ 0, 7 ],
      "id_str" : "48294441",
      "id" : 48294441
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "288207479622471680",
  "geo" : {
  },
  "id_str" : "288208075314327552",
  "in_reply_to_user_id" : 48294441,
  "text" : "@Ik4ru5 ... und dann das Gasleck mal genauer inspizieren.",
  "id" : 288208075314327552,
  "in_reply_to_status_id" : 288207479622471680,
  "created_at" : "Mon Jan 07 08:58:54 +0000 2013",
  "in_reply_to_screen_name" : "Ik4ru5",
  "in_reply_to_user_id_str" : "48294441",
  "user" : {
    "name" : "Felix",
    "screen_name" : "nicidienase",
    "protected" : false,
    "id_str" : "22396883",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3125784966/8223a4c5c9535be22d15c82ec829c2df_normal.jpeg",
    "id" : 22396883,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.tweetlanes.com\" rel=\"nofollow\">Tweet Lanes for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "$(RandomName)",
      "screen_name" : "Ik4ru5",
      "indices" : [ 0, 7 ],
      "id_str" : "48294441",
      "id" : 48294441
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "288195955658985473",
  "geo" : {
  },
  "id_str" : "288207179985604608",
  "in_reply_to_user_id" : 48294441,
  "text" : "@Ik4ru5 Toller Start in die Woche",
  "id" : 288207179985604608,
  "in_reply_to_status_id" : 288195955658985473,
  "created_at" : "Mon Jan 07 08:55:20 +0000 2013",
  "in_reply_to_screen_name" : "Ik4ru5",
  "in_reply_to_user_id_str" : "48294441",
  "user" : {
    "name" : "Felix",
    "screen_name" : "nicidienase",
    "protected" : false,
    "id_str" : "22396883",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3125784966/8223a4c5c9535be22d15c82ec829c2df_normal.jpeg",
    "id" : 22396883,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.tweetlanes.com\" rel=\"nofollow\">Tweet Lanes for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tweet Lanes",
      "screen_name" : "TweetLanes",
      "indices" : [ 0, 11 ],
      "id_str" : "482651243",
      "id" : 482651243
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "287995728645726208",
  "in_reply_to_user_id" : 482651243,
  "text" : "@TweetLanes  If I use TweetLanes on more than one device, do I have to do the 'Free for life'-thing on each device?",
  "id" : 287995728645726208,
  "created_at" : "Sun Jan 06 18:55:07 +0000 2013",
  "in_reply_to_screen_name" : "TweetLanes",
  "in_reply_to_user_id_str" : "482651243",
  "user" : {
    "name" : "Felix",
    "screen_name" : "nicidienase",
    "protected" : false,
    "id_str" : "22396883",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3125784966/8223a4c5c9535be22d15c82ec829c2df_normal.jpeg",
    "id" : 22396883,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "287992160773619712",
  "geo" : {
  },
  "id_str" : "287994654207643648",
  "in_reply_to_user_id" : 121226933,
  "text" : "@NervengiftC Daf\u00FCr kriegt man alle zuk\u00FCnftigen paid-extras kostenlos. Und ich hab das auf mehreren devices installiert.",
  "id" : 287994654207643648,
  "in_reply_to_status_id" : 287992160773619712,
  "created_at" : "Sun Jan 06 18:50:50 +0000 2013",
  "in_reply_to_screen_name" : "nervengiftlabs",
  "in_reply_to_user_id_str" : "121226933",
  "user" : {
    "name" : "Felix",
    "screen_name" : "nicidienase",
    "protected" : false,
    "id_str" : "22396883",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3125784966/8223a4c5c9535be22d15c82ec829c2df_normal.jpeg",
    "id" : 22396883,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.tweetlanes.com\" rel=\"nofollow\">Tweet Lanes for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tweet Lanes",
      "screen_name" : "TweetLanes",
      "indices" : [ 17, 28 ],
      "id_str" : "482651243",
      "id" : 482651243
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 93, 113 ],
      "url" : "http://t.co/iJ3Elrab",
      "expanded_url" : "http://bit.ly/tweetlanes",
      "display_url" : "bit.ly/tweetlanes"
    } ]
  },
  "geo" : {
  },
  "id_str" : "287987574725820416",
  "text" : "I'm checking out @TweetLanes, a brand new Twitter app for Android. Looks pretty cool so far. http://t.co/iJ3Elrab",
  "id" : 287987574725820416,
  "created_at" : "Sun Jan 06 18:22:43 +0000 2013",
  "user" : {
    "name" : "Felix",
    "screen_name" : "nicidienase",
    "protected" : false,
    "id_str" : "22396883",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3125784966/8223a4c5c9535be22d15c82ec829c2df_normal.jpeg",
    "id" : 22396883,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Eva Eichhorn",
      "screen_name" : "MamsellChaos",
      "indices" : [ 3, 16 ],
      "id_str" : "140774041",
      "id" : 140774041
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 58, 78 ],
      "url" : "http://t.co/AaL96fGm",
      "expanded_url" : "http://clockworker.de/cw/2013/01/05/roboter-spielen-ace-of-spades/",
      "display_url" : "clockworker.de/cw/2013/01/05/\u2026"
    } ]
  },
  "geo" : {
  },
  "id_str" : "287722262981918720",
  "text" : "RT @MamsellChaos: hahaha. roboter spielen ace of spades?! http://t.co/AaL96fGm",
  "retweeted_status" : {
    "source" : "<a href=\"http://tapbots.com/software/tweetbot/mac\" rel=\"nofollow\">Tweetbot for Mac</a>",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 40, 60 ],
        "url" : "http://t.co/AaL96fGm",
        "expanded_url" : "http://clockworker.de/cw/2013/01/05/roboter-spielen-ace-of-spades/",
        "display_url" : "clockworker.de/cw/2013/01/05/\u2026"
      } ]
    },
    "geo" : {
    },
    "id_str" : "287674746198425600",
    "text" : "hahaha. roboter spielen ace of spades?! http://t.co/AaL96fGm",
    "id" : 287674746198425600,
    "created_at" : "Sat Jan 05 21:39:38 +0000 2013",
    "user" : {
      "name" : "Eva Eichhorn",
      "screen_name" : "MamsellChaos",
      "protected" : false,
      "id_str" : "140774041",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/3231510280/b59cd7b5771078fb646882e5e5882940_normal.jpeg",
      "id" : 140774041,
      "verified" : false
    }
  },
  "id" : 287722262981918720,
  "created_at" : "Sun Jan 06 00:48:27 +0000 2013",
  "user" : {
    "name" : "Felix",
    "screen_name" : "nicidienase",
    "protected" : false,
    "id_str" : "22396883",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3125784966/8223a4c5c9535be22d15c82ec829c2df_normal.jpeg",
    "id" : 22396883,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "wurstfilme",
      "indices" : [ 12, 23 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "287616944050413568",
  "text" : "Wurst Games #wurstfilme",
  "id" : 287616944050413568,
  "created_at" : "Sat Jan 05 17:49:57 +0000 2013",
  "user" : {
    "name" : "Felix",
    "screen_name" : "nicidienase",
    "protected" : false,
    "id_str" : "22396883",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3125784966/8223a4c5c9535be22d15c82ec829c2df_normal.jpeg",
    "id" : 22396883,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "psy",
      "screen_name" : "psycon",
      "indices" : [ 0, 7 ],
      "id_str" : "87286054",
      "id" : 87286054
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "287312436564992000",
  "geo" : {
  },
  "id_str" : "287368887652200448",
  "in_reply_to_user_id" : 87286054,
  "text" : "@psycon Dann musst du wohl oder \u00FCbel selber einen schreiben. Es gibt ja eh so wenige ...",
  "id" : 287368887652200448,
  "in_reply_to_status_id" : 287312436564992000,
  "created_at" : "Sat Jan 05 01:24:16 +0000 2013",
  "in_reply_to_screen_name" : "psycon",
  "in_reply_to_user_id_str" : "87286054",
  "user" : {
    "name" : "Felix",
    "screen_name" : "nicidienase",
    "protected" : false,
    "id_str" : "22396883",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3125784966/8223a4c5c9535be22d15c82ec829c2df_normal.jpeg",
    "id" : 22396883,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Command Line Magic",
      "screen_name" : "climagic",
      "indices" : [ 3, 12 ],
      "id_str" : "91333167",
      "id" : 91333167
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "287235837299675136",
  "text" : "RT @climagic: Linux sex: date; unzip; strip; touch; mount; yes; etc.. Windows sex: start; explore; reboot; viruscheck; solitaire",
  "retweeted_status" : {
    "source" : "<a href=\"http://suso.suso.org/xulu/Command_Line_Magic\" rel=\"nofollow\">CLI Magic poster</a>",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : {
    },
    "id_str" : "287208100883210241",
    "text" : "Linux sex: date; unzip; strip; touch; mount; yes; etc.. Windows sex: start; explore; reboot; viruscheck; solitaire",
    "id" : 287208100883210241,
    "created_at" : "Fri Jan 04 14:45:21 +0000 2013",
    "user" : {
      "name" : "Command Line Magic",
      "screen_name" : "climagic",
      "protected" : false,
      "id_str" : "91333167",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/535876218/climagic-icon_normal.png",
      "id" : 91333167,
      "verified" : false
    }
  },
  "id" : 287235837299675136,
  "created_at" : "Fri Jan 04 16:35:34 +0000 2013",
  "user" : {
    "name" : "Felix",
    "screen_name" : "nicidienase",
    "protected" : false,
    "id_str" : "22396883",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3125784966/8223a4c5c9535be22d15c82ec829c2df_normal.jpeg",
    "id" : 22396883,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The Atlantic",
      "screen_name" : "TheAtlantic",
      "indices" : [ 3, 15 ],
      "id_str" : "35773039",
      "id" : 35773039
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 107, 127 ],
      "url" : "http://t.co/xwZiCq0d",
      "expanded_url" : "http://theatln.tc/W8lzZE",
      "display_url" : "theatln.tc/W8lzZE"
    } ]
  },
  "geo" : {
  },
  "id_str" : "287197657842208769",
  "text" : "RT @TheAtlantic: William Shatner tweeted at an astronaut\u2014and the astronaut responded with a Star Trek joke http://t.co/xwZiCq0d http://t ...",
  "retweeted_status" : {
    "source" : "<a href=\"http://sproutsocial.com\" rel=\"nofollow\">Sprout Social</a>",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "http://twitter.com/TheAtlantic/status/287038415839576064/photo/1",
        "indices" : [ 111, 131 ],
        "url" : "http://t.co/YvM1fZgA",
        "media_url" : "http://pbs.twimg.com/media/A_vD6x2CQAELIRK.png",
        "id_str" : "287038415847964673",
        "id" : 287038415847964673,
        "media_url_https" : "https://pbs.twimg.com/media/A_vD6x2CQAELIRK.png",
        "sizes" : [ {
          "h" : 186,
          "resize" : "fit",
          "w" : 398
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 186,
          "resize" : "fit",
          "w" : 398
        }, {
          "h" : 159,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 186,
          "resize" : "fit",
          "w" : 398
        } ],
        "display_url" : "pic.twitter.com/YvM1fZgA"
      } ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 90, 110 ],
        "url" : "http://t.co/xwZiCq0d",
        "expanded_url" : "http://theatln.tc/W8lzZE",
        "display_url" : "theatln.tc/W8lzZE"
      } ]
    },
    "geo" : {
    },
    "id_str" : "287038415839576064",
    "text" : "William Shatner tweeted at an astronaut\u2014and the astronaut responded with a Star Trek joke http://t.co/xwZiCq0d http://t.co/YvM1fZgA",
    "id" : 287038415839576064,
    "created_at" : "Fri Jan 04 03:31:06 +0000 2013",
    "user" : {
      "name" : "The Atlantic",
      "screen_name" : "TheAtlantic",
      "protected" : false,
      "id_str" : "35773039",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/1268207868/twitter-icon-main_normal.png",
      "id" : 35773039,
      "verified" : true
    }
  },
  "id" : 287197657842208769,
  "created_at" : "Fri Jan 04 14:03:52 +0000 2013",
  "user" : {
    "name" : "Felix",
    "screen_name" : "nicidienase",
    "protected" : false,
    "id_str" : "22396883",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3125784966/8223a4c5c9535be22d15c82ec829c2df_normal.jpeg",
    "id" : 22396883,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Frank Rieger",
      "screen_name" : "frank_rieger",
      "indices" : [ 3, 16 ],
      "id_str" : "53016156",
      "id" : 53016156
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "29C3",
      "indices" : [ 104, 109 ]
    } ],
    "urls" : [ {
      "indices" : [ 115, 135 ],
      "url" : "http://t.co/CDjrT3nM",
      "expanded_url" : "http://tageshauschaos.blogspot.de/2013/01/mal-luft-machen-und-doch-danke-sagen.html",
      "display_url" : "tageshauschaos.blogspot.de/2013/01/mal-lu\u2026"
    } ]
  },
  "geo" : {
  },
  "id_str" : "287195361997631489",
  "text" : "RT @frank_rieger: Offener Brief einer Congressbesucherin mit besonderen Bed\u00FCrfnissen an den CCC und die #29C3 Orga http://t.co/CDjrT3nM",
  "retweeted_status" : {
    "source" : "web",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "29C3",
        "indices" : [ 86, 91 ]
      } ],
      "urls" : [ {
        "indices" : [ 97, 117 ],
        "url" : "http://t.co/CDjrT3nM",
        "expanded_url" : "http://tageshauschaos.blogspot.de/2013/01/mal-luft-machen-und-doch-danke-sagen.html",
        "display_url" : "tageshauschaos.blogspot.de/2013/01/mal-lu\u2026"
      } ]
    },
    "geo" : {
    },
    "id_str" : "287013832977686529",
    "text" : "Offener Brief einer Congressbesucherin mit besonderen Bed\u00FCrfnissen an den CCC und die #29C3 Orga http://t.co/CDjrT3nM",
    "id" : 287013832977686529,
    "created_at" : "Fri Jan 04 01:53:24 +0000 2013",
    "user" : {
      "name" : "Frank Rieger",
      "screen_name" : "frank_rieger",
      "protected" : false,
      "id_str" : "53016156",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/293948630/twitter_icon_normal.JPG",
      "id" : 53016156,
      "verified" : false
    }
  },
  "id" : 287195361997631489,
  "created_at" : "Fri Jan 04 13:54:44 +0000 2013",
  "user" : {
    "name" : "Felix",
    "screen_name" : "nicidienase",
    "protected" : false,
    "id_str" : "22396883",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3125784966/8223a4c5c9535be22d15c82ec829c2df_normal.jpeg",
    "id" : 22396883,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "29c3",
      "indices" : [ 39, 44 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 20 ],
      "url" : "http://t.co/HJXuA7pn",
      "expanded_url" : "http://fun.drno.de/pics/who-thinks-what/ccc.jpg",
      "display_url" : "fun.drno.de/pics/who-think\u2026"
    } ]
  },
  "geo" : {
  },
  "id_str" : "286600910984060928",
  "text" : "http://t.co/HJXuA7pn Seems about right #29c3",
  "id" : 286600910984060928,
  "created_at" : "Wed Jan 02 22:32:36 +0000 2013",
  "user" : {
    "name" : "Felix",
    "screen_name" : "nicidienase",
    "protected" : false,
    "id_str" : "22396883",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3125784966/8223a4c5c9535be22d15c82ec829c2df_normal.jpeg",
    "id" : 22396883,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Frank M.",
      "screen_name" : "B00N",
      "indices" : [ 3, 8 ],
      "id_str" : "18940999",
      "id" : 18940999
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 63, 83 ],
      "url" : "http://t.co/veF4LBpy",
      "expanded_url" : "http://www.youtube.com/watch?v=CxDE2vskyms",
      "display_url" : "youtube.com/watch?v=CxDE2v\u2026"
    } ]
  },
  "geo" : {
  },
  "id_str" : "286572730357260288",
  "text" : "RT @B00N: Worf Losing it - Star Trek Next Generation Outtakes: http://t.co/veF4LBpy",
  "retweeted_status" : {
    "source" : "<a href=\"http://www.tweetdeck.com\" rel=\"nofollow\">TweetDeck</a>",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 53, 73 ],
        "url" : "http://t.co/veF4LBpy",
        "expanded_url" : "http://www.youtube.com/watch?v=CxDE2vskyms",
        "display_url" : "youtube.com/watch?v=CxDE2v\u2026"
      } ]
    },
    "geo" : {
    },
    "id_str" : "286559399139495936",
    "text" : "Worf Losing it - Star Trek Next Generation Outtakes: http://t.co/veF4LBpy",
    "id" : 286559399139495936,
    "created_at" : "Wed Jan 02 19:47:39 +0000 2013",
    "user" : {
      "name" : "Frank M.",
      "screen_name" : "B00N",
      "protected" : false,
      "id_str" : "18940999",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/2360026676/pff1whtmobq8xcps0qvq_normal.jpeg",
      "id" : 18940999,
      "verified" : false
    }
  },
  "id" : 286572730357260288,
  "created_at" : "Wed Jan 02 20:40:37 +0000 2013",
  "user" : {
    "name" : "Felix",
    "screen_name" : "nicidienase",
    "protected" : false,
    "id_str" : "22396883",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3125784966/8223a4c5c9535be22d15c82ec829c2df_normal.jpeg",
    "id" : 22396883,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "F. Nord",
      "screen_name" : "rettetdieborg",
      "indices" : [ 3, 17 ],
      "id_str" : "905841942",
      "id" : 905841942
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "286469511064985600",
  "text" : "RT @rettetdieborg: look at my labcoat, my labcoat's amazing! give it a lick!",
  "retweeted_status" : {
    "source" : "web",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : {
    },
    "id_str" : "286286825574768640",
    "text" : "look at my labcoat, my labcoat's amazing! give it a lick!",
    "id" : 286286825574768640,
    "created_at" : "Wed Jan 02 01:44:32 +0000 2013",
    "user" : {
      "name" : "F. Nord",
      "screen_name" : "rettetdieborg",
      "protected" : false,
      "id_str" : "905841942",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/2766587981/fe0849952b70b8678b474bc63acc50c0_normal.jpeg",
      "id" : 905841942,
      "verified" : false
    }
  },
  "id" : 286469511064985600,
  "created_at" : "Wed Jan 02 13:50:28 +0000 2013",
  "user" : {
    "name" : "Felix",
    "screen_name" : "nicidienase",
    "protected" : false,
    "id_str" : "22396883",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3125784966/8223a4c5c9535be22d15c82ec829c2df_normal.jpeg",
    "id" : 22396883,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http://twitter.com/nicidienase/status/286128106773835777/photo/1",
      "indices" : [ 23, 43 ],
      "url" : "http://t.co/ELVtpr8e",
      "media_url" : "http://pbs.twimg.com/media/A_iH_0TCcAEpidW.jpg",
      "id_str" : "286128106778030081",
      "id" : 286128106778030081,
      "media_url_https" : "https://pbs.twimg.com/media/A_iH_0TCcAEpidW.jpg",
      "sizes" : [ {
        "h" : 1365,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 2560,
        "resize" : "fit",
        "w" : 1920
      }, {
        "h" : 453,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 800,
        "resize" : "fit",
        "w" : 600
      } ],
      "display_url" : "pic.twitter.com/ELVtpr8e"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "286128106773835777",
  "text" : "Yeay, neues Spielzeug. http://t.co/ELVtpr8e",
  "id" : 286128106773835777,
  "created_at" : "Tue Jan 01 15:13:52 +0000 2013",
  "user" : {
    "name" : "Felix",
    "screen_name" : "nicidienase",
    "protected" : false,
    "id_str" : "22396883",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3125784966/8223a4c5c9535be22d15c82ec829c2df_normal.jpeg",
    "id" : 22396883,
    "verified" : false
  }
} ]