Grailbird.data.tweets_2012_09 = 
 [ {
  "source" : "<a href=\"https://play.google.com/store/apps/details?id=org.mariotaku.twidere\" rel=\"nofollow\">Twidere for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Der Postillon",
      "screen_name" : "Der_Postillon",
      "indices" : [ 3, 17 ],
      "id_str" : "105554801",
      "id" : 105554801
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "newstweet",
      "indices" : [ 119, 129 ]
    } ],
    "urls" : [ {
      "indices" : [ 97, 117 ],
      "url" : "http://t.co/rfe5Fc6C",
      "expanded_url" : "http://www.der-postillon.com/2012/09/newsticker-364.html",
      "display_url" : "der-postillon.com/2012/09/newsti\u2026"
    } ]
  },
  "geo" : {
  },
  "id_str" : "252345390052024320",
  "text" : "RT @Der_Postillon: ++++ Malware: Hacker nutzen Sicherheitsl\u00FCcke in Paint ++++ (Newsticker (364): http://t.co/rfe5Fc6C) #newstweet",
  "retweeted_status" : {
    "source" : "web",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "newstweet",
        "indices" : [ 100, 110 ]
      } ],
      "urls" : [ {
        "indices" : [ 78, 98 ],
        "url" : "http://t.co/rfe5Fc6C",
        "expanded_url" : "http://www.der-postillon.com/2012/09/newsticker-364.html",
        "display_url" : "der-postillon.com/2012/09/newsti\u2026"
      } ]
    },
    "geo" : {
    },
    "id_str" : "249056362439520257",
    "text" : "++++ Malware: Hacker nutzen Sicherheitsl\u00FCcke in Paint ++++ (Newsticker (364): http://t.co/rfe5Fc6C) #newstweet",
    "id" : 249056362439520257,
    "created_at" : "Fri Sep 21 08:03:58 +0000 2012",
    "user" : {
      "name" : "Der Postillon",
      "screen_name" : "Der_Postillon",
      "protected" : false,
      "id_str" : "105554801",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/1274516114/Twitterpferd_normal.jpg",
      "id" : 105554801,
      "verified" : false
    }
  },
  "id" : 252345390052024320,
  "created_at" : "Sun Sep 30 09:53:23 +0000 2012",
  "user" : {
    "name" : "Felix",
    "screen_name" : "nicidienase",
    "protected" : false,
    "id_str" : "22396883",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3125784966/8223a4c5c9535be22d15c82ec829c2df_normal.jpeg",
    "id" : 22396883,
    "verified" : false
  }
}, {
  "source" : "<a href=\"https://play.google.com/store/apps/details?id=org.mariotaku.twidere\" rel=\"nofollow\">Twidere for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Andrew Ducker",
      "screen_name" : "andrewducker",
      "indices" : [ 3, 16 ],
      "id_str" : "9221622",
      "id" : 9221622
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 108, 128 ],
      "url" : "http://t.co/hKBWFmNP",
      "expanded_url" : "http://bit.ly/Qx8DOG",
      "display_url" : "bit.ly/Qx8DOG"
    } ]
  },
  "geo" : {
  },
  "id_str" : "252028235938926592",
  "text" : "RT @andrewducker: Today we celebrate Petrov Day - the man who decided not to destroy the world (No, really) http://t.co/hKBWFmNP",
  "retweeted_status" : {
    "source" : "<a href=\"http://bufferapp.com\" rel=\"nofollow\">Buffer</a>",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 90, 110 ],
        "url" : "http://t.co/hKBWFmNP",
        "expanded_url" : "http://bit.ly/Qx8DOG",
        "display_url" : "bit.ly/Qx8DOG"
      } ]
    },
    "geo" : {
    },
    "id_str" : "250935427236765696",
    "text" : "Today we celebrate Petrov Day - the man who decided not to destroy the world (No, really) http://t.co/hKBWFmNP",
    "id" : 250935427236765696,
    "created_at" : "Wed Sep 26 12:30:42 +0000 2012",
    "user" : {
      "name" : "Andrew Ducker",
      "screen_name" : "andrewducker",
      "protected" : false,
      "id_str" : "9221622",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/1368148893/10d2f243-80e1-47fc-bdf6-dd9f13281c67_normal.jpg",
      "id" : 9221622,
      "verified" : false
    }
  },
  "id" : 252028235938926592,
  "created_at" : "Sat Sep 29 12:53:08 +0000 2012",
  "user" : {
    "name" : "Felix",
    "screen_name" : "nicidienase",
    "protected" : false,
    "id_str" : "22396883",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3125784966/8223a4c5c9535be22d15c82ec829c2df_normal.jpeg",
    "id" : 22396883,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.echofon.com/\" rel=\"nofollow\">Echofon</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "251691187768012800",
  "text" : "OH: \"Wann fahrn wir los?\" \"W\u00FCrd sagen relativ fr\u00FCh. So um 12?\"",
  "id" : 251691187768012800,
  "created_at" : "Fri Sep 28 14:33:50 +0000 2012",
  "user" : {
    "name" : "Felix",
    "screen_name" : "nicidienase",
    "protected" : false,
    "id_str" : "22396883",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3125784966/8223a4c5c9535be22d15c82ec829c2df_normal.jpeg",
    "id" : 22396883,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.echofon.com/\" rel=\"nofollow\">Echofon</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Praxisnachbereitung",
      "indices" : [ 41, 61 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "250869790527348736",
  "text" : "Arrg, kann mich bitte jemand erschie\u00DFen. #Praxisnachbereitung",
  "id" : 250869790527348736,
  "created_at" : "Wed Sep 26 08:09:53 +0000 2012",
  "user" : {
    "name" : "Felix",
    "screen_name" : "nicidienase",
    "protected" : false,
    "id_str" : "22396883",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3125784966/8223a4c5c9535be22d15c82ec829c2df_normal.jpeg",
    "id" : 22396883,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http://twitter.com/nicidienase/status/249187142474027008/photo/1",
      "indices" : [ 6, 26 ],
      "url" : "http://t.co/LUONW0Oh",
      "media_url" : "http://pbs.twimg.com/media/A3VKYsYCUAATskL.jpg",
      "id_str" : "249187142478221312",
      "id" : 249187142478221312,
      "media_url_https" : "https://pbs.twimg.com/media/A3VKYsYCUAATskL.jpg",
      "sizes" : [ {
        "h" : 450,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 1920,
        "resize" : "fit",
        "w" : 2560
      }, {
        "h" : 768,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 255,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com/LUONW0Oh"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 49.0151806, 8.392916 ]
  },
  "id_str" : "249187142474027008",
  "text" : "Babe. http://t.co/LUONW0Oh",
  "id" : 249187142474027008,
  "created_at" : "Fri Sep 21 16:43:40 +0000 2012",
  "user" : {
    "name" : "Felix",
    "screen_name" : "nicidienase",
    "protected" : false,
    "id_str" : "22396883",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3125784966/8223a4c5c9535be22d15c82ec829c2df_normal.jpeg",
    "id" : 22396883,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0541744, 8.5853523 ]
  },
  "id_str" : "247388911217827840",
  "text" : "Zur\u00FCck in Deutschland. Mal schauen ob ich mich daran gew\u00F6hnen kann dass es hier viel weniger h\u00FCbsche, rothaarige Frauen gibt als in Irland.",
  "id" : 247388911217827840,
  "created_at" : "Sun Sep 16 17:38:07 +0000 2012",
  "user" : {
    "name" : "Felix",
    "screen_name" : "nicidienase",
    "protected" : false,
    "id_str" : "22396883",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3125784966/8223a4c5c9535be22d15c82ec829c2df_normal.jpeg",
    "id" : 22396883,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://instagram.com\" rel=\"nofollow\">Instagram</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 19, 39 ],
      "url" : "http://t.co/z2E3GYiF",
      "expanded_url" : "http://instagr.am/p/PaDbgvl0bB/",
      "display_url" : "instagr.am/p/PaDbgvl0bB/"
    } ]
  },
  "geo" : {
  },
  "id_str" : "245247492571156480",
  "text" : "Baileys Cheesecake http://t.co/z2E3GYiF",
  "id" : 245247492571156480,
  "created_at" : "Mon Sep 10 19:48:53 +0000 2012",
  "user" : {
    "name" : "Felix",
    "screen_name" : "nicidienase",
    "protected" : false,
    "id_str" : "22396883",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3125784966/8223a4c5c9535be22d15c82ec829c2df_normal.jpeg",
    "id" : 22396883,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://instagram.com\" rel=\"nofollow\">Instagram</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 22, 42 ],
      "url" : "http://t.co/oQpwjNfr",
      "expanded_url" : "http://instagr.am/p/PaC9TVl0as/",
      "display_url" : "instagr.am/p/PaC9TVl0as/"
    } ]
  },
  "geo" : {
  },
  "id_str" : "245246473099436032",
  "text" : "Hot Chocolate Pudding http://t.co/oQpwjNfr",
  "id" : 245246473099436032,
  "created_at" : "Mon Sep 10 19:44:50 +0000 2012",
  "user" : {
    "name" : "Felix",
    "screen_name" : "nicidienase",
    "protected" : false,
    "id_str" : "22396883",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3125784966/8223a4c5c9535be22d15c82ec829c2df_normal.jpeg",
    "id" : 22396883,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://instagram.com\" rel=\"nofollow\">Instagram</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 18, 38 ],
      "url" : "http://t.co/qyigjsws",
      "expanded_url" : "http://instagr.am/p/PaCEoEl0aD/",
      "display_url" : "instagr.am/p/PaCEoEl0aD/"
    } ]
  },
  "geo" : {
  },
  "id_str" : "245244337049464832",
  "text" : "Irish Beef Burger http://t.co/qyigjsws",
  "id" : 245244337049464832,
  "created_at" : "Mon Sep 10 19:36:21 +0000 2012",
  "user" : {
    "name" : "Felix",
    "screen_name" : "nicidienase",
    "protected" : false,
    "id_str" : "22396883",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3125784966/8223a4c5c9535be22d15c82ec829c2df_normal.jpeg",
    "id" : 22396883,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http://twitter.com/nicidienase/status/244736466754883584/photo/1",
      "indices" : [ 17, 37 ],
      "url" : "http://t.co/GNjIv1nX",
      "media_url" : "http://pbs.twimg.com/media/A2V6hRSCUAEwnhT.jpg",
      "id_str" : "244736466754883585",
      "id" : 244736466754883585,
      "media_url_https" : "https://pbs.twimg.com/media/A2V6hRSCUAEwnhT.jpg",
      "sizes" : [ {
        "h" : 1365,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 2560,
        "resize" : "fit",
        "w" : 1920
      }, {
        "h" : 453,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 800,
        "resize" : "fit",
        "w" : 600
      } ],
      "display_url" : "pic.twitter.com/GNjIv1nX"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "244736466754883584",
  "text" : "X marks the spot http://t.co/GNjIv1nX",
  "id" : 244736466754883584,
  "created_at" : "Sun Sep 09 09:58:17 +0000 2012",
  "user" : {
    "name" : "Felix",
    "screen_name" : "nicidienase",
    "protected" : false,
    "id_str" : "22396883",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3125784966/8223a4c5c9535be22d15c82ec829c2df_normal.jpeg",
    "id" : 22396883,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.echofon.com/\" rel=\"nofollow\">Echofon</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Michael Bukowski",
      "screen_name" : "mbukowski",
      "indices" : [ 3, 13 ],
      "id_str" : "21085351",
      "id" : 21085351
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 65, 85 ],
      "url" : "http://t.co/Am4A0qnH",
      "expanded_url" : "http://twitpic.com/as4c96",
      "display_url" : "twitpic.com/as4c96"
    } ]
  },
  "geo" : {
  },
  "id_str" : "244435439736459264",
  "text" : "RT @mbukowski: Ach, wie nett, mal wieder ein Artikel im Spiegel: http://t.co/Am4A0qnH",
  "retweeted_status" : {
    "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 50, 70 ],
        "url" : "http://t.co/Am4A0qnH",
        "expanded_url" : "http://twitpic.com/as4c96",
        "display_url" : "twitpic.com/as4c96"
      } ]
    },
    "geo" : {
    },
    "id_str" : "244161868871110656",
    "text" : "Ach, wie nett, mal wieder ein Artikel im Spiegel: http://t.co/Am4A0qnH",
    "id" : 244161868871110656,
    "created_at" : "Fri Sep 07 19:55:00 +0000 2012",
    "user" : {
      "name" : "Michael Bukowski",
      "screen_name" : "mbukowski",
      "protected" : false,
      "id_str" : "21085351",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/1192363777/MB_geschn_normal.jpg",
      "id" : 21085351,
      "verified" : false
    }
  },
  "id" : 244435439736459264,
  "created_at" : "Sat Sep 08 14:02:04 +0000 2012",
  "user" : {
    "name" : "Felix",
    "screen_name" : "nicidienase",
    "protected" : false,
    "id_str" : "22396883",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3125784966/8223a4c5c9535be22d15c82ec829c2df_normal.jpeg",
    "id" : 22396883,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.echofon.com/\" rel=\"nofollow\">Echofon</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Brian R. Bondy",
      "screen_name" : "brianbondy",
      "indices" : [ 3, 14 ],
      "id_str" : "14862647",
      "id" : 14862647
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "244007377236525056",
  "text" : "RT @brianbondy: A programmer goes to the shop to buy some milk. His wife calls and says \"While you're out, get some eggs.\" He never returns.",
  "retweeted_status" : {
    "source" : "web",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : {
    },
    "id_str" : "243056323112095744",
    "text" : "A programmer goes to the shop to buy some milk. His wife calls and says \"While you're out, get some eggs.\" He never returns.",
    "id" : 243056323112095744,
    "created_at" : "Tue Sep 04 18:41:57 +0000 2012",
    "user" : {
      "name" : "Brian R. Bondy",
      "screen_name" : "brianbondy",
      "protected" : false,
      "id_str" : "14862647",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/351251709/brianbondy_normal.png",
      "id" : 14862647,
      "verified" : false
    }
  },
  "id" : 244007377236525056,
  "created_at" : "Fri Sep 07 09:41:06 +0000 2012",
  "user" : {
    "name" : "Felix",
    "screen_name" : "nicidienase",
    "protected" : false,
    "id_str" : "22396883",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3125784966/8223a4c5c9535be22d15c82ec829c2df_normal.jpeg",
    "id" : 22396883,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.echofon.com/\" rel=\"nofollow\">Echofon</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "i42n",
      "screen_name" : "i42n",
      "indices" : [ 0, 5 ],
      "id_str" : "22298116",
      "id" : 22298116
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "243989733997441024",
  "geo" : {
  },
  "id_str" : "243990244314189824",
  "in_reply_to_user_id" : 22298116,
  "text" : "@i42n Mach mal, dann stell ich meine Rechner auch um wenn das mit gescheiter Doku keine 4h mehr dauert ;)",
  "id" : 243990244314189824,
  "in_reply_to_status_id" : 243989733997441024,
  "created_at" : "Fri Sep 07 08:33:02 +0000 2012",
  "in_reply_to_screen_name" : "i42n",
  "in_reply_to_user_id_str" : "22298116",
  "user" : {
    "name" : "Felix",
    "screen_name" : "nicidienase",
    "protected" : false,
    "id_str" : "22396883",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3125784966/8223a4c5c9535be22d15c82ec829c2df_normal.jpeg",
    "id" : 22396883,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Chaosradio",
      "screen_name" : "chaosradio",
      "indices" : [ 0, 11 ],
      "id_str" : "14257211",
      "id" : 14257211
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "243747740180430848",
  "geo" : {
  },
  "id_str" : "243774540273025024",
  "in_reply_to_user_id" : 14257211,
  "text" : "@chaosradio Ohne! Die sind ja selbst wenn man den Podcast am n\u00E4chsten Tag h\u00F6rt schon alt.",
  "id" : 243774540273025024,
  "in_reply_to_status_id" : 243747740180430848,
  "created_at" : "Thu Sep 06 18:15:54 +0000 2012",
  "in_reply_to_screen_name" : "chaosradio",
  "in_reply_to_user_id_str" : "14257211",
  "user" : {
    "name" : "Felix",
    "screen_name" : "nicidienase",
    "protected" : false,
    "id_str" : "22396883",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3125784966/8223a4c5c9535be22d15c82ec829c2df_normal.jpeg",
    "id" : 22396883,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.echofon.com/\" rel=\"nofollow\">Echofon</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sturzelchen.",
      "screen_name" : "randsturz",
      "indices" : [ 0, 10 ],
      "id_str" : "73659102",
      "id" : 73659102
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "243732514261323777",
  "text" : "@randsturz Soweit mein Verst\u00E4ndniss der StVO ist m\u00FCssen die sich (ohne Blaulicht) an die gleichen Regeln halten wie alle anderen auch.",
  "id" : 243732514261323777,
  "created_at" : "Thu Sep 06 15:28:54 +0000 2012",
  "user" : {
    "name" : "Felix",
    "screen_name" : "nicidienase",
    "protected" : false,
    "id_str" : "22396883",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3125784966/8223a4c5c9535be22d15c82ec829c2df_normal.jpeg",
    "id" : 22396883,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.echofon.com/\" rel=\"nofollow\">Echofon</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Joern Seemann",
      "screen_name" : "derjoern",
      "indices" : [ 3, 12 ],
      "id_str" : "19253681",
      "id" : 19253681
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 36, 56 ],
      "url" : "http://t.co/p2Wzi3cp",
      "expanded_url" : "http://i.imgur.com/Ox5iN.jpeg",
      "display_url" : "i.imgur.com/Ox5iN.jpeg"
    } ]
  },
  "geo" : {
  },
  "id_str" : "243657267881312256",
  "text" : "RT @derjoern: Ehre wem Ehre geb\u00FChrt http://t.co/p2Wzi3cp",
  "retweeted_status" : {
    "source" : "<a href=\"http://turpial.org.ve\" rel=\"nofollow\">Turpial1.6</a>",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 22, 42 ],
        "url" : "http://t.co/p2Wzi3cp",
        "expanded_url" : "http://i.imgur.com/Ox5iN.jpeg",
        "display_url" : "i.imgur.com/Ox5iN.jpeg"
      } ]
    },
    "geo" : {
    },
    "id_str" : "243422311527624704",
    "text" : "Ehre wem Ehre geb\u00FChrt http://t.co/p2Wzi3cp",
    "id" : 243422311527624704,
    "created_at" : "Wed Sep 05 18:56:16 +0000 2012",
    "user" : {
      "name" : "Joern Seemann",
      "screen_name" : "derjoern",
      "protected" : false,
      "id_str" : "19253681",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/1504712394/joernc_normal.jpg",
      "id" : 19253681,
      "verified" : false
    }
  },
  "id" : 243657267881312256,
  "created_at" : "Thu Sep 06 10:29:54 +0000 2012",
  "user" : {
    "name" : "Felix",
    "screen_name" : "nicidienase",
    "protected" : false,
    "id_str" : "22396883",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3125784966/8223a4c5c9535be22d15c82ec829c2df_normal.jpeg",
    "id" : 22396883,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "243413892896792576",
  "text" : "Arrg, warum sagt mir den niemand das ich die 1000-Tweet-Grenze \u00FCberschritten hab.",
  "id" : 243413892896792576,
  "created_at" : "Wed Sep 05 18:22:49 +0000 2012",
  "user" : {
    "name" : "Felix",
    "screen_name" : "nicidienase",
    "protected" : false,
    "id_str" : "22396883",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3125784966/8223a4c5c9535be22d15c82ec829c2df_normal.jpeg",
    "id" : 22396883,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.echofon.com/\" rel=\"nofollow\">Echofon</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "getDigital Team",
      "screen_name" : "getDigital_de",
      "indices" : [ 0, 14 ],
      "id_str" : "45354877",
      "id" : 45354877
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "243361896202391552",
  "in_reply_to_user_id" : 45354877,
  "text" : "@getDigital_de Warum habt ihr eigentlich keine &lt;head&gt;&lt;/head&gt; Kopfbedeckung, passend zum &lt;body&gt;&lt;/body&gt; T-Shirt?",
  "id" : 243361896202391552,
  "created_at" : "Wed Sep 05 14:56:12 +0000 2012",
  "in_reply_to_screen_name" : "getDigital_de",
  "in_reply_to_user_id_str" : "45354877",
  "user" : {
    "name" : "Felix",
    "screen_name" : "nicidienase",
    "protected" : false,
    "id_str" : "22396883",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3125784966/8223a4c5c9535be22d15c82ec829c2df_normal.jpeg",
    "id" : 22396883,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.echofon.com/\" rel=\"nofollow\">Echofon</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Frederic Hemberger",
      "screen_name" : "fhemberger",
      "indices" : [ 3, 14 ],
      "id_str" : "47944587",
      "id" : 47944587
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "243353616600166400",
  "text" : "RT @fhemberger: UTF-8 is twenty years old this week. Finally \uFFFDmlauts work everywhere.",
  "retweeted_status" : {
    "source" : "<a href=\"http://itunes.apple.com/us/app/twitter/id409789998?mt=12\" rel=\"nofollow\">Twitter for Mac</a>",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : {
    },
    "id_str" : "243338303464685568",
    "text" : "UTF-8 is twenty years old this week. Finally \uFFFDmlauts work everywhere.",
    "id" : 243338303464685568,
    "created_at" : "Wed Sep 05 13:22:27 +0000 2012",
    "user" : {
      "name" : "Frederic Hemberger",
      "screen_name" : "fhemberger",
      "protected" : false,
      "id_str" : "47944587",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/1080936599/avatar_webmonkey_normal.jpg",
      "id" : 47944587,
      "verified" : false
    }
  },
  "id" : 243353616600166400,
  "created_at" : "Wed Sep 05 14:23:18 +0000 2012",
  "user" : {
    "name" : "Felix",
    "screen_name" : "nicidienase",
    "protected" : false,
    "id_str" : "22396883",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3125784966/8223a4c5c9535be22d15c82ec829c2df_normal.jpeg",
    "id" : 22396883,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.echofon.com/\" rel=\"nofollow\">Echofon</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Laurian Gridinoc",
      "screen_name" : "gridinoc",
      "indices" : [ 3, 12 ],
      "id_str" : "5017391",
      "id" : 5017391
    }, {
      "name" : "Joe Marley",
      "screen_name" : "groovyreg",
      "indices" : [ 14, 24 ],
      "id_str" : "173862777",
      "id" : 173862777
    }, {
      "name" : "Stephen Fry",
      "screen_name" : "stephenfry",
      "indices" : [ 25, 36 ],
      "id_str" : "15439395",
      "id" : 15439395
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 67, 87 ],
      "url" : "http://t.co/kfZc3nqM",
      "expanded_url" : "http://istwitterwrong.tumblr.com/post/30876620628/did-the-sun-publish-a-mocking-story-in-1991-comparing",
      "display_url" : "istwitterwrong.tumblr.com/post/308766206\u2026"
    } ]
  },
  "geo" : {
  },
  "id_str" : "243319096597430272",
  "text" : "RT @gridinoc: @groovyreg @stephenfry it is reported as a fake here http://t.co/kfZc3nqM",
  "retweeted_status" : {
    "source" : "<a href=\"http://itunes.apple.com/us/app/twitter/id409789998?mt=12\" rel=\"nofollow\">Twitter for Mac</a>",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Joe Marley",
        "screen_name" : "groovyreg",
        "indices" : [ 0, 10 ],
        "id_str" : "173862777",
        "id" : 173862777
      }, {
        "name" : "Stephen Fry",
        "screen_name" : "stephenfry",
        "indices" : [ 11, 22 ],
        "id_str" : "15439395",
        "id" : 15439395
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 53, 73 ],
        "url" : "http://t.co/kfZc3nqM",
        "expanded_url" : "http://istwitterwrong.tumblr.com/post/30876620628/did-the-sun-publish-a-mocking-story-in-1991-comparing",
        "display_url" : "istwitterwrong.tumblr.com/post/308766206\u2026"
      } ]
    },
    "in_reply_to_status_id_str" : "243316492387643393",
    "geo" : {
    },
    "id_str" : "243316852695113729",
    "in_reply_to_user_id" : 15439395,
    "text" : "@groovyreg @stephenfry it is reported as a fake here http://t.co/kfZc3nqM",
    "id" : 243316852695113729,
    "in_reply_to_status_id" : 243316492387643393,
    "created_at" : "Wed Sep 05 11:57:12 +0000 2012",
    "in_reply_to_screen_name" : "stephenfry",
    "in_reply_to_user_id_str" : "15439395",
    "user" : {
      "name" : "Laurian Gridinoc",
      "screen_name" : "gridinoc",
      "protected" : false,
      "id_str" : "5017391",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/1213321126/avatar_normal.png",
      "id" : 5017391,
      "verified" : false
    }
  },
  "id" : 243319096597430272,
  "created_at" : "Wed Sep 05 12:06:07 +0000 2012",
  "user" : {
    "name" : "Felix",
    "screen_name" : "nicidienase",
    "protected" : false,
    "id_str" : "22396883",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3125784966/8223a4c5c9535be22d15c82ec829c2df_normal.jpeg",
    "id" : 22396883,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.echofon.com/\" rel=\"nofollow\">Echofon</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "BBC Comedy",
      "screen_name" : "bbccomedy",
      "indices" : [ 3, 13 ],
      "id_str" : "7267562",
      "id" : 7267562
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 39, 59 ],
      "url" : "http://t.co/pUqjjM3d",
      "expanded_url" : "http://www.twitpic.com/505hlu/full",
      "display_url" : "twitpic.com/505hlu/full"
    } ]
  },
  "geo" : {
  },
  "id_str" : "243307949496360960",
  "text" : "RT @bbccomedy: World Wide What? (1991) http://t.co/pUqjjM3d",
  "retweeted_status" : {
    "source" : "web",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 24, 44 ],
        "url" : "http://t.co/pUqjjM3d",
        "expanded_url" : "http://www.twitpic.com/505hlu/full",
        "display_url" : "twitpic.com/505hlu/full"
      } ]
    },
    "geo" : {
    },
    "id_str" : "242912660662915073",
    "text" : "World Wide What? (1991) http://t.co/pUqjjM3d",
    "id" : 242912660662915073,
    "created_at" : "Tue Sep 04 09:11:06 +0000 2012",
    "user" : {
      "name" : "BBC Comedy",
      "screen_name" : "bbccomedy",
      "protected" : false,
      "id_str" : "7267562",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/3391729315/9197e081c53a8c3be5d0889116ced99c_normal.jpeg",
      "id" : 7267562,
      "verified" : true
    }
  },
  "id" : 243307949496360960,
  "created_at" : "Wed Sep 05 11:21:50 +0000 2012",
  "user" : {
    "name" : "Felix",
    "screen_name" : "nicidienase",
    "protected" : false,
    "id_str" : "22396883",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3125784966/8223a4c5c9535be22d15c82ec829c2df_normal.jpeg",
    "id" : 22396883,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.echofon.com/\" rel=\"nofollow\">Echofon</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Demo",
      "indices" : [ 33, 38 ]
    }, {
      "text" : "Karlsruhe",
      "indices" : [ 60, 70 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "243278495357214721",
  "text" : "Was marschiert den hier f\u00FCr eine #Demo den Ostring entlang? #Karlsruhe",
  "id" : 243278495357214721,
  "created_at" : "Wed Sep 05 09:24:47 +0000 2012",
  "user" : {
    "name" : "Felix",
    "screen_name" : "nicidienase",
    "protected" : false,
    "id_str" : "22396883",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3125784966/8223a4c5c9535be22d15c82ec829c2df_normal.jpeg",
    "id" : 22396883,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.echofon.com/\" rel=\"nofollow\">Echofon</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "blabber",
      "screen_name" : "_blabber_",
      "indices" : [ 3, 13 ],
      "id_str" : "400581412",
      "id" : 400581412
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 82, 102 ],
      "url" : "http://t.co/oOk2omeb",
      "expanded_url" : "http://r-wos.org/hacks/gti",
      "display_url" : "r-wos.org/hacks/gti"
    } ]
  },
  "geo" : {
  },
  "id_str" : "243261397285351424",
  "text" : "RT @_blabber_: \"I've finally implemented the command I keep typing all day: gti.\" http://t.co/oOk2omeb",
  "retweeted_status" : {
    "source" : "web",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 67, 87 ],
        "url" : "http://t.co/oOk2omeb",
        "expanded_url" : "http://r-wos.org/hacks/gti",
        "display_url" : "r-wos.org/hacks/gti"
      } ]
    },
    "geo" : {
    },
    "id_str" : "243053253019983872",
    "text" : "\"I've finally implemented the command I keep typing all day: gti.\" http://t.co/oOk2omeb",
    "id" : 243053253019983872,
    "created_at" : "Tue Sep 04 18:29:45 +0000 2012",
    "user" : {
      "name" : "blabber",
      "screen_name" : "_blabber_",
      "protected" : false,
      "id_str" : "400581412",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/1888478088/Doom_Shall_Rise_I_04_bigger_normal.JPG",
      "id" : 400581412,
      "verified" : false
    }
  },
  "id" : 243261397285351424,
  "created_at" : "Wed Sep 05 08:16:51 +0000 2012",
  "user" : {
    "name" : "Felix",
    "screen_name" : "nicidienase",
    "protected" : false,
    "id_str" : "22396883",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3125784966/8223a4c5c9535be22d15c82ec829c2df_normal.jpeg",
    "id" : 22396883,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.echofon.com/\" rel=\"nofollow\">Echofon</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lilly W.",
      "screen_name" : "dielilly",
      "indices" : [ 3, 12 ],
      "id_str" : "19603003",
      "id" : 19603003
    }, {
      "name" : "M\u00FCnchen 72/12",
      "screen_name" : "Muenchen_7212",
      "indices" : [ 42, 56 ],
      "id_str" : "715716792",
      "id" : 715716792
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "243260266912051201",
  "text" : "RT @dielilly: Ab jetzt wirds spannend bei @Muenchen_7212",
  "retweeted_status" : {
    "source" : "<a href=\"http://tapbots.com/tweetbot\" rel=\"nofollow\">Tweetbot for iOS</a>",
    "entities" : {
      "user_mentions" : [ {
        "name" : "M\u00FCnchen 72/12",
        "screen_name" : "Muenchen_7212",
        "indices" : [ 28, 42 ],
        "id_str" : "715716792",
        "id" : 715716792
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : {
    },
    "id_str" : "243212763344797697",
    "text" : "Ab jetzt wirds spannend bei @Muenchen_7212",
    "id" : 243212763344797697,
    "created_at" : "Wed Sep 05 05:03:36 +0000 2012",
    "user" : {
      "name" : "Lilly W.",
      "screen_name" : "dielilly",
      "protected" : false,
      "id_str" : "19603003",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/3217478653/94ba887554ffa33ae41bdc05830e05d8_normal.jpeg",
      "id" : 19603003,
      "verified" : false
    }
  },
  "id" : 243260266912051201,
  "created_at" : "Wed Sep 05 08:12:21 +0000 2012",
  "user" : {
    "name" : "Felix",
    "screen_name" : "nicidienase",
    "protected" : false,
    "id_str" : "22396883",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3125784966/8223a4c5c9535be22d15c82ec829c2df_normal.jpeg",
    "id" : 22396883,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.echofon.com/\" rel=\"nofollow\">Echofon</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Christian Heilmann ",
      "screen_name" : "codepo8",
      "indices" : [ 3, 11 ],
      "id_str" : "13567",
      "id" : 13567
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 47, 67 ],
      "url" : "http://t.co/vgFZU3L4",
      "expanded_url" : "http://yfrog.com/j2tpnhp",
      "display_url" : "yfrog.com/j2tpnhp"
    } ]
  },
  "geo" : {
  },
  "id_str" : "242968086116962305",
  "text" : "RT @codepo8: I have a new favourite WTF sign.  http://t.co/vgFZU3L4",
  "retweeted_status" : {
    "source" : "<a href=\"http://itunes.apple.com/us/app/twitter/id409789998?mt=12\" rel=\"nofollow\">Twitter for Mac</a>",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 34, 54 ],
        "url" : "http://t.co/vgFZU3L4",
        "expanded_url" : "http://yfrog.com/j2tpnhp",
        "display_url" : "yfrog.com/j2tpnhp"
      } ]
    },
    "geo" : {
    },
    "id_str" : "242748128720211968",
    "text" : "I have a new favourite WTF sign.  http://t.co/vgFZU3L4",
    "id" : 242748128720211968,
    "created_at" : "Mon Sep 03 22:17:18 +0000 2012",
    "user" : {
      "name" : "Christian Heilmann ",
      "screen_name" : "codepo8",
      "protected" : false,
      "id_str" : "13567",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/1666904408/codepo8_normal.png",
      "id" : 13567,
      "verified" : false
    }
  },
  "id" : 242968086116962305,
  "created_at" : "Tue Sep 04 12:51:20 +0000 2012",
  "user" : {
    "name" : "Felix",
    "screen_name" : "nicidienase",
    "protected" : false,
    "id_str" : "22396883",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3125784966/8223a4c5c9535be22d15c82ec829c2df_normal.jpeg",
    "id" : 22396883,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "sprech.sucht",
      "screen_name" : "Sprechsucht",
      "indices" : [ 3, 15 ],
      "id_str" : "34935149",
      "id" : 34935149
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 84, 104 ],
      "url" : "http://t.co/yg1rrtAD",
      "expanded_url" : "http://goo.gl/9rlZz",
      "display_url" : "goo.gl/9rlZz"
    } ]
  },
  "geo" : {
  },
  "id_str" : "242266292621545472",
  "text" : "RT @Sprechsucht: G+: PORN STAR OR MY LITTLE PONY? A fun game for the whole family ! http://t.co/yg1rrtAD",
  "retweeted_status" : {
    "source" : "<a href=\"http://manageflitter.com\" rel=\"nofollow\">ManageFlitter</a>",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 67, 87 ],
        "url" : "http://t.co/yg1rrtAD",
        "expanded_url" : "http://goo.gl/9rlZz",
        "display_url" : "goo.gl/9rlZz"
      } ]
    },
    "geo" : {
    },
    "id_str" : "242239426279907329",
    "text" : "G+: PORN STAR OR MY LITTLE PONY? A fun game for the whole family ! http://t.co/yg1rrtAD",
    "id" : 242239426279907329,
    "created_at" : "Sun Sep 02 12:35:54 +0000 2012",
    "user" : {
      "name" : "sprech.sucht",
      "screen_name" : "Sprechsucht",
      "protected" : false,
      "id_str" : "34935149",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/3193713136/aadfab3cc520834790c804f9c891ffaf_normal.jpeg",
      "id" : 34935149,
      "verified" : false
    }
  },
  "id" : 242266292621545472,
  "created_at" : "Sun Sep 02 14:22:39 +0000 2012",
  "user" : {
    "name" : "Felix",
    "screen_name" : "nicidienase",
    "protected" : false,
    "id_str" : "22396883",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3125784966/8223a4c5c9535be22d15c82ec829c2df_normal.jpeg",
    "id" : 22396883,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "i42n",
      "screen_name" : "i42n",
      "indices" : [ 3, 8 ],
      "id_str" : "22298116",
      "id" : 22298116
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 41, 62 ],
      "url" : "https://t.co/O3JpkbaH",
      "expanded_url" : "https://github.com/sangyye/Suicide-Linux-Script",
      "display_url" : "github.com/sangyye/Suicid\u2026"
    } ]
  },
  "geo" : {
  },
  "id_str" : "242022176327335940",
  "text" : "RT @i42n: Suicide Linux. Lustige Idee :) https://t.co/O3JpkbaH",
  "retweeted_status" : {
    "source" : "<a href=\"http://www.echofon.com/\" rel=\"nofollow\">Echofon</a>",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 31, 52 ],
        "url" : "https://t.co/O3JpkbaH",
        "expanded_url" : "https://github.com/sangyye/Suicide-Linux-Script",
        "display_url" : "github.com/sangyye/Suicid\u2026"
      } ]
    },
    "geo" : {
    },
    "id_str" : "241982547461029888",
    "text" : "Suicide Linux. Lustige Idee :) https://t.co/O3JpkbaH",
    "id" : 241982547461029888,
    "created_at" : "Sat Sep 01 19:35:09 +0000 2012",
    "user" : {
      "name" : "i42n",
      "screen_name" : "i42n",
      "protected" : false,
      "id_str" : "22298116",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/3129115691/3c2e9123db7f498d478ace57a0ac1b69_normal.png",
      "id" : 22298116,
      "verified" : false
    }
  },
  "id" : 242022176327335940,
  "created_at" : "Sat Sep 01 22:12:38 +0000 2012",
  "user" : {
    "name" : "Felix",
    "screen_name" : "nicidienase",
    "protected" : false,
    "id_str" : "22396883",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3125784966/8223a4c5c9535be22d15c82ec829c2df_normal.jpeg",
    "id" : 22396883,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kati K\u00FCrsch",
      "screen_name" : "KatiKuersch",
      "indices" : [ 3, 15 ],
      "id_str" : "46991038",
      "id" : 46991038
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 69, 89 ],
      "url" : "http://t.co/vVTbAAiO",
      "expanded_url" : "http://25.media.tumblr.com/tumblr_m9lak0Rgne1rnxkm4o1_400.gif",
      "display_url" : "25.media.tumblr.com/tumblr_m9lak0R\u2026"
    } ]
  },
  "geo" : {
  },
  "id_str" : "242020263137513473",
  "text" : "RT @KatiKuersch: Das coolste Katzengif, das ich jemals gesehen habe. http://t.co/vVTbAAiO",
  "retweeted_status" : {
    "source" : "web",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 52, 72 ],
        "url" : "http://t.co/vVTbAAiO",
        "expanded_url" : "http://25.media.tumblr.com/tumblr_m9lak0Rgne1rnxkm4o1_400.gif",
        "display_url" : "25.media.tumblr.com/tumblr_m9lak0R\u2026"
      } ]
    },
    "geo" : {
    },
    "id_str" : "241952768997326848",
    "text" : "Das coolste Katzengif, das ich jemals gesehen habe. http://t.co/vVTbAAiO",
    "id" : 241952768997326848,
    "created_at" : "Sat Sep 01 17:36:50 +0000 2012",
    "user" : {
      "name" : "Kati K\u00FCrsch",
      "screen_name" : "KatiKuersch",
      "protected" : false,
      "id_str" : "46991038",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/3503050573/83b4d8da5f22d6beb9ad4ae0f89488de_normal.jpeg",
      "id" : 46991038,
      "verified" : false
    }
  },
  "id" : 242020263137513473,
  "created_at" : "Sat Sep 01 22:05:01 +0000 2012",
  "user" : {
    "name" : "Felix",
    "screen_name" : "nicidienase",
    "protected" : false,
    "id_str" : "22396883",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3125784966/8223a4c5c9535be22d15c82ec829c2df_normal.jpeg",
    "id" : 22396883,
    "verified" : false
  }
} ]