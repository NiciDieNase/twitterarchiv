Grailbird.data.tweets_2010_11 = 
 [ {
  "source" : "<a href=\"http://tweed.pivotallabs.com\" rel=\"nofollow\">Tweed webOS</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Eve",
      "screen_name" : "ChiisanaIchigo",
      "indices" : [ 0, 15 ],
      "id_str" : "187553346",
      "id" : 187553346
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 49.013223, 8.391664 ]
  },
  "id_str" : "9241676178526209",
  "in_reply_to_user_id" : 187553346,
  "text" : "@ChiisanaIchigo Dann musst du mal ganz fleisig viel Werbung f\u00FCr Jabber machen.",
  "id" : 9241676178526209,
  "created_at" : "Mon Nov 29 13:46:01 +0000 2010",
  "in_reply_to_screen_name" : "ChiisanaIchigo",
  "in_reply_to_user_id_str" : "187553346",
  "user" : {
    "name" : "Felix",
    "screen_name" : "nicidienase",
    "protected" : false,
    "id_str" : "22396883",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3125784966/8223a4c5c9535be22d15c82ec829c2df_normal.jpeg",
    "id" : 22396883,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://tweed.pivotallabs.com\" rel=\"nofollow\">Tweed webOS</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Eve",
      "screen_name" : "ChiisanaIchigo",
      "indices" : [ 0, 15 ],
      "id_str" : "187553346",
      "id" : 187553346
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "8986714429194241",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 49.015353, 8.392763 ]
  },
  "id_str" : "9150734113181696",
  "in_reply_to_user_id" : 187553346,
  "text" : "@ChiisanaIchigo Du benutzt noch MSN?",
  "id" : 9150734113181696,
  "in_reply_to_status_id" : 8986714429194241,
  "created_at" : "Mon Nov 29 07:44:39 +0000 2010",
  "in_reply_to_screen_name" : "ChiisanaIchigo",
  "in_reply_to_user_id_str" : "187553346",
  "user" : {
    "name" : "Felix",
    "screen_name" : "nicidienase",
    "protected" : false,
    "id_str" : "22396883",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3125784966/8223a4c5c9535be22d15c82ec829c2df_normal.jpeg",
    "id" : 22396883,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://tweed.pivotallabs.com\" rel=\"nofollow\">Tweed webOS</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Bastian Greshake",
      "screen_name" : "gedankenstuecke",
      "indices" : [ 3, 19 ],
      "id_str" : "14286491",
      "id" : 14286491
    }, {
      "name" : "Dominic Herzberg",
      "screen_name" : "berlinnow",
      "indices" : [ 24, 34 ],
      "id_str" : "23032302",
      "id" : 23032302
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "8321381284450304",
  "text" : "RT @gedankenstuecke: RT @berlinnow: Im Blog: Wie ich unter Terrorverdacht geriet - http://berlinnow.org/?p=719 Rucksackkontrolle wegen d ...",
  "retweeted_status" : {
    "source" : "<a href=\"http://www.echofon.com/\" rel=\"nofollow\">Echofon</a>",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Dominic Herzberg",
        "screen_name" : "berlinnow",
        "indices" : [ 3, 13 ],
        "id_str" : "23032302",
        "id" : 23032302
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : {
      "type" : "Point",
      "coordinates" : [ 49.98903, 8.226893 ]
    },
    "id_str" : "8266552390459393",
    "text" : "RT @berlinnow: Im Blog: Wie ich unter Terrorverdacht geriet - http://berlinnow.org/?p=719 Rucksackkontrolle wegen der falschen Musik.",
    "id" : 8266552390459393,
    "created_at" : "Fri Nov 26 21:11:14 +0000 2010",
    "user" : {
      "name" : "Bastian Greshake",
      "screen_name" : "gedankenstuecke",
      "protected" : false,
      "id_str" : "14286491",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/2466316198/7D66C55E-2643-4F71-8115-B524A7B8E72F_normal",
      "id" : 14286491,
      "verified" : false
    }
  },
  "id" : 8321381284450304,
  "created_at" : "Sat Nov 27 00:49:06 +0000 2010",
  "user" : {
    "name" : "Felix",
    "screen_name" : "nicidienase",
    "protected" : false,
    "id_str" : "22396883",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3125784966/8223a4c5c9535be22d15c82ec829c2df_normal.jpeg",
    "id" : 22396883,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://tweed.pivotallabs.com\" rel=\"nofollow\">Tweed webOS</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "~PsYCoN~",
      "screen_name" : "nocysp",
      "indices" : [ 0, 7 ],
      "id_str" : "14010592",
      "id" : 14010592
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "8188802975670272",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 48.887044, 8.708042 ]
  },
  "id_str" : "8200829286752256",
  "in_reply_to_user_id" : 87286054,
  "text" : "@nocysp In der 3 auf dem Weg zum Bahnhof. Ich stand am Kronenplatz und hab auf die S5 gewartet.",
  "id" : 8200829286752256,
  "in_reply_to_status_id" : 8188802975670272,
  "created_at" : "Fri Nov 26 16:50:04 +0000 2010",
  "in_reply_to_screen_name" : "psycon",
  "in_reply_to_user_id_str" : "87286054",
  "user" : {
    "name" : "Felix",
    "screen_name" : "nicidienase",
    "protected" : false,
    "id_str" : "22396883",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3125784966/8223a4c5c9535be22d15c82ec829c2df_normal.jpeg",
    "id" : 22396883,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://tweed.pivotallabs.com\" rel=\"nofollow\">Tweed webOS</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Karlsruhe",
      "indices" : [ 27, 37 ]
    }, {
      "text" : "WTF",
      "indices" : [ 97, 101 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 49.008014, 8.408898 ]
  },
  "id_str" : "8178866719817728",
  "text" : "Sagt mal geht's noch?!? In #Karlsruhe in der Stra\u00DFenbahn stehn Polizisten mit Maschienenpistole. #WTF",
  "id" : 8178866719817728,
  "created_at" : "Fri Nov 26 15:22:48 +0000 2010",
  "user" : {
    "name" : "Felix",
    "screen_name" : "nicidienase",
    "protected" : false,
    "id_str" : "22396883",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3125784966/8223a4c5c9535be22d15c82ec829c2df_normal.jpeg",
    "id" : 22396883,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://tweed.pivotallabs.com\" rel=\"nofollow\">Tweed webOS</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sunday8pm",
      "screen_name" : "sunday_8pm",
      "indices" : [ 0, 11 ],
      "id_str" : "80762004",
      "id" : 80762004
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "8073143922991104",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 49.008014, 8.408898 ]
  },
  "id_str" : "8158980287234048",
  "in_reply_to_user_id" : 80762004,
  "text" : "@Sunday_8pm Was hast du dir den f\u00FCr eines gekauft?",
  "id" : 8158980287234048,
  "in_reply_to_status_id" : 8073143922991104,
  "created_at" : "Fri Nov 26 14:03:47 +0000 2010",
  "in_reply_to_screen_name" : "sunday_8pm",
  "in_reply_to_user_id_str" : "80762004",
  "user" : {
    "name" : "Felix",
    "screen_name" : "nicidienase",
    "protected" : false,
    "id_str" : "22396883",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3125784966/8223a4c5c9535be22d15c82ec829c2df_normal.jpeg",
    "id" : 22396883,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://tweed.pivotallabs.com\" rel=\"nofollow\">Tweed webOS</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 49.008059, 8.41155 ]
  },
  "id_str" : "7577632119984128",
  "text" : "Mmmmmmmh, hei\u00DFe Schokolade mit Baileys.",
  "id" : 7577632119984128,
  "created_at" : "Wed Nov 24 23:33:42 +0000 2010",
  "user" : {
    "name" : "Felix",
    "screen_name" : "nicidienase",
    "protected" : false,
    "id_str" : "22396883",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3125784966/8223a4c5c9535be22d15c82ec829c2df_normal.jpeg",
    "id" : 22396883,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://tweed.pivotallabs.com\" rel=\"nofollow\">Tweed webOS</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 49.008059, 8.41155 ]
  },
  "id_str" : "7481412311584768",
  "text" : "Yeay, ich weis wie ich mein Netbook zerst\u00F6rungsfrei auf kriege. Jetzt muss ich mich nur noch f\u00FCr ne SSD entscheiden.",
  "id" : 7481412311584768,
  "created_at" : "Wed Nov 24 17:11:22 +0000 2010",
  "user" : {
    "name" : "Felix",
    "screen_name" : "nicidienase",
    "protected" : false,
    "id_str" : "22396883",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3125784966/8223a4c5c9535be22d15c82ec829c2df_normal.jpeg",
    "id" : 22396883,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://tweed.pivotallabs.com\" rel=\"nofollow\">Tweed webOS</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Till Westermayer",
      "screen_name" : "_tillwe_",
      "indices" : [ 3, 12 ],
      "id_str" : "15342735",
      "id" : 15342735
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "7063878320001024",
  "text" : "RT @_tillwe_: Finde, wir sollten fordern, wg. dem Terrordings alle AKWs vorsorglich auszuschalten.",
  "retweeted_status" : {
    "source" : "<a href=\"http://mobile.twitter.com\" rel=\"nofollow\">Mobile Web</a>",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : {
    },
    "id_str" : "7006168232763392",
    "text" : "Finde, wir sollten fordern, wg. dem Terrordings alle AKWs vorsorglich auszuschalten.",
    "id" : 7006168232763392,
    "created_at" : "Tue Nov 23 09:42:55 +0000 2010",
    "user" : {
      "name" : "Till Westermayer",
      "screen_name" : "_tillwe_",
      "protected" : false,
      "id_str" : "15342735",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/2477992243/fhj5oo0g2rrg7gg56paz_normal.png",
      "id" : 15342735,
      "verified" : false
    }
  },
  "id" : 7063878320001024,
  "created_at" : "Tue Nov 23 13:32:14 +0000 2010",
  "user" : {
    "name" : "Felix",
    "screen_name" : "nicidienase",
    "protected" : false,
    "id_str" : "22396883",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3125784966/8223a4c5c9535be22d15c82ec829c2df_normal.jpeg",
    "id" : 22396883,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://tweed.pivotallabs.com\" rel=\"nofollow\">Tweed webOS</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "julius01",
      "screen_name" : "julius01",
      "indices" : [ 3, 12 ],
      "id_str" : "10970952",
      "id" : 10970952
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "6663181749460992",
  "text" : "RT @julius01: Wenn bei jedem der mehr als 4.000 Verkehrstoten die Stra\u00DFenverkehrsordnung so versch\u00E4rft w\u00FCrde, als sei es Terror, w\u00E4re Au ...",
  "retweeted_status" : {
    "source" : "web",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : {
    },
    "id_str" : "6437754145607680",
    "text" : "Wenn bei jedem der mehr als 4.000 Verkehrstoten die Stra\u00DFenverkehrsordnung so versch\u00E4rft w\u00FCrde, als sei es Terror, w\u00E4re Autofahren verboten.",
    "id" : 6437754145607680,
    "created_at" : "Sun Nov 21 20:04:14 +0000 2010",
    "user" : {
      "name" : "julius01",
      "screen_name" : "julius01",
      "protected" : false,
      "id_str" : "10970952",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/1850587967/Julius_color_small_normal.jpg",
      "id" : 10970952,
      "verified" : false
    }
  },
  "id" : 6663181749460992,
  "created_at" : "Mon Nov 22 11:00:00 +0000 2010",
  "user" : {
    "name" : "Felix",
    "screen_name" : "nicidienase",
    "protected" : false,
    "id_str" : "22396883",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3125784966/8223a4c5c9535be22d15c82ec829c2df_normal.jpeg",
    "id" : 22396883,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://tweed.pivotallabs.com\" rel=\"nofollow\">Tweed webOS</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "David Blue",
      "screen_name" : "DavidBlue",
      "indices" : [ 3, 13 ],
      "id_str" : "16827760",
      "id" : 16827760
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "NerdLove",
      "indices" : [ 112, 121 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "6619680940761088",
  "text" : "RT @DavidBlue: You know you're a nerd when cleaning up the computer takes more time than cleaning up the house. #NerdLove",
  "retweeted_status" : {
    "source" : "<a href=\"http://www.echofon.com/\" rel=\"nofollow\">Echofon</a>",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "NerdLove",
        "indices" : [ 97, 106 ]
      } ],
      "urls" : [ ]
    },
    "geo" : {
    },
    "id_str" : "6079506414567424",
    "text" : "You know you're a nerd when cleaning up the computer takes more time than cleaning up the house. #NerdLove",
    "id" : 6079506414567424,
    "created_at" : "Sat Nov 20 20:20:41 +0000 2010",
    "user" : {
      "name" : "David Blue",
      "screen_name" : "DavidBlue",
      "protected" : false,
      "id_str" : "16827760",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/2995822473/4b3df655c6e6d2de78100ef68a7666fd_normal.jpeg",
      "id" : 16827760,
      "verified" : true
    }
  },
  "id" : 6619680940761088,
  "created_at" : "Mon Nov 22 08:07:09 +0000 2010",
  "user" : {
    "name" : "Felix",
    "screen_name" : "nicidienase",
    "protected" : false,
    "id_str" : "22396883",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3125784966/8223a4c5c9535be22d15c82ec829c2df_normal.jpeg",
    "id" : 22396883,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://tweed.pivotallabs.com\" rel=\"nofollow\">Tweed webOS</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Roman Held",
      "screen_name" : "hoch21",
      "indices" : [ 3, 10 ],
      "id_str" : "10406212",
      "id" : 10406212
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "6619292330106880",
  "text" : "RT @hoch21: Ich sage es mal so: Seit September 2009 ist eine Regierung in diesem Land im Amt, die mir mehr Sorgen bereitet als Terrorans ...",
  "retweeted_status" : {
    "source" : "web",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : {
    },
    "id_str" : "6022496675438592",
    "text" : "Ich sage es mal so: Seit September 2009 ist eine Regierung in diesem Land im Amt, die mir mehr Sorgen bereitet als Terroranschl\u00E4ge.",
    "id" : 6022496675438592,
    "created_at" : "Sat Nov 20 16:34:09 +0000 2010",
    "user" : {
      "name" : "Roman Held",
      "screen_name" : "hoch21",
      "protected" : false,
      "id_str" : "10406212",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/3346747784/14b252a1e5c63554e72ad218f2199e7b_normal.jpeg",
      "id" : 10406212,
      "verified" : false
    }
  },
  "id" : 6619292330106880,
  "created_at" : "Mon Nov 22 08:05:36 +0000 2010",
  "user" : {
    "name" : "Felix",
    "screen_name" : "nicidienase",
    "protected" : false,
    "id_str" : "22396883",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3125784966/8223a4c5c9535be22d15c82ec829c2df_normal.jpeg",
    "id" : 22396883,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://tweed.pivotallabs.com\" rel=\"nofollow\">Tweed webOS</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "superkatinka",
      "screen_name" : "diekathrin",
      "indices" : [ 3, 14 ],
      "id_str" : "15082960",
      "id" : 15082960
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "6612007692279809",
  "text" : "RT @diekathrin: Es ist gar nicht so leicht, jemanden zu entzippen, der sich rar macht.",
  "retweeted_status" : {
    "source" : "<a href=\"http://www.tweetdeck.com\" rel=\"nofollow\">TweetDeck</a>",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : {
    },
    "id_str" : "5564815636434944",
    "text" : "Es ist gar nicht so leicht, jemanden zu entzippen, der sich rar macht.",
    "id" : 5564815636434944,
    "created_at" : "Fri Nov 19 10:15:30 +0000 2010",
    "user" : {
      "name" : "superkatinka",
      "screen_name" : "diekathrin",
      "protected" : false,
      "id_str" : "15082960",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/2360191825/qxz7op1ieb721hosed87_normal.png",
      "id" : 15082960,
      "verified" : false
    }
  },
  "id" : 6612007692279809,
  "created_at" : "Mon Nov 22 07:36:40 +0000 2010",
  "user" : {
    "name" : "Felix",
    "screen_name" : "nicidienase",
    "protected" : false,
    "id_str" : "22396883",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3125784966/8223a4c5c9535be22d15c82ec829c2df_normal.jpeg",
    "id" : 22396883,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.bravenewcode.com/products/wordtwit\" rel=\"nofollow\">WordTwit Plugin</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "5672615481970688",
  "text" : "Neuer Blog-Beitrag, Twitter Wandkalender 2011 - http://tinyurl.com/26pygbw",
  "id" : 5672615481970688,
  "created_at" : "Fri Nov 19 17:23:51 +0000 2010",
  "user" : {
    "name" : "Felix",
    "screen_name" : "nicidienase",
    "protected" : false,
    "id_str" : "22396883",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3125784966/8223a4c5c9535be22d15c82ec829c2df_normal.jpeg",
    "id" : 22396883,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://tweed.pivotallabs.com\" rel=\"nofollow\">Tweed webOS</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 49.015353, 8.392763 ]
  },
  "id_str" : "4839554859139072",
  "text" : "Bin grade das erste Mal ans Limit meines Datentarifs gekommen. Jetzt bis zum 20. mobil nur noch schmalspur-surfen.",
  "id" : 4839554859139072,
  "created_at" : "Wed Nov 17 10:13:34 +0000 2010",
  "user" : {
    "name" : "Felix",
    "screen_name" : "nicidienase",
    "protected" : false,
    "id_str" : "22396883",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3125784966/8223a4c5c9535be22d15c82ec829c2df_normal.jpeg",
    "id" : 22396883,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://tweed.pivotallabs.com\" rel=\"nofollow\">Tweed webOS</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Manu",
      "screen_name" : "Mini_Tequila",
      "indices" : [ 0, 13 ],
      "id_str" : "177909051",
      "id" : 177909051
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "3885546422149120",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 49.015353, 8.392763 ]
  },
  "id_str" : "4078675829985280",
  "in_reply_to_user_id" : 177909051,
  "text" : "@Mini_Tequila Freitag Vormittag z\u00E4hlt bei dir schon zum Wochenende?",
  "id" : 4078675829985280,
  "in_reply_to_status_id" : 3885546422149120,
  "created_at" : "Mon Nov 15 07:50:06 +0000 2010",
  "in_reply_to_screen_name" : "Mini_Tequila",
  "in_reply_to_user_id_str" : "177909051",
  "user" : {
    "name" : "Felix",
    "screen_name" : "nicidienase",
    "protected" : false,
    "id_str" : "22396883",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3125784966/8223a4c5c9535be22d15c82ec829c2df_normal.jpeg",
    "id" : 22396883,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://tweed.pivotallabs.com\" rel=\"nofollow\">Tweed webOS</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Florian M. Dobler",
      "screen_name" : "voerdus",
      "indices" : [ 3, 11 ],
      "id_str" : "19146073",
      "id" : 19146073
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "4061957548150785",
  "text" : "RT @voerdus: Manchmal w\u00FCnschte ich Hom\u00F6opathie w\u00FCrde wirken, dann m\u00FCsste man nicht soviel Geld ausgeben um sich zu betrinken.",
  "retweeted_status" : {
    "source" : "<a href=\"http://www.echofon.com/\" rel=\"nofollow\">Echofon</a>",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : {
    },
    "id_str" : "3580027601948672",
    "text" : "Manchmal w\u00FCnschte ich Hom\u00F6opathie w\u00FCrde wirken, dann m\u00FCsste man nicht soviel Geld ausgeben um sich zu betrinken.",
    "id" : 3580027601948672,
    "created_at" : "Sat Nov 13 22:48:39 +0000 2010",
    "user" : {
      "name" : "Florian M. Dobler",
      "screen_name" : "voerdus",
      "protected" : false,
      "id_str" : "19146073",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/1288255414/Foto_am_31-12-2010_um_16.40__3_normal.jpg",
      "id" : 19146073,
      "verified" : false
    }
  },
  "id" : 4061957548150785,
  "created_at" : "Mon Nov 15 06:43:40 +0000 2010",
  "user" : {
    "name" : "Felix",
    "screen_name" : "nicidienase",
    "protected" : false,
    "id_str" : "22396883",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3125784966/8223a4c5c9535be22d15c82ec829c2df_normal.jpeg",
    "id" : 22396883,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://tweed.pivotallabs.com\" rel=\"nofollow\">Tweed webOS</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 49.004569, 8.497479 ]
  },
  "id_str" : "3664944809644032",
  "text" : "Legt das am Alkohol oder am Twitter-lesen das mir die Fahrt von PF nach KA k\u00FCrzer vor kommt als sonst?!?",
  "id" : 3664944809644032,
  "created_at" : "Sun Nov 14 04:26:05 +0000 2010",
  "user" : {
    "name" : "Felix",
    "screen_name" : "nicidienase",
    "protected" : false,
    "id_str" : "22396883",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3125784966/8223a4c5c9535be22d15c82ec829c2df_normal.jpeg",
    "id" : 22396883,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://tweed.pivotallabs.com\" rel=\"nofollow\">Tweed webOS</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Max Winde",
      "screen_name" : "343max",
      "indices" : [ 3, 10 ],
      "id_str" : "2284151",
      "id" : 2284151
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "3659306884931584",
  "text" : "RT @343max: Dass das mal klar ist! http://twitpic.com/35mq0z",
  "retweeted_status" : {
    "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : {
      "type" : "Point",
      "coordinates" : [ 52.51030171, 13.3895060008 ]
    },
    "id_str" : "2411310797033472",
    "text" : "Dass das mal klar ist! http://twitpic.com/35mq0z",
    "id" : 2411310797033472,
    "created_at" : "Wed Nov 10 17:24:35 +0000 2010",
    "user" : {
      "name" : "Max Winde",
      "screen_name" : "343max",
      "protected" : false,
      "id_str" : "2284151",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/1573654380/edween_normal.png",
      "id" : 2284151,
      "verified" : false
    }
  },
  "id" : 3659306884931584,
  "created_at" : "Sun Nov 14 04:03:41 +0000 2010",
  "user" : {
    "name" : "Felix",
    "screen_name" : "nicidienase",
    "protected" : false,
    "id_str" : "22396883",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3125784966/8223a4c5c9535be22d15c82ec829c2df_normal.jpeg",
    "id" : 22396883,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://tweed.pivotallabs.com\" rel=\"nofollow\">Tweed webOS</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Eve",
      "screen_name" : "ChiisanaIchigo",
      "indices" : [ 0, 15 ],
      "id_str" : "187553346",
      "id" : 187553346
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "29130319085",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 49.008354, 8.41737 ]
  },
  "id_str" : "29377650755",
  "in_reply_to_user_id" : 187553346,
  "text" : "@ChiisanaIchigo Heute abend is bei uns in der Waldhorn-Bar ab 21Uhr After-Halloween-Ultrastar-Abend",
  "id" : 29377650755,
  "in_reply_to_status_id" : 29130319085,
  "created_at" : "Mon Nov 01 14:36:06 +0000 2010",
  "in_reply_to_screen_name" : "ChiisanaIchigo",
  "in_reply_to_user_id_str" : "187553346",
  "user" : {
    "name" : "Felix",
    "screen_name" : "nicidienase",
    "protected" : false,
    "id_str" : "22396883",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3125784966/8223a4c5c9535be22d15c82ec829c2df_normal.jpeg",
    "id" : 22396883,
    "verified" : false
  }
} ]