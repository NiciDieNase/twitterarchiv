Grailbird.data.tweets_2010_06 = 
 [ {
  "source" : "<a href=\"http://www.bravenewcode.com/products/wordtwit\" rel=\"nofollow\">WordTwit Plugin</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "17432720630",
  "text" : "Neuer Blog-Beitrag, Nordkorea-Dokus - http://tinyurl.com/37akatt",
  "id" : 17432720630,
  "created_at" : "Wed Jun 30 18:18:19 +0000 2010",
  "user" : {
    "name" : "Felix",
    "screen_name" : "nicidienase",
    "protected" : false,
    "id_str" : "22396883",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3125784966/8223a4c5c9535be22d15c82ec829c2df_normal.jpeg",
    "id" : 22396883,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Besim Karadeniz",
      "screen_name" : "besim",
      "indices" : [ 3, 9 ],
      "id_str" : "15170704",
      "id" : 15170704
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "17431997391",
  "text" : "RT @besim: Ist eigentlich schon jemandem aufgefallen, dass wenn jetzt Au\u00DFerirdische den Reichstag weglasern, die Republik komplett f\u00FChre ...",
  "retweeted_status" : {
    "source" : "<a href=\"http://www.tweetdeck.com\" rel=\"nofollow\">TweetDeck</a>",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : {
    },
    "id_str" : "17417758451",
    "text" : "Ist eigentlich schon jemandem aufgefallen, dass wenn jetzt Au\u00DFerirdische den Reichstag weglasern, die Republik komplett f\u00FChrerlos w\u00E4re?",
    "id" : 17417758451,
    "created_at" : "Wed Jun 30 14:26:41 +0000 2010",
    "user" : {
      "name" : "Besim Karadeniz",
      "screen_name" : "besim",
      "protected" : false,
      "id_str" : "15170704",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/2307419522/xqmi3xbuwtmhe9fok94d_normal.jpeg",
      "id" : 15170704,
      "verified" : false
    }
  },
  "id" : 17431997391,
  "created_at" : "Wed Jun 30 18:04:35 +0000 2010",
  "user" : {
    "name" : "Felix",
    "screen_name" : "nicidienase",
    "protected" : false,
    "id_str" : "22396883",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3125784966/8223a4c5c9535be22d15c82ec829c2df_normal.jpeg",
    "id" : 22396883,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://pivotallabs.com/landing/tweed\" rel=\"nofollow\">Tweed</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "17068734353",
  "text" : "1&1-Sommerfest - gefeiert bis es hell war, geilste Party sei langem.",
  "id" : 17068734353,
  "created_at" : "Sat Jun 26 04:39:30 +0000 2010",
  "user" : {
    "name" : "Felix",
    "screen_name" : "nicidienase",
    "protected" : false,
    "id_str" : "22396883",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3125784966/8223a4c5c9535be22d15c82ec829c2df_normal.jpeg",
    "id" : 22396883,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://dev.twitter.com/\" rel=\"nofollow\">API</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Fin",
      "screen_name" : "finbarrbrady",
      "indices" : [ 3, 16 ],
      "id_str" : "14371943",
      "id" : 14371943
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "17055702664",
  "text" : "RT @finbarrbrady: When Chuck Norris touches an iPhone 4, the signal strength increases",
  "retweeted_status" : {
    "source" : "<a href=\"http://seesmic.com/app\" rel=\"nofollow\">Seesmic Web</a>",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : {
    },
    "id_str" : "17003465704",
    "text" : "When Chuck Norris touches an iPhone 4, the signal strength increases",
    "id" : 17003465704,
    "created_at" : "Fri Jun 25 10:10:04 +0000 2010",
    "user" : {
      "name" : "Fin",
      "screen_name" : "finbarrbrady",
      "protected" : false,
      "id_str" : "14371943",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/1527985273/5B020841-3ED4-4C42-B1D0-AD6A51E49868_normal",
      "id" : 14371943,
      "verified" : false
    }
  },
  "id" : 17055702664,
  "created_at" : "Sat Jun 26 00:53:34 +0000 2010",
  "user" : {
    "name" : "Felix",
    "screen_name" : "nicidienase",
    "protected" : false,
    "id_str" : "22396883",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3125784966/8223a4c5c9535be22d15c82ec829c2df_normal.jpeg",
    "id" : 22396883,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://pivotallabs.com/landing/tweed\" rel=\"nofollow\">Tweed</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sunday8pm",
      "screen_name" : "sunday_8pm",
      "indices" : [ 0, 11 ],
      "id_str" : "80762004",
      "id" : 80762004
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "16856605120",
  "geo" : {
  },
  "id_str" : "16877820102",
  "in_reply_to_user_id" : 80762004,
  "text" : "@Sunday_8pm Das Sekretariat war halt im 9. und maximal m\u00F6glich w\u00E4r der 13. gewesen, und da sitzen die Meteorologen.",
  "id" : 16877820102,
  "in_reply_to_status_id" : 16856605120,
  "created_at" : "Wed Jun 23 21:17:25 +0000 2010",
  "in_reply_to_screen_name" : "sunday_8pm",
  "in_reply_to_user_id_str" : "80762004",
  "user" : {
    "name" : "Felix",
    "screen_name" : "nicidienase",
    "protected" : false,
    "id_str" : "22396883",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3125784966/8223a4c5c9535be22d15c82ec829c2df_normal.jpeg",
    "id" : 22396883,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://pivotallabs.com/landing/tweed\" rel=\"nofollow\">Tweed</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "16843992836",
  "text" : "9. Stock Physikhochhaus zu Fu\u00DF gelaufen. Das war genug Sport f\u00FCr heute.",
  "id" : 16843992836,
  "created_at" : "Wed Jun 23 11:47:58 +0000 2010",
  "user" : {
    "name" : "Felix",
    "screen_name" : "nicidienase",
    "protected" : false,
    "id_str" : "22396883",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3125784966/8223a4c5c9535be22d15c82ec829c2df_normal.jpeg",
    "id" : 22396883,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://pivotallabs.com/landing/tweed\" rel=\"nofollow\">Tweed</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sunday8pm",
      "screen_name" : "sunday_8pm",
      "indices" : [ 0, 11 ],
      "id_str" : "80762004",
      "id" : 80762004
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "16236634676",
  "geo" : {
  },
  "id_str" : "16257720921",
  "in_reply_to_user_id" : 80762004,
  "text" : "@Sunday_8pm Cool, neues Spielzeug is immer gut.",
  "id" : 16257720921,
  "in_reply_to_status_id" : 16236634676,
  "created_at" : "Tue Jun 15 21:58:24 +0000 2010",
  "in_reply_to_screen_name" : "sunday_8pm",
  "in_reply_to_user_id_str" : "80762004",
  "user" : {
    "name" : "Felix",
    "screen_name" : "nicidienase",
    "protected" : false,
    "id_str" : "22396883",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3125784966/8223a4c5c9535be22d15c82ec829c2df_normal.jpeg",
    "id" : 22396883,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://pivotallabs.com/landing/tweed\" rel=\"nofollow\">Tweed</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Darth Vader",
      "screen_name" : "darthvader",
      "indices" : [ 3, 14 ],
      "id_str" : "618593",
      "id" : 618593
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "worldcup",
      "indices" : [ 47, 56 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "16036479522",
  "text" : "RT @darthvader: Do or do not, there is no tie. #worldcup",
  "id" : 16036479522,
  "created_at" : "Sat Jun 12 23:39:45 +0000 2010",
  "user" : {
    "name" : "Felix",
    "screen_name" : "nicidienase",
    "protected" : false,
    "id_str" : "22396883",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3125784966/8223a4c5c9535be22d15c82ec829c2df_normal.jpeg",
    "id" : 22396883,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://pivotallabs.com/landing/tweed\" rel=\"nofollow\">Tweed</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Holger Klein",
      "screen_name" : "holgi",
      "indices" : [ 3, 9 ],
      "id_str" : "3068271",
      "id" : 3068271
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "bravo",
      "indices" : [ 67, 73 ]
    }, {
      "text" : "sebf",
      "indices" : [ 74, 79 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "15856924636",
  "text" : "RT @holgi: *ROFL* 20 Tips, davon 18 strafbar: http://bit.ly/dzhQw3 #bravo #sebf",
  "id" : 15856924636,
  "created_at" : "Thu Jun 10 15:14:39 +0000 2010",
  "user" : {
    "name" : "Felix",
    "screen_name" : "nicidienase",
    "protected" : false,
    "id_str" : "22396883",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3125784966/8223a4c5c9535be22d15c82ec829c2df_normal.jpeg",
    "id" : 22396883,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://pivotallabs.com/landing/tweed\" rel=\"nofollow\">Tweed</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Gerd Eist",
      "screen_name" : "erdgeist",
      "indices" : [ 3, 12 ],
      "id_str" : "16701619",
      "id" : 16701619
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "15618312055",
  "text" : "RT @erdgeist: Batlh be'Hom tlhej bathlet http://i.imgur.com/Zs1XQ.jpg",
  "id" : 15618312055,
  "created_at" : "Mon Jun 07 09:39:42 +0000 2010",
  "user" : {
    "name" : "Felix",
    "screen_name" : "nicidienase",
    "protected" : false,
    "id_str" : "22396883",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3125784966/8223a4c5c9535be22d15c82ec829c2df_normal.jpeg",
    "id" : 22396883,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://pivotallabs.com/landing/tweed\" rel=\"nofollow\">Tweed</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "15617842087",
  "text" : "This Drummer is at the wrong Gig: http://www.youtube.com/watch?v=EbbjDbvZQ1U",
  "id" : 15617842087,
  "created_at" : "Mon Jun 07 09:26:41 +0000 2010",
  "user" : {
    "name" : "Felix",
    "screen_name" : "nicidienase",
    "protected" : false,
    "id_str" : "22396883",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3125784966/8223a4c5c9535be22d15c82ec829c2df_normal.jpeg",
    "id" : 22396883,
    "verified" : false
  }
} ]