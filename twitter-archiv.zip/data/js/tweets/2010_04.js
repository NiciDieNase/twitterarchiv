Grailbird.data.tweets_2010_04 = 
 [ {
  "source" : "<a href=\"http://pivotallabs.com/landing/tweed\" rel=\"nofollow\">Tweed</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Edward",
      "screen_name" : "twitgeridoo",
      "indices" : [ 3, 15 ],
      "id_str" : "46379961",
      "id" : 46379961
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "13095561329",
  "text" : "RT @twitgeridoo: Kauft mehr chinesische Milit\u00E4rschaufeln! http://j.mp/aUzMY9 :D",
  "id" : 13095561329,
  "created_at" : "Thu Apr 29 23:15:30 +0000 2010",
  "user" : {
    "name" : "Felix",
    "screen_name" : "nicidienase",
    "protected" : false,
    "id_str" : "22396883",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3125784966/8223a4c5c9535be22d15c82ec829c2df_normal.jpeg",
    "id" : 22396883,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://pivotallabs.com/landing/tweed\" rel=\"nofollow\">Tweed</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "12990534636",
  "text" : "In aller Herrgottsfr\u00FChe aufgestanden uns Schreibtischstuhl zum reparieren zum Hausmeister gebracht. Was mach ich jetzt 2h bis zur Vorlesung?",
  "id" : 12990534636,
  "created_at" : "Wed Apr 28 05:46:22 +0000 2010",
  "user" : {
    "name" : "Felix",
    "screen_name" : "nicidienase",
    "protected" : false,
    "id_str" : "22396883",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3125784966/8223a4c5c9535be22d15c82ec829c2df_normal.jpeg",
    "id" : 22396883,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://pivotallabs.com/landing/tweed\" rel=\"nofollow\">Tweed</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mario Sixtus",
      "screen_name" : "sixtus",
      "indices" : [ 3, 10 ],
      "id_str" : "9334352",
      "id" : 9334352
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "12731223919",
  "text" : "RT @sixtus: Warum ich die Apple-Attit\u00FCde gerne mit der DDR vergleiche? Vielleicht wegen solcher Geschichtchen: http://is.gd/bFp0q",
  "id" : 12731223919,
  "created_at" : "Fri Apr 23 23:38:43 +0000 2010",
  "user" : {
    "name" : "Felix",
    "screen_name" : "nicidienase",
    "protected" : false,
    "id_str" : "22396883",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3125784966/8223a4c5c9535be22d15c82ec829c2df_normal.jpeg",
    "id" : 22396883,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Gerd Eist",
      "screen_name" : "erdgeist",
      "indices" : [ 3, 12 ],
      "id_str" : "16701619",
      "id" : 16701619
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "12708561016",
  "text" : "RT @erdgeist: Robot unicorn attack. (au\u00DFer iPads) http://games.adultswim.com/robot-unicorn-attack-twitchy-online-game.html",
  "retweeted_status" : {
    "source" : "<a href=\"http://twitterrific.com\" rel=\"nofollow\">Twitterrific</a>",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : {
    },
    "id_str" : "12670992033",
    "text" : "Robot unicorn attack. (au\u00DFer iPads) http://games.adultswim.com/robot-unicorn-attack-twitchy-online-game.html",
    "id" : 12670992033,
    "created_at" : "Fri Apr 23 00:30:58 +0000 2010",
    "user" : {
      "name" : "Gerd Eist",
      "screen_name" : "erdgeist",
      "protected" : false,
      "id_str" : "16701619",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/61748149/ta_normal.jpg",
      "id" : 16701619,
      "verified" : false
    }
  },
  "id" : 12708561016,
  "created_at" : "Fri Apr 23 15:33:01 +0000 2010",
  "user" : {
    "name" : "Felix",
    "screen_name" : "nicidienase",
    "protected" : false,
    "id_str" : "22396883",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3125784966/8223a4c5c9535be22d15c82ec829c2df_normal.jpeg",
    "id" : 22396883,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://pivotallabs.com/landing/tweed\" rel=\"nofollow\">Tweed</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Wil Wheaton",
      "screen_name" : "wilw",
      "indices" : [ 3, 8 ],
      "id_str" : "1183041",
      "id" : 1183041
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "12592877050",
  "text" : "RT @wilw: Wil Wheaton Prime uses Linux to bring you Evil Wil Wheaton sitting in Sheldon's spot: http://bit.ly/akB7QY",
  "id" : 12592877050,
  "created_at" : "Wed Apr 21 19:10:55 +0000 2010",
  "user" : {
    "name" : "Felix",
    "screen_name" : "nicidienase",
    "protected" : false,
    "id_str" : "22396883",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3125784966/8223a4c5c9535be22d15c82ec829c2df_normal.jpeg",
    "id" : 22396883,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://pivotallabs.com/landing/tweed\" rel=\"nofollow\">Tweed</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Edward",
      "screen_name" : "twitgeridoo",
      "indices" : [ 3, 15 ],
      "id_str" : "46379961",
      "id" : 46379961
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Filesharing",
      "indices" : [ 53, 65 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "12154769521",
  "text" : "RT @twitgeridoo: Der US-Rechnungshof r\u00E4umt ein, dass #Filesharing der Unterhaltungsindustrie dienlich sein k\u00F6nnte: http://j.mp/asIl7E",
  "id" : 12154769521,
  "created_at" : "Wed Apr 14 09:44:53 +0000 2010",
  "user" : {
    "name" : "Felix",
    "screen_name" : "nicidienase",
    "protected" : false,
    "id_str" : "22396883",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3125784966/8223a4c5c9535be22d15c82ec829c2df_normal.jpeg",
    "id" : 22396883,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://pivotallabs.com/landing/tweed\" rel=\"nofollow\">Tweed</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sunday8pm",
      "screen_name" : "sunday_8pm",
      "indices" : [ 0, 11 ],
      "id_str" : "80762004",
      "id" : 80762004
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "11982062574",
  "geo" : {
  },
  "id_str" : "11987083355",
  "in_reply_to_user_id" : 80762004,
  "text" : "@Sunday_8pm Naja, soweit weg von wir is das net. Aber auch net grade direkt vor meiner Haust\u00FCr.",
  "id" : 11987083355,
  "in_reply_to_status_id" : 11982062574,
  "created_at" : "Sun Apr 11 11:39:20 +0000 2010",
  "in_reply_to_screen_name" : "sunday_8pm",
  "in_reply_to_user_id_str" : "80762004",
  "user" : {
    "name" : "Felix",
    "screen_name" : "nicidienase",
    "protected" : false,
    "id_str" : "22396883",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3125784966/8223a4c5c9535be22d15c82ec829c2df_normal.jpeg",
    "id" : 22396883,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://pivotallabs.com/landing/tweed\" rel=\"nofollow\">Tweed</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sunday8pm",
      "screen_name" : "sunday_8pm",
      "indices" : [ 0, 11 ],
      "id_str" : "80762004",
      "id" : 80762004
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Karlsruhe",
      "indices" : [ 112, 122 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "11953264352",
  "geo" : {
  },
  "id_str" : "11957648837",
  "in_reply_to_user_id" : 80762004,
  "text" : "@Sunday_8pm Das muss dann ja grade bei mir um die Ecke gewesen sein. St\u00E4ndig diese Unf\u00E4lle mit Stra\u00DFenbahnen in #Karlsruhe",
  "id" : 11957648837,
  "in_reply_to_status_id" : 11953264352,
  "created_at" : "Sat Apr 10 21:53:22 +0000 2010",
  "in_reply_to_screen_name" : "sunday_8pm",
  "in_reply_to_user_id_str" : "80762004",
  "user" : {
    "name" : "Felix",
    "screen_name" : "nicidienase",
    "protected" : false,
    "id_str" : "22396883",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3125784966/8223a4c5c9535be22d15c82ec829c2df_normal.jpeg",
    "id" : 22396883,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://pivotallabs.com/landing/tweed\" rel=\"nofollow\">Tweed</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "stefan",
      "screen_name" : "stefan005",
      "indices" : [ 14, 24 ],
      "id_str" : "49648872",
      "id" : 49648872
    }, {
      "name" : "Tim Pritlove",
      "screen_name" : "timpritlove",
      "indices" : [ 26, 38 ],
      "id_str" : "11268812",
      "id" : 11268812
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "nsfw",
      "indices" : [ 69, 74 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "11945280972",
  "text" : "Ich auch!! RT @stefan005: @timpritlove jawoll ich freu mich schon:-) #nsfw",
  "id" : 11945280972,
  "created_at" : "Sat Apr 10 16:40:01 +0000 2010",
  "user" : {
    "name" : "Felix",
    "screen_name" : "nicidienase",
    "protected" : false,
    "id_str" : "22396883",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3125784966/8223a4c5c9535be22d15c82ec829c2df_normal.jpeg",
    "id" : 22396883,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://pivotallabs.com/landing/tweed\" rel=\"nofollow\">Tweed</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sunday8pm",
      "screen_name" : "sunday_8pm",
      "indices" : [ 0, 11 ],
      "id_str" : "80762004",
      "id" : 80762004
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "11937678087",
  "geo" : {
  },
  "id_str" : "11945132061",
  "in_reply_to_user_id" : 80762004,
  "text" : "@Sunday_8pm Da bin ich mal kurz meine Oma besuchen dann is in KA die H\u00F6lle los. Was machst du \u00FCberhaupt in KA an nem Sa?",
  "id" : 11945132061,
  "in_reply_to_status_id" : 11937678087,
  "created_at" : "Sat Apr 10 16:36:47 +0000 2010",
  "in_reply_to_screen_name" : "sunday_8pm",
  "in_reply_to_user_id_str" : "80762004",
  "user" : {
    "name" : "Felix",
    "screen_name" : "nicidienase",
    "protected" : false,
    "id_str" : "22396883",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3125784966/8223a4c5c9535be22d15c82ec829c2df_normal.jpeg",
    "id" : 22396883,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://pivotallabs.com/landing/tweed\" rel=\"nofollow\">Tweed</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "webosblog",
      "screen_name" : "webos_blog",
      "indices" : [ 3, 14 ],
      "id_str" : "36693294",
      "id" : 36693294
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "11654060254",
  "text" : "RT @webos_blog: Die \u00DCbersetzungen in Tweed sind doch beschissen. \"versuche wieder\", \"oeffentliche Zeitlinie\", \"Folger\". Dann bitte Englisch!",
  "id" : 11654060254,
  "created_at" : "Mon Apr 05 18:29:37 +0000 2010",
  "user" : {
    "name" : "Felix",
    "screen_name" : "nicidienase",
    "protected" : false,
    "id_str" : "22396883",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3125784966/8223a4c5c9535be22d15c82ec829c2df_normal.jpeg",
    "id" : 22396883,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://pivotallabs.com/landing/tweed\" rel=\"nofollow\">Tweed</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Pre",
      "indices" : [ 59, 63 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "11413026983",
  "text" : "Endlich gibt es wieder eine brauchbare StudiVZ-App f\u00FCr den #Pre. Nach gef\u00FChlten Jahrzehnten Wartezeit.",
  "id" : 11413026983,
  "created_at" : "Thu Apr 01 07:31:32 +0000 2010",
  "user" : {
    "name" : "Felix",
    "screen_name" : "nicidienase",
    "protected" : false,
    "id_str" : "22396883",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3125784966/8223a4c5c9535be22d15c82ec829c2df_normal.jpeg",
    "id" : 22396883,
    "verified" : false
  }
} ]