Grailbird.data.tweets_2012_03 = 
 [ {
  "source" : "<a href=\"http://www.echofon.com/\" rel=\"nofollow\">Echofon</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "WH36",
      "indices" : [ 37, 42 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "185625653293494273",
  "text" : "Grade Schl\u00FCssel abgegeben. Machs gut #WH36, waren 4 sch\u00F6ne Jahre im Wohnheim.",
  "id" : 185625653293494273,
  "created_at" : "Fri Mar 30 07:12:59 +0000 2012",
  "user" : {
    "name" : "Felix",
    "screen_name" : "nicidienase",
    "protected" : false,
    "id_str" : "22396883",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3125784966/8223a4c5c9535be22d15c82ec829c2df_normal.jpeg",
    "id" : 22396883,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.echofon.com/\" rel=\"nofollow\">Echofon</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tim Weber",
      "screen_name" : "Scytale",
      "indices" : [ 3, 11 ],
      "id_str" : "594921016",
      "id" : 594921016
    }, {
      "name" : "Jericho Seguenza",
      "screen_name" : "echox",
      "indices" : [ 76, 82 ],
      "id_str" : "1100913680",
      "id" : 1100913680
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 50, 70 ],
      "url" : "http://t.co/nRTCLZgA",
      "expanded_url" : "http://madebyevan.com/webgl-water/",
      "display_url" : "madebyevan.com/webgl-water/"
    } ]
  },
  "geo" : {
  },
  "id_str" : "185363972269158400",
  "text" : "RT @Scytale: Wow. WebGL-Demo mit Wasser und Zeug. http://t.co/nRTCLZgA (via @echox)",
  "retweeted_status" : {
    "source" : "<a href=\"http://www.tweetdeck.com\" rel=\"nofollow\">TweetDeck</a>",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Jericho Seguenza",
        "screen_name" : "echox",
        "indices" : [ 63, 69 ],
        "id_str" : "1100913680",
        "id" : 1100913680
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 37, 57 ],
        "url" : "http://t.co/nRTCLZgA",
        "expanded_url" : "http://madebyevan.com/webgl-water/",
        "display_url" : "madebyevan.com/webgl-water/"
      } ]
    },
    "geo" : {
      "type" : "Point",
      "coordinates" : [ 49.4955473928, 8.4576165676 ]
    },
    "id_str" : "185363048226238466",
    "text" : "Wow. WebGL-Demo mit Wasser und Zeug. http://t.co/nRTCLZgA (via @echox)",
    "id" : 185363048226238466,
    "created_at" : "Thu Mar 29 13:49:29 +0000 2012",
    "user" : {
      "name" : "Tim Weber",
      "screen_name" : "scy",
      "protected" : false,
      "id_str" : "8308632",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/424137519/avatar184_normal.jpg",
      "id" : 8308632,
      "verified" : false
    }
  },
  "id" : 185363972269158400,
  "created_at" : "Thu Mar 29 13:53:09 +0000 2012",
  "user" : {
    "name" : "Felix",
    "screen_name" : "nicidienase",
    "protected" : false,
    "id_str" : "22396883",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3125784966/8223a4c5c9535be22d15c82ec829c2df_normal.jpeg",
    "id" : 22396883,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.echofon.com/\" rel=\"nofollow\">Echofon</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "andreasdotorg",
      "screen_name" : "andreasdotorg",
      "indices" : [ 0, 14 ],
      "id_str" : "14285735",
      "id" : 14285735
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "185353407052255232",
  "geo" : {
  },
  "id_str" : "185353948432052224",
  "in_reply_to_user_id" : 14285735,
  "text" : "@andreasdotorg Bin gespannt wann die EU Crashtests verbiete um Autos sicherer zu machen.",
  "id" : 185353948432052224,
  "in_reply_to_status_id" : 185353407052255232,
  "created_at" : "Thu Mar 29 13:13:19 +0000 2012",
  "in_reply_to_screen_name" : "andreasdotorg",
  "in_reply_to_user_id_str" : "14285735",
  "user" : {
    "name" : "Felix",
    "screen_name" : "nicidienase",
    "protected" : false,
    "id_str" : "22396883",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3125784966/8223a4c5c9535be22d15c82ec829c2df_normal.jpeg",
    "id" : 22396883,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.echofon.com/\" rel=\"nofollow\">Echofon</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lilly W.",
      "screen_name" : "dielilly",
      "indices" : [ 0, 9 ],
      "id_str" : "19603003",
      "id" : 19603003
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "185338824849764352",
  "geo" : {
  },
  "id_str" : "185339730265780225",
  "in_reply_to_user_id" : 19603003,
  "text" : "@dielilly Weil mehr Leute Geld f\u00FCr \u00FCberteuerte Taschen als f\u00FCr \u00FCberteuerte Autos haben.",
  "id" : 185339730265780225,
  "in_reply_to_status_id" : 185338824849764352,
  "created_at" : "Thu Mar 29 12:16:49 +0000 2012",
  "in_reply_to_screen_name" : "dielilly",
  "in_reply_to_user_id_str" : "19603003",
  "user" : {
    "name" : "Felix",
    "screen_name" : "nicidienase",
    "protected" : false,
    "id_str" : "22396883",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3125784966/8223a4c5c9535be22d15c82ec829c2df_normal.jpeg",
    "id" : 22396883,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.echofon.com/\" rel=\"nofollow\">Echofon</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tim Weber",
      "screen_name" : "Scytale",
      "indices" : [ 3, 11 ],
      "id_str" : "594921016",
      "id" : 594921016
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "185023503479738371",
  "text" : "RT @Scytale: OH: \u00BBIch glaub jeder merkt sich das mit der selben Eselsbr\u00FCcke.\u00AB\u00A0\u2013 \u00BBWas?\u00AB\u00A0\u2013 \u00BBStalagtiten.\u00AB",
  "retweeted_status" : {
    "source" : "<a href=\"http://www.tweetdeck.com\" rel=\"nofollow\">TweetDeck</a>",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : {
      "type" : "Point",
      "coordinates" : [ 49.4955473928, 8.4576165676 ]
    },
    "id_str" : "185023136369098752",
    "text" : "OH: \u00BBIch glaub jeder merkt sich das mit der selben Eselsbr\u00FCcke.\u00AB\u00A0\u2013 \u00BBWas?\u00AB\u00A0\u2013 \u00BBStalagtiten.\u00AB",
    "id" : 185023136369098752,
    "created_at" : "Wed Mar 28 15:18:47 +0000 2012",
    "user" : {
      "name" : "Tim Weber",
      "screen_name" : "scy",
      "protected" : false,
      "id_str" : "8308632",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/424137519/avatar184_normal.jpg",
      "id" : 8308632,
      "verified" : false
    }
  },
  "id" : 185023503479738371,
  "created_at" : "Wed Mar 28 15:20:15 +0000 2012",
  "user" : {
    "name" : "Felix",
    "screen_name" : "nicidienase",
    "protected" : false,
    "id_str" : "22396883",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3125784966/8223a4c5c9535be22d15c82ec829c2df_normal.jpeg",
    "id" : 22396883,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.echofon.com/\" rel=\"nofollow\">Echofon</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Stephan D\u00F6rner",
      "screen_name" : "Doener",
      "indices" : [ 3, 10 ],
      "id_str" : "14742504",
      "id" : 14742504
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 95, 115 ],
      "url" : "http://t.co/C5isnZyV",
      "expanded_url" : "http://www.happyplace.com/15065/guy-comes-out-of-closet-on-facebook-to-friends-entirely-too-geeky-to-care",
      "display_url" : "happyplace.com/15065/guy-come\u2026"
    } ]
  },
  "geo" : {
  },
  "id_str" : "184957436770254848",
  "text" : "RT @Doener: Guy comes out of closet on Facebook to friends who are entirely too geeky to care. http://t.co/C5isnZyV",
  "retweeted_status" : {
    "source" : "web",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 83, 103 ],
        "url" : "http://t.co/C5isnZyV",
        "expanded_url" : "http://www.happyplace.com/15065/guy-comes-out-of-closet-on-facebook-to-friends-entirely-too-geeky-to-care",
        "display_url" : "happyplace.com/15065/guy-come\u2026"
      } ]
    },
    "geo" : {
    },
    "id_str" : "184937133939752960",
    "text" : "Guy comes out of closet on Facebook to friends who are entirely too geeky to care. http://t.co/C5isnZyV",
    "id" : 184937133939752960,
    "created_at" : "Wed Mar 28 09:37:03 +0000 2012",
    "user" : {
      "name" : "Stephan D\u00F6rner",
      "screen_name" : "Doener",
      "protected" : false,
      "id_str" : "14742504",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/2936265019/f01857933ac694ec5abdfb095e3288c3_normal.jpeg",
      "id" : 14742504,
      "verified" : false
    }
  },
  "id" : 184957436770254848,
  "created_at" : "Wed Mar 28 10:57:43 +0000 2012",
  "user" : {
    "name" : "Felix",
    "screen_name" : "nicidienase",
    "protected" : false,
    "id_str" : "22396883",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3125784966/8223a4c5c9535be22d15c82ec829c2df_normal.jpeg",
    "id" : 22396883,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.echofon.com/\" rel=\"nofollow\">Echofon</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Die Marginalen",
      "screen_name" : "DieMarginalen",
      "indices" : [ 3, 17 ],
      "id_str" : "520329951",
      "id" : 520329951
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "184921846263717888",
  "text" : "RT @DieMarginalen: Atomkraft ist gut! Es gibt keine Endlagerproblematik. Das ist nur eine Tyrannei der Asse.",
  "retweeted_status" : {
    "source" : "<a href=\"http://www.tweetdeck.com\" rel=\"nofollow\">TweetDeck</a>",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : {
    },
    "id_str" : "184920353645150208",
    "text" : "Atomkraft ist gut! Es gibt keine Endlagerproblematik. Das ist nur eine Tyrannei der Asse.",
    "id" : 184920353645150208,
    "created_at" : "Wed Mar 28 08:30:22 +0000 2012",
    "user" : {
      "name" : "Die Marginalen",
      "screen_name" : "DieMarginalen",
      "protected" : false,
      "id_str" : "520329951",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/1886071460/diemarginalen_normal.png",
      "id" : 520329951,
      "verified" : false
    }
  },
  "id" : 184921846263717888,
  "created_at" : "Wed Mar 28 08:36:18 +0000 2012",
  "user" : {
    "name" : "Felix",
    "screen_name" : "nicidienase",
    "protected" : false,
    "id_str" : "22396883",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3125784966/8223a4c5c9535be22d15c82ec829c2df_normal.jpeg",
    "id" : 22396883,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.echofon.com/\" rel=\"nofollow\">Echofon</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tim Weber",
      "screen_name" : "Scytale",
      "indices" : [ 3, 11 ],
      "id_str" : "594921016",
      "id" : 594921016
    }, {
      "name" : "Kev",
      "screen_name" : "einfachkaputt",
      "indices" : [ 91, 105 ],
      "id_str" : "86698329",
      "id" : 86698329
    }, {
      "name" : "Cheatha",
      "screen_name" : "Cheatha",
      "indices" : [ 106, 114 ],
      "id_str" : "6712152",
      "id" : 6712152
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 65, 85 ],
      "url" : "http://t.co/PNIccxxP",
      "expanded_url" : "http://yfrog.com/kiabzsuj",
      "display_url" : "yfrog.com/kiabzsuj"
    } ]
  },
  "geo" : {
  },
  "id_str" : "184591206641188864",
  "text" : "RT @Scytale: So, jetzt wrd aber gebumst! Ich bumse n\u00E4mlich gern. http://t.co/PNIccxxP (via @einfachkaputt @Cheatha)",
  "retweeted_status" : {
    "source" : "<a href=\"http://www.tweetdeck.com\" rel=\"nofollow\">TweetDeck</a>",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Kev",
        "screen_name" : "einfachkaputt",
        "indices" : [ 78, 92 ],
        "id_str" : "86698329",
        "id" : 86698329
      }, {
        "name" : "Cheatha",
        "screen_name" : "Cheatha",
        "indices" : [ 93, 101 ],
        "id_str" : "6712152",
        "id" : 6712152
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 52, 72 ],
        "url" : "http://t.co/PNIccxxP",
        "expanded_url" : "http://yfrog.com/kiabzsuj",
        "display_url" : "yfrog.com/kiabzsuj"
      } ]
    },
    "geo" : {
      "type" : "Point",
      "coordinates" : [ 49.4955473928, 8.4576165676 ]
    },
    "id_str" : "184568272597954560",
    "text" : "So, jetzt wrd aber gebumst! Ich bumse n\u00E4mlich gern. http://t.co/PNIccxxP (via @einfachkaputt @Cheatha)",
    "id" : 184568272597954560,
    "created_at" : "Tue Mar 27 09:11:19 +0000 2012",
    "user" : {
      "name" : "Tim Weber",
      "screen_name" : "scy",
      "protected" : false,
      "id_str" : "8308632",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/424137519/avatar184_normal.jpg",
      "id" : 8308632,
      "verified" : false
    }
  },
  "id" : 184591206641188864,
  "created_at" : "Tue Mar 27 10:42:27 +0000 2012",
  "user" : {
    "name" : "Felix",
    "screen_name" : "nicidienase",
    "protected" : false,
    "id_str" : "22396883",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3125784966/8223a4c5c9535be22d15c82ec829c2df_normal.jpeg",
    "id" : 22396883,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://getspaz.com\" rel=\"nofollow\">Spaz HD for webOS</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tim Pritlove",
      "screen_name" : "timpritlove",
      "indices" : [ 3, 15 ],
      "id_str" : "11268812",
      "id" : 11268812
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 53, 73 ],
      "url" : "http://t.co/scbWHo2x",
      "expanded_url" : "http://blog.intercom.io/whats-in-a-name/",
      "display_url" : "blog.intercom.io/whats-in-a-nam\u2026"
    } ]
  },
  "geo" : {
  },
  "id_str" : "184350706449391620",
  "text" : "RT @timpritlove: Is it a condom or is it an Android? http://t.co/scbWHo2x",
  "retweeted_status" : {
    "source" : "<a href=\"http://tapbots.com/tweetbot\" rel=\"nofollow\">Tweetbot for iOS</a>",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 36, 56 ],
        "url" : "http://t.co/scbWHo2x",
        "expanded_url" : "http://blog.intercom.io/whats-in-a-name/",
        "display_url" : "blog.intercom.io/whats-in-a-nam\u2026"
      } ]
    },
    "geo" : {
    },
    "id_str" : "184345671082590208",
    "text" : "Is it a condom or is it an Android? http://t.co/scbWHo2x",
    "id" : 184345671082590208,
    "created_at" : "Mon Mar 26 18:26:47 +0000 2012",
    "user" : {
      "name" : "Tim Pritlove",
      "screen_name" : "timpritlove",
      "protected" : false,
      "id_str" : "11268812",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/2332275606/Tim_Pritlove_2009_Avatar_512x512_normal.jpg",
      "id" : 11268812,
      "verified" : true
    }
  },
  "id" : 184350706449391620,
  "created_at" : "Mon Mar 26 18:46:48 +0000 2012",
  "user" : {
    "name" : "Felix",
    "screen_name" : "nicidienase",
    "protected" : false,
    "id_str" : "22396883",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3125784966/8223a4c5c9535be22d15c82ec829c2df_normal.jpeg",
    "id" : 22396883,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.echofon.com/\" rel=\"nofollow\">Echofon</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "184180874005323776",
  "text" : "OH: \"Es wird Fr\u00FChling, drau\u00DFen twittern die V\u00F6gel.\"",
  "id" : 184180874005323776,
  "created_at" : "Mon Mar 26 07:31:56 +0000 2012",
  "user" : {
    "name" : "Felix",
    "screen_name" : "nicidienase",
    "protected" : false,
    "id_str" : "22396883",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3125784966/8223a4c5c9535be22d15c82ec829c2df_normal.jpeg",
    "id" : 22396883,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://getspaz.com\" rel=\"nofollow\">Spaz HD for webOS</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dana Contreras",
      "screen_name" : "DanaDanger",
      "indices" : [ 3, 14 ],
      "id_str" : "821958",
      "id" : 821958
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "184022254202527744",
  "text" : "RT @DanaDanger: HTTP response codes for dummies. 50x: we fucked up. 40x: you fucked up. 30x: ask that dude over there. 20x: cool.",
  "retweeted_status" : {
    "source" : "<a href=\"http://itunes.apple.com/us/app/twitter/id409789998?mt=12\" rel=\"nofollow\">Twitter for Mac</a>",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : {
    },
    "id_str" : "183316183494311936",
    "text" : "HTTP response codes for dummies. 50x: we fucked up. 40x: you fucked up. 30x: ask that dude over there. 20x: cool.",
    "id" : 183316183494311936,
    "created_at" : "Fri Mar 23 22:15:58 +0000 2012",
    "user" : {
      "name" : "Dana Contreras",
      "screen_name" : "DanaDanger",
      "protected" : false,
      "id_str" : "821958",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/3210283193/49a7ef90a568f680d31b9e748aabaa62_normal.jpeg",
      "id" : 821958,
      "verified" : false
    }
  },
  "id" : 184022254202527744,
  "created_at" : "Sun Mar 25 21:01:39 +0000 2012",
  "user" : {
    "name" : "Felix",
    "screen_name" : "nicidienase",
    "protected" : false,
    "id_str" : "22396883",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3125784966/8223a4c5c9535be22d15c82ec829c2df_normal.jpeg",
    "id" : 22396883,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://getspaz.com\" rel=\"nofollow\">Spaz HD for webOS</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Raumzeit",
      "screen_name" : "raumzeit",
      "indices" : [ 17, 26 ],
      "id_str" : "84790809",
      "id" : 84790809
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 94, 114 ],
      "url" : "http://t.co/VBlk83A4",
      "expanded_url" : "http://www.raumzeit-podcast.de/abonnieren/",
      "display_url" : "raumzeit-podcast.de/abonnieren/"
    } ]
  },
  "geo" : {
  },
  "id_str" : "183858969121533952",
  "text" : "Yeay Danke!1! RT @raumzeit Der mehrfach gew\u00FCnschte MP3-Feed f\u00FCr Raumzeit ist jetzt verf\u00FCgbar: http://t.co/VBlk83A4",
  "id" : 183858969121533952,
  "created_at" : "Sun Mar 25 10:12:48 +0000 2012",
  "user" : {
    "name" : "Felix",
    "screen_name" : "nicidienase",
    "protected" : false,
    "id_str" : "22396883",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3125784966/8223a4c5c9535be22d15c82ec829c2df_normal.jpeg",
    "id" : 22396883,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://getspaz.com\" rel=\"nofollow\">Spaz</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kate H.",
      "screen_name" : "elaoe7",
      "indices" : [ 0, 7 ],
      "id_str" : "149650777",
      "id" : 149650777
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "183640230140710912",
  "geo" : {
  },
  "id_str" : "183649379188613120",
  "in_reply_to_user_id" : 149650777,
  "text" : "@elaoe7 Ich was \u00FCberrascht das sie Lampe weg und der Rechner noch da was.Aber wir ham jetzt unseren meisten Krempel daJetzt grillen wir noch",
  "id" : 183649379188613120,
  "in_reply_to_status_id" : 183640230140710912,
  "created_at" : "Sat Mar 24 20:19:58 +0000 2012",
  "in_reply_to_screen_name" : "elaoe7",
  "in_reply_to_user_id_str" : "149650777",
  "user" : {
    "name" : "Felix",
    "screen_name" : "nicidienase",
    "protected" : false,
    "id_str" : "22396883",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3125784966/8223a4c5c9535be22d15c82ec829c2df_normal.jpeg",
    "id" : 22396883,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.echofon.com/\" rel=\"nofollow\">Echofon</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lore Frost",
      "screen_name" : "Lobot",
      "indices" : [ 3, 9 ],
      "id_str" : "1492631",
      "id" : 1492631
    }, {
      "name" : "Arne",
      "screen_name" : "aberaberarne",
      "indices" : [ 14, 27 ],
      "id_str" : "36003089",
      "id" : 36003089
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "uniwtal",
      "indices" : [ 117, 125 ]
    } ],
    "urls" : [ {
      "indices" : [ 96, 116 ],
      "url" : "http://t.co/QhASI2x2",
      "expanded_url" : "http://is.gd/Q3zbvA",
      "display_url" : "is.gd/Q3zbvA"
    } ]
  },
  "geo" : {
  },
  "id_str" : "182050193624150018",
  "text" : "RT @Lobot: RT @aberaberarne: \"Lehramt am Berufsko\u2026\" Moment: \"Lehramt an Berufske\u2026\" Wait, what!? http://t.co/QhASI2x2 #uniwtal http://t.c ...",
  "retweeted_status" : {
    "source" : "<a href=\"http://www.tweetdeck.com\" rel=\"nofollow\">TweetDeck</a>",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Arne",
        "screen_name" : "aberaberarne",
        "indices" : [ 3, 16 ],
        "id_str" : "36003089",
        "id" : 36003089
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "uniwtal",
        "indices" : [ 106, 114 ]
      } ],
      "urls" : [ {
        "indices" : [ 85, 105 ],
        "url" : "http://t.co/QhASI2x2",
        "expanded_url" : "http://is.gd/Q3zbvA",
        "display_url" : "is.gd/Q3zbvA"
      }, {
        "indices" : [ 115, 135 ],
        "url" : "http://t.co/ktONb9TN",
        "expanded_url" : "http://twitpic.com/8yur5g",
        "display_url" : "twitpic.com/8yur5g"
      } ]
    },
    "geo" : {
    },
    "id_str" : "182048700342865920",
    "text" : "RT @aberaberarne: \"Lehramt am Berufsko\u2026\" Moment: \"Lehramt an Berufske\u2026\" Wait, what!? http://t.co/QhASI2x2 #uniwtal http://t.co/ktONb9TN",
    "id" : 182048700342865920,
    "created_at" : "Tue Mar 20 10:19:27 +0000 2012",
    "user" : {
      "name" : "Lore Frost",
      "screen_name" : "Lobot",
      "protected" : false,
      "id_str" : "1492631",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/1846171052/user_manual_330x330_sw_normal.jpg",
      "id" : 1492631,
      "verified" : false
    }
  },
  "id" : 182050193624150018,
  "created_at" : "Tue Mar 20 10:25:23 +0000 2012",
  "user" : {
    "name" : "Felix",
    "screen_name" : "nicidienase",
    "protected" : false,
    "id_str" : "22396883",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3125784966/8223a4c5c9535be22d15c82ec829c2df_normal.jpeg",
    "id" : 22396883,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://getspaz.com\" rel=\"nofollow\">Spaz</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 51, 71 ],
      "url" : "http://t.co/2rcCclOC",
      "expanded_url" : "http://twitpic.com/8xpuyp",
      "display_url" : "twitpic.com/8xpuyp"
    } ]
  },
  "geo" : {
  },
  "id_str" : "181155734627692544",
  "text" : "Milch 43 aus dem K\u00E4tzchenglas - lecker und knuffig http://t.co/2rcCclOC",
  "id" : 181155734627692544,
  "created_at" : "Sat Mar 17 23:11:07 +0000 2012",
  "user" : {
    "name" : "Felix",
    "screen_name" : "nicidienase",
    "protected" : false,
    "id_str" : "22396883",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3125784966/8223a4c5c9535be22d15c82ec829c2df_normal.jpeg",
    "id" : 22396883,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://getspaz.com\" rel=\"nofollow\">Spaz HD for webOS</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Gordin",
      "screen_name" : "g0rdin",
      "indices" : [ 3, 10 ],
      "id_str" : "41788328",
      "id" : 41788328
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "leidergeil",
      "indices" : [ 113, 124 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "181035976104230913",
  "text" : "RT @g0rdin: Falls ihr euch fragt, wie man ohne Balkon aus dem Fenster raus grillen kann, genau SO macht man das. #leidergeil http://t.co ...",
  "retweeted_status" : {
    "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "http://twitter.com/g0rdin/status/180661205839511556/photo/1",
        "indices" : [ 113, 133 ],
        "url" : "http://t.co/Ut95lqR5",
        "media_url" : "http://pbs.twimg.com/media/AoHWaNdCAAA3vXm.jpg",
        "id_str" : "180661205847900160",
        "id" : 180661205847900160,
        "media_url_https" : "https://pbs.twimg.com/media/AoHWaNdCAAA3vXm.jpg",
        "sizes" : [ {
          "h" : 2592,
          "resize" : "fit",
          "w" : 1944
        }, {
          "h" : 1365,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 453,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 800,
          "resize" : "fit",
          "w" : 600
        } ],
        "display_url" : "pic.twitter.com/Ut95lqR5"
      } ],
      "hashtags" : [ {
        "text" : "leidergeil",
        "indices" : [ 101, 112 ]
      } ],
      "urls" : [ ]
    },
    "geo" : {
    },
    "id_str" : "180661205839511556",
    "text" : "Falls ihr euch fragt, wie man ohne Balkon aus dem Fenster raus grillen kann, genau SO macht man das. #leidergeil http://t.co/Ut95lqR5",
    "id" : 180661205839511556,
    "created_at" : "Fri Mar 16 14:26:03 +0000 2012",
    "user" : {
      "name" : "Gordin",
      "screen_name" : "g0rdin",
      "protected" : false,
      "id_str" : "41788328",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/1722265246/Quadrat_normal.jpg",
      "id" : 41788328,
      "verified" : false
    }
  },
  "id" : 181035976104230913,
  "created_at" : "Sat Mar 17 15:15:14 +0000 2012",
  "user" : {
    "name" : "Felix",
    "screen_name" : "nicidienase",
    "protected" : false,
    "id_str" : "22396883",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3125784966/8223a4c5c9535be22d15c82ec829c2df_normal.jpeg",
    "id" : 22396883,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.echofon.com/\" rel=\"nofollow\">Echofon</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "zero",
      "screen_name" : "_zero",
      "indices" : [ 0, 6 ],
      "id_str" : "14176177",
      "id" : 14176177
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "180274548883730432",
  "geo" : {
  },
  "id_str" : "180276687957798915",
  "in_reply_to_user_id" : 14176177,
  "text" : "@_zero K\u00F6nntest du die mir nicht irgendwie schicken? Ich k\u00F6nnte die gerade dringend gebrauchen.",
  "id" : 180276687957798915,
  "in_reply_to_status_id" : 180274548883730432,
  "created_at" : "Thu Mar 15 12:58:06 +0000 2012",
  "in_reply_to_screen_name" : "_zero",
  "in_reply_to_user_id_str" : "14176177",
  "user" : {
    "name" : "Felix",
    "screen_name" : "nicidienase",
    "protected" : false,
    "id_str" : "22396883",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3125784966/8223a4c5c9535be22d15c82ec829c2df_normal.jpeg",
    "id" : 22396883,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.echofon.com/\" rel=\"nofollow\">Echofon</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "zero",
      "screen_name" : "_zero",
      "indices" : [ 0, 6 ],
      "id_str" : "14176177",
      "id" : 14176177
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "180242880269516800",
  "in_reply_to_user_id" : 14176177,
  "text" : "@_zero Gibt es die Slides von deinem \"Context is Magic\"-Talk schon irgendwo online?",
  "id" : 180242880269516800,
  "created_at" : "Thu Mar 15 10:43:46 +0000 2012",
  "in_reply_to_screen_name" : "_zero",
  "in_reply_to_user_id_str" : "14176177",
  "user" : {
    "name" : "Felix",
    "screen_name" : "nicidienase",
    "protected" : false,
    "id_str" : "22396883",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3125784966/8223a4c5c9535be22d15c82ec829c2df_normal.jpeg",
    "id" : 22396883,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.echofon.com/\" rel=\"nofollow\">Echofon</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "lol",
      "indices" : [ 0, 4 ]
    } ],
    "urls" : [ {
      "indices" : [ 5, 25 ],
      "url" : "http://t.co/NhMUAGnH",
      "expanded_url" : "http://stackoverflow.com/a/245073/298479",
      "display_url" : "stackoverflow.com/a/245073/298479"
    } ]
  },
  "geo" : {
  },
  "id_str" : "180239889592369152",
  "text" : "#lol http://t.co/NhMUAGnH",
  "id" : 180239889592369152,
  "created_at" : "Thu Mar 15 10:31:53 +0000 2012",
  "user" : {
    "name" : "Felix",
    "screen_name" : "nicidienase",
    "protected" : false,
    "id_str" : "22396883",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3125784966/8223a4c5c9535be22d15c82ec829c2df_normal.jpeg",
    "id" : 22396883,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.echofon.com/\" rel=\"nofollow\">Echofon</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "octonyancat",
      "indices" : [ 28, 40 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 20 ],
      "url" : "http://t.co/fbgDhcq1",
      "expanded_url" : "http://octodex.github.com/nyantocat/",
      "display_url" : "octodex.github.com/nyantocat/"
    } ]
  },
  "geo" : {
  },
  "id_str" : "179844629296988160",
  "text" : "http://t.co/fbgDhcq1 Yeah!! #octonyancat",
  "id" : 179844629296988160,
  "created_at" : "Wed Mar 14 08:21:15 +0000 2012",
  "user" : {
    "name" : "Felix",
    "screen_name" : "nicidienase",
    "protected" : false,
    "id_str" : "22396883",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3125784966/8223a4c5c9535be22d15c82ec829c2df_normal.jpeg",
    "id" : 22396883,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://getspaz.com\" rel=\"nofollow\">Spaz</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sunday8pm",
      "screen_name" : "sunday_8pm",
      "indices" : [ 0, 11 ],
      "id_str" : "80762004",
      "id" : 80762004
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "179605213039173632",
  "geo" : {
  },
  "id_str" : "179628590147706880",
  "in_reply_to_user_id" : 80762004,
  "text" : "@Sunday_8pm N\u00F6, ich programmier in der Arbeit f\u00FCr Android. Bin doch seit Anfang des Monats im Praxissemester.",
  "id" : 179628590147706880,
  "in_reply_to_status_id" : 179605213039173632,
  "created_at" : "Tue Mar 13 18:02:47 +0000 2012",
  "in_reply_to_screen_name" : "sunday_8pm",
  "in_reply_to_user_id_str" : "80762004",
  "user" : {
    "name" : "Felix",
    "screen_name" : "nicidienase",
    "protected" : false,
    "id_str" : "22396883",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3125784966/8223a4c5c9535be22d15c82ec829c2df_normal.jpeg",
    "id" : 22396883,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.echofon.com/\" rel=\"nofollow\">Echofon</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Android",
      "indices" : [ 19, 27 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "179601797642596352",
  "text" : "Warum is das unter #Android so schei\u00DF umst\u00E4ndlich zu Laufzeit das Theme f\u00FCr die ganze Application zu \u00E4ndern *grml*",
  "id" : 179601797642596352,
  "created_at" : "Tue Mar 13 16:16:20 +0000 2012",
  "user" : {
    "name" : "Felix",
    "screen_name" : "nicidienase",
    "protected" : false,
    "id_str" : "22396883",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3125784966/8223a4c5c9535be22d15c82ec829c2df_normal.jpeg",
    "id" : 22396883,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://github.com/minego/phnx\" rel=\"nofollow\">Project Macaw for webOS</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "178473145001455617",
  "text" : "Is halb drei zu sp\u00E4t zum Fr\u00FChst\u00FCcken??",
  "id" : 178473145001455617,
  "created_at" : "Sat Mar 10 13:31:28 +0000 2012",
  "user" : {
    "name" : "Felix",
    "screen_name" : "nicidienase",
    "protected" : false,
    "id_str" : "22396883",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3125784966/8223a4c5c9535be22d15c82ec829c2df_normal.jpeg",
    "id" : 22396883,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://getspaz.com\" rel=\"nofollow\">Spaz HD for webOS</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "177850876617170944",
  "text" : "Gerade aus Versehen eine Mate-Flasche umgeworfen. Da f\u00FChlt man sich gleich wieder wie auf dem Congress.",
  "id" : 177850876617170944,
  "created_at" : "Thu Mar 08 20:18:47 +0000 2012",
  "user" : {
    "name" : "Felix",
    "screen_name" : "nicidienase",
    "protected" : false,
    "id_str" : "22396883",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3125784966/8223a4c5c9535be22d15c82ec829c2df_normal.jpeg",
    "id" : 22396883,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://getspaz.com\" rel=\"nofollow\">Spaz HD for webOS</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 43, 63 ],
      "url" : "http://t.co/jQ2xjG8U",
      "expanded_url" : "http://www.youtube.com/watch?v=367Nd07eF9E",
      "display_url" : "youtube.com/watch?v=367Nd0\u2026"
    } ]
  },
  "geo" : {
  },
  "id_str" : "176751793202659328",
  "text" : "Genial!! Simpsons Game of Thrones-Couchgag\u00A0http://t.co/jQ2xjG8U",
  "id" : 176751793202659328,
  "created_at" : "Mon Mar 05 19:31:26 +0000 2012",
  "user" : {
    "name" : "Felix",
    "screen_name" : "nicidienase",
    "protected" : false,
    "id_str" : "22396883",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3125784966/8223a4c5c9535be22d15c82ec829c2df_normal.jpeg",
    "id" : 22396883,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://getspaz.com\" rel=\"nofollow\">Spaz HD for webOS</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ralf Bendrath",
      "screen_name" : "bendrath",
      "indices" : [ 3, 12 ],
      "id_str" : "13927862",
      "id" : 13927862
    }, {
      "name" : "Jens Ohlig",
      "screen_name" : "johl",
      "indices" : [ 14, 19 ],
      "id_str" : "1147751",
      "id" : 1147751
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "176294881856200704",
  "text" : "RT @bendrath: @johl und wieviele Liberale braucht man, um ne Gl\u00FChbirne zu wechseln? Keinen. Das regelt der Markt. *hohoho*",
  "retweeted_status" : {
    "source" : "<a href=\"http://www.tweetdeck.com\" rel=\"nofollow\">TweetDeck</a>",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Jens Ohlig",
        "screen_name" : "johl",
        "indices" : [ 0, 5 ],
        "id_str" : "1147751",
        "id" : 1147751
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "in_reply_to_status_id_str" : "176098699464802305",
    "geo" : {
    },
    "id_str" : "176108958459764737",
    "in_reply_to_user_id" : 1147751,
    "text" : "@johl und wieviele Liberale braucht man, um ne Gl\u00FChbirne zu wechseln? Keinen. Das regelt der Markt. *hohoho*",
    "id" : 176108958459764737,
    "in_reply_to_status_id" : 176098699464802305,
    "created_at" : "Sun Mar 04 00:57:02 +0000 2012",
    "in_reply_to_screen_name" : "johl",
    "in_reply_to_user_id_str" : "1147751",
    "user" : {
      "name" : "Ralf Bendrath",
      "screen_name" : "bendrath",
      "protected" : false,
      "id_str" : "13927862",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/448936580/Ralf-quadratisch_normal.jpg",
      "id" : 13927862,
      "verified" : false
    }
  },
  "id" : 176294881856200704,
  "created_at" : "Sun Mar 04 13:15:49 +0000 2012",
  "user" : {
    "name" : "Felix",
    "screen_name" : "nicidienase",
    "protected" : false,
    "id_str" : "22396883",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3125784966/8223a4c5c9535be22d15c82ec829c2df_normal.jpeg",
    "id" : 22396883,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://getspaz.com\" rel=\"nofollow\">Spaz</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "fpn2",
      "indices" : [ 16, 21 ]
    } ],
    "urls" : [ {
      "indices" : [ 22, 42 ],
      "url" : "http://t.co/d72YFwlZ",
      "expanded_url" : "http://twitpic.com/8rliz2",
      "display_url" : "twitpic.com/8rliz2"
    } ]
  },
  "geo" : {
  },
  "id_str" : "176045479245791233",
  "text" : "CHIIILLIIIIIIII #fpn2 http://t.co/d72YFwlZ",
  "id" : 176045479245791233,
  "created_at" : "Sat Mar 03 20:44:47 +0000 2012",
  "user" : {
    "name" : "Felix",
    "screen_name" : "nicidienase",
    "protected" : false,
    "id_str" : "22396883",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3125784966/8223a4c5c9535be22d15c82ec829c2df_normal.jpeg",
    "id" : 22396883,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://getspaz.com\" rel=\"nofollow\">Spaz</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "FPN2",
      "indices" : [ 0, 5 ]
    } ],
    "urls" : [ {
      "indices" : [ 30, 50 ],
      "url" : "http://t.co/n63CZcQx",
      "expanded_url" : "http://twitpic.com/8rk9ry",
      "display_url" : "twitpic.com/8rk9ry"
    } ]
  },
  "geo" : {
  },
  "id_str" : "176017976028446720",
  "text" : "#FPN2 Jetzt mit Twitterwall!! http://t.co/n63CZcQx",
  "id" : 176017976028446720,
  "created_at" : "Sat Mar 03 18:55:30 +0000 2012",
  "user" : {
    "name" : "Felix",
    "screen_name" : "nicidienase",
    "protected" : false,
    "id_str" : "22396883",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3125784966/8223a4c5c9535be22d15c82ec829c2df_normal.jpeg",
    "id" : 22396883,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://getspaz.com\" rel=\"nofollow\">Spaz</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "175955562654216192",
  "text" : "Playlist f\u00FCr meine Beerdigung: \"Always look on the bright Side of Life\" \"Never gonna give you up\"",
  "id" : 175955562654216192,
  "created_at" : "Sat Mar 03 14:47:29 +0000 2012",
  "user" : {
    "name" : "Felix",
    "screen_name" : "nicidienase",
    "protected" : false,
    "id_str" : "22396883",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3125784966/8223a4c5c9535be22d15c82ec829c2df_normal.jpeg",
    "id" : 22396883,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://getspaz.com\" rel=\"nofollow\">Spaz</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ari",
      "screen_name" : "Ari42",
      "indices" : [ 0, 6 ],
      "id_str" : "53464921",
      "id" : 53464921
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "175708131660283904",
  "geo" : {
  },
  "id_str" : "175770987911069697",
  "in_reply_to_user_id" : 53464921,
  "text" : "@Ari42 Danke f\u00FCr das Lob, aber alles in allem wars doch ein bischen chaotisch und verplant.",
  "id" : 175770987911069697,
  "in_reply_to_status_id" : 175708131660283904,
  "created_at" : "Sat Mar 03 02:34:03 +0000 2012",
  "in_reply_to_screen_name" : "Ari42",
  "in_reply_to_user_id_str" : "53464921",
  "user" : {
    "name" : "Felix",
    "screen_name" : "nicidienase",
    "protected" : false,
    "id_str" : "22396883",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3125784966/8223a4c5c9535be22d15c82ec829c2df_normal.jpeg",
    "id" : 22396883,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://getspaz.com\" rel=\"nofollow\">Spaz</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "cluetec GmbH",
      "screen_name" : "cluetec",
      "indices" : [ 26, 34 ],
      "id_str" : "357348558",
      "id" : 357348558
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "praxissemester",
      "indices" : [ 89, 104 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "175272541605203969",
  "text" : "So, erster Arbeitstag bei @cluetec rum. Kollegen sind nett, Athmosph\u00E4re gut, macht Spa\u00DF! #praxissemester",
  "id" : 175272541605203969,
  "created_at" : "Thu Mar 01 17:33:24 +0000 2012",
  "user" : {
    "name" : "Felix",
    "screen_name" : "nicidienase",
    "protected" : false,
    "id_str" : "22396883",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3125784966/8223a4c5c9535be22d15c82ec829c2df_normal.jpeg",
    "id" : 22396883,
    "verified" : false
  }
} ]