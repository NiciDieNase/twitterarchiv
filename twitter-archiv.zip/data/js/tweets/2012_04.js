Grailbird.data.tweets_2012_04 = 
 [ {
  "source" : "<a href=\"http://getspaz.com\" rel=\"nofollow\">Spaz HD for webOS</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "nibbler",
      "screen_name" : "nblr",
      "indices" : [ 3, 8 ],
      "id_str" : "174052946",
      "id" : 174052946
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "1mai",
      "indices" : [ 67, 72 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "197080586848976897",
  "text" : "RT @nblr: OH: oh, those germans... they even have scheduled riots. #1mai",
  "retweeted_status" : {
    "source" : "web",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "1mai",
        "indices" : [ 57, 62 ]
      } ],
      "urls" : [ ]
    },
    "geo" : {
    },
    "id_str" : "197033392271929344",
    "text" : "OH: oh, those germans... they even have scheduled riots. #1mai",
    "id" : 197033392271929344,
    "created_at" : "Mon Apr 30 18:43:16 +0000 2012",
    "user" : {
      "name" : "nibbler",
      "screen_name" : "nblr",
      "protected" : false,
      "id_str" : "174052946",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/3311942359/003f0d345d2017faf4f04c54b1e19ad6_normal.png",
      "id" : 174052946,
      "verified" : false
    }
  },
  "id" : 197080586848976897,
  "created_at" : "Mon Apr 30 21:50:48 +0000 2012",
  "user" : {
    "name" : "Felix",
    "screen_name" : "nicidienase",
    "protected" : false,
    "id_str" : "22396883",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3125784966/8223a4c5c9535be22d15c82ec829c2df_normal.jpeg",
    "id" : 22396883,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.echofon.com/\" rel=\"nofollow\">Echofon</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jiska",
      "screen_name" : "jiska___",
      "indices" : [ 0, 9 ],
      "id_str" : "61871130",
      "id" : 61871130
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "196956253442932736",
  "geo" : {
  },
  "id_str" : "196957764315127809",
  "in_reply_to_user_id" : 61871130,
  "text" : "@jiska___ Eine K\u00FCche die sonst keiner dreckig macht macht aber auch niemand anderes sauber.",
  "id" : 196957764315127809,
  "in_reply_to_status_id" : 196956253442932736,
  "created_at" : "Mon Apr 30 13:42:44 +0000 2012",
  "in_reply_to_screen_name" : "jiska___",
  "in_reply_to_user_id_str" : "61871130",
  "user" : {
    "name" : "Felix",
    "screen_name" : "nicidienase",
    "protected" : false,
    "id_str" : "22396883",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3125784966/8223a4c5c9535be22d15c82ec829c2df_normal.jpeg",
    "id" : 22396883,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.echofon.com/\" rel=\"nofollow\">Echofon</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jakob Adler",
      "screen_name" : "jakuuub",
      "indices" : [ 3, 11 ],
      "id_str" : "15211500",
      "id" : 15211500
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 83, 103 ],
      "url" : "http://t.co/VBe6lQxQ",
      "expanded_url" : "http://twitter.com/jakuuub/status/196716566518304768/photo/1",
      "display_url" : "pic.twitter.com/VBe6lQxQ"
    } ]
  },
  "geo" : {
  },
  "id_str" : "196890485036548096",
  "text" : "RT @jakuuub: Endlich! Ich kann mit meinem Laptop das Licht in der Wohnung steuern. http://t.co/VBe6lQxQ",
  "retweeted_status" : {
    "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "http://twitter.com/jakuuub/status/196716566518304768/photo/1",
        "indices" : [ 70, 90 ],
        "url" : "http://t.co/VBe6lQxQ",
        "media_url" : "http://pbs.twimg.com/media/ArrgrM0CEAAxcxI.jpg",
        "id_str" : "196716566522499072",
        "id" : 196716566522499072,
        "media_url_https" : "https://pbs.twimg.com/media/ArrgrM0CEAAxcxI.jpg",
        "sizes" : [ {
          "h" : 1024,
          "resize" : "fit",
          "w" : 768
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 453,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 800,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 1024,
          "resize" : "fit",
          "w" : 768
        } ],
        "display_url" : "pic.twitter.com/VBe6lQxQ"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : {
      "type" : "Point",
      "coordinates" : [ 53.5533317754, 9.9174099485 ]
    },
    "id_str" : "196716566518304768",
    "text" : "Endlich! Ich kann mit meinem Laptop das Licht in der Wohnung steuern. http://t.co/VBe6lQxQ",
    "id" : 196716566518304768,
    "created_at" : "Sun Apr 29 21:44:19 +0000 2012",
    "user" : {
      "name" : "Jakob Adler",
      "screen_name" : "jakuuub",
      "protected" : false,
      "id_str" : "15211500",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/3406980130/341648b9db665f993e6177341a9b1877_normal.jpeg",
      "id" : 15211500,
      "verified" : false
    }
  },
  "id" : 196890485036548096,
  "created_at" : "Mon Apr 30 09:15:24 +0000 2012",
  "user" : {
    "name" : "Felix",
    "screen_name" : "nicidienase",
    "protected" : false,
    "id_str" : "22396883",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3125784966/8223a4c5c9535be22d15c82ec829c2df_normal.jpeg",
    "id" : 22396883,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.echofon.com/\" rel=\"nofollow\">Echofon</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Gerd Eist",
      "screen_name" : "erdgeist",
      "indices" : [ 3, 12 ],
      "id_str" : "16701619",
      "id" : 16701619
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "196228970381971458",
  "text" : "RT @erdgeist: Die BBC hat einfach mal coole Dokus. \"Inside Nature's Giants\" schneidet mit Biologen gro\u00DFe Tiere auf und guckt rein http:/ ...",
  "retweeted_status" : {
    "source" : "web",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 116, 136 ],
        "url" : "http://t.co/lOZbZ9vE",
        "expanded_url" : "http://www.youtube.com/watch?v=EKzeorIrSKU",
        "display_url" : "youtube.com/watch?v=EKzeor\u2026"
      } ]
    },
    "geo" : {
    },
    "id_str" : "196225399502540800",
    "text" : "Die BBC hat einfach mal coole Dokus. \"Inside Nature's Giants\" schneidet mit Biologen gro\u00DFe Tiere auf und guckt rein http://t.co/lOZbZ9vE",
    "id" : 196225399502540800,
    "created_at" : "Sat Apr 28 13:12:35 +0000 2012",
    "user" : {
      "name" : "Gerd Eist",
      "screen_name" : "erdgeist",
      "protected" : false,
      "id_str" : "16701619",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/61748149/ta_normal.jpg",
      "id" : 16701619,
      "verified" : false
    }
  },
  "id" : 196228970381971458,
  "created_at" : "Sat Apr 28 13:26:46 +0000 2012",
  "user" : {
    "name" : "Felix",
    "screen_name" : "nicidienase",
    "protected" : false,
    "id_str" : "22396883",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3125784966/8223a4c5c9535be22d15c82ec829c2df_normal.jpeg",
    "id" : 22396883,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://getspaz.com\" rel=\"nofollow\">Spaz HD for webOS</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "magg0t",
      "screen_name" : "NQmagg0t",
      "indices" : [ 3, 12 ],
      "id_str" : "43342490",
      "id" : 43342490
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 34, 54 ],
      "url" : "http://t.co/ddXvLDPs",
      "expanded_url" : "http://b.asset.soup.io/asset/3129/4715_ca50_480.jpeg",
      "display_url" : "b.asset.soup.io/asset/3129/471\u2026"
    } ]
  },
  "geo" : {
  },
  "id_str" : "196026407237861376",
  "text" : "RT @NQmagg0t: *g* Admineralwasser http://t.co/ddXvLDPs",
  "retweeted_status" : {
    "source" : "web",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 20, 40 ],
        "url" : "http://t.co/ddXvLDPs",
        "expanded_url" : "http://b.asset.soup.io/asset/3129/4715_ca50_480.jpeg",
        "display_url" : "b.asset.soup.io/asset/3129/471\u2026"
      } ]
    },
    "geo" : {
    },
    "id_str" : "195869253482713088",
    "text" : "*g* Admineralwasser http://t.co/ddXvLDPs",
    "id" : 195869253482713088,
    "created_at" : "Fri Apr 27 13:37:23 +0000 2012",
    "user" : {
      "name" : "magg0t",
      "screen_name" : "NQmagg0t",
      "protected" : false,
      "id_str" : "43342490",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/237962924/christian_kleiner_normal.jpg",
      "id" : 43342490,
      "verified" : false
    }
  },
  "id" : 196026407237861376,
  "created_at" : "Sat Apr 28 00:01:52 +0000 2012",
  "user" : {
    "name" : "Felix",
    "screen_name" : "nicidienase",
    "protected" : false,
    "id_str" : "22396883",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3125784966/8223a4c5c9535be22d15c82ec829c2df_normal.jpeg",
    "id" : 22396883,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.echofon.com/\" rel=\"nofollow\">Echofon</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "MissStress Dora",
      "screen_name" : "Pandora__82",
      "indices" : [ 3, 15 ],
      "id_str" : "60663416",
      "id" : 60663416
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "195797094785757184",
  "text" : "RT @Pandora__82: Was ist braun, doof und leuchtet im Dunkeln? ein Neon-Nazi...",
  "retweeted_status" : {
    "source" : "web",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : {
    },
    "id_str" : "195786605519323136",
    "text" : "Was ist braun, doof und leuchtet im Dunkeln? ein Neon-Nazi...",
    "id" : 195786605519323136,
    "created_at" : "Fri Apr 27 08:08:58 +0000 2012",
    "user" : {
      "name" : "MissStress Dora",
      "screen_name" : "Pandora__82",
      "protected" : false,
      "id_str" : "60663416",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/3476482234/a99ae0f415ad0d473bbea860c8e62472_normal.jpeg",
      "id" : 60663416,
      "verified" : false
    }
  },
  "id" : 195797094785757184,
  "created_at" : "Fri Apr 27 08:50:39 +0000 2012",
  "user" : {
    "name" : "Felix",
    "screen_name" : "nicidienase",
    "protected" : false,
    "id_str" : "22396883",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3125784966/8223a4c5c9535be22d15c82ec829c2df_normal.jpeg",
    "id" : 22396883,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://getspaz.com\" rel=\"nofollow\">Spaz HD for webOS</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "195594364808998914",
  "text" : "Lust auf Zocken, Windows gebootet, h\u00E4ngt sich beim Login auf. Aaaaaarg, Windows Y U NO WORK???",
  "id" : 195594364808998914,
  "created_at" : "Thu Apr 26 19:25:05 +0000 2012",
  "user" : {
    "name" : "Felix",
    "screen_name" : "nicidienase",
    "protected" : false,
    "id_str" : "22396883",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3125784966/8223a4c5c9535be22d15c82ec829c2df_normal.jpeg",
    "id" : 22396883,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://getspaz.com\" rel=\"nofollow\">Spaz HD for webOS</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Herr haekelschwein",
      "screen_name" : "haekelschwein",
      "indices" : [ 3, 17 ],
      "id_str" : "21523802",
      "id" : 21523802
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "195574378954625024",
  "text" : "RT @haekelschwein: Wenn Anonymit\u00E4t zu schlechtem Benehmen f\u00FChrt, sollten Polizisten auf Demos unbedingt Namensschilder tragen.",
  "retweeted_status" : {
    "source" : "<a href=\"http://itunes.apple.com/us/app/twitter/id409789998?mt=12\" rel=\"nofollow\">Twitter for Mac</a>",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : {
    },
    "id_str" : "195097445213028353",
    "text" : "Wenn Anonymit\u00E4t zu schlechtem Benehmen f\u00FChrt, sollten Polizisten auf Demos unbedingt Namensschilder tragen.",
    "id" : 195097445213028353,
    "created_at" : "Wed Apr 25 10:30:30 +0000 2012",
    "user" : {
      "name" : "Herr haekelschwein",
      "screen_name" : "haekelschwein",
      "protected" : false,
      "id_str" : "21523802",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/81174685/vornew_normal.jpg",
      "id" : 21523802,
      "verified" : false
    }
  },
  "id" : 195574378954625024,
  "created_at" : "Thu Apr 26 18:05:40 +0000 2012",
  "user" : {
    "name" : "Felix",
    "screen_name" : "nicidienase",
    "protected" : false,
    "id_str" : "22396883",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3125784966/8223a4c5c9535be22d15c82ec829c2df_normal.jpeg",
    "id" : 22396883,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.echofon.com/\" rel=\"nofollow\">Echofon</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "cluetec GmbH",
      "screen_name" : "cluetec",
      "indices" : [ 3, 11 ],
      "id_str" : "357348558",
      "id" : 357348558
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Jobs",
      "indices" : [ 80, 85 ]
    }, {
      "text" : "Karlsruhe",
      "indices" : [ 86, 96 ]
    }, {
      "text" : "java",
      "indices" : [ 97, 102 ]
    }, {
      "text" : "Android",
      "indices" : [ 103, 111 ]
    } ],
    "urls" : [ {
      "indices" : [ 59, 79 ],
      "url" : "http://t.co/OuDr9r3b",
      "expanded_url" : "http://www.mquest.de/unternehmen/jobs/",
      "display_url" : "mquest.de/unternehmen/jo\u2026"
    } ]
  },
  "geo" : {
  },
  "id_str" : "195512163283120128",
  "text" : "RT @cluetec: cluetec sucht Entwickler - Java, JEE, Android http://t.co/OuDr9r3b #Jobs #Karlsruhe #java #Android",
  "retweeted_status" : {
    "source" : "web",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "Jobs",
        "indices" : [ 67, 72 ]
      }, {
        "text" : "Karlsruhe",
        "indices" : [ 73, 83 ]
      }, {
        "text" : "java",
        "indices" : [ 84, 89 ]
      }, {
        "text" : "Android",
        "indices" : [ 90, 98 ]
      } ],
      "urls" : [ {
        "indices" : [ 46, 66 ],
        "url" : "http://t.co/OuDr9r3b",
        "expanded_url" : "http://www.mquest.de/unternehmen/jobs/",
        "display_url" : "mquest.de/unternehmen/jo\u2026"
      } ]
    },
    "geo" : {
    },
    "id_str" : "195510168241455105",
    "text" : "cluetec sucht Entwickler - Java, JEE, Android http://t.co/OuDr9r3b #Jobs #Karlsruhe #java #Android",
    "id" : 195510168241455105,
    "created_at" : "Thu Apr 26 13:50:31 +0000 2012",
    "user" : {
      "name" : "cluetec GmbH",
      "screen_name" : "cluetec",
      "protected" : false,
      "id_str" : "357348558",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/1857333043/profil_spirale_normal.png",
      "id" : 357348558,
      "verified" : false
    }
  },
  "id" : 195512163283120128,
  "created_at" : "Thu Apr 26 13:58:26 +0000 2012",
  "user" : {
    "name" : "Felix",
    "screen_name" : "nicidienase",
    "protected" : false,
    "id_str" : "22396883",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3125784966/8223a4c5c9535be22d15c82ec829c2df_normal.jpeg",
    "id" : 22396883,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.echofon.com/\" rel=\"nofollow\">Echofon</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "gpn12",
      "indices" : [ 21, 27 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "195466672306536449",
  "text" : "Heute Urlaub f\u00FCr die #gpn12 beantragt und genehmigt!",
  "id" : 195466672306536449,
  "created_at" : "Thu Apr 26 10:57:40 +0000 2012",
  "user" : {
    "name" : "Felix",
    "screen_name" : "nicidienase",
    "protected" : false,
    "id_str" : "22396883",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3125784966/8223a4c5c9535be22d15c82ec829c2df_normal.jpeg",
    "id" : 22396883,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.echofon.com/\" rel=\"nofollow\">Echofon</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lars Kasper",
      "screen_name" : "LarsKasper",
      "indices" : [ 3, 14 ],
      "id_str" : "13589362",
      "id" : 13589362
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Betreuungsgeld",
      "indices" : [ 24, 39 ]
    }, {
      "text" : "Nerdpr\u00E4mie",
      "indices" : [ 125, 136 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "195461485298851840",
  "text" : "RT @LarsKasper: Wieviel #Betreuungsgeld gibt es eigentlich, wenn man die Server zuhause hinstellt anstatt ins Rechenzentrum? #Nerdpr\u00E4mie",
  "retweeted_status" : {
    "source" : "<a href=\"http://itunes.apple.com/us/app/twitter/id409789998?mt=12\" rel=\"nofollow\">Twitter for Mac</a>",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "Betreuungsgeld",
        "indices" : [ 8, 23 ]
      }, {
        "text" : "Nerdpr\u00E4mie",
        "indices" : [ 109, 120 ]
      } ],
      "urls" : [ ]
    },
    "geo" : {
    },
    "id_str" : "195051851232722945",
    "text" : "Wieviel #Betreuungsgeld gibt es eigentlich, wenn man die Server zuhause hinstellt anstatt ins Rechenzentrum? #Nerdpr\u00E4mie",
    "id" : 195051851232722945,
    "created_at" : "Wed Apr 25 07:29:19 +0000 2012",
    "user" : {
      "name" : "Lars Kasper",
      "screen_name" : "LarsKasper",
      "protected" : false,
      "id_str" : "13589362",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/461986143/2009-08-20_0020_Gewitter_Twitter_normal.jpg",
      "id" : 13589362,
      "verified" : false
    }
  },
  "id" : 195461485298851840,
  "created_at" : "Thu Apr 26 10:37:04 +0000 2012",
  "user" : {
    "name" : "Felix",
    "screen_name" : "nicidienase",
    "protected" : false,
    "id_str" : "22396883",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3125784966/8223a4c5c9535be22d15c82ec829c2df_normal.jpeg",
    "id" : 22396883,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.echofon.com/\" rel=\"nofollow\">Echofon</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tom Hudson",
      "screen_name" : "TomNomNom",
      "indices" : [ 3, 13 ],
      "id_str" : "17440273",
      "id" : 17440273
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 40, 60 ],
      "url" : "http://t.co/7oIbPMiJ",
      "expanded_url" : "http://twitter.com/TomNomNom/status/195304317601849344/photo/1",
      "display_url" : "pic.twitter.com/7oIbPMiJ"
    } ]
  },
  "geo" : {
  },
  "id_str" : "195439613765095426",
  "text" : "RT @TomNomNom: I wrote a book about PHP http://t.co/7oIbPMiJ",
  "retweeted_status" : {
    "source" : "web",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "http://twitter.com/TomNomNom/status/195304317601849344/photo/1",
        "indices" : [ 25, 45 ],
        "url" : "http://t.co/7oIbPMiJ",
        "media_url" : "http://pbs.twimg.com/media/ArXcPfoCIAE1r0G.jpg",
        "id_str" : "195304317606043649",
        "id" : 195304317606043649,
        "media_url_https" : "https://pbs.twimg.com/media/ArXcPfoCIAE1r0G.jpg",
        "sizes" : [ {
          "h" : 419,
          "resize" : "fit",
          "w" : 778
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 323,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 183,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 419,
          "resize" : "fit",
          "w" : 778
        } ],
        "display_url" : "pic.twitter.com/7oIbPMiJ"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : {
    },
    "id_str" : "195304317601849344",
    "text" : "I wrote a book about PHP http://t.co/7oIbPMiJ",
    "id" : 195304317601849344,
    "created_at" : "Thu Apr 26 00:12:33 +0000 2012",
    "user" : {
      "name" : "Tom Hudson",
      "screen_name" : "TomNomNom",
      "protected" : false,
      "id_str" : "17440273",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/3028057013/8e4d08ee7f95c7a4836b1ad18ac55c2d_normal.jpeg",
      "id" : 17440273,
      "verified" : false
    }
  },
  "id" : 195439613765095426,
  "created_at" : "Thu Apr 26 09:10:09 +0000 2012",
  "user" : {
    "name" : "Felix",
    "screen_name" : "nicidienase",
    "protected" : false,
    "id_str" : "22396883",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3125784966/8223a4c5c9535be22d15c82ec829c2df_normal.jpeg",
    "id" : 22396883,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://getspaz.com\" rel=\"nofollow\">Spaz HD for webOS</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Holger Klein",
      "screen_name" : "holgi",
      "indices" : [ 0, 6 ],
      "id_str" : "3068271",
      "id" : 3068271
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "195205212129083392",
  "geo" : {
  },
  "id_str" : "195235376003170305",
  "in_reply_to_user_id" : 3068271,
  "text" : "@holgi Ich hatte mal ne Geschichte-Lehrerin bei der klangs immer so als w\u00FCrde sie Burger statt B\u00FCrger sagen",
  "id" : 195235376003170305,
  "in_reply_to_status_id" : 195205212129083392,
  "created_at" : "Wed Apr 25 19:38:35 +0000 2012",
  "in_reply_to_screen_name" : "holgi",
  "in_reply_to_user_id_str" : "3068271",
  "user" : {
    "name" : "Felix",
    "screen_name" : "nicidienase",
    "protected" : false,
    "id_str" : "22396883",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3125784966/8223a4c5c9535be22d15c82ec829c2df_normal.jpeg",
    "id" : 22396883,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "webosblog",
      "screen_name" : "webos_blog",
      "indices" : [ 3, 14 ],
      "id_str" : "36693294",
      "id" : 36693294
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 107, 127 ],
      "url" : "http://t.co/o6FzBNlw",
      "expanded_url" : "http://www.webos-blog.de/2012-04-24-sprinpad-app-fur-webos-meorg-im-videoreview-inklusive-promocodes/",
      "display_url" : "webos-blog.de/2012-04-24-spr\u2026"
    } ]
  },
  "geo" : {
  },
  "id_str" : "195160838666076160",
  "text" : "RT @webos_blog: neuer Beitrag: UPDATE: Springpad-App f\u00FCr webOS: MeOrg! im Videoreview inklusive Promocodes http://t.co/o6FzBNlw",
  "retweeted_status" : {
    "source" : "<a href=\"http://www.webos-blog.de\" rel=\"nofollow\">webOS Blog</a>",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 91, 111 ],
        "url" : "http://t.co/o6FzBNlw",
        "expanded_url" : "http://www.webos-blog.de/2012-04-24-sprinpad-app-fur-webos-meorg-im-videoreview-inklusive-promocodes/",
        "display_url" : "webos-blog.de/2012-04-24-spr\u2026"
      } ]
    },
    "geo" : {
    },
    "id_str" : "194869856607272963",
    "text" : "neuer Beitrag: UPDATE: Springpad-App f\u00FCr webOS: MeOrg! im Videoreview inklusive Promocodes http://t.co/o6FzBNlw",
    "id" : 194869856607272963,
    "created_at" : "Tue Apr 24 19:26:08 +0000 2012",
    "user" : {
      "name" : "webosblog",
      "screen_name" : "webos_blog",
      "protected" : false,
      "id_str" : "36693294",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/193412894/logo_normal.png",
      "id" : 36693294,
      "verified" : false
    }
  },
  "id" : 195160838666076160,
  "created_at" : "Wed Apr 25 14:42:24 +0000 2012",
  "user" : {
    "name" : "Felix",
    "screen_name" : "nicidienase",
    "protected" : false,
    "id_str" : "22396883",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3125784966/8223a4c5c9535be22d15c82ec829c2df_normal.jpeg",
    "id" : 22396883,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.echofon.com/\" rel=\"nofollow\">Echofon</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mario Sixtus",
      "screen_name" : "sixtus",
      "indices" : [ 3, 10 ],
      "id_str" : "9334352",
      "id" : 9334352
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 93, 113 ],
      "url" : "http://t.co/7lMXT461",
      "expanded_url" : "http://bit.ly/Ic6VhU",
      "display_url" : "bit.ly/Ic6VhU"
    } ]
  },
  "geo" : {
  },
  "id_str" : "195102010385776641",
  "text" : "RT @sixtus: Mit diesem Positionspapier d\u00FCrften die Piraten in NRW die 20%-H\u00FCrde \u00FCberfl\u00FCgeln: http://t.co/7lMXT461",
  "retweeted_status" : {
    "source" : "<a href=\"http://bitly.com\" rel=\"nofollow\">bitly</a>",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 81, 101 ],
        "url" : "http://t.co/7lMXT461",
        "expanded_url" : "http://bit.ly/Ic6VhU",
        "display_url" : "bit.ly/Ic6VhU"
      } ]
    },
    "geo" : {
    },
    "id_str" : "195088434648457217",
    "text" : "Mit diesem Positionspapier d\u00FCrften die Piraten in NRW die 20%-H\u00FCrde \u00FCberfl\u00FCgeln: http://t.co/7lMXT461",
    "id" : 195088434648457217,
    "created_at" : "Wed Apr 25 09:54:42 +0000 2012",
    "user" : {
      "name" : "Mario Sixtus",
      "screen_name" : "sixtus",
      "protected" : false,
      "id_str" : "9334352",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/274542155/mario_normal.gif",
      "id" : 9334352,
      "verified" : true
    }
  },
  "id" : 195102010385776641,
  "created_at" : "Wed Apr 25 10:48:38 +0000 2012",
  "user" : {
    "name" : "Felix",
    "screen_name" : "nicidienase",
    "protected" : false,
    "id_str" : "22396883",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3125784966/8223a4c5c9535be22d15c82ec829c2df_normal.jpeg",
    "id" : 22396883,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://getspaz.com\" rel=\"nofollow\">Spaz</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 38, 58 ],
      "url" : "http://t.co/Q50zw7o5",
      "expanded_url" : "http://twitpic.com/9di9g1",
      "display_url" : "twitpic.com/9di9g1"
    } ]
  },
  "geo" : {
  },
  "id_str" : "194928481824546816",
  "text" : "WTF, mein wecker steht auf 7:77 Uhr?? http://t.co/Q50zw7o5",
  "id" : 194928481824546816,
  "created_at" : "Tue Apr 24 23:19:06 +0000 2012",
  "user" : {
    "name" : "Felix",
    "screen_name" : "nicidienase",
    "protected" : false,
    "id_str" : "22396883",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3125784966/8223a4c5c9535be22d15c82ec829c2df_normal.jpeg",
    "id" : 22396883,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.echofon.com/\" rel=\"nofollow\">Echofon</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sonne",
      "screen_name" : "mrs_krolock",
      "indices" : [ 0, 12 ],
      "id_str" : "213821462",
      "id" : 213821462
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "194814733180874755",
  "geo" : {
  },
  "id_str" : "194815081350049794",
  "in_reply_to_user_id" : 213821462,
  "text" : "@mrs_krolock oder von Mama ..",
  "id" : 194815081350049794,
  "in_reply_to_status_id" : 194814733180874755,
  "created_at" : "Tue Apr 24 15:48:29 +0000 2012",
  "in_reply_to_screen_name" : "mrs_krolock",
  "in_reply_to_user_id_str" : "213821462",
  "user" : {
    "name" : "Felix",
    "screen_name" : "nicidienase",
    "protected" : false,
    "id_str" : "22396883",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3125784966/8223a4c5c9535be22d15c82ec829c2df_normal.jpeg",
    "id" : 22396883,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://getspaz.com\" rel=\"nofollow\">Spaz</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 42, 62 ],
      "url" : "http://t.co/znaCbFnH",
      "expanded_url" : "http://twitpic.com/9cj7pn",
      "display_url" : "twitpic.com/9cj7pn"
    } ]
  },
  "geo" : {
  },
  "id_str" : "193793776316186624",
  "text" : "WTF Ich hab ne Ampel geschenkt gekriegt!! http://t.co/znaCbFnH",
  "id" : 193793776316186624,
  "created_at" : "Sat Apr 21 20:10:11 +0000 2012",
  "user" : {
    "name" : "Felix",
    "screen_name" : "nicidienase",
    "protected" : false,
    "id_str" : "22396883",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3125784966/8223a4c5c9535be22d15c82ec829c2df_normal.jpeg",
    "id" : 22396883,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://getspaz.com\" rel=\"nofollow\">Spaz HD for webOS</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Caro Usel",
      "screen_name" : "colourfulzebra",
      "indices" : [ 3, 18 ],
      "id_str" : "74303306",
      "id" : 74303306
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "193074548927774720",
  "text" : "RT @colourfulzebra: Lust auf Sex und nicht die richtige Person in der N\u00E4he. Ihr kennt das.",
  "retweeted_status" : {
    "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : {
    },
    "id_str" : "193071099066597376",
    "text" : "Lust auf Sex und nicht die richtige Person in der N\u00E4he. Ihr kennt das.",
    "id" : 193071099066597376,
    "created_at" : "Thu Apr 19 20:18:31 +0000 2012",
    "user" : {
      "name" : "Caro Usel",
      "screen_name" : "colourfulzebra",
      "protected" : false,
      "id_str" : "74303306",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/3477778438/d1ec06fc31a2d26c933adbab703dce3c_normal.jpeg",
      "id" : 74303306,
      "verified" : false
    }
  },
  "id" : 193074548927774720,
  "created_at" : "Thu Apr 19 20:32:14 +0000 2012",
  "user" : {
    "name" : "Felix",
    "screen_name" : "nicidienase",
    "protected" : false,
    "id_str" : "22396883",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3125784966/8223a4c5c9535be22d15c82ec829c2df_normal.jpeg",
    "id" : 22396883,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://getspaz.com\" rel=\"nofollow\">Spaz HD for webOS</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "192687239917092865",
  "geo" : {
  },
  "id_str" : "192720909365284865",
  "in_reply_to_user_id" : 20689932,
  "text" : "@Geruhn Das passiert wenn Marketingleute auf solche Messen kommen und keine Entwickler/Leute die Ahnung haben.",
  "id" : 192720909365284865,
  "in_reply_to_status_id" : 192687239917092865,
  "created_at" : "Wed Apr 18 21:07:00 +0000 2012",
  "in_reply_to_screen_name" : "keinGeruhn",
  "in_reply_to_user_id_str" : "20689932",
  "user" : {
    "name" : "Felix",
    "screen_name" : "nicidienase",
    "protected" : false,
    "id_str" : "22396883",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3125784966/8223a4c5c9535be22d15c82ec829c2df_normal.jpeg",
    "id" : 22396883,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://getspaz.com\" rel=\"nofollow\">Spaz HD for webOS</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Caro Usel",
      "screen_name" : "colourfulzebra",
      "indices" : [ 0, 15 ],
      "id_str" : "74303306",
      "id" : 74303306
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "192655910873726979",
  "geo" : {
  },
  "id_str" : "192719185636364289",
  "in_reply_to_user_id" : 74303306,
  "text" : "@colourfulzebra Deswegen mag ich meinen Boblbee Megalopolis, dem sieht man nicht an ob was drin is oder nicht ..",
  "id" : 192719185636364289,
  "in_reply_to_status_id" : 192655910873726979,
  "created_at" : "Wed Apr 18 21:00:09 +0000 2012",
  "in_reply_to_screen_name" : "colourfulzebra",
  "in_reply_to_user_id_str" : "74303306",
  "user" : {
    "name" : "Felix",
    "screen_name" : "nicidienase",
    "protected" : false,
    "id_str" : "22396883",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3125784966/8223a4c5c9535be22d15c82ec829c2df_normal.jpeg",
    "id" : 22396883,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.echofon.com/\" rel=\"nofollow\">Echofon</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tim Weber",
      "screen_name" : "Scytale",
      "indices" : [ 3, 11 ],
      "id_str" : "594921016",
      "id" : 594921016
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 34, 54 ],
      "url" : "http://t.co/r7yaWRuD",
      "expanded_url" : "http://www.clicktorelease.com/code/streetViewReflectionMapping/",
      "display_url" : "clicktorelease.com/code/streetVie\u2026"
    } ]
  },
  "geo" : {
  },
  "id_str" : "192528379369619456",
  "text" : "RT @Scytale: Floating shiny knot. http://t.co/r7yaWRuD",
  "retweeted_status" : {
    "source" : "<a href=\"http://www.tweetdeck.com\" rel=\"nofollow\">TweetDeck</a>",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 21, 41 ],
        "url" : "http://t.co/r7yaWRuD",
        "expanded_url" : "http://www.clicktorelease.com/code/streetViewReflectionMapping/",
        "display_url" : "clicktorelease.com/code/streetVie\u2026"
      } ]
    },
    "geo" : {
      "type" : "Point",
      "coordinates" : [ 49.4955473928, 8.4576165676 ]
    },
    "id_str" : "192524187955494912",
    "text" : "Floating shiny knot. http://t.co/r7yaWRuD",
    "id" : 192524187955494912,
    "created_at" : "Wed Apr 18 08:05:17 +0000 2012",
    "user" : {
      "name" : "Tim Weber",
      "screen_name" : "scy",
      "protected" : false,
      "id_str" : "8308632",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/424137519/avatar184_normal.jpg",
      "id" : 8308632,
      "verified" : false
    }
  },
  "id" : 192528379369619456,
  "created_at" : "Wed Apr 18 08:21:57 +0000 2012",
  "user" : {
    "name" : "Felix",
    "screen_name" : "nicidienase",
    "protected" : false,
    "id_str" : "22396883",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3125784966/8223a4c5c9535be22d15c82ec829c2df_normal.jpeg",
    "id" : 22396883,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://getspaz.com\" rel=\"nofollow\">Spaz</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Not Safe For Work",
      "screen_name" : "me_nsfw",
      "indices" : [ 36, 44 ],
      "id_str" : "198895800",
      "id" : 198895800
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "192000936921661440",
  "geo" : {
  },
  "id_str" : "192009321402478592",
  "in_reply_to_user_id" : 198895800,
  "text" : "Waaah ihr k\u00F6nnt doch die neue Folge @me_nsfw nicht um diese Zeit ver\u00F6ffentlichen Ich muss morgen arbeiten!!",
  "id" : 192009321402478592,
  "in_reply_to_status_id" : 192000936921661440,
  "created_at" : "Mon Apr 16 21:59:24 +0000 2012",
  "in_reply_to_screen_name" : "me_nsfw",
  "in_reply_to_user_id_str" : "198895800",
  "user" : {
    "name" : "Felix",
    "screen_name" : "nicidienase",
    "protected" : false,
    "id_str" : "22396883",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3125784966/8223a4c5c9535be22d15c82ec829c2df_normal.jpeg",
    "id" : 22396883,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.echofon.com/\" rel=\"nofollow\">Echofon</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Caro Usel",
      "screen_name" : "colourfulzebra",
      "indices" : [ 0, 15 ],
      "id_str" : "74303306",
      "id" : 74303306
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "191908479336853504",
  "geo" : {
  },
  "id_str" : "191916369409884160",
  "in_reply_to_user_id" : 74303306,
  "text" : "@colourfulzebra Also ich trenne meinen M\u00FCll, entferne meine (langen) Haare aus der Dusche und die Sp\u00FClmaschine w\u00FCrd ich auch einr\u00E4umen.",
  "id" : 191916369409884160,
  "in_reply_to_status_id" : 191908479336853504,
  "created_at" : "Mon Apr 16 15:50:02 +0000 2012",
  "in_reply_to_screen_name" : "colourfulzebra",
  "in_reply_to_user_id_str" : "74303306",
  "user" : {
    "name" : "Felix",
    "screen_name" : "nicidienase",
    "protected" : false,
    "id_str" : "22396883",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3125784966/8223a4c5c9535be22d15c82ec829c2df_normal.jpeg",
    "id" : 22396883,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.echofon.com/\" rel=\"nofollow\">Echofon</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Hemithea",
      "screen_name" : "Hemithea",
      "indices" : [ 3, 12 ],
      "id_str" : "492422472",
      "id" : 492422472
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "191820958212960256",
  "text" : "RT @Hemithea: Ein Retweet ist ein kleiner selbstloser Akt, der zeigt dass du damit einverstanden bist, dass andere witziger sind als du!",
  "retweeted_status" : {
    "source" : "<a href=\"http://twitter.com/#!/download/ipad\" rel=\"nofollow\">Twitter for iPad</a>",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : {
    },
    "id_str" : "191280228826497025",
    "text" : "Ein Retweet ist ein kleiner selbstloser Akt, der zeigt dass du damit einverstanden bist, dass andere witziger sind als du!",
    "id" : 191280228826497025,
    "created_at" : "Sat Apr 14 21:42:15 +0000 2012",
    "user" : {
      "name" : "Hemithea",
      "screen_name" : "Hemithea",
      "protected" : false,
      "id_str" : "492422472",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/3393397291/a4dd73bf050fd06bcb80ed140b6d149e_normal.jpeg",
      "id" : 492422472,
      "verified" : false
    }
  },
  "id" : 191820958212960256,
  "created_at" : "Mon Apr 16 09:30:54 +0000 2012",
  "user" : {
    "name" : "Felix",
    "screen_name" : "nicidienase",
    "protected" : false,
    "id_str" : "22396883",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3125784966/8223a4c5c9535be22d15c82ec829c2df_normal.jpeg",
    "id" : 22396883,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.echofon.com/\" rel=\"nofollow\">Echofon</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tim Weber",
      "screen_name" : "Scytale",
      "indices" : [ 3, 11 ],
      "id_str" : "594921016",
      "id" : 594921016
    }, {
      "name" : "Dan Schmidt",
      "screen_name" : "Schmidt",
      "indices" : [ 128, 136 ],
      "id_str" : "2140401",
      "id" : 2140401
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 94, 114 ],
      "url" : "http://t.co/f9UfdRXG",
      "expanded_url" : "http://is.gd/7jD9z2",
      "display_url" : "is.gd/7jD9z2"
    } ]
  },
  "geo" : {
  },
  "id_str" : "191814888232980480",
  "text" : "RT @Scytale: Als Angestellter bei Netflix darf man \u00FCbrigens so viel in Urlaub wie man m\u00F6chte. http://t.co/f9UfdRXG (quasi) (via @Schmidt ...",
  "retweeted_status" : {
    "source" : "<a href=\"http://www.tweetdeck.com\" rel=\"nofollow\">TweetDeck</a>",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Christopher Lauer",
        "screen_name" : "Schmidtlepp",
        "indices" : [ 115, 127 ],
        "id_str" : "59085146",
        "id" : 59085146
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 81, 101 ],
        "url" : "http://t.co/f9UfdRXG",
        "expanded_url" : "http://is.gd/7jD9z2",
        "display_url" : "is.gd/7jD9z2"
      } ]
    },
    "geo" : {
      "type" : "Point",
      "coordinates" : [ 49.4955473928, 8.4576165676 ]
    },
    "id_str" : "191808099030544384",
    "text" : "Als Angestellter bei Netflix darf man \u00FCbrigens so viel in Urlaub wie man m\u00F6chte. http://t.co/f9UfdRXG (quasi) (via @Schmidtlepp)",
    "id" : 191808099030544384,
    "created_at" : "Mon Apr 16 08:39:49 +0000 2012",
    "user" : {
      "name" : "Tim Weber",
      "screen_name" : "scy",
      "protected" : false,
      "id_str" : "8308632",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/424137519/avatar184_normal.jpg",
      "id" : 8308632,
      "verified" : false
    }
  },
  "id" : 191814888232980480,
  "created_at" : "Mon Apr 16 09:06:47 +0000 2012",
  "user" : {
    "name" : "Felix",
    "screen_name" : "nicidienase",
    "protected" : false,
    "id_str" : "22396883",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3125784966/8223a4c5c9535be22d15c82ec829c2df_normal.jpeg",
    "id" : 22396883,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://getspaz.com\" rel=\"nofollow\">Spaz HD for webOS</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kati K\u00FCrsch",
      "screen_name" : "KatiKuersch",
      "indices" : [ 3, 15 ],
      "id_str" : "46991038",
      "id" : 46991038
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "191625636564054018",
  "text" : "RT @KatiKuersch: Richtig bitter ist chronischer Sexmangel erst, wenn man von Nonnen f\u00FCr das Durchhalteverm\u00F6gen (was die Enthaltsamkeit a ...",
  "retweeted_status" : {
    "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : {
    },
    "id_str" : "191617828217044992",
    "text" : "Richtig bitter ist chronischer Sexmangel erst, wenn man von Nonnen f\u00FCr das Durchhalteverm\u00F6gen (was die Enthaltsamkeit angeht) gelobt wird.",
    "id" : 191617828217044992,
    "created_at" : "Sun Apr 15 20:03:44 +0000 2012",
    "user" : {
      "name" : "Kati K\u00FCrsch",
      "screen_name" : "KatiKuersch",
      "protected" : false,
      "id_str" : "46991038",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/3503050573/83b4d8da5f22d6beb9ad4ae0f89488de_normal.jpeg",
      "id" : 46991038,
      "verified" : false
    }
  },
  "id" : 191625636564054018,
  "created_at" : "Sun Apr 15 20:34:46 +0000 2012",
  "user" : {
    "name" : "Felix",
    "screen_name" : "nicidienase",
    "protected" : false,
    "id_str" : "22396883",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3125784966/8223a4c5c9535be22d15c82ec829c2df_normal.jpeg",
    "id" : 22396883,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://getspaz.com\" rel=\"nofollow\">Spaz HD for webOS</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Floyd",
      "screen_name" : "DerFloyd",
      "indices" : [ 3, 12 ],
      "id_str" : "256995048",
      "id" : 256995048
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "191306005102067712",
  "text" : "RT @DerFloyd: Mir schei\u00DFegal ob dumm gut fickt. \nIntelligente Frauen sind sexy.",
  "retweeted_status" : {
    "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : {
    },
    "id_str" : "191240394393128961",
    "text" : "Mir schei\u00DFegal ob dumm gut fickt. \nIntelligente Frauen sind sexy.",
    "id" : 191240394393128961,
    "created_at" : "Sat Apr 14 19:03:57 +0000 2012",
    "user" : {
      "name" : "Floyd",
      "screen_name" : "DerFloyd",
      "protected" : false,
      "id_str" : "256995048",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/3284311242/2895cef4273ddbafa10b2d820b19c225_normal.jpeg",
      "id" : 256995048,
      "verified" : false
    }
  },
  "id" : 191306005102067712,
  "created_at" : "Sat Apr 14 23:24:40 +0000 2012",
  "user" : {
    "name" : "Felix",
    "screen_name" : "nicidienase",
    "protected" : false,
    "id_str" : "22396883",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3125784966/8223a4c5c9535be22d15c82ec829c2df_normal.jpeg",
    "id" : 22396883,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://getspaz.com\" rel=\"nofollow\">Spaz HD for webOS</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Abian Hammann",
      "screen_name" : "ultrafritz",
      "indices" : [ 3, 14 ],
      "id_str" : "14833166",
      "id" : 14833166
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Oettinger",
      "indices" : [ 22, 32 ]
    }, {
      "text" : "Mate",
      "indices" : [ 40, 45 ]
    } ],
    "urls" : [ {
      "indices" : [ 65, 85 ],
      "url" : "http://t.co/Y8RU2Lsf",
      "expanded_url" : "http://twitter.com/ultrafritz/status/190878839285628929/photo/1",
      "display_url" : "pic.twitter.com/Y8RU2Lsf"
    } ]
  },
  "geo" : {
  },
  "id_str" : "190902842209468416",
  "text" : "RT @ultrafritz: woot! #Oettinger hat ne #Mate-Cola rausgebracht. http://t.co/Y8RU2Lsf",
  "retweeted_status" : {
    "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "http://twitter.com/ultrafritz/status/190878839285628929/photo/1",
        "indices" : [ 49, 69 ],
        "url" : "http://t.co/Y8RU2Lsf",
        "media_url" : "http://pbs.twimg.com/media/AqYjSwMCQAETqIS.jpg",
        "id_str" : "190878839289823233",
        "id" : 190878839289823233,
        "media_url_https" : "https://pbs.twimg.com/media/AqYjSwMCQAETqIS.jpg",
        "sizes" : [ {
          "h" : 1365,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 3264,
          "resize" : "fit",
          "w" : 2448
        }, {
          "h" : 453,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 800,
          "resize" : "fit",
          "w" : 600
        } ],
        "display_url" : "pic.twitter.com/Y8RU2Lsf"
      } ],
      "hashtags" : [ {
        "text" : "Oettinger",
        "indices" : [ 6, 16 ]
      }, {
        "text" : "Mate",
        "indices" : [ 24, 29 ]
      } ],
      "urls" : [ ]
    },
    "geo" : {
    },
    "id_str" : "190878839285628929",
    "text" : "woot! #Oettinger hat ne #Mate-Cola rausgebracht. http://t.co/Y8RU2Lsf",
    "id" : 190878839285628929,
    "created_at" : "Fri Apr 13 19:07:20 +0000 2012",
    "user" : {
      "name" : "Abian Hammann",
      "screen_name" : "ultrafritz",
      "protected" : false,
      "id_str" : "14833166",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/1356948365/tw_8424139_1305592727_normal.jpg",
      "id" : 14833166,
      "verified" : false
    }
  },
  "id" : 190902842209468416,
  "created_at" : "Fri Apr 13 20:42:39 +0000 2012",
  "user" : {
    "name" : "Felix",
    "screen_name" : "nicidienase",
    "protected" : false,
    "id_str" : "22396883",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3125784966/8223a4c5c9535be22d15c82ec829c2df_normal.jpeg",
    "id" : 22396883,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://getspaz.com\" rel=\"nofollow\">Spaz</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "GPN12",
      "indices" : [ 5, 11 ]
    } ],
    "urls" : [ {
      "indices" : [ 19, 39 ],
      "url" : "http://t.co/vK06zwMt",
      "expanded_url" : "http://twitpic.com/99cxos",
      "display_url" : "twitpic.com/99cxos"
    } ]
  },
  "geo" : {
  },
  "id_str" : "190888200850513920",
  "text" : "Yeay #GPN12 Poster http://t.co/vK06zwMt",
  "id" : 190888200850513920,
  "created_at" : "Fri Apr 13 19:44:28 +0000 2012",
  "user" : {
    "name" : "Felix",
    "screen_name" : "nicidienase",
    "protected" : false,
    "id_str" : "22396883",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3125784966/8223a4c5c9535be22d15c82ec829c2df_normal.jpeg",
    "id" : 22396883,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.echofon.com/\" rel=\"nofollow\">Echofon</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Caro Usel",
      "screen_name" : "colourfulzebra",
      "indices" : [ 17, 32 ],
      "id_str" : "74303306",
      "id" : 74303306
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 75, 95 ],
      "url" : "http://t.co/tZC58LG0",
      "expanded_url" : "http://twitter.com/colourfulzebra/status/190773799858348032/photo/1",
      "display_url" : "pic.twitter.com/tZC58LG0"
    } ]
  },
  "geo" : {
  },
  "id_str" : "190780282310369280",
  "text" : "+1, und WLAN RT: @colourfulzebra: F\u00FCr solche Dinger in Bahnen und Kneipen. http://t.co/tZC58LG0",
  "id" : 190780282310369280,
  "created_at" : "Fri Apr 13 12:35:38 +0000 2012",
  "user" : {
    "name" : "Felix",
    "screen_name" : "nicidienase",
    "protected" : false,
    "id_str" : "22396883",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3125784966/8223a4c5c9535be22d15c82ec829c2df_normal.jpeg",
    "id" : 22396883,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.echofon.com/\" rel=\"nofollow\">Echofon</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Andreas Schepers",
      "screen_name" : "AndreasSchepers",
      "indices" : [ 3, 19 ],
      "id_str" : "12321512",
      "id" : 12321512
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Piraten",
      "indices" : [ 43, 51 ]
    } ],
    "urls" : [ {
      "indices" : [ 65, 85 ],
      "url" : "http://t.co/cDUaC6pk",
      "expanded_url" : "http://www.titanic-magazin.de/uploads/pics/Deep-Inside-the-Pirates.jpg",
      "display_url" : "titanic-magazin.de/uploads/pics/D\u2026"
    } ]
  },
  "geo" : {
  },
  "id_str" : "190778417225015297",
  "text" : "RT @AndreasSchepers: +++EIL+++ Inhalte der #Piraten aufgetaucht: http://t.co/cDUaC6pk +++",
  "retweeted_status" : {
    "source" : "<a href=\"http://www.tweetdeck.com\" rel=\"nofollow\">TweetDeck</a>",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "Piraten",
        "indices" : [ 22, 30 ]
      } ],
      "urls" : [ {
        "indices" : [ 44, 64 ],
        "url" : "http://t.co/cDUaC6pk",
        "expanded_url" : "http://www.titanic-magazin.de/uploads/pics/Deep-Inside-the-Pirates.jpg",
        "display_url" : "titanic-magazin.de/uploads/pics/D\u2026"
      } ]
    },
    "geo" : {
    },
    "id_str" : "190776342067945472",
    "text" : "+++EIL+++ Inhalte der #Piraten aufgetaucht: http://t.co/cDUaC6pk +++",
    "id" : 190776342067945472,
    "created_at" : "Fri Apr 13 12:19:59 +0000 2012",
    "user" : {
      "name" : "Andreas Schepers",
      "screen_name" : "AndreasSchepers",
      "protected" : false,
      "id_str" : "12321512",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/2626352948/mwfrpbya6qam02t4o77m_normal.jpeg",
      "id" : 12321512,
      "verified" : false
    }
  },
  "id" : 190778417225015297,
  "created_at" : "Fri Apr 13 12:28:13 +0000 2012",
  "user" : {
    "name" : "Felix",
    "screen_name" : "nicidienase",
    "protected" : false,
    "id_str" : "22396883",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3125784966/8223a4c5c9535be22d15c82ec829c2df_normal.jpeg",
    "id" : 22396883,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.echofon.com/\" rel=\"nofollow\">Echofon</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Eva Eichhorn",
      "screen_name" : "MamsellChaos",
      "indices" : [ 0, 13 ],
      "id_str" : "140774041",
      "id" : 140774041
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "190725174126063617",
  "geo" : {
  },
  "id_str" : "190730956368384001",
  "in_reply_to_user_id" : 140774041,
  "text" : "@MamsellChaos Vieleicht hat es eine Identit\u00E4tskrise und denkt es w\u00E4r ne Heizung ;-)",
  "id" : 190730956368384001,
  "in_reply_to_status_id" : 190725174126063617,
  "created_at" : "Fri Apr 13 09:19:38 +0000 2012",
  "in_reply_to_screen_name" : "MamsellChaos",
  "in_reply_to_user_id_str" : "140774041",
  "user" : {
    "name" : "Felix",
    "screen_name" : "nicidienase",
    "protected" : false,
    "id_str" : "22396883",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3125784966/8223a4c5c9535be22d15c82ec829c2df_normal.jpeg",
    "id" : 22396883,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.echofon.com/\" rel=\"nofollow\">Echofon</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Eva Eichhorn",
      "screen_name" : "MamsellChaos",
      "indices" : [ 0, 13 ],
      "id_str" : "140774041",
      "id" : 140774041
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "190722570960642048",
  "geo" : {
  },
  "id_str" : "190723232129757186",
  "in_reply_to_user_id" : 140774041,
  "text" : "@MamsellChaos mein alter PalmPre wurde bei schlechtem Netz ziemlich hei\u00DF (und hat den Akku leergesaugt wie nix)",
  "id" : 190723232129757186,
  "in_reply_to_status_id" : 190722570960642048,
  "created_at" : "Fri Apr 13 08:48:56 +0000 2012",
  "in_reply_to_screen_name" : "MamsellChaos",
  "in_reply_to_user_id_str" : "140774041",
  "user" : {
    "name" : "Felix",
    "screen_name" : "nicidienase",
    "protected" : false,
    "id_str" : "22396883",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3125784966/8223a4c5c9535be22d15c82ec829c2df_normal.jpeg",
    "id" : 22396883,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.echofon.com/\" rel=\"nofollow\">Echofon</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The God Tweets",
      "screen_name" : "TheGoogleFacts",
      "indices" : [ 3, 18 ],
      "id_str" : "804811148",
      "id" : 804811148
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "190717314755330049",
  "text" : "RT @TheGoogleFacts: 91% of women like men in pink T-Shirt. But ironically, 91% of men in pink T-Shirt don't like women.",
  "retweeted_status" : {
    "source" : "<a href=\"http://www.facebook.com/twitter\" rel=\"nofollow\">Facebook</a>",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : {
    },
    "id_str" : "190553619152637952",
    "text" : "91% of women like men in pink T-Shirt. But ironically, 91% of men in pink T-Shirt don't like women.",
    "id" : 190553619152637952,
    "created_at" : "Thu Apr 12 21:34:57 +0000 2012",
    "user" : {
      "name" : "Mind Blowing Facts",
      "screen_name" : "TheMindBlowing",
      "protected" : false,
      "id_str" : "488751763",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/3169173387/96f8a7faee3389266311c4f89406c440_normal.jpeg",
      "id" : 488751763,
      "verified" : false
    }
  },
  "id" : 190717314755330049,
  "created_at" : "Fri Apr 13 08:25:25 +0000 2012",
  "user" : {
    "name" : "Felix",
    "screen_name" : "nicidienase",
    "protected" : false,
    "id_str" : "22396883",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3125784966/8223a4c5c9535be22d15c82ec829c2df_normal.jpeg",
    "id" : 22396883,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.echofon.com/\" rel=\"nofollow\">Echofon</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 45, 65 ],
      "url" : "http://t.co/NGmRZwmY",
      "expanded_url" : "http://prettycolors.tumblr.com/",
      "display_url" : "prettycolors.tumblr.com"
    } ]
  },
  "geo" : {
  },
  "id_str" : "190433197203533826",
  "text" : "RT @NervengiftC: prettycolors . tumblr . com\nhttp://t.co/NGmRZwmY",
  "retweeted_status" : {
    "source" : "<a href=\"http://www.tweetdeck.com\" rel=\"nofollow\">TweetDeck</a>",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 28, 48 ],
        "url" : "http://t.co/NGmRZwmY",
        "expanded_url" : "http://prettycolors.tumblr.com/",
        "display_url" : "prettycolors.tumblr.com"
      } ]
    },
    "geo" : {
    },
    "id_str" : "190431244109099008",
    "text" : "prettycolors . tumblr . com\nhttp://t.co/NGmRZwmY",
    "id" : 190431244109099008,
    "created_at" : "Thu Apr 12 13:28:41 +0000 2012",
    "user" : {
      "name" : "\u2623Das Nervengift",
      "screen_name" : "nervengiftlabs",
      "protected" : false,
      "id_str" : "121226933",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/969113240/6-563bee5733b3613c_normal.jpg",
      "id" : 121226933,
      "verified" : false
    }
  },
  "id" : 190433197203533826,
  "created_at" : "Thu Apr 12 13:36:26 +0000 2012",
  "user" : {
    "name" : "Felix",
    "screen_name" : "nicidienase",
    "protected" : false,
    "id_str" : "22396883",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3125784966/8223a4c5c9535be22d15c82ec829c2df_normal.jpeg",
    "id" : 22396883,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.echofon.com/\" rel=\"nofollow\">Echofon</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "memo",
      "screen_name" : "memo42",
      "indices" : [ 0, 7 ],
      "id_str" : "55311456",
      "id" : 55311456
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "190416767951179776",
  "geo" : {
  },
  "id_str" : "190420089860919297",
  "in_reply_to_user_id" : 55311456,
  "text" : "@memo42 weder noch. Mein neues Schwenkgelenk kann man drehen und die Rotation kann man per Config \u00E4ndern",
  "id" : 190420089860919297,
  "in_reply_to_status_id" : 190416767951179776,
  "created_at" : "Thu Apr 12 12:44:21 +0000 2012",
  "in_reply_to_screen_name" : "memo42",
  "in_reply_to_user_id_str" : "55311456",
  "user" : {
    "name" : "Felix",
    "screen_name" : "nicidienase",
    "protected" : false,
    "id_str" : "22396883",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3125784966/8223a4c5c9535be22d15c82ec829c2df_normal.jpeg",
    "id" : 22396883,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.echofon.com/\" rel=\"nofollow\">Echofon</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kate H.",
      "screen_name" : "elaoe7",
      "indices" : [ 0, 7 ],
      "id_str" : "149650777",
      "id" : 149650777
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "190345451009093634",
  "geo" : {
  },
  "id_str" : "190349578904670208",
  "in_reply_to_user_id" : 149650777,
  "text" : "@elaoe7 Michael Jackson?",
  "id" : 190349578904670208,
  "in_reply_to_status_id" : 190345451009093634,
  "created_at" : "Thu Apr 12 08:04:10 +0000 2012",
  "in_reply_to_screen_name" : "elaoe7",
  "in_reply_to_user_id_str" : "149650777",
  "user" : {
    "name" : "Felix",
    "screen_name" : "nicidienase",
    "protected" : false,
    "id_str" : "22396883",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3125784966/8223a4c5c9535be22d15c82ec829c2df_normal.jpeg",
    "id" : 22396883,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.echofon.com/\" rel=\"nofollow\">Echofon</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Miss J.",
      "screen_name" : "_notausgang",
      "indices" : [ 3, 15 ],
      "id_str" : "43136856",
      "id" : 43136856
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "190349244597665792",
  "text" : "RT @_notausgang: \"Ich steh gleich auf. Noch 5 min.\"\n-ich so, seit ner Std.",
  "retweeted_status" : {
    "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : {
    },
    "id_str" : "190332123889143808",
    "text" : "\"Ich steh gleich auf. Noch 5 min.\"\n-ich so, seit ner Std.",
    "id" : 190332123889143808,
    "created_at" : "Thu Apr 12 06:54:49 +0000 2012",
    "user" : {
      "name" : "Miss J.",
      "screen_name" : "_notausgang",
      "protected" : false,
      "id_str" : "43136856",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/3485581486/bf68521159927a237e50edd785f47c0c_normal.jpeg",
      "id" : 43136856,
      "verified" : false
    }
  },
  "id" : 190349244597665792,
  "created_at" : "Thu Apr 12 08:02:51 +0000 2012",
  "user" : {
    "name" : "Felix",
    "screen_name" : "nicidienase",
    "protected" : false,
    "id_str" : "22396883",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3125784966/8223a4c5c9535be22d15c82ec829c2df_normal.jpeg",
    "id" : 22396883,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "psy",
      "screen_name" : "psycon",
      "indices" : [ 3, 10 ],
      "id_str" : "87286054",
      "id" : 87286054
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 47, 67 ],
      "url" : "http://t.co/yHB9V7wr",
      "expanded_url" : "http://www.youtube.com/watch?v=316AzLYfAzw",
      "display_url" : "youtube.com/watch?v=316AzL\u2026"
    } ]
  },
  "geo" : {
  },
  "id_str" : "190182989043482624",
  "text" : "RT @psycon: Das nenn ich mal ne geile Werbung: http://t.co/yHB9V7wr",
  "retweeted_status" : {
    "source" : "web",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 35, 55 ],
        "url" : "http://t.co/yHB9V7wr",
        "expanded_url" : "http://www.youtube.com/watch?v=316AzLYfAzw",
        "display_url" : "youtube.com/watch?v=316AzL\u2026"
      } ]
    },
    "geo" : {
    },
    "id_str" : "190178184682147840",
    "text" : "Das nenn ich mal ne geile Werbung: http://t.co/yHB9V7wr",
    "id" : 190178184682147840,
    "created_at" : "Wed Apr 11 20:43:07 +0000 2012",
    "user" : {
      "name" : "psy",
      "screen_name" : "psycon",
      "protected" : false,
      "id_str" : "87286054",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/2620981046/xkjfqh2iy0xp1lxx6cl1_normal.jpeg",
      "id" : 87286054,
      "verified" : false
    }
  },
  "id" : 190182989043482624,
  "created_at" : "Wed Apr 11 21:02:12 +0000 2012",
  "user" : {
    "name" : "Felix",
    "screen_name" : "nicidienase",
    "protected" : false,
    "id_str" : "22396883",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3125784966/8223a4c5c9535be22d15c82ec829c2df_normal.jpeg",
    "id" : 22396883,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://getspaz.com\" rel=\"nofollow\">Spaz</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 40, 60 ],
      "url" : "http://t.co/UFGAQTgl",
      "expanded_url" : "http://twitpic.com/98m846",
      "display_url" : "twitpic.com/98m846"
    } ]
  },
  "geo" : {
  },
  "id_str" : "190174787853758465",
  "text" : "Timeline im Hochformat hat schon was .. http://t.co/UFGAQTgl",
  "id" : 190174787853758465,
  "created_at" : "Wed Apr 11 20:29:37 +0000 2012",
  "user" : {
    "name" : "Felix",
    "screen_name" : "nicidienase",
    "protected" : false,
    "id_str" : "22396883",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3125784966/8223a4c5c9535be22d15c82ec829c2df_normal.jpeg",
    "id" : 22396883,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.echofon.com/\" rel=\"nofollow\">Echofon</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Betty White",
      "screen_name" : "BettyMWhite",
      "indices" : [ 8, 20 ],
      "id_str" : "544517731",
      "id" : 544517731
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "190105631649304576",
  "text" : "Awesome @BettyMWhite is on Twitter",
  "id" : 190105631649304576,
  "created_at" : "Wed Apr 11 15:54:49 +0000 2012",
  "user" : {
    "name" : "Felix",
    "screen_name" : "nicidienase",
    "protected" : false,
    "id_str" : "22396883",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3125784966/8223a4c5c9535be22d15c82ec829c2df_normal.jpeg",
    "id" : 22396883,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.echofon.com/\" rel=\"nofollow\">Echofon</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Betty White",
      "screen_name" : "BettyMWhite",
      "indices" : [ 3, 15 ],
      "id_str" : "544517731",
      "id" : 544517731
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "190105522496741377",
  "text" : "RT @BettyMWhite: Hello Twitter!  And they said it would never happen.  Oh wait, that was me.",
  "retweeted_status" : {
    "source" : "web",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : {
    },
    "id_str" : "189830836655366144",
    "text" : "Hello Twitter!  And they said it would never happen.  Oh wait, that was me.",
    "id" : 189830836655366144,
    "created_at" : "Tue Apr 10 21:42:53 +0000 2012",
    "user" : {
      "name" : "Betty White",
      "screen_name" : "BettyMWhite",
      "protected" : false,
      "id_str" : "544517731",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/2029688967/Betty_Photo_normal.jpg",
      "id" : 544517731,
      "verified" : true
    }
  },
  "id" : 190105522496741377,
  "created_at" : "Wed Apr 11 15:54:23 +0000 2012",
  "user" : {
    "name" : "Felix",
    "screen_name" : "nicidienase",
    "protected" : false,
    "id_str" : "22396883",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3125784966/8223a4c5c9535be22d15c82ec829c2df_normal.jpeg",
    "id" : 22396883,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.echofon.com/\" rel=\"nofollow\">Echofon</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "190031525079822336",
  "text" : "Irgendwas muss heute mit den K\u00E4sesp\u00E4tzle gewesen sein, anders kann ich mir mein unterirdisch schlechtes Kickerspiel heute nicht erkl\u00E4ren.",
  "id" : 190031525079822336,
  "created_at" : "Wed Apr 11 11:00:20 +0000 2012",
  "user" : {
    "name" : "Felix",
    "screen_name" : "nicidienase",
    "protected" : false,
    "id_str" : "22396883",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3125784966/8223a4c5c9535be22d15c82ec829c2df_normal.jpeg",
    "id" : 22396883,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.echofon.com/\" rel=\"nofollow\">Echofon</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "little dear",
      "screen_name" : "abgeloost",
      "indices" : [ 3, 13 ],
      "id_str" : "1061139056",
      "id" : 1061139056
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "189696656571236353",
  "text" : "RT @abgeloost: Der Grund warum boobs das englische Wort f\u00FCr br\u00FCste ist: B- Draufsicht.\noo- vorderansicht.\nb- Seitenansicht.",
  "retweeted_status" : {
    "source" : "<a href=\"http://www.tweetdeck.com\" rel=\"nofollow\">TweetDeck</a>",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : {
    },
    "id_str" : "128838131859472384",
    "text" : "Der Grund warum boobs das englische Wort f\u00FCr br\u00FCste ist: B- Draufsicht.\noo- vorderansicht.\nb- Seitenansicht.",
    "id" : 128838131859472384,
    "created_at" : "Tue Oct 25 14:19:38 +0000 2011",
    "user" : {
      "name" : "_",
      "screen_name" : "Laberrhabarber_",
      "protected" : false,
      "id_str" : "334011135",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/3303437108/84618354b6446b1af156b9a55ec3d681_normal.jpeg",
      "id" : 334011135,
      "verified" : false
    }
  },
  "id" : 189696656571236353,
  "created_at" : "Tue Apr 10 12:49:41 +0000 2012",
  "user" : {
    "name" : "Felix",
    "screen_name" : "nicidienase",
    "protected" : false,
    "id_str" : "22396883",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3125784966/8223a4c5c9535be22d15c82ec829c2df_normal.jpeg",
    "id" : 22396883,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://getspaz.com\" rel=\"nofollow\">Spaz HD for webOS</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "yetzt",
      "screen_name" : "yetzt",
      "indices" : [ 3, 9 ],
      "id_str" : "2902401",
      "id" : 2902401
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "189609169588994048",
  "text" : "RT @yetzt: POH: \"wer l\u00E4uft durchs rechenzentrum und versteckt server? der hosterhase.\"",
  "retweeted_status" : {
    "source" : "<a href=\"http://www.echofon.com/\" rel=\"nofollow\">Echofon</a>",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : {
    },
    "id_str" : "189461938743418880",
    "text" : "POH: \"wer l\u00E4uft durchs rechenzentrum und versteckt server? der hosterhase.\"",
    "id" : 189461938743418880,
    "created_at" : "Mon Apr 09 21:17:00 +0000 2012",
    "user" : {
      "name" : "yetzt",
      "screen_name" : "yetzt",
      "protected" : false,
      "id_str" : "2902401",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/2541812133/qp1r3ec2njl54p8lcsp3_normal.png",
      "id" : 2902401,
      "verified" : false
    }
  },
  "id" : 189609169588994048,
  "created_at" : "Tue Apr 10 07:02:03 +0000 2012",
  "user" : {
    "name" : "Felix",
    "screen_name" : "nicidienase",
    "protected" : false,
    "id_str" : "22396883",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3125784966/8223a4c5c9535be22d15c82ec829c2df_normal.jpeg",
    "id" : 22396883,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://getspaz.com\" rel=\"nofollow\">Spaz HD for webOS</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jesus von Nazareth",
      "screen_name" : "VonJesus",
      "indices" : [ 3, 12 ],
      "id_str" : "546757548",
      "id" : 546757548
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "189001778757509120",
  "text" : "RT @VonJesus: Was f\u00FCr ein Wochenende! Erst vergessen mich die Idioten an so einem Holzkreuz und dann wach ich in einer H\u00F6hle auf. Hab vo ...",
  "retweeted_status" : {
    "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : {
    },
    "id_str" : "188977434505383937",
    "text" : "Was f\u00FCr ein Wochenende! Erst vergessen mich die Idioten an so einem Holzkreuz und dann wach ich in einer H\u00F6hle auf. Hab voll den Filmriss...",
    "id" : 188977434505383937,
    "created_at" : "Sun Apr 08 13:11:46 +0000 2012",
    "user" : {
      "name" : "Jesus von Nazareth",
      "screen_name" : "VonJesus",
      "protected" : false,
      "id_str" : "546757548",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/2049168504/Buddy_Jesus_normal.jpg",
      "id" : 546757548,
      "verified" : false
    }
  },
  "id" : 189001778757509120,
  "created_at" : "Sun Apr 08 14:48:30 +0000 2012",
  "user" : {
    "name" : "Felix",
    "screen_name" : "nicidienase",
    "protected" : false,
    "id_str" : "22396883",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3125784966/8223a4c5c9535be22d15c82ec829c2df_normal.jpeg",
    "id" : 22396883,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ironsky",
      "indices" : [ 28, 36 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "187698473607503872",
  "text" : "Iron Sky ist so AWESOME!!!! #ironsky",
  "id" : 187698473607503872,
  "created_at" : "Thu Apr 05 00:29:38 +0000 2012",
  "user" : {
    "name" : "Felix",
    "screen_name" : "nicidienase",
    "protected" : false,
    "id_str" : "22396883",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3125784966/8223a4c5c9535be22d15c82ec829c2df_normal.jpeg",
    "id" : 22396883,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://getspaz.com\" rel=\"nofollow\">Spaz HD for webOS</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tim Weber",
      "screen_name" : "Scytale",
      "indices" : [ 3, 11 ],
      "id_str" : "594921016",
      "id" : 594921016
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 43, 63 ],
      "url" : "http://t.co/3GYPhojj",
      "expanded_url" : "http://kottke.org/12/04/kinect-star-wars-dance-party",
      "display_url" : "kottke.org/12/04/kinect-s\u2026"
    } ]
  },
  "geo" : {
  },
  "id_str" : "186961651675832320",
  "text" : "RT @Scytale: Kinect Star Wars Dance Party. http://t.co/3GYPhojj (mit DJ Lobot)",
  "retweeted_status" : {
    "source" : "<a href=\"http://www.tweetdeck.com\" rel=\"nofollow\">TweetDeck</a>",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 30, 50 ],
        "url" : "http://t.co/3GYPhojj",
        "expanded_url" : "http://kottke.org/12/04/kinect-star-wars-dance-party",
        "display_url" : "kottke.org/12/04/kinect-s\u2026"
      } ]
    },
    "geo" : {
    },
    "id_str" : "186881813237608448",
    "text" : "Kinect Star Wars Dance Party. http://t.co/3GYPhojj (mit DJ Lobot)",
    "id" : 186881813237608448,
    "created_at" : "Mon Apr 02 18:24:31 +0000 2012",
    "user" : {
      "name" : "Tim Weber",
      "screen_name" : "scy",
      "protected" : false,
      "id_str" : "8308632",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/424137519/avatar184_normal.jpg",
      "id" : 8308632,
      "verified" : false
    }
  },
  "id" : 186961651675832320,
  "created_at" : "Mon Apr 02 23:41:45 +0000 2012",
  "user" : {
    "name" : "Felix",
    "screen_name" : "nicidienase",
    "protected" : false,
    "id_str" : "22396883",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3125784966/8223a4c5c9535be22d15c82ec829c2df_normal.jpeg",
    "id" : 22396883,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://getspaz.com\" rel=\"nofollow\">Spaz HD for webOS</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Martin Stoppler",
      "screen_name" : "stoppegp",
      "indices" : [ 3, 12 ],
      "id_str" : "70145536",
      "id" : 70145536
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 89, 109 ],
      "url" : "http://t.co/cgEvOz5F",
      "expanded_url" : "http://bit.ly/HuNBaG",
      "display_url" : "bit.ly/HuNBaG"
    } ]
  },
  "geo" : {
  },
  "id_str" : "186377310709088256",
  "text" : "RT @stoppegp: OK, ich bin ja kein Fan von Aprilscherzen, aber der hier ist wirklich gut! http://t.co/cgEvOz5F",
  "retweeted_status" : {
    "source" : "<a href=\"http://www.tweetdeck.com\" rel=\"nofollow\">TweetDeck</a>",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 75, 95 ],
        "url" : "http://t.co/cgEvOz5F",
        "expanded_url" : "http://bit.ly/HuNBaG",
        "display_url" : "bit.ly/HuNBaG"
      } ]
    },
    "geo" : {
    },
    "id_str" : "186221403211702272",
    "text" : "OK, ich bin ja kein Fan von Aprilscherzen, aber der hier ist wirklich gut! http://t.co/cgEvOz5F",
    "id" : 186221403211702272,
    "created_at" : "Sat Mar 31 22:40:17 +0000 2012",
    "user" : {
      "name" : "Martin Stoppler",
      "screen_name" : "stoppegp",
      "protected" : false,
      "id_str" : "70145536",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/1509579642/35797_103908709661635_100001275182159_23434_2385237_n_normal.jpg",
      "id" : 70145536,
      "verified" : false
    }
  },
  "id" : 186377310709088256,
  "created_at" : "Sun Apr 01 08:59:48 +0000 2012",
  "user" : {
    "name" : "Felix",
    "screen_name" : "nicidienase",
    "protected" : false,
    "id_str" : "22396883",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3125784966/8223a4c5c9535be22d15c82ec829c2df_normal.jpeg",
    "id" : 22396883,
    "verified" : false
  }
} ]