Grailbird.data.tweets_2011_09 = 
 [ {
  "source" : "<a href=\"http://getspaz.com\" rel=\"nofollow\">Spaz</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "118398963702439936",
  "text" : "Damn it! Bl\u00F6des Autokorrekt. Das sollte \"von meinem Pre\" hei\u00DFen!",
  "id" : 118398963702439936,
  "created_at" : "Mon Sep 26 18:58:07 +0000 2011",
  "user" : {
    "name" : "Felix",
    "screen_name" : "nicidienase",
    "protected" : false,
    "id_str" : "22396883",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3125784966/8223a4c5c9535be22d15c82ec829c2df_normal.jpeg",
    "id" : 22396883,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://getspaz.com\" rel=\"nofollow\">Spaz</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "118398640929767424",
  "text" : "Yeay! Nachdem ich mal meine SSL-Zertifikate aufger\u00E4umt hab kann ich jetzt endlich auch von meinem Pro aus meinen eigenen Mailserver abrufen!",
  "id" : 118398640929767424,
  "created_at" : "Mon Sep 26 18:56:50 +0000 2011",
  "user" : {
    "name" : "Felix",
    "screen_name" : "nicidienase",
    "protected" : false,
    "id_str" : "22396883",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3125784966/8223a4c5c9535be22d15c82ec829c2df_normal.jpeg",
    "id" : 22396883,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://getspaz.com\" rel=\"nofollow\">Spaz</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "touchpad",
      "indices" : [ 27, 36 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "117969352883572736",
  "text" : "Hab soeben bei eBay ein HP #touchpad erworben!",
  "id" : 117969352883572736,
  "created_at" : "Sun Sep 25 14:31:00 +0000 2011",
  "user" : {
    "name" : "Felix",
    "screen_name" : "nicidienase",
    "protected" : false,
    "id_str" : "22396883",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3125784966/8223a4c5c9535be22d15c82ec829c2df_normal.jpeg",
    "id" : 22396883,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://getspaz.com\" rel=\"nofollow\">Spaz</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jens Ohlig",
      "screen_name" : "johl",
      "indices" : [ 3, 8 ],
      "id_str" : "1147751",
      "id" : 1147751
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "117968507580321792",
  "text" : "RT @johl: \"Neutrino!\" \u2014 \"Who's there?\" \u2014 \"Knock, knock.\"",
  "retweeted_status" : {
    "source" : "<a href=\"http://itunes.apple.com/us/app/twitter/id409789998?mt=12\" rel=\"nofollow\">Twitter for Mac</a>",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : {
    },
    "id_str" : "117706562713292800",
    "text" : "\"Neutrino!\" \u2014 \"Who's there?\" \u2014 \"Knock, knock.\"",
    "id" : 117706562713292800,
    "created_at" : "Sat Sep 24 21:06:46 +0000 2011",
    "user" : {
      "name" : "Jens Ohlig",
      "screen_name" : "johl",
      "protected" : false,
      "id_str" : "1147751",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/2396409791/oeym506iih2iyj0e80f9_normal.png",
      "id" : 1147751,
      "verified" : false
    }
  },
  "id" : 117968507580321792,
  "created_at" : "Sun Sep 25 14:27:38 +0000 2011",
  "user" : {
    "name" : "Felix",
    "screen_name" : "nicidienase",
    "protected" : false,
    "id_str" : "22396883",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3125784966/8223a4c5c9535be22d15c82ec829c2df_normal.jpeg",
    "id" : 22396883,
    "verified" : false
  }
} ]