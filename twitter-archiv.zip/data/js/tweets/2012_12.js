Grailbird.data.tweets_2012_12 = 
 [ {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "psy",
      "screen_name" : "psycon",
      "indices" : [ 0, 7 ],
      "id_str" : "87286054",
      "id" : 87286054
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "wildguess",
      "indices" : [ 53, 63 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "285758384026812416",
  "geo" : {
  },
  "id_str" : "285760210650398720",
  "in_reply_to_user_id" : 87286054,
  "text" : "@psycon Die war mindestens einmal zum bcc und zur\u00FCck #wildguess",
  "id" : 285760210650398720,
  "in_reply_to_status_id" : 285758384026812416,
  "created_at" : "Mon Dec 31 14:51:58 +0000 2012",
  "in_reply_to_screen_name" : "psycon",
  "in_reply_to_user_id_str" : "87286054",
  "user" : {
    "name" : "Felix",
    "screen_name" : "nicidienase",
    "protected" : false,
    "id_str" : "22396883",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3125784966/8223a4c5c9535be22d15c82ec829c2df_normal.jpeg",
    "id" : 22396883,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Command Line Magic",
      "screen_name" : "climagic",
      "indices" : [ 3, 12 ],
      "id_str" : "91333167",
      "id" : 91333167
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "285759918689120258",
  "text" : "RT @climagic: New Year's resolution: 80x24",
  "retweeted_status" : {
    "source" : "<a href=\"http://suso.suso.org/xulu/Command_Line_Magic\" rel=\"nofollow\">CLI Magic poster</a>",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : {
    },
    "id_str" : "285751080883716096",
    "text" : "New Year's resolution: 80x24",
    "id" : 285751080883716096,
    "created_at" : "Mon Dec 31 14:15:41 +0000 2012",
    "user" : {
      "name" : "Command Line Magic",
      "screen_name" : "climagic",
      "protected" : false,
      "id_str" : "91333167",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/535876218/climagic-icon_normal.png",
      "id" : 91333167,
      "verified" : false
    }
  },
  "id" : 285759918689120258,
  "created_at" : "Mon Dec 31 14:50:48 +0000 2012",
  "user" : {
    "name" : "Felix",
    "screen_name" : "nicidienase",
    "protected" : false,
    "id_str" : "22396883",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3125784966/8223a4c5c9535be22d15c82ec829c2df_normal.jpeg",
    "id" : 22396883,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "psy",
      "screen_name" : "psycon",
      "indices" : [ 0, 7 ],
      "id_str" : "87286054",
      "id" : 87286054
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "285748951553015808",
  "geo" : {
  },
  "id_str" : "285759860409266176",
  "in_reply_to_user_id" : 87286054,
  "text" : "@psycon Ich sogar im RE. Mit Tischen und Strom. L\u00E4sst sich bei 15min Fahrt leider nicht richtig ausnutzen.",
  "id" : 285759860409266176,
  "in_reply_to_status_id" : 285748951553015808,
  "created_at" : "Mon Dec 31 14:50:34 +0000 2012",
  "in_reply_to_screen_name" : "psycon",
  "in_reply_to_user_id_str" : "87286054",
  "user" : {
    "name" : "Felix",
    "screen_name" : "nicidienase",
    "protected" : false,
    "id_str" : "22396883",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3125784966/8223a4c5c9535be22d15c82ec829c2df_normal.jpeg",
    "id" : 22396883,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Maik Musall",
      "screen_name" : "maikm",
      "indices" : [ 3, 9 ],
      "id_str" : "20852571",
      "id" : 20852571
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "29c3",
      "indices" : [ 11, 16 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "285672823983308800",
  "text" : "RT @maikm: #29c3 B.E/S{T} -C//O[NG]R-E|S&gt;S (E-V)E/R",
  "retweeted_status" : {
    "source" : "<a href=\"http://tapbots.com/tweetbot\" rel=\"nofollow\">Tweetbot for iOS</a>",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "29c3",
        "indices" : [ 0, 5 ]
      } ],
      "urls" : [ ]
    },
    "geo" : {
    },
    "id_str" : "285477129209131008",
    "text" : "#29c3 B.E/S{T} -C//O[NG]R-E|S&gt;S (E-V)E/R",
    "id" : 285477129209131008,
    "created_at" : "Sun Dec 30 20:07:06 +0000 2012",
    "user" : {
      "name" : "Maik Musall",
      "screen_name" : "maikm",
      "protected" : false,
      "id_str" : "20852571",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/2424948699/f5c7s2bq9pei0gdv9rgh_normal.jpeg",
      "id" : 20852571,
      "verified" : false
    }
  },
  "id" : 285672823983308800,
  "created_at" : "Mon Dec 31 09:04:43 +0000 2012",
  "user" : {
    "name" : "Felix",
    "screen_name" : "nicidienase",
    "protected" : false,
    "id_str" : "22396883",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3125784966/8223a4c5c9535be22d15c82ec829c2df_normal.jpeg",
    "id" : 22396883,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "29c3",
      "indices" : [ 25, 30 ]
    }, {
      "text" : "dbl",
      "indices" : [ 37, 41 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "285672728369967106",
  "text" : "Goodbye Hamburg! Goodbye #29c3 ICE75 #dbl",
  "id" : 285672728369967106,
  "created_at" : "Mon Dec 31 09:04:20 +0000 2012",
  "user" : {
    "name" : "Felix",
    "screen_name" : "nicidienase",
    "protected" : false,
    "id_str" : "22396883",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3125784966/8223a4c5c9535be22d15c82ec829c2df_normal.jpeg",
    "id" : 22396883,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "29c3",
      "indices" : [ 105, 110 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "285521570682773504",
  "text" : "Wir warten jetzt schon eine dreiviertel Stunde auf den Shuttlebus, der sollte jede halbe Stunden fahren. #29c3",
  "id" : 285521570682773504,
  "created_at" : "Sun Dec 30 23:03:41 +0000 2012",
  "user" : {
    "name" : "Felix",
    "screen_name" : "nicidienase",
    "protected" : false,
    "id_str" : "22396883",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3125784966/8223a4c5c9535be22d15c82ec829c2df_normal.jpeg",
    "id" : 22396883,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Retinacast",
      "screen_name" : "retinacast",
      "indices" : [ 101, 112 ],
      "id_str" : "341269227",
      "id" : 341269227
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "29c3",
      "indices" : [ 18, 23 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "285206423892283392",
  "text" : "Da l\u00E4ufst du aufm #29c3 rum, h\u00F6rst pl\u00F6tzlich bekannte Stimmen und schon kennst du das halbe Team vom @retinacast :-)",
  "id" : 285206423892283392,
  "created_at" : "Sun Dec 30 02:11:24 +0000 2012",
  "user" : {
    "name" : "Felix",
    "screen_name" : "nicidienase",
    "protected" : false,
    "id_str" : "22396883",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3125784966/8223a4c5c9535be22d15c82ec829c2df_normal.jpeg",
    "id" : 22396883,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Eva Eichhorn",
      "screen_name" : "MamsellChaos",
      "indices" : [ 0, 13 ],
      "id_str" : "140774041",
      "id" : 140774041
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "285074015595413504",
  "geo" : {
  },
  "id_str" : "285098546389213184",
  "in_reply_to_user_id" : 140774041,
  "text" : "@MamsellChaos Fuchur? Als ich den das letzte Mal gesehen hab war der noch ein St\u00FCck kleiner.",
  "id" : 285098546389213184,
  "in_reply_to_status_id" : 285074015595413504,
  "created_at" : "Sat Dec 29 19:02:44 +0000 2012",
  "in_reply_to_screen_name" : "MamsellChaos",
  "in_reply_to_user_id_str" : "140774041",
  "user" : {
    "name" : "Felix",
    "screen_name" : "nicidienase",
    "protected" : false,
    "id_str" : "22396883",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3125784966/8223a4c5c9535be22d15c82ec829c2df_normal.jpeg",
    "id" : 22396883,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.echofon.com/\" rel=\"nofollow\">Echofon</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "29c3",
      "indices" : [ 77, 82 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "285076405010702336",
  "text" : "OH: \"Kann man eigentlich den Laptop anlassen beim Lasern und weiter Seeden?\" #29c3",
  "id" : 285076405010702336,
  "created_at" : "Sat Dec 29 17:34:46 +0000 2012",
  "user" : {
    "name" : "Felix",
    "screen_name" : "nicidienase",
    "protected" : false,
    "id_str" : "22396883",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3125784966/8223a4c5c9535be22d15c82ec829c2df_normal.jpeg",
    "id" : 22396883,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "29c3",
      "indices" : [ 27, 32 ]
    }, {
      "text" : "gym",
      "indices" : [ 33, 37 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "284871570449641472",
  "text" : "3-stimmiger Schnarch-Kanon #29c3 #gym",
  "id" : 284871570449641472,
  "created_at" : "Sat Dec 29 04:00:49 +0000 2012",
  "user" : {
    "name" : "Felix",
    "screen_name" : "nicidienase",
    "protected" : false,
    "id_str" : "22396883",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3125784966/8223a4c5c9535be22d15c82ec829c2df_normal.jpeg",
    "id" : 22396883,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ernesto Ruge",
      "screen_name" : "the_infinity",
      "indices" : [ 3, 16 ],
      "id_str" : "44870919",
      "id" : 44870919
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "284685312129638401",
  "text" : "RT @the_infinity: Leider ist der Gender+Informatik Vortag sehr trocken und \u00FCbertrieben fachworthaltig ... schade. Obwohl so wichtiges Th ...",
  "retweeted_status" : {
    "source" : "<a href=\"http://www.hootsuite.com\" rel=\"nofollow\">HootSuite</a>",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "29c3",
        "indices" : [ 123, 128 ]
      } ],
      "urls" : [ ]
    },
    "geo" : {
    },
    "id_str" : "284679525705601028",
    "text" : "Leider ist der Gender+Informatik Vortag sehr trocken und \u00FCbertrieben fachworthaltig ... schade. Obwohl so wichtiges Thema. #29c3",
    "id" : 284679525705601028,
    "created_at" : "Fri Dec 28 15:17:42 +0000 2012",
    "user" : {
      "name" : "Ernesto Ruge",
      "screen_name" : "the_infinity",
      "protected" : false,
      "id_str" : "44870919",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/1162498693/IMGP1466_square_normal.jpg",
      "id" : 44870919,
      "verified" : false
    }
  },
  "id" : 284685312129638401,
  "created_at" : "Fri Dec 28 15:40:42 +0000 2012",
  "user" : {
    "name" : "Felix",
    "screen_name" : "nicidienase",
    "protected" : false,
    "id_str" : "22396883",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3125784966/8223a4c5c9535be22d15c82ec829c2df_normal.jpeg",
    "id" : 22396883,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "29C3 Streaming",
      "screen_name" : "c3streaming",
      "indices" : [ 0, 12 ],
      "id_str" : "53929744",
      "id" : 53929744
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "284444987838570496",
  "geo" : {
  },
  "id_str" : "284446625924014081",
  "in_reply_to_user_id" : 53929744,
  "text" : "@c3streaming Will there be recordings?",
  "id" : 284446625924014081,
  "in_reply_to_status_id" : 284444987838570496,
  "created_at" : "Thu Dec 27 23:52:15 +0000 2012",
  "in_reply_to_screen_name" : "c3streaming",
  "in_reply_to_user_id_str" : "53929744",
  "user" : {
    "name" : "Felix",
    "screen_name" : "nicidienase",
    "protected" : false,
    "id_str" : "22396883",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3125784966/8223a4c5c9535be22d15c82ec829c2df_normal.jpeg",
    "id" : 22396883,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Botschaft Israel ",
      "screen_name" : "IsraelinGermany",
      "indices" : [ 3, 19 ],
      "id_str" : "104519327",
      "id" : 104519327
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Israel",
      "indices" : [ 127, 134 ]
    } ],
    "urls" : [ {
      "indices" : [ 106, 126 ],
      "url" : "http://t.co/WLfVAw7D",
      "expanded_url" : "http://ow.ly/gnoR3",
      "display_url" : "ow.ly/gnoR3"
    } ]
  },
  "geo" : {
  },
  "id_str" : "284418583948300288",
  "text" : "RT @IsraelinGermany: Israel hat gleich zwei Piraten-Parteien: Israel Pirate Party und Pirate Party Israel http://t.co/WLfVAw7D #Israel # ...",
  "retweeted_status" : {
    "source" : "<a href=\"http://www.hootsuite.com\" rel=\"nofollow\">HootSuite</a>",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "Israel",
        "indices" : [ 106, 113 ]
      }, {
        "text" : "Piraten",
        "indices" : [ 114, 122 ]
      }, {
        "text" : "MontyPython",
        "indices" : [ 123, 135 ]
      } ],
      "urls" : [ {
        "indices" : [ 85, 105 ],
        "url" : "http://t.co/WLfVAw7D",
        "expanded_url" : "http://ow.ly/gnoR3",
        "display_url" : "ow.ly/gnoR3"
      } ]
    },
    "geo" : {
    },
    "id_str" : "284320521724772354",
    "text" : "Israel hat gleich zwei Piraten-Parteien: Israel Pirate Party und Pirate Party Israel http://t.co/WLfVAw7D #Israel #Piraten #MontyPython",
    "id" : 284320521724772354,
    "created_at" : "Thu Dec 27 15:31:09 +0000 2012",
    "user" : {
      "name" : "Botschaft Israel ",
      "screen_name" : "IsraelinGermany",
      "protected" : false,
      "id_str" : "104519327",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/1238428120/twitterlogo_normal.PNG",
      "id" : 104519327,
      "verified" : true
    }
  },
  "id" : 284418583948300288,
  "created_at" : "Thu Dec 27 22:00:49 +0000 2012",
  "user" : {
    "name" : "Felix",
    "screen_name" : "nicidienase",
    "protected" : false,
    "id_str" : "22396883",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3125784966/8223a4c5c9535be22d15c82ec829c2df_normal.jpeg",
    "id" : 22396883,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "29c3",
      "indices" : [ 33, 38 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "284417523435315200",
  "text" : "Wer hat das Wiki kaputt gemacht? #29c3",
  "id" : 284417523435315200,
  "created_at" : "Thu Dec 27 21:56:36 +0000 2012",
  "user" : {
    "name" : "Felix",
    "screen_name" : "nicidienase",
    "protected" : false,
    "id_str" : "22396883",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3125784966/8223a4c5c9535be22d15c82ec829c2df_normal.jpeg",
    "id" : 22396883,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jock Dieslag",
      "screen_name" : "Joccck",
      "indices" : [ 3, 10 ],
      "id_str" : "94173309",
      "id" : 94173309
    }, {
      "name" : "Felix",
      "screen_name" : "nicidienase",
      "indices" : [ 13, 25 ],
      "id_str" : "22396883",
      "id" : 22396883
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "29c3",
      "indices" : [ 132, 137 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "284333702794866688",
  "text" : "RT @Joccck: .@nicidienase Es werden in jedem Saal einige ausgelegte Keramikfliesen ben\u00F6tigt! - Dedicated Mate Falling Areas (DMFAs) #29c3",
  "retweeted_status" : {
    "source" : "web",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Felix",
        "screen_name" : "nicidienase",
        "indices" : [ 1, 13 ],
        "id_str" : "22396883",
        "id" : 22396883
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "29c3",
        "indices" : [ 120, 125 ]
      } ],
      "urls" : [ ]
    },
    "in_reply_to_status_id_str" : "284306882112413696",
    "geo" : {
    },
    "id_str" : "284331868067876866",
    "in_reply_to_user_id" : 22396883,
    "text" : ".@nicidienase Es werden in jedem Saal einige ausgelegte Keramikfliesen ben\u00F6tigt! - Dedicated Mate Falling Areas (DMFAs) #29c3",
    "id" : 284331868067876866,
    "in_reply_to_status_id" : 284306882112413696,
    "created_at" : "Thu Dec 27 16:16:14 +0000 2012",
    "in_reply_to_screen_name" : "nicidienase",
    "in_reply_to_user_id_str" : "22396883",
    "user" : {
      "name" : "Jock Dieslag",
      "screen_name" : "Joccck",
      "protected" : false,
      "id_str" : "94173309",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/582541186/tw_normal.png",
      "id" : 94173309,
      "verified" : false
    }
  },
  "id" : 284333702794866688,
  "created_at" : "Thu Dec 27 16:23:32 +0000 2012",
  "user" : {
    "name" : "Felix",
    "screen_name" : "nicidienase",
    "protected" : false,
    "id_str" : "22396883",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3125784966/8223a4c5c9535be22d15c82ec829c2df_normal.jpeg",
    "id" : 22396883,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "29c3",
      "indices" : [ 105, 110 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "284306882112413696",
  "text" : "TEPPICHBODEN! AUF DEM CONGRESS! WIE SOLLEN DA DIE UMFALLENDEN MATE-FLASCHEN IRGEND EIN GER\u00C4USCH MACHEN?? #29c3",
  "id" : 284306882112413696,
  "created_at" : "Thu Dec 27 14:36:57 +0000 2012",
  "user" : {
    "name" : "Felix",
    "screen_name" : "nicidienase",
    "protected" : false,
    "id_str" : "22396883",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3125784966/8223a4c5c9535be22d15c82ec829c2df_normal.jpeg",
    "id" : 22396883,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "29c3",
      "indices" : [ 21, 26 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "284264453451694080",
  "text" : "Fuck ist Saal1 gro\u00DF. #29c3",
  "id" : 284264453451694080,
  "created_at" : "Thu Dec 27 11:48:21 +0000 2012",
  "user" : {
    "name" : "Felix",
    "screen_name" : "nicidienase",
    "protected" : false,
    "id_str" : "22396883",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3125784966/8223a4c5c9535be22d15c82ec829c2df_normal.jpeg",
    "id" : 22396883,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "*andy",
      "screen_name" : "derGeruhn",
      "indices" : [ 0, 10 ],
      "id_str" : "936437276",
      "id" : 936437276
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "284258932980084736",
  "geo" : {
  },
  "id_str" : "284260250461302785",
  "in_reply_to_user_id" : 936437276,
  "text" : "@derGeruhn seid ihr alle im Talk? Wo is den unser Tisch?",
  "id" : 284260250461302785,
  "in_reply_to_status_id" : 284258932980084736,
  "created_at" : "Thu Dec 27 11:31:39 +0000 2012",
  "in_reply_to_screen_name" : "derGeruhn",
  "in_reply_to_user_id_str" : "936437276",
  "user" : {
    "name" : "Felix",
    "screen_name" : "nicidienase",
    "protected" : false,
    "id_str" : "22396883",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3125784966/8223a4c5c9535be22d15c82ec829c2df_normal.jpeg",
    "id" : 22396883,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "*andy",
      "screen_name" : "derGeruhn",
      "indices" : [ 0, 10 ],
      "id_str" : "936437276",
      "id" : 936437276
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "284258932980084736",
  "geo" : {
  },
  "id_str" : "284259066723840000",
  "in_reply_to_user_id" : 936437276,
  "text" : "@derGeruhn zum assembly",
  "id" : 284259066723840000,
  "in_reply_to_status_id" : 284258932980084736,
  "created_at" : "Thu Dec 27 11:26:57 +0000 2012",
  "in_reply_to_screen_name" : "derGeruhn",
  "in_reply_to_user_id_str" : "936437276",
  "user" : {
    "name" : "Felix",
    "screen_name" : "nicidienase",
    "protected" : false,
    "id_str" : "22396883",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3125784966/8223a4c5c9535be22d15c82ec829c2df_normal.jpeg",
    "id" : 22396883,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "*andy",
      "screen_name" : "derGeruhn",
      "indices" : [ 0, 10 ],
      "id_str" : "936437276",
      "id" : 936437276
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "284258288927924224",
  "in_reply_to_user_id" : 936437276,
  "text" : "@derGeruhn schick mal jemanden der uns abholt. Wir sind gleich am Ende der Schlange.",
  "id" : 284258288927924224,
  "created_at" : "Thu Dec 27 11:23:52 +0000 2012",
  "in_reply_to_screen_name" : "derGeruhn",
  "in_reply_to_user_id_str" : "936437276",
  "user" : {
    "name" : "Felix",
    "screen_name" : "nicidienase",
    "protected" : false,
    "id_str" : "22396883",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3125784966/8223a4c5c9535be22d15c82ec829c2df_normal.jpeg",
    "id" : 22396883,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "29c3",
      "indices" : [ 51, 56 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "284249915117432833",
  "text" : "Gibts schon ein Foursquare-Venue f\u00FCr die Schlange? #29c3",
  "id" : 284249915117432833,
  "created_at" : "Thu Dec 27 10:50:35 +0000 2012",
  "user" : {
    "name" : "Felix",
    "screen_name" : "nicidienase",
    "protected" : false,
    "id_str" : "22396883",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3125784966/8223a4c5c9535be22d15c82ec829c2df_normal.jpeg",
    "id" : 22396883,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http://twitter.com/nicidienase/status/284249124633726976/photo/1",
      "indices" : [ 38, 58 ],
      "url" : "http://t.co/KvbR1rN4",
      "media_url" : "http://pbs.twimg.com/media/A_HbEqXCUAAXPx1.jpg",
      "id_str" : "284249124637921280",
      "id" : 284249124637921280,
      "media_url_https" : "https://pbs.twimg.com/media/A_HbEqXCUAAXPx1.jpg",
      "sizes" : [ {
        "h" : 296,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 608,
        "resize" : "fit",
        "w" : 1232
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 505,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 168,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com/KvbR1rN4"
    } ],
    "hashtags" : [ {
      "text" : "29c3",
      "indices" : [ 32, 37 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "284249124633726976",
  "text" : "Die Schlange wird nicht k\u00FCrzer. #29c3 http://t.co/KvbR1rN4",
  "id" : 284249124633726976,
  "created_at" : "Thu Dec 27 10:47:27 +0000 2012",
  "user" : {
    "name" : "Felix",
    "screen_name" : "nicidienase",
    "protected" : false,
    "id_str" : "22396883",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3125784966/8223a4c5c9535be22d15c82ec829c2df_normal.jpeg",
    "id" : 22396883,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "memo",
      "screen_name" : "memo42",
      "indices" : [ 0, 7 ],
      "id_str" : "55311456",
      "id" : 55311456
    }, {
      "name" : "*andy",
      "screen_name" : "derGeruhn",
      "indices" : [ 8, 18 ],
      "id_str" : "936437276",
      "id" : 936437276
    }, {
      "name" : "WarFrog",
      "screen_name" : "WarFrog123",
      "indices" : [ 19, 30 ],
      "id_str" : "604042793",
      "id" : 604042793
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "284197702479253505",
  "in_reply_to_user_id" : 55311456,
  "text" : "@memo42 @derGeruhn @WarFrog123 Steht unser Assemby eigentlich schon?",
  "id" : 284197702479253505,
  "created_at" : "Thu Dec 27 07:23:07 +0000 2012",
  "in_reply_to_screen_name" : "memo42",
  "in_reply_to_user_id_str" : "55311456",
  "user" : {
    "name" : "Felix",
    "screen_name" : "nicidienase",
    "protected" : false,
    "id_str" : "22396883",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3125784966/8223a4c5c9535be22d15c82ec829c2df_normal.jpeg",
    "id" : 22396883,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "psy",
      "screen_name" : "psycon",
      "indices" : [ 0, 7 ],
      "id_str" : "87286054",
      "id" : 87286054
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "284177210825400320",
  "geo" : {
  },
  "id_str" : "284177798833262592",
  "in_reply_to_user_id" : 87286054,
  "text" : "@psycon wagen 12 platz 23, direkt neben euch ... Bene is auch da.",
  "id" : 284177798833262592,
  "in_reply_to_status_id" : 284177210825400320,
  "created_at" : "Thu Dec 27 06:04:01 +0000 2012",
  "in_reply_to_screen_name" : "psycon",
  "in_reply_to_user_id_str" : "87286054",
  "user" : {
    "name" : "Felix",
    "screen_name" : "nicidienase",
    "protected" : false,
    "id_str" : "22396883",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3125784966/8223a4c5c9535be22d15c82ec829c2df_normal.jpeg",
    "id" : 22396883,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "$(RandomName)",
      "screen_name" : "Ik4ru5",
      "indices" : [ 0, 7 ],
      "id_str" : "48294441",
      "id" : 48294441
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "284177003492564992",
  "in_reply_to_user_id" : 48294441,
  "text" : "@Ik4ru5 warum hast du eigentlich im Ruhebereich reserviert wo es kein WLAN gibt?",
  "id" : 284177003492564992,
  "created_at" : "Thu Dec 27 06:00:52 +0000 2012",
  "in_reply_to_screen_name" : "Ik4ru5",
  "in_reply_to_user_id_str" : "48294441",
  "user" : {
    "name" : "Felix",
    "screen_name" : "nicidienase",
    "protected" : false,
    "id_str" : "22396883",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3125784966/8223a4c5c9535be22d15c82ec829c2df_normal.jpeg",
    "id" : 22396883,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "29c3",
      "indices" : [ 51, 56 ]
    }, {
      "text" : "dbl",
      "indices" : [ 70, 74 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "284170366891462657",
  "text" : "ICE670 steht in KA bereit, Abfahrt in knapp 20min. #29c3 Here we come #dbl",
  "id" : 284170366891462657,
  "created_at" : "Thu Dec 27 05:34:29 +0000 2012",
  "user" : {
    "name" : "Felix",
    "screen_name" : "nicidienase",
    "protected" : false,
    "id_str" : "22396883",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3125784966/8223a4c5c9535be22d15c82ec829c2df_normal.jpeg",
    "id" : 22396883,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "29c3",
      "indices" : [ 66, 71 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "284068038163181568",
  "text" : "Damn it. Wenn ich meine Timeline lese will ich auch schon auf dem #29c3 sein. N\u00E4chstes Mal muss ich sp\u00E4testens an Day 0 anreisen.",
  "id" : 284068038163181568,
  "created_at" : "Wed Dec 26 22:47:52 +0000 2012",
  "user" : {
    "name" : "Felix",
    "screen_name" : "nicidienase",
    "protected" : false,
    "id_str" : "22396883",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3125784966/8223a4c5c9535be22d15c82ec829c2df_normal.jpeg",
    "id" : 22396883,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Fred",
      "screen_name" : "waith",
      "indices" : [ 3, 9 ],
      "id_str" : "23775030",
      "id" : 23775030
    }, {
      "name" : "Ten Forward",
      "screen_name" : "29c3TenForward",
      "indices" : [ 26, 41 ],
      "id_str" : "1000739786",
      "id" : 1000739786
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "29c3",
      "indices" : [ 70, 75 ]
    } ],
    "urls" : [ {
      "indices" : [ 76, 96 ],
      "url" : "http://t.co/Io0NMska",
      "expanded_url" : "http://twitpic.com/bphlr7",
      "display_url" : "twitpic.com/bphlr7"
    }, {
      "indices" : [ 97, 117 ],
      "url" : "http://t.co/S9O2Vpsx",
      "expanded_url" : "http://twitpic.com/bphm9a",
      "display_url" : "twitpic.com/bphm9a"
    }, {
      "indices" : [ 119, 139 ],
      "url" : "http://t.co/QvNzUfcs",
      "expanded_url" : "http://twitpic.com/bphmb7",
      "display_url" : "twitpic.com/bphmb7"
    } ]
  },
  "geo" : {
  },
  "id_str" : "284065660433219584",
  "text" : "RT @waith: Ich glaube das @29c3TenForward wird mein Lieblingsort beim #29c3 http://t.co/Io0NMska http://t.co/S9O2Vpsx  http://t.co/QvNzUfcs",
  "retweeted_status" : {
    "source" : "web",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Ten Forward",
        "screen_name" : "29c3TenForward",
        "indices" : [ 15, 30 ],
        "id_str" : "1000739786",
        "id" : 1000739786
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "29c3",
        "indices" : [ 59, 64 ]
      } ],
      "urls" : [ {
        "indices" : [ 65, 85 ],
        "url" : "http://t.co/Io0NMska",
        "expanded_url" : "http://twitpic.com/bphlr7",
        "display_url" : "twitpic.com/bphlr7"
      }, {
        "indices" : [ 86, 106 ],
        "url" : "http://t.co/S9O2Vpsx",
        "expanded_url" : "http://twitpic.com/bphm9a",
        "display_url" : "twitpic.com/bphm9a"
      }, {
        "indices" : [ 108, 128 ],
        "url" : "http://t.co/QvNzUfcs",
        "expanded_url" : "http://twitpic.com/bphmb7",
        "display_url" : "twitpic.com/bphmb7"
      } ]
    },
    "geo" : {
    },
    "id_str" : "283862565031915520",
    "text" : "Ich glaube das @29c3TenForward wird mein Lieblingsort beim #29c3 http://t.co/Io0NMska http://t.co/S9O2Vpsx  http://t.co/QvNzUfcs",
    "id" : 283862565031915520,
    "created_at" : "Wed Dec 26 09:11:24 +0000 2012",
    "user" : {
      "name" : "Fred",
      "screen_name" : "waith",
      "protected" : false,
      "id_str" : "23775030",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/2551137089/profile_normal.png",
      "id" : 23775030,
      "verified" : false
    }
  },
  "id" : 284065660433219584,
  "created_at" : "Wed Dec 26 22:38:25 +0000 2012",
  "user" : {
    "name" : "Felix",
    "screen_name" : "nicidienase",
    "protected" : false,
    "id_str" : "22396883",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3125784966/8223a4c5c9535be22d15c82ec829c2df_normal.jpeg",
    "id" : 22396883,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "neingeist",
      "screen_name" : "neingeist",
      "indices" : [ 3, 13 ],
      "id_str" : "11193712",
      "id" : 11193712
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "29c3",
      "indices" : [ 38, 43 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "283960520346828800",
  "text" : "RT @neingeist: Don't f0rget ur R0ket! #29c3",
  "retweeted_status" : {
    "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "29c3",
        "indices" : [ 23, 28 ]
      } ],
      "urls" : [ ]
    },
    "geo" : {
    },
    "id_str" : "283945588293255168",
    "text" : "Don't f0rget ur R0ket! #29c3",
    "id" : 283945588293255168,
    "created_at" : "Wed Dec 26 14:41:18 +0000 2012",
    "user" : {
      "name" : "neingeist",
      "screen_name" : "neingeist",
      "protected" : false,
      "id_str" : "11193712",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/3506751329/a8c317b7b69ff0f8eef00b9cb842cbc0_normal.png",
      "id" : 11193712,
      "verified" : false
    }
  },
  "id" : 283960520346828800,
  "created_at" : "Wed Dec 26 15:40:38 +0000 2012",
  "user" : {
    "name" : "Felix",
    "screen_name" : "nicidienase",
    "protected" : false,
    "id_str" : "22396883",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3125784966/8223a4c5c9535be22d15c82ec829c2df_normal.jpeg",
    "id" : 22396883,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Michael Seemann",
      "screen_name" : "mspro",
      "indices" : [ 3, 9 ],
      "id_str" : "5751892",
      "id" : 5751892
    }, {
      "name" : "fukami",
      "screen_name" : "fukami",
      "indices" : [ 25, 32 ],
      "id_str" : "1209301",
      "id" : 1209301
    } ],
    "media" : [ {
      "expanded_url" : "http://twitter.com/fukami/status/283686458378842112/photo/1",
      "indices" : [ 49, 69 ],
      "url" : "http://t.co/pzNB3plV",
      "media_url" : "http://pbs.twimg.com/media/A-_bVLOCcAAKb-0.jpg",
      "id_str" : "283686458383036416",
      "id" : 283686458383036416,
      "media_url_https" : "https://pbs.twimg.com/media/A-_bVLOCcAAKb-0.jpg",
      "sizes" : [ {
        "h" : 450,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 255,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 720,
        "resize" : "fit",
        "w" : 960
      }, {
        "h" : 720,
        "resize" : "fit",
        "w" : 960
      } ],
      "display_url" : "pic.twitter.com/pzNB3plV"
    } ],
    "hashtags" : [ {
      "text" : "29C3",
      "indices" : [ 34, 39 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "283707287418310657",
  "text" : "RT @mspro: fuck yeah! RT @fukami: #29C3 B\u00E4llebad http://t.co/pzNB3plV",
  "retweeted_status" : {
    "source" : "<a href=\"http://itunes.apple.com/us/app/twitter/id409789998?mt=12\" rel=\"nofollow\">Twitter for Mac</a>",
    "entities" : {
      "user_mentions" : [ {
        "name" : "fukami",
        "screen_name" : "fukami",
        "indices" : [ 14, 21 ],
        "id_str" : "1209301",
        "id" : 1209301
      } ],
      "media" : [ {
        "expanded_url" : "http://twitter.com/fukami/status/283686458378842112/photo/1",
        "indices" : [ 38, 58 ],
        "url" : "http://t.co/pzNB3plV",
        "media_url" : "http://pbs.twimg.com/media/A-_bVLOCcAAKb-0.jpg",
        "id_str" : "283686458383036416",
        "id" : 283686458383036416,
        "media_url_https" : "https://pbs.twimg.com/media/A-_bVLOCcAAKb-0.jpg",
        "sizes" : [ {
          "h" : 450,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 255,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 720,
          "resize" : "fit",
          "w" : 960
        }, {
          "h" : 720,
          "resize" : "fit",
          "w" : 960
        } ],
        "display_url" : "pic.twitter.com/pzNB3plV"
      } ],
      "hashtags" : [ {
        "text" : "29C3",
        "indices" : [ 23, 28 ]
      } ],
      "urls" : [ ]
    },
    "geo" : {
    },
    "id_str" : "283687068524232704",
    "text" : "fuck yeah! RT @fukami: #29C3 B\u00E4llebad http://t.co/pzNB3plV",
    "id" : 283687068524232704,
    "created_at" : "Tue Dec 25 21:34:02 +0000 2012",
    "user" : {
      "name" : "Michael Seemann",
      "screen_name" : "mspro",
      "protected" : false,
      "id_str" : "5751892",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/3408641243/2edf38d3c995612edf5b3d2e20d74861_normal.jpeg",
      "id" : 5751892,
      "verified" : false
    }
  },
  "id" : 283707287418310657,
  "created_at" : "Tue Dec 25 22:54:23 +0000 2012",
  "user" : {
    "name" : "Felix",
    "screen_name" : "nicidienase",
    "protected" : false,
    "id_str" : "22396883",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3125784966/8223a4c5c9535be22d15c82ec829c2df_normal.jpeg",
    "id" : 22396883,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "acid\u0FC8 \u1515\u1548\u1587\u1571\u15EF\u1602 \u1515\u1573\u157C\u15DD\u1602\u1571\u1587",
      "screen_name" : "acid23",
      "indices" : [ 3, 10 ],
      "id_str" : "35535998",
      "id" : 35535998
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "283227940412592128",
  "text" : "RT @acid23: RT $private: Deutschland h\u00E4tte Maria und Josef abgeschoben. Fr\u00F6hliche Weihnachten.",
  "retweeted_status" : {
    "source" : "<a href=\"http://identi.ca\" rel=\"nofollow\">identica</a>",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : {
    },
    "id_str" : "283180758397485056",
    "text" : "RT $private: Deutschland h\u00E4tte Maria und Josef abgeschoben. Fr\u00F6hliche Weihnachten.",
    "id" : 283180758397485056,
    "created_at" : "Mon Dec 24 12:02:08 +0000 2012",
    "user" : {
      "name" : "acid\u0FC8 \u1515\u1548\u1587\u1571\u15EF\u1602 \u1515\u1573\u157C\u15DD\u1602\u1571\u1587",
      "screen_name" : "acid23",
      "protected" : false,
      "id_str" : "35535998",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/3375172075/0c072a6c7bfd5a80819a6e0f4350b4ca_normal.jpeg",
      "id" : 35535998,
      "verified" : false
    }
  },
  "id" : 283227940412592128,
  "created_at" : "Mon Dec 24 15:09:37 +0000 2012",
  "user" : {
    "name" : "Felix",
    "screen_name" : "nicidienase",
    "protected" : false,
    "id_str" : "22396883",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3125784966/8223a4c5c9535be22d15c82ec829c2df_normal.jpeg",
    "id" : 22396883,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "neingeist",
      "screen_name" : "neingeist",
      "indices" : [ 0, 10 ],
      "id_str" : "11193712",
      "id" : 11193712
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "282448722120540160",
  "geo" : {
  },
  "id_str" : "282494799481819137",
  "in_reply_to_user_id" : 11193712,
  "text" : "@neingeist Machen die so fr\u00FCh zu?",
  "id" : 282494799481819137,
  "in_reply_to_status_id" : 282448722120540160,
  "created_at" : "Sat Dec 22 14:36:23 +0000 2012",
  "in_reply_to_screen_name" : "neingeist",
  "in_reply_to_user_id_str" : "11193712",
  "user" : {
    "name" : "Felix",
    "screen_name" : "nicidienase",
    "protected" : false,
    "id_str" : "22396883",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3125784966/8223a4c5c9535be22d15c82ec829c2df_normal.jpeg",
    "id" : 22396883,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "andreasdotorg",
      "screen_name" : "andreasdotorg",
      "indices" : [ 3, 17 ],
      "id_str" : "14285735",
      "id" : 14285735
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "29c3",
      "indices" : [ 58, 63 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "282494434988412928",
  "text" : "RT @andreasdotorg: Ha, nur noch ein Weihnachten, dann ist #29c3!",
  "retweeted_status" : {
    "source" : "web",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "29c3",
        "indices" : [ 39, 44 ]
      } ],
      "urls" : [ ]
    },
    "geo" : {
    },
    "id_str" : "282440462630002689",
    "text" : "Ha, nur noch ein Weihnachten, dann ist #29c3!",
    "id" : 282440462630002689,
    "created_at" : "Sat Dec 22 11:00:28 +0000 2012",
    "user" : {
      "name" : "andreasdotorg",
      "screen_name" : "andreasdotorg",
      "protected" : false,
      "id_str" : "14285735",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/2857263613/87df849b9667509c53079d7bb7fd0b31_normal.jpeg",
      "id" : 14285735,
      "verified" : false
    }
  },
  "id" : 282494434988412928,
  "created_at" : "Sat Dec 22 14:34:56 +0000 2012",
  "user" : {
    "name" : "Felix",
    "screen_name" : "nicidienase",
    "protected" : false,
    "id_str" : "22396883",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3125784966/8223a4c5c9535be22d15c82ec829c2df_normal.jpeg",
    "id" : 22396883,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.echofon.com/\" rel=\"nofollow\">Echofon</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "whedonesque",
      "screen_name" : "whedonesque",
      "indices" : [ 3, 15 ],
      "id_str" : "13007812",
      "id" : 13007812
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "282111203852042240",
  "text" : "RT @whedonesque: Looks like Buffy saved us again",
  "retweeted_status" : {
    "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : {
    },
    "id_str" : "282081679642853377",
    "text" : "Looks like Buffy saved us again",
    "id" : 282081679642853377,
    "created_at" : "Fri Dec 21 11:14:47 +0000 2012",
    "user" : {
      "name" : "whedonesque",
      "screen_name" : "whedonesque",
      "protected" : false,
      "id_str" : "13007812",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/59693658/w_normal.jpg",
      "id" : 13007812,
      "verified" : false
    }
  },
  "id" : 282111203852042240,
  "created_at" : "Fri Dec 21 13:12:07 +0000 2012",
  "user" : {
    "name" : "Felix",
    "screen_name" : "nicidienase",
    "protected" : false,
    "id_str" : "22396883",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3125784966/8223a4c5c9535be22d15c82ec829c2df_normal.jpeg",
    "id" : 22396883,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Grant Imahara",
      "screen_name" : "grantimahara",
      "indices" : [ 3, 16 ],
      "id_str" : "28521141",
      "id" : 28521141
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "DoctorWho",
      "indices" : [ 55, 65 ]
    }, {
      "text" : "apocalypse",
      "indices" : [ 66, 77 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "282103615714373632",
  "text" : "RT @grantimahara: THE DOCTOR DID IT! HE SAVED US ALL!! #DoctorWho #apocalypse",
  "retweeted_status" : {
    "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "DoctorWho",
        "indices" : [ 37, 47 ]
      }, {
        "text" : "apocalypse",
        "indices" : [ 48, 59 ]
      } ],
      "urls" : [ ]
    },
    "geo" : {
    },
    "id_str" : "282049158574129152",
    "text" : "THE DOCTOR DID IT! HE SAVED US ALL!! #DoctorWho #apocalypse",
    "id" : 282049158574129152,
    "created_at" : "Fri Dec 21 09:05:34 +0000 2012",
    "user" : {
      "name" : "Grant Imahara",
      "screen_name" : "grantimahara",
      "protected" : false,
      "id_str" : "28521141",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/3003132229/53338ad2b848f7f59261f53901a391a6_normal.jpeg",
      "id" : 28521141,
      "verified" : true
    }
  },
  "id" : 282103615714373632,
  "created_at" : "Fri Dec 21 12:41:57 +0000 2012",
  "user" : {
    "name" : "Felix",
    "screen_name" : "nicidienase",
    "protected" : false,
    "id_str" : "22396883",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3125784966/8223a4c5c9535be22d15c82ec829c2df_normal.jpeg",
    "id" : 22396883,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Stephan Urbach",
      "screen_name" : "herrurbach",
      "indices" : [ 3, 14 ],
      "id_str" : "28090494",
      "id" : 28090494
    }, {
      "name" : "George Takei",
      "screen_name" : "GeorgeTakei",
      "indices" : [ 97, 109 ],
      "id_str" : "237845487",
      "id" : 237845487
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 110, 130 ],
      "url" : "http://t.co/dfq0nWYo",
      "expanded_url" : "http://www.youtube.com/watch?v=7WahBH9sANg",
      "display_url" : "youtube.com/watch?v=7WahBH\u2026"
    } ]
  },
  "geo" : {
  },
  "id_str" : "281908313548017664",
  "text" : "RT @herrurbach: The only person who can read 50 shades of grey in a sexy way is the one and only @GeorgeTakei http://t.co/dfq0nWYo",
  "retweeted_status" : {
    "source" : "<a href=\"http://tapbots.com/software/tweetbot/mac\" rel=\"nofollow\">Tweetbot for Mac</a>",
    "entities" : {
      "user_mentions" : [ {
        "name" : "George Takei",
        "screen_name" : "GeorgeTakei",
        "indices" : [ 81, 93 ],
        "id_str" : "237845487",
        "id" : 237845487
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 94, 114 ],
        "url" : "http://t.co/dfq0nWYo",
        "expanded_url" : "http://www.youtube.com/watch?v=7WahBH9sANg",
        "display_url" : "youtube.com/watch?v=7WahBH\u2026"
      } ]
    },
    "geo" : {
    },
    "id_str" : "281885648393236481",
    "text" : "The only person who can read 50 shades of grey in a sexy way is the one and only @GeorgeTakei http://t.co/dfq0nWYo",
    "id" : 281885648393236481,
    "created_at" : "Thu Dec 20 22:15:50 +0000 2012",
    "user" : {
      "name" : "Stephan Urbach",
      "screen_name" : "herrurbach",
      "protected" : false,
      "id_str" : "28090494",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/3423620193/d62adf8686b62848c30cbf3ef56989fd_normal.jpeg",
      "id" : 28090494,
      "verified" : false
    }
  },
  "id" : 281908313548017664,
  "created_at" : "Thu Dec 20 23:45:54 +0000 2012",
  "user" : {
    "name" : "Felix",
    "screen_name" : "nicidienase",
    "protected" : false,
    "id_str" : "22396883",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3125784966/8223a4c5c9535be22d15c82ec829c2df_normal.jpeg",
    "id" : 22396883,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "psy",
      "screen_name" : "psycon",
      "indices" : [ 0, 7 ],
      "id_str" : "87286054",
      "id" : 87286054
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "281864733215313921",
  "geo" : {
  },
  "id_str" : "281905031660314626",
  "in_reply_to_user_id" : 87286054,
  "text" : "@psycon Bleib da. In der FS is niemand mehr.",
  "id" : 281905031660314626,
  "in_reply_to_status_id" : 281864733215313921,
  "created_at" : "Thu Dec 20 23:32:51 +0000 2012",
  "in_reply_to_screen_name" : "psycon",
  "in_reply_to_user_id_str" : "87286054",
  "user" : {
    "name" : "Felix",
    "screen_name" : "nicidienase",
    "protected" : false,
    "id_str" : "22396883",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3125784966/8223a4c5c9535be22d15c82ec829c2df_normal.jpeg",
    "id" : 22396883,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "m.",
      "screen_name" : "ohaimareiki",
      "indices" : [ 3, 15 ],
      "id_str" : "14732096",
      "id" : 14732096
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "281904695969185792",
  "text" : "RT @ohaimareiki: und tumblr so: \"everyone\u2019s making apocalypse jokes like there\u2019s no tomorrow\".",
  "retweeted_status" : {
    "source" : "<a href=\"http://itunes.apple.com/us/app/twitter/id409789998?mt=12\" rel=\"nofollow\">Twitter for Mac</a>",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : {
    },
    "id_str" : "281862619147694080",
    "text" : "und tumblr so: \"everyone\u2019s making apocalypse jokes like there\u2019s no tomorrow\".",
    "id" : 281862619147694080,
    "created_at" : "Thu Dec 20 20:44:19 +0000 2012",
    "user" : {
      "name" : "m.",
      "screen_name" : "ohaimareiki",
      "protected" : false,
      "id_str" : "14732096",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/3100722026/475d6897ce8c06c7cd73742c8fae872f_normal.jpeg",
      "id" : 14732096,
      "verified" : false
    }
  },
  "id" : 281904695969185792,
  "created_at" : "Thu Dec 20 23:31:31 +0000 2012",
  "user" : {
    "name" : "Felix",
    "screen_name" : "nicidienase",
    "protected" : false,
    "id_str" : "22396883",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3125784966/8223a4c5c9535be22d15c82ec829c2df_normal.jpeg",
    "id" : 22396883,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "HAL 9000",
      "screen_name" : "HAL9000_",
      "indices" : [ 3, 12 ],
      "id_str" : "29038088",
      "id" : 29038088
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "281806759708987392",
  "text" : "RT @HAL9000_: It's December 21st in Australia and the world hasn't ended, this just proves a theory I've had for a while: Australia isn' ...",
  "retweeted_status" : {
    "source" : "web",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : {
    },
    "id_str" : "281774478449598464",
    "text" : "It's December 21st in Australia and the world hasn't ended, this just proves a theory I've had for a while: Australia isn't real",
    "id" : 281774478449598464,
    "created_at" : "Thu Dec 20 14:54:05 +0000 2012",
    "user" : {
      "name" : "HAL 9000",
      "screen_name" : "HAL9000_",
      "protected" : false,
      "id_str" : "29038088",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/1788506913/HAL-MC2_normal.png",
      "id" : 29038088,
      "verified" : false
    }
  },
  "id" : 281806759708987392,
  "created_at" : "Thu Dec 20 17:02:21 +0000 2012",
  "user" : {
    "name" : "Felix",
    "screen_name" : "nicidienase",
    "protected" : false,
    "id_str" : "22396883",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3125784966/8223a4c5c9535be22d15c82ec829c2df_normal.jpeg",
    "id" : 22396883,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "fukami",
      "screen_name" : "fukami",
      "indices" : [ 3, 10 ],
      "id_str" : "1209301",
      "id" : 1209301
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "29C3",
      "indices" : [ 100, 105 ]
    } ],
    "urls" : [ {
      "indices" : [ 106, 126 ],
      "url" : "http://t.co/rBk3QwNo",
      "expanded_url" : "http://twitter.com/fukami/status/281747024431439872/photo/1",
      "display_url" : "pic.twitter.com/rBk3QwNo"
    } ]
  },
  "geo" : {
  },
  "id_str" : "281756768483295232",
  "text" : "RT @fukami: Einer der Gr\u00FCnde, warum es mancherorts in Hamburg mit der Koffeinversorgung etwas h\u00E4ngt #29C3 http://t.co/rBk3QwNo",
  "retweeted_status" : {
    "source" : "<a href=\"http://www.apple.com\" rel=\"nofollow\">Camera on iOS</a>",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "http://twitter.com/fukami/status/281747024431439872/photo/1",
        "indices" : [ 94, 114 ],
        "url" : "http://t.co/rBk3QwNo",
        "media_url" : "http://pbs.twimg.com/media/A-j3bQyCYAAX5Y4.jpg",
        "id_str" : "281747024444022784",
        "id" : 281747024444022784,
        "media_url_https" : "https://pbs.twimg.com/media/A-j3bQyCYAAX5Y4.jpg",
        "sizes" : [ {
          "h" : 450,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 255,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 720,
          "resize" : "fit",
          "w" : 960
        }, {
          "h" : 720,
          "resize" : "fit",
          "w" : 960
        } ],
        "display_url" : "pic.twitter.com/rBk3QwNo"
      } ],
      "hashtags" : [ {
        "text" : "29C3",
        "indices" : [ 88, 93 ]
      } ],
      "urls" : [ ]
    },
    "geo" : {
      "type" : "Point",
      "coordinates" : [ 53.562032, 9.985839 ]
    },
    "id_str" : "281747024431439872",
    "text" : "Einer der Gr\u00FCnde, warum es mancherorts in Hamburg mit der Koffeinversorgung etwas h\u00E4ngt #29C3 http://t.co/rBk3QwNo",
    "id" : 281747024431439872,
    "created_at" : "Thu Dec 20 13:05:00 +0000 2012",
    "user" : {
      "name" : "fukami",
      "screen_name" : "fukami",
      "protected" : false,
      "id_str" : "1209301",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/772745887/fukami-twitter_normal.jpg",
      "id" : 1209301,
      "verified" : false
    }
  },
  "id" : 281756768483295232,
  "created_at" : "Thu Dec 20 13:43:43 +0000 2012",
  "user" : {
    "name" : "Felix",
    "screen_name" : "nicidienase",
    "protected" : false,
    "id_str" : "22396883",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3125784966/8223a4c5c9535be22d15c82ec829c2df_normal.jpeg",
    "id" : 22396883,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "neingeist",
      "screen_name" : "neingeist",
      "indices" : [ 0, 10 ],
      "id_str" : "11193712",
      "id" : 11193712
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "281754915188117507",
  "geo" : {
  },
  "id_str" : "281755759602184193",
  "in_reply_to_user_id" : 11193712,
  "text" : "@neingeist okay, fromHell is vielleicht \u00FCbertrieben. Aber wenn das \"hoffentlich\" nicht n\u00F6tig gewesen w\u00E4re, w\u00E4r sch\u00F6ner.",
  "id" : 281755759602184193,
  "in_reply_to_status_id" : 281754915188117507,
  "created_at" : "Thu Dec 20 13:39:42 +0000 2012",
  "in_reply_to_screen_name" : "neingeist",
  "in_reply_to_user_id_str" : "11193712",
  "user" : {
    "name" : "Felix",
    "screen_name" : "nicidienase",
    "protected" : false,
    "id_str" : "22396883",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3125784966/8223a4c5c9535be22d15c82ec829c2df_normal.jpeg",
    "id" : 22396883,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.echofon.com/\" rel=\"nofollow\">Echofon</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "CommitcommentsFromHell",
      "indices" : [ 30, 53 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "281754665073385472",
  "text" : "\"$Fehler hoffentlich behoben\" #CommitcommentsFromHell",
  "id" : 281754665073385472,
  "created_at" : "Thu Dec 20 13:35:21 +0000 2012",
  "user" : {
    "name" : "Felix",
    "screen_name" : "nicidienase",
    "protected" : false,
    "id_str" : "22396883",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3125784966/8223a4c5c9535be22d15c82ec829c2df_normal.jpeg",
    "id" : 22396883,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Matthias Schrade",
      "screen_name" : "kungler",
      "indices" : [ 3, 11 ],
      "id_str" : "36089543",
      "id" : 36089543
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "281725624299696128",
  "text" : "RT @kungler: +++EIL+++ Berliner atmen auf: Weltuntergang verschiebt sich auf Oktober 2014. Es gibt Probleme mit dem Brandschutz.",
  "retweeted_status" : {
    "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : {
    },
    "id_str" : "281706974196924416",
    "text" : "+++EIL+++ Berliner atmen auf: Weltuntergang verschiebt sich auf Oktober 2014. Es gibt Probleme mit dem Brandschutz.",
    "id" : 281706974196924416,
    "created_at" : "Thu Dec 20 10:25:51 +0000 2012",
    "user" : {
      "name" : "Matthias Schrade",
      "screen_name" : "kungler",
      "protected" : false,
      "id_str" : "36089543",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/3499567327/6793c3b1afdd528b33f8c36a12663240_normal.jpeg",
      "id" : 36089543,
      "verified" : false
    }
  },
  "id" : 281725624299696128,
  "created_at" : "Thu Dec 20 11:39:57 +0000 2012",
  "user" : {
    "name" : "Felix",
    "screen_name" : "nicidienase",
    "protected" : false,
    "id_str" : "22396883",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3125784966/8223a4c5c9535be22d15c82ec829c2df_normal.jpeg",
    "id" : 22396883,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "kamikaze.de",
      "screen_name" : "lonkamikaze",
      "indices" : [ 0, 12 ],
      "id_str" : "935331409",
      "id" : 935331409
    }, {
      "name" : "neingeist",
      "screen_name" : "neingeist",
      "indices" : [ 13, 23 ],
      "id_str" : "11193712",
      "id" : 11193712
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "281703193149308928",
  "geo" : {
  },
  "id_str" : "281703578647818241",
  "in_reply_to_user_id" : 935331409,
  "text" : "@lonkamikaze @neingeist feuerfest aus Asbest, dass niemand im Lavastrom ertrinkt?",
  "id" : 281703578647818241,
  "in_reply_to_status_id" : 281703193149308928,
  "created_at" : "Thu Dec 20 10:12:21 +0000 2012",
  "in_reply_to_screen_name" : "lonkamikaze",
  "in_reply_to_user_id_str" : "935331409",
  "user" : {
    "name" : "Felix",
    "screen_name" : "nicidienase",
    "protected" : false,
    "id_str" : "22396883",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3125784966/8223a4c5c9535be22d15c82ec829c2df_normal.jpeg",
    "id" : 22396883,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "neingeist",
      "screen_name" : "neingeist",
      "indices" : [ 0, 10 ],
      "id_str" : "11193712",
      "id" : 11193712
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "281691996626767873",
  "geo" : {
  },
  "id_str" : "281702042270056448",
  "in_reply_to_user_id" : 11193712,
  "text" : "@neingeist Nichts!",
  "id" : 281702042270056448,
  "in_reply_to_status_id" : 281691996626767873,
  "created_at" : "Thu Dec 20 10:06:15 +0000 2012",
  "in_reply_to_screen_name" : "neingeist",
  "in_reply_to_user_id_str" : "11193712",
  "user" : {
    "name" : "Felix",
    "screen_name" : "nicidienase",
    "protected" : false,
    "id_str" : "22396883",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3125784966/8223a4c5c9535be22d15c82ec829c2df_normal.jpeg",
    "id" : 22396883,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Alles Mist",
      "screen_name" : "alles_Mist",
      "indices" : [ 3, 14 ],
      "id_str" : "91072382",
      "id" : 91072382
    }, {
      "name" : "Ahoi Polloi",
      "screen_name" : "ahoi_polloi",
      "indices" : [ 16, 28 ],
      "id_str" : "218709143",
      "id" : 218709143
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "281557103942987776",
  "text" : "RT @alles_Mist: @ahoi_polloi Yo dawg, I heard you like Tannenbaum so I put a Tanenbaum under your Tannenbaum.",
  "retweeted_status" : {
    "source" : "web",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Ahoi Polloi",
        "screen_name" : "ahoi_polloi",
        "indices" : [ 0, 12 ],
        "id_str" : "218709143",
        "id" : 218709143
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "in_reply_to_status_id_str" : "281494421348966401",
    "geo" : {
    },
    "id_str" : "281495011126808576",
    "in_reply_to_user_id" : 218709143,
    "text" : "@ahoi_polloi Yo dawg, I heard you like Tannenbaum so I put a Tanenbaum under your Tannenbaum.",
    "id" : 281495011126808576,
    "in_reply_to_status_id" : 281494421348966401,
    "created_at" : "Wed Dec 19 20:23:35 +0000 2012",
    "in_reply_to_screen_name" : "ahoi_polloi",
    "in_reply_to_user_id_str" : "218709143",
    "user" : {
      "name" : "Alles Mist",
      "screen_name" : "alles_Mist",
      "protected" : false,
      "id_str" : "91072382",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/3418699983/f5ed6dacc395f0e79c0db058569a0ee3_normal.png",
      "id" : 91072382,
      "verified" : false
    }
  },
  "id" : 281557103942987776,
  "created_at" : "Thu Dec 20 00:30:19 +0000 2012",
  "user" : {
    "name" : "Felix",
    "screen_name" : "nicidienase",
    "protected" : false,
    "id_str" : "22396883",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3125784966/8223a4c5c9535be22d15c82ec829c2df_normal.jpeg",
    "id" : 22396883,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tim Pritlove",
      "screen_name" : "timpritlove",
      "indices" : [ 3, 15 ],
      "id_str" : "11268812",
      "id" : 11268812
    }, {
      "name" : "auphonic",
      "screen_name" : "auphonic",
      "indices" : [ 25, 34 ],
      "id_str" : "297423041",
      "id" : 297423041
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "281470897024544768",
  "text" : "RT @timpritlove: Schick: @auphonic hat rechtzeitig vor dem Weltuntergang den passenden Audiofilter daf\u00FCr freigeschaltet: http://t.co/3aJ ...",
  "retweeted_status" : {
    "source" : "<a href=\"http://www.echofon.com/\" rel=\"nofollow\">Echofon</a>",
    "entities" : {
      "user_mentions" : [ {
        "name" : "auphonic",
        "screen_name" : "auphonic",
        "indices" : [ 8, 17 ],
        "id_str" : "297423041",
        "id" : 297423041
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 104, 124 ],
        "url" : "http://t.co/3aJijLQ9",
        "expanded_url" : "http://meta.metaebene.me/media/tmp/bewohner-dieser-erde.m4a",
        "display_url" : "meta.metaebene.me/media/tmp/bewo\u2026"
      } ]
    },
    "geo" : {
    },
    "id_str" : "281467590931542016",
    "text" : "Schick: @auphonic hat rechtzeitig vor dem Weltuntergang den passenden Audiofilter daf\u00FCr freigeschaltet: http://t.co/3aJijLQ9",
    "id" : 281467590931542016,
    "created_at" : "Wed Dec 19 18:34:37 +0000 2012",
    "user" : {
      "name" : "Tim Pritlove",
      "screen_name" : "timpritlove",
      "protected" : false,
      "id_str" : "11268812",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/2332275606/Tim_Pritlove_2009_Avatar_512x512_normal.jpg",
      "id" : 11268812,
      "verified" : true
    }
  },
  "id" : 281470897024544768,
  "created_at" : "Wed Dec 19 18:47:45 +0000 2012",
  "user" : {
    "name" : "Felix",
    "screen_name" : "nicidienase",
    "protected" : false,
    "id_str" : "22396883",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3125784966/8223a4c5c9535be22d15c82ec829c2df_normal.jpeg",
    "id" : 22396883,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kim Dotcom",
      "screen_name" : "KimDotcom",
      "indices" : [ 3, 13 ],
      "id_str" : "611986351",
      "id" : 611986351
    }, {
      "name" : "MPAA",
      "screen_name" : "MPAA",
      "indices" : [ 105, 110 ],
      "id_str" : "289072583",
      "id" : 289072583
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "281030113829744640",
  "text" : "RT @KimDotcom: Remember \"You wouldn't steal a car\" from the MPAA anti-piracy commercial? Guess what, the @MPAA stole all my cars. http:/ ...",
  "retweeted_status" : {
    "source" : "web",
    "entities" : {
      "user_mentions" : [ {
        "name" : "MPAA",
        "screen_name" : "MPAA",
        "indices" : [ 90, 95 ],
        "id_str" : "289072583",
        "id" : 289072583
      } ],
      "media" : [ {
        "expanded_url" : "http://twitter.com/KimDotcom/status/279478477407793153/photo/1",
        "indices" : [ 115, 135 ],
        "url" : "http://t.co/WFnTcJEd",
        "media_url" : "http://pbs.twimg.com/media/A-DoMcjCMAA8rr9.jpg",
        "id_str" : "279478477416181760",
        "id" : 279478477416181760,
        "media_url_https" : "https://pbs.twimg.com/media/A-DoMcjCMAA8rr9.jpg",
        "sizes" : [ {
          "h" : 313,
          "resize" : "fit",
          "w" : 530
        }, {
          "h" : 313,
          "resize" : "fit",
          "w" : 530
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 313,
          "resize" : "fit",
          "w" : 530
        }, {
          "h" : 201,
          "resize" : "fit",
          "w" : 340
        } ],
        "display_url" : "pic.twitter.com/WFnTcJEd"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : {
    },
    "id_str" : "279478477407793153",
    "text" : "Remember \"You wouldn't steal a car\" from the MPAA anti-piracy commercial? Guess what, the @MPAA stole all my cars. http://t.co/WFnTcJEd",
    "id" : 279478477407793153,
    "created_at" : "Fri Dec 14 06:50:36 +0000 2012",
    "user" : {
      "name" : "Kim Dotcom",
      "screen_name" : "KimDotcom",
      "protected" : false,
      "id_str" : "611986351",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/2320423543/9qheijpvtu9g5dteqvvw_normal.jpeg",
      "id" : 611986351,
      "verified" : false
    }
  },
  "id" : 281030113829744640,
  "created_at" : "Tue Dec 18 13:36:15 +0000 2012",
  "user" : {
    "name" : "Felix",
    "screen_name" : "nicidienase",
    "protected" : false,
    "id_str" : "22396883",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3125784966/8223a4c5c9535be22d15c82ec829c2df_normal.jpeg",
    "id" : 22396883,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.echofon.com/\" rel=\"nofollow\">Echofon</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "281010070114938880",
  "text" : "Arrrg, Leute die Mails nur Betreff und leerem Body verschicken. Wie ich das hasse.",
  "id" : 281010070114938880,
  "created_at" : "Tue Dec 18 12:16:36 +0000 2012",
  "user" : {
    "name" : "Felix",
    "screen_name" : "nicidienase",
    "protected" : false,
    "id_str" : "22396883",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3125784966/8223a4c5c9535be22d15c82ec829c2df_normal.jpeg",
    "id" : 22396883,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.echofon.com/\" rel=\"nofollow\">Echofon</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "280698988666183681",
  "text" : "Nerviges Insekt macht nervige Ger\u00E4usche in der Deckenlampe. Ich dreh gleich durch. (\u256F\u00B0\u25A1\u00B0\uFF09\u256F\uFE35 \u253B\u2501\u253B",
  "id" : 280698988666183681,
  "created_at" : "Mon Dec 17 15:40:28 +0000 2012",
  "user" : {
    "name" : "Felix",
    "screen_name" : "nicidienase",
    "protected" : false,
    "id_str" : "22396883",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3125784966/8223a4c5c9535be22d15c82ec829c2df_normal.jpeg",
    "id" : 22396883,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "psy",
      "screen_name" : "psycon",
      "indices" : [ 0, 7 ],
      "id_str" : "87286054",
      "id" : 87286054
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "280656122543751168",
  "geo" : {
  },
  "id_str" : "280663293360746496",
  "in_reply_to_user_id" : 87286054,
  "text" : "@psycon Das funktioniert leider nicht bei allen Chefs ...",
  "id" : 280663293360746496,
  "in_reply_to_status_id" : 280656122543751168,
  "created_at" : "Mon Dec 17 13:18:38 +0000 2012",
  "in_reply_to_screen_name" : "psycon",
  "in_reply_to_user_id_str" : "87286054",
  "user" : {
    "name" : "Felix",
    "screen_name" : "nicidienase",
    "protected" : false,
    "id_str" : "22396883",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3125784966/8223a4c5c9535be22d15c82ec829c2df_normal.jpeg",
    "id" : 22396883,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "i42n",
      "screen_name" : "i42n",
      "indices" : [ 0, 5 ],
      "id_str" : "22298116",
      "id" : 22298116
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "280642816084951041",
  "geo" : {
  },
  "id_str" : "280652292674433024",
  "in_reply_to_user_id" : 22298116,
  "text" : "@i42n Seit Anfang des Jahres hat das IZ ja endlich mal einen kompetenten  Leiter in Vollzeit. Die Chancen auf Besserung stehen gut.",
  "id" : 280652292674433024,
  "in_reply_to_status_id" : 280642816084951041,
  "created_at" : "Mon Dec 17 12:34:55 +0000 2012",
  "in_reply_to_screen_name" : "i42n",
  "in_reply_to_user_id_str" : "22298116",
  "user" : {
    "name" : "Felix",
    "screen_name" : "nicidienase",
    "protected" : false,
    "id_str" : "22396883",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3125784966/8223a4c5c9535be22d15c82ec829c2df_normal.jpeg",
    "id" : 22396883,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u2661FF00FF\u2120\u300E\u2640o\u24B6\u2694\u26A1\u2622\u269B\u2623\u2620\u300F",
      "screen_name" : "FF00FFde",
      "indices" : [ 3, 12 ],
      "id_str" : "417538245",
      "id" : 417538245
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "280640415223398400",
  "text" : "RT @FF00FFde: Programmieren Sie immer so, als w\u00E4re der Typ, der den Code pflegen muss, ein gewaltbereiter Psychopath, der wei\u00DF, wo Sie w ...",
  "retweeted_status" : {
    "source" : "web",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : {
    },
    "id_str" : "280492483920670720",
    "text" : "Programmieren Sie immer so, als w\u00E4re der Typ, der den Code pflegen muss, ein gewaltbereiter Psychopath, der wei\u00DF, wo Sie wohnen.",
    "id" : 280492483920670720,
    "created_at" : "Mon Dec 17 01:59:54 +0000 2012",
    "user" : {
      "name" : "\u2661FF00FF\u2120\u300E\u2640o\u24B6\u2694\u26A1\u2622\u269B\u2623\u2620\u300F",
      "screen_name" : "FF00FFde",
      "protected" : false,
      "id_str" : "417538245",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/3503620315/cae7f877160817becb39e383fde7aa31_normal.jpeg",
      "id" : 417538245,
      "verified" : false
    }
  },
  "id" : 280640415223398400,
  "created_at" : "Mon Dec 17 11:47:43 +0000 2012",
  "user" : {
    "name" : "Felix",
    "screen_name" : "nicidienase",
    "protected" : false,
    "id_str" : "22396883",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3125784966/8223a4c5c9535be22d15c82ec829c2df_normal.jpeg",
    "id" : 22396883,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ashley Winkler",
      "screen_name" : "facella",
      "indices" : [ 0, 8 ],
      "id_str" : "37720367",
      "id" : 37720367
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "280597888734752768",
  "geo" : {
  },
  "id_str" : "280600791700615169",
  "in_reply_to_user_id" : 37720367,
  "text" : "@facella Zum Gl\u00FCck ist in 5 Tagen ja _alles_ vorbei.",
  "id" : 280600791700615169,
  "in_reply_to_status_id" : 280597888734752768,
  "created_at" : "Mon Dec 17 09:10:16 +0000 2012",
  "in_reply_to_screen_name" : "facella",
  "in_reply_to_user_id_str" : "37720367",
  "user" : {
    "name" : "Felix",
    "screen_name" : "nicidienase",
    "protected" : false,
    "id_str" : "22396883",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3125784966/8223a4c5c9535be22d15c82ec829c2df_normal.jpeg",
    "id" : 22396883,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Thomas",
      "screen_name" : "tcschulz1983",
      "indices" : [ 0, 13 ],
      "id_str" : "752722549",
      "id" : 752722549
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "280449381067550720",
  "geo" : {
  },
  "id_str" : "280464776893710337",
  "in_reply_to_user_id" : 752722549,
  "text" : "@tcschulz1983 Cool. Probier ich aus. Danke!",
  "id" : 280464776893710337,
  "in_reply_to_status_id" : 280449381067550720,
  "created_at" : "Mon Dec 17 00:09:48 +0000 2012",
  "in_reply_to_screen_name" : "tcschulz1983",
  "in_reply_to_user_id_str" : "752722549",
  "user" : {
    "name" : "Felix",
    "screen_name" : "nicidienase",
    "protected" : false,
    "id_str" : "22396883",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3125784966/8223a4c5c9535be22d15c82ec829c2df_normal.jpeg",
    "id" : 22396883,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tim Weber",
      "screen_name" : "scy",
      "indices" : [ 0, 4 ],
      "id_str" : "8308632",
      "id" : 8308632
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ingress",
      "indices" : [ 83, 91 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "280443727271563264",
  "geo" : {
  },
  "id_str" : "280445915553218561",
  "in_reply_to_user_id" : 8308632,
  "text" : "@scy Wen muss man kennen/mit wem muss man schlafen, dass man da ein Invite kriegt? #ingress",
  "id" : 280445915553218561,
  "in_reply_to_status_id" : 280443727271563264,
  "created_at" : "Sun Dec 16 22:54:51 +0000 2012",
  "in_reply_to_screen_name" : "scy",
  "in_reply_to_user_id_str" : "8308632",
  "user" : {
    "name" : "Felix",
    "screen_name" : "nicidienase",
    "protected" : false,
    "id_str" : "22396883",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3125784966/8223a4c5c9535be22d15c82ec829c2df_normal.jpeg",
    "id" : 22396883,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "psy",
      "screen_name" : "psycon",
      "indices" : [ 0, 7 ],
      "id_str" : "87286054",
      "id" : 87286054
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "280393389722202112",
  "geo" : {
  },
  "id_str" : "280412431258378244",
  "in_reply_to_user_id" : 87286054,
  "text" : "@psycon Hattest du keinen Lock auf das GPN-Pulli-Mutex?",
  "id" : 280412431258378244,
  "in_reply_to_status_id" : 280393389722202112,
  "created_at" : "Sun Dec 16 20:41:48 +0000 2012",
  "in_reply_to_screen_name" : "psycon",
  "in_reply_to_user_id_str" : "87286054",
  "user" : {
    "name" : "Felix",
    "screen_name" : "nicidienase",
    "protected" : false,
    "id_str" : "22396883",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3125784966/8223a4c5c9535be22d15c82ec829c2df_normal.jpeg",
    "id" : 22396883,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mark Reid",
      "screen_name" : "mdreid",
      "indices" : [ 0, 7 ],
      "id_str" : "14053240",
      "id" : 14053240
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "280269141942878208",
  "geo" : {
  },
  "id_str" : "280381779511214082",
  "in_reply_to_user_id" : 14053240,
  "text" : "@mdreid I get the US and Mexico, but I'm really surprised about Switzerland.",
  "id" : 280381779511214082,
  "in_reply_to_status_id" : 280269141942878208,
  "created_at" : "Sun Dec 16 18:40:00 +0000 2012",
  "in_reply_to_screen_name" : "mdreid",
  "in_reply_to_user_id_str" : "14053240",
  "user" : {
    "name" : "Felix",
    "screen_name" : "nicidienase",
    "protected" : false,
    "id_str" : "22396883",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3125784966/8223a4c5c9535be22d15c82ec829c2df_normal.jpeg",
    "id" : 22396883,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mark Reid",
      "screen_name" : "mdreid",
      "indices" : [ 3, 10 ],
      "id_str" : "14053240",
      "id" : 14053240
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "280381521876099072",
  "text" : "RT @mdreid: Out of curiosity, I grabbed gun death and gun ownership data for OECD countries from Wikipedia and ran it through R: https:/ ...",
  "retweeted_status" : {
    "source" : "web",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 117, 138 ],
        "url" : "https://t.co/hgsOeQzp",
        "expanded_url" : "https://dl.dropbox.com/u/38668/deaths-vs-guns.png",
        "display_url" : "dl.dropbox.com/u/38668/deaths\u2026"
      } ]
    },
    "geo" : {
    },
    "id_str" : "280269141942878208",
    "text" : "Out of curiosity, I grabbed gun death and gun ownership data for OECD countries from Wikipedia and ran it through R: https://t.co/hgsOeQzp",
    "id" : 280269141942878208,
    "created_at" : "Sun Dec 16 11:12:25 +0000 2012",
    "user" : {
      "name" : "Mark Reid",
      "screen_name" : "mdreid",
      "protected" : false,
      "id_str" : "14053240",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/80511651/me_coffee_normal.jpg",
      "id" : 14053240,
      "verified" : false
    }
  },
  "id" : 280381521876099072,
  "created_at" : "Sun Dec 16 18:38:58 +0000 2012",
  "user" : {
    "name" : "Felix",
    "screen_name" : "nicidienase",
    "protected" : false,
    "id_str" : "22396883",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3125784966/8223a4c5c9535be22d15c82ec829c2df_normal.jpeg",
    "id" : 22396883,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Andr Zerozero",
      "screen_name" : "andr00",
      "indices" : [ 3, 10 ],
      "id_str" : "6143152",
      "id" : 6143152
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "280377581038100480",
  "text" : "RT @andr00: Today's software engineering word is \"farpotshket.\" This is a Yiddish word meaning, \"broken, because someone tried to fix it.\"",
  "retweeted_status" : {
    "source" : "<a href=\"http://www.apparentsoft.com/socialite\" rel=\"nofollow\">Socialite.app</a>",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : {
    },
    "id_str" : "276731514958524416",
    "text" : "Today's software engineering word is \"farpotshket.\" This is a Yiddish word meaning, \"broken, because someone tried to fix it.\"",
    "id" : 276731514958524416,
    "created_at" : "Thu Dec 06 16:55:09 +0000 2012",
    "user" : {
      "name" : "Andr Zerozero",
      "screen_name" : "andr00",
      "protected" : false,
      "id_str" : "6143152",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/227992987/robodonut1_0002_normal.jpg",
      "id" : 6143152,
      "verified" : false
    }
  },
  "id" : 280377581038100480,
  "created_at" : "Sun Dec 16 18:23:19 +0000 2012",
  "user" : {
    "name" : "Felix",
    "screen_name" : "nicidienase",
    "protected" : false,
    "id_str" : "22396883",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3125784966/8223a4c5c9535be22d15c82ec829c2df_normal.jpeg",
    "id" : 22396883,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Birgit Schrowange",
      "screen_name" : "Schwutte",
      "indices" : [ 3, 12 ],
      "id_str" : "26826250",
      "id" : 26826250
    } ],
    "media" : [ {
      "expanded_url" : "http://twitter.com/Schwutte/status/280104333268381696/photo/1",
      "indices" : [ 14, 34 ],
      "url" : "http://t.co/1j6Fb5ak",
      "media_url" : "http://pbs.twimg.com/media/A-MhaDTCcAITCVg.jpg",
      "id_str" : "280104333272576002",
      "id" : 280104333272576002,
      "media_url_https" : "https://pbs.twimg.com/media/A-MhaDTCcAITCVg.jpg",
      "sizes" : [ {
        "h" : 318,
        "resize" : "fit",
        "w" : 720
      }, {
        "h" : 318,
        "resize" : "fit",
        "w" : 720
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 265,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com/1j6Fb5ak"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "280377106519711745",
  "text" : "RT @Schwutte: http://t.co/1j6Fb5ak",
  "retweeted_status" : {
    "source" : "<a href=\"http://tapbots.com/tweetbot\" rel=\"nofollow\">Tweetbot for iOS</a>",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "http://twitter.com/Schwutte/status/280104333268381696/photo/1",
        "indices" : [ 0, 20 ],
        "url" : "http://t.co/1j6Fb5ak",
        "media_url" : "http://pbs.twimg.com/media/A-MhaDTCcAITCVg.jpg",
        "id_str" : "280104333272576002",
        "id" : 280104333272576002,
        "media_url_https" : "https://pbs.twimg.com/media/A-MhaDTCcAITCVg.jpg",
        "sizes" : [ {
          "h" : 318,
          "resize" : "fit",
          "w" : 720
        }, {
          "h" : 318,
          "resize" : "fit",
          "w" : 720
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 265,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 150,
          "resize" : "fit",
          "w" : 340
        } ],
        "display_url" : "pic.twitter.com/1j6Fb5ak"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : {
    },
    "id_str" : "280104333268381696",
    "text" : "http://t.co/1j6Fb5ak",
    "id" : 280104333268381696,
    "created_at" : "Sun Dec 16 00:17:32 +0000 2012",
    "user" : {
      "name" : "Birgit Schrowange",
      "screen_name" : "Schwutte",
      "protected" : false,
      "id_str" : "26826250",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/3471830238/7de6a630e66bd388d2df570d1a27d7fc_normal.jpeg",
      "id" : 26826250,
      "verified" : false
    }
  },
  "id" : 280377106519711745,
  "created_at" : "Sun Dec 16 18:21:26 +0000 2012",
  "user" : {
    "name" : "Felix",
    "screen_name" : "nicidienase",
    "protected" : false,
    "id_str" : "22396883",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3125784966/8223a4c5c9535be22d15c82ec829c2df_normal.jpeg",
    "id" : 22396883,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ari",
      "screen_name" : "Ari42",
      "indices" : [ 0, 6 ],
      "id_str" : "53464921",
      "id" : 53464921
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "279958115070402561",
  "geo" : {
  },
  "id_str" : "279958452166594562",
  "in_reply_to_user_id" : 53464921,
  "text" : "@Ari42 Danke. Mir brummt schon der ganze Tag der Sch\u00E4del.",
  "id" : 279958452166594562,
  "in_reply_to_status_id" : 279958115070402561,
  "created_at" : "Sat Dec 15 14:37:51 +0000 2012",
  "in_reply_to_screen_name" : "Ari42",
  "in_reply_to_user_id_str" : "53464921",
  "user" : {
    "name" : "Felix",
    "screen_name" : "nicidienase",
    "protected" : false,
    "id_str" : "22396883",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3125784966/8223a4c5c9535be22d15c82ec829c2df_normal.jpeg",
    "id" : 22396883,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http://twitter.com/nicidienase/status/279945498754949120/photo/1",
      "indices" : [ 50, 70 ],
      "url" : "http://t.co/lmiWHIhz",
      "media_url" : "http://pbs.twimg.com/media/A-KQ8qoCIAEjXRQ.png",
      "id_str" : "279945498759143425",
      "id" : 279945498759143425,
      "media_url_https" : "https://pbs.twimg.com/media/A-KQ8qoCIAEjXRQ.png",
      "sizes" : [ {
        "h" : 800,
        "resize" : "fit",
        "w" : 480
      }, {
        "h" : 567,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 800,
        "resize" : "fit",
        "w" : 480
      }, {
        "h" : 800,
        "resize" : "fit",
        "w" : 480
      } ],
      "display_url" : "pic.twitter.com/lmiWHIhz"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "279945498754949120",
  "text" : "Wie zur H\u00F6lle kam den diese \u00DCbersetzung zustande? http://t.co/lmiWHIhz",
  "id" : 279945498754949120,
  "created_at" : "Sat Dec 15 13:46:22 +0000 2012",
  "user" : {
    "name" : "Felix",
    "screen_name" : "nicidienase",
    "protected" : false,
    "id_str" : "22396883",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3125784966/8223a4c5c9535be22d15c82ec829c2df_normal.jpeg",
    "id" : 22396883,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "kamikaze.de",
      "screen_name" : "lonkamikaze",
      "indices" : [ 0, 12 ],
      "id_str" : "935331409",
      "id" : 935331409
    }, {
      "name" : "Uwe Lancier",
      "screen_name" : "Ulan_ka",
      "indices" : [ 13, 21 ],
      "id_str" : "379173142",
      "id" : 379173142
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "279939072460468224",
  "geo" : {
  },
  "id_str" : "279939626746138624",
  "in_reply_to_user_id" : 935331409,
  "text" : "@lonkamikaze @Ulan_ka Kann nat\u00FCrlich sein das unser Anschluss extern nur ne v6 IP hat(te) uns kein ganzes Netz.",
  "id" : 279939626746138624,
  "in_reply_to_status_id" : 279939072460468224,
  "created_at" : "Sat Dec 15 13:23:02 +0000 2012",
  "in_reply_to_screen_name" : "lonkamikaze",
  "in_reply_to_user_id_str" : "935331409",
  "user" : {
    "name" : "Felix",
    "screen_name" : "nicidienase",
    "protected" : false,
    "id_str" : "22396883",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3125784966/8223a4c5c9535be22d15c82ec829c2df_normal.jpeg",
    "id" : 22396883,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "LaTeX",
      "indices" : [ 44, 50 ]
    }, {
      "text" : "Literaturverweis",
      "indices" : [ 56, 73 ]
    }, {
      "text" : "Beispiel",
      "indices" : [ 74, 83 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "279937200567762944",
  "text" : "\"P. Aas: 'Ich lebe von Toten' Geier-Verlag\" #LaTeX-Kurs #Literaturverweis #Beispiel",
  "id" : 279937200567762944,
  "created_at" : "Sat Dec 15 13:13:24 +0000 2012",
  "user" : {
    "name" : "Felix",
    "screen_name" : "nicidienase",
    "protected" : false,
    "id_str" : "22396883",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3125784966/8223a4c5c9535be22d15c82ec829c2df_normal.jpeg",
    "id" : 22396883,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "kamikaze.de",
      "screen_name" : "lonkamikaze",
      "indices" : [ 0, 12 ],
      "id_str" : "935331409",
      "id" : 935331409
    }, {
      "name" : "Uwe Lancier",
      "screen_name" : "Ulan_ka",
      "indices" : [ 13, 21 ],
      "id_str" : "379173142",
      "id" : 379173142
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "279932532915585024",
  "geo" : {
  },
  "id_str" : "279935505775333376",
  "in_reply_to_user_id" : 935331409,
  "text" : "@lonkamikaze @Ulan_ka Also ich hab vor net ganzen Weilen schon unseren Anschluss von extern \u00FCber IPv6 pingen k\u00F6nnen.",
  "id" : 279935505775333376,
  "in_reply_to_status_id" : 279932532915585024,
  "created_at" : "Sat Dec 15 13:06:40 +0000 2012",
  "in_reply_to_screen_name" : "lonkamikaze",
  "in_reply_to_user_id_str" : "935331409",
  "user" : {
    "name" : "Felix",
    "screen_name" : "nicidienase",
    "protected" : false,
    "id_str" : "22396883",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3125784966/8223a4c5c9535be22d15c82ec829c2df_normal.jpeg",
    "id" : 22396883,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "psy",
      "screen_name" : "psycon",
      "indices" : [ 0, 7 ],
      "id_str" : "87286054",
      "id" : 87286054
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "279749190983245824",
  "geo" : {
  },
  "id_str" : "279762487086313472",
  "in_reply_to_user_id" : 87286054,
  "text" : "@psycon *g*",
  "id" : 279762487086313472,
  "in_reply_to_status_id" : 279749190983245824,
  "created_at" : "Sat Dec 15 01:39:09 +0000 2012",
  "in_reply_to_screen_name" : "psycon",
  "in_reply_to_user_id_str" : "87286054",
  "user" : {
    "name" : "Felix",
    "screen_name" : "nicidienase",
    "protected" : false,
    "id_str" : "22396883",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3125784966/8223a4c5c9535be22d15c82ec829c2df_normal.jpeg",
    "id" : 22396883,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "WarFrog",
      "screen_name" : "WarFrog123",
      "indices" : [ 0, 11 ],
      "id_str" : "604042793",
      "id" : 604042793
    }, {
      "name" : "psy",
      "screen_name" : "psycon",
      "indices" : [ 12, 19 ],
      "id_str" : "87286054",
      "id" : 87286054
    }, {
      "name" : "$(RandomName)",
      "screen_name" : "Ik4ru5",
      "indices" : [ 20, 27 ],
      "id_str" : "48294441",
      "id" : 48294441
    }, {
      "name" : "Andy P.",
      "screen_name" : "keinGeruhn",
      "indices" : [ 28, 39 ],
      "id_str" : "20689932",
      "id" : 20689932
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "279714503912984579",
  "in_reply_to_user_id" : 604042793,
  "text" : "@WarFrog123 @psycon @Ik4ru5 @keinGeruhn Was geht noch auf der FS-Weihnachtsfeier?",
  "id" : 279714503912984579,
  "created_at" : "Fri Dec 14 22:28:29 +0000 2012",
  "in_reply_to_screen_name" : "WarFrog123",
  "in_reply_to_user_id_str" : "604042793",
  "user" : {
    "name" : "Felix",
    "screen_name" : "nicidienase",
    "protected" : false,
    "id_str" : "22396883",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3125784966/8223a4c5c9535be22d15c82ec829c2df_normal.jpeg",
    "id" : 22396883,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http://twitter.com/nicidienase/status/279630030420725760/photo/1",
      "indices" : [ 58, 78 ],
      "url" : "http://t.co/RnHO8VRk",
      "media_url" : "http://pbs.twimg.com/media/A-FyB_gCUAAYtqm.jpg",
      "id_str" : "279630030424920064",
      "id" : 279630030424920064,
      "media_url_https" : "https://pbs.twimg.com/media/A-FyB_gCUAAYtqm.jpg",
      "sizes" : [ {
        "h" : 1365,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 2560,
        "resize" : "fit",
        "w" : 1920
      }, {
        "h" : 453,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 800,
        "resize" : "fit",
        "w" : 600
      } ],
      "display_url" : "pic.twitter.com/RnHO8VRk"
    } ],
    "hashtags" : [ {
      "text" : "ZerlegteCat5KabelAlsBaumschmuck",
      "indices" : [ 25, 57 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "279630030420725760",
  "text" : "Fr\u00FCher war mehr Lametta! #ZerlegteCat5KabelAlsBaumschmuck http://t.co/RnHO8VRk",
  "id" : 279630030420725760,
  "created_at" : "Fri Dec 14 16:52:50 +0000 2012",
  "user" : {
    "name" : "Felix",
    "screen_name" : "nicidienase",
    "protected" : false,
    "id_str" : "22396883",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3125784966/8223a4c5c9535be22d15c82ec829c2df_normal.jpeg",
    "id" : 22396883,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mareike Peter",
      "screen_name" : "Carridwen",
      "indices" : [ 3, 13 ],
      "id_str" : "197468202",
      "id" : 197468202
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 101, 121 ],
      "url" : "http://t.co/hsWRb6Jv",
      "expanded_url" : "http://www.der-postillon.com/2012/12/auch-menschen-betroffen-regierung.html",
      "display_url" : "der-postillon.com/2012/12/auch-m\u2026"
    } ]
  },
  "geo" : {
  },
  "id_str" : "279581686285615105",
  "text" : "RT @Carridwen: Auch Menschen betroffen: Regierung verbietet versehentlich Sex mit ALLEN Wirbeltieren http://t.co/hsWRb6Jv",
  "retweeted_status" : {
    "source" : "<a href=\"http://itunes.apple.com/us/app/twitter/id409789998?mt=12\" rel=\"nofollow\">Twitter for Mac</a>",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 86, 106 ],
        "url" : "http://t.co/hsWRb6Jv",
        "expanded_url" : "http://www.der-postillon.com/2012/12/auch-menschen-betroffen-regierung.html",
        "display_url" : "der-postillon.com/2012/12/auch-m\u2026"
      } ]
    },
    "geo" : {
    },
    "id_str" : "279576874215161856",
    "text" : "Auch Menschen betroffen: Regierung verbietet versehentlich Sex mit ALLEN Wirbeltieren http://t.co/hsWRb6Jv",
    "id" : 279576874215161856,
    "created_at" : "Fri Dec 14 13:21:35 +0000 2012",
    "user" : {
      "name" : "Mareike Peter",
      "screen_name" : "Carridwen",
      "protected" : false,
      "id_str" : "197468202",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/3479952423/b84c010cbc99771461483adc385aab3f_normal.png",
      "id" : 197468202,
      "verified" : false
    }
  },
  "id" : 279581686285615105,
  "created_at" : "Fri Dec 14 13:40:43 +0000 2012",
  "user" : {
    "name" : "Felix",
    "screen_name" : "nicidienase",
    "protected" : false,
    "id_str" : "22396883",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3125784966/8223a4c5c9535be22d15c82ec829c2df_normal.jpeg",
    "id" : 22396883,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "psy",
      "screen_name" : "psycon",
      "indices" : [ 0, 7 ],
      "id_str" : "87286054",
      "id" : 87286054
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "279553579537268736",
  "geo" : {
  },
  "id_str" : "279564037757476864",
  "in_reply_to_user_id" : 87286054,
  "text" : "@psycon Wirf nicht so viele Karten durch die Gegend.",
  "id" : 279564037757476864,
  "in_reply_to_status_id" : 279553579537268736,
  "created_at" : "Fri Dec 14 12:30:35 +0000 2012",
  "in_reply_to_screen_name" : "psycon",
  "in_reply_to_user_id_str" : "87286054",
  "user" : {
    "name" : "Felix",
    "screen_name" : "nicidienase",
    "protected" : false,
    "id_str" : "22396883",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3125784966/8223a4c5c9535be22d15c82ec829c2df_normal.jpeg",
    "id" : 22396883,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 33, 54 ],
      "url" : "https://t.co/mR62KPi3",
      "expanded_url" : "https://fbcdn-sphotos-e-a.akamaihd.net/hphotos-ak-ash4/399261_10151203211799482_2047568051_n.jpg",
      "display_url" : "fbcdn-sphotos-e-a.akamaihd.net/hphotos-ak-ash\u2026"
    } ]
  },
  "geo" : {
  },
  "id_str" : "279543471335936002",
  "text" : "My little Pony - S-Bahn is Magic https://t.co/mR62KPi3",
  "id" : 279543471335936002,
  "created_at" : "Fri Dec 14 11:08:51 +0000 2012",
  "user" : {
    "name" : "Felix",
    "screen_name" : "nicidienase",
    "protected" : false,
    "id_str" : "22396883",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3125784966/8223a4c5c9535be22d15c82ec829c2df_normal.jpeg",
    "id" : 22396883,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http://twitter.com/roy/status/279224830413402112/photo/1",
      "indices" : [ 34, 54 ],
      "url" : "http://t.co/Qn0Z3hOP",
      "media_url" : "http://pbs.twimg.com/media/A-ABgP3CcAAC7ff.jpg",
      "id_str" : "279224830421790720",
      "id" : 279224830421790720,
      "media_url_https" : "https://pbs.twimg.com/media/A-ABgP3CcAAC7ff.jpg",
      "sizes" : [ {
        "h" : 600,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 960,
        "resize" : "fit",
        "w" : 960
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 960,
        "resize" : "fit",
        "w" : 960
      }, {
        "h" : 340,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com/Qn0Z3hOP"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "279542115824975873",
  "text" : "RT @J_Pingen: Google 1 - 0 Apple. http://t.co/Qn0Z3hOP",
  "retweeted_status" : {
    "source" : "web",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "http://twitter.com/roy/status/279224830413402112/photo/1",
        "indices" : [ 20, 40 ],
        "url" : "http://t.co/Qn0Z3hOP",
        "media_url" : "http://pbs.twimg.com/media/A-ABgP3CcAAC7ff.jpg",
        "id_str" : "279224830421790720",
        "id" : 279224830421790720,
        "media_url_https" : "https://pbs.twimg.com/media/A-ABgP3CcAAC7ff.jpg",
        "sizes" : [ {
          "h" : 600,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 960,
          "resize" : "fit",
          "w" : 960
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 960,
          "resize" : "fit",
          "w" : 960
        }, {
          "h" : 340,
          "resize" : "fit",
          "w" : 340
        } ],
        "display_url" : "pic.twitter.com/Qn0Z3hOP"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : {
    },
    "id_str" : "279287150938312705",
    "text" : "Google 1 - 0 Apple. http://t.co/Qn0Z3hOP",
    "id" : 279287150938312705,
    "created_at" : "Thu Dec 13 18:10:20 +0000 2012",
    "user" : {
      "name" : "Jelle Pingen",
      "screen_name" : "JellePingen",
      "protected" : false,
      "id_str" : "133751926",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/2963440974/a0eaf3d385bf0939516640832fb0e408_normal.jpeg",
      "id" : 133751926,
      "verified" : false
    }
  },
  "id" : 279542115824975873,
  "created_at" : "Fri Dec 14 11:03:28 +0000 2012",
  "user" : {
    "name" : "Felix",
    "screen_name" : "nicidienase",
    "protected" : false,
    "id_str" : "22396883",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3125784966/8223a4c5c9535be22d15c82ec829c2df_normal.jpeg",
    "id" : 22396883,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "$(RandomName)",
      "screen_name" : "Ik4ru5",
      "indices" : [ 0, 7 ],
      "id_str" : "48294441",
      "id" : 48294441
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "279518554234163200",
  "geo" : {
  },
  "id_str" : "279522039323299840",
  "in_reply_to_user_id" : 48294441,
  "text" : "@Ik4ru5 Fahrkarte umsonst? Den Schein musst  du aufheben.",
  "id" : 279522039323299840,
  "in_reply_to_status_id" : 279518554234163200,
  "created_at" : "Fri Dec 14 09:43:42 +0000 2012",
  "in_reply_to_screen_name" : "Ik4ru5",
  "in_reply_to_user_id_str" : "48294441",
  "user" : {
    "name" : "Felix",
    "screen_name" : "nicidienase",
    "protected" : false,
    "id_str" : "22396883",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3125784966/8223a4c5c9535be22d15c82ec829c2df_normal.jpeg",
    "id" : 22396883,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "hdz",
      "screen_name" : "hdznrrd",
      "indices" : [ 3, 11 ],
      "id_str" : "100255193",
      "id" : 100255193
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ern\u00FCchterung",
      "indices" : [ 110, 123 ]
    }, {
      "text" : "vergrault",
      "indices" : [ 124, 134 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "279514454306213890",
  "text" : "RT @hdznrrd: damals, als packstation noch erleicherung war.. nicht verkomplizierung und stadtweite paketsuche #ern\u00FCchterung #vergrault @ ...",
  "retweeted_status" : {
    "source" : "<a href=\"http://www.tweetdeck.com\" rel=\"nofollow\">TweetDeck</a>",
    "entities" : {
      "user_mentions" : [ {
        "name" : "DHL Paket",
        "screen_name" : "DHLPaket",
        "indices" : [ 122, 131 ],
        "id_str" : "42414621",
        "id" : 42414621
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "ern\u00FCchterung",
        "indices" : [ 97, 110 ]
      }, {
        "text" : "vergrault",
        "indices" : [ 111, 121 ]
      } ],
      "urls" : [ ]
    },
    "geo" : {
    },
    "id_str" : "279504665534664704",
    "text" : "damals, als packstation noch erleicherung war.. nicht verkomplizierung und stadtweite paketsuche #ern\u00FCchterung #vergrault @dhlpaket",
    "id" : 279504665534664704,
    "created_at" : "Fri Dec 14 08:34:39 +0000 2012",
    "user" : {
      "name" : "hdz",
      "screen_name" : "hdznrrd",
      "protected" : false,
      "id_str" : "100255193",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/1407871966/avatar_normal.jpg",
      "id" : 100255193,
      "verified" : false
    }
  },
  "id" : 279514454306213890,
  "created_at" : "Fri Dec 14 09:13:33 +0000 2012",
  "user" : {
    "name" : "Felix",
    "screen_name" : "nicidienase",
    "protected" : false,
    "id_str" : "22396883",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3125784966/8223a4c5c9535be22d15c82ec829c2df_normal.jpeg",
    "id" : 22396883,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "neingeist",
      "screen_name" : "neingeist",
      "indices" : [ 3, 13 ],
      "id_str" : "11193712",
      "id" : 11193712
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "279502784389341185",
  "text" : "RT @neingeist: Liebe Radfahrer! Es ist glatt.",
  "retweeted_status" : {
    "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : {
    },
    "id_str" : "279493054241583104",
    "text" : "Liebe Radfahrer! Es ist glatt.",
    "id" : 279493054241583104,
    "created_at" : "Fri Dec 14 07:48:31 +0000 2012",
    "user" : {
      "name" : "neingeist",
      "screen_name" : "neingeist",
      "protected" : false,
      "id_str" : "11193712",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/3506751329/a8c317b7b69ff0f8eef00b9cb842cbc0_normal.png",
      "id" : 11193712,
      "verified" : false
    }
  },
  "id" : 279502784389341185,
  "created_at" : "Fri Dec 14 08:27:11 +0000 2012",
  "user" : {
    "name" : "Felix",
    "screen_name" : "nicidienase",
    "protected" : false,
    "id_str" : "22396883",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3125784966/8223a4c5c9535be22d15c82ec829c2df_normal.jpeg",
    "id" : 22396883,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Florian",
      "screen_name" : "x3Florianx3",
      "indices" : [ 3, 15 ],
      "id_str" : "184203603",
      "id" : 184203603
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 23, 43 ],
      "url" : "http://t.co/AiokVxsB",
      "expanded_url" : "http://twitpic.com/blkw7t",
      "display_url" : "twitpic.com/blkw7t"
    } ]
  },
  "geo" : {
  },
  "id_str" : "279268414743248896",
  "text" : "RT @x3Florianx3: Hehe. http://t.co/AiokVxsB",
  "retweeted_status" : {
    "source" : "<a href=\"http://tapbots.com/tweetbot\" rel=\"nofollow\">Tweetbot for iOS</a>",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 6, 26 ],
        "url" : "http://t.co/AiokVxsB",
        "expanded_url" : "http://twitpic.com/blkw7t",
        "display_url" : "twitpic.com/blkw7t"
      } ]
    },
    "geo" : {
    },
    "id_str" : "279196306713489408",
    "text" : "Hehe. http://t.co/AiokVxsB",
    "id" : 279196306713489408,
    "created_at" : "Thu Dec 13 12:09:21 +0000 2012",
    "user" : {
      "name" : "Florian",
      "screen_name" : "x3Florianx3",
      "protected" : false,
      "id_str" : "184203603",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/3372085263/6f13668cd33fb42d92339531f1407a96_normal.jpeg",
      "id" : 184203603,
      "verified" : false
    }
  },
  "id" : 279268414743248896,
  "created_at" : "Thu Dec 13 16:55:53 +0000 2012",
  "user" : {
    "name" : "Felix",
    "screen_name" : "nicidienase",
    "protected" : false,
    "id_str" : "22396883",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3125784966/8223a4c5c9535be22d15c82ec829c2df_normal.jpeg",
    "id" : 22396883,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http://twitter.com/tariskalein/status/279153320508149761/photo/1",
      "indices" : [ 52, 72 ],
      "url" : "http://t.co/PDhpxmuS",
      "media_url" : "http://pbs.twimg.com/media/A9_Ad0sCUAApRur.jpg",
      "id_str" : "279153320512344064",
      "id" : 279153320512344064,
      "media_url_https" : "https://pbs.twimg.com/media/A9_Ad0sCUAApRur.jpg",
      "sizes" : [ {
        "h" : 107,
        "resize" : "fit",
        "w" : 500
      }, {
        "h" : 107,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 107,
        "resize" : "fit",
        "w" : 500
      }, {
        "h" : 107,
        "resize" : "fit",
        "w" : 500
      }, {
        "h" : 73,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com/PDhpxmuS"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "279205186919096320",
  "text" : "RT @tariskalein: What? Da bin ich ja erleichtert D: http://t.co/PDhpxmuS",
  "retweeted_status" : {
    "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "http://twitter.com/tschistka/status/279153320508149761/photo/1",
        "indices" : [ 35, 55 ],
        "url" : "http://t.co/PDhpxmuS",
        "media_url" : "http://pbs.twimg.com/media/A9_Ad0sCUAApRur.jpg",
        "id_str" : "279153320512344064",
        "id" : 279153320512344064,
        "media_url_https" : "https://pbs.twimg.com/media/A9_Ad0sCUAApRur.jpg",
        "sizes" : [ {
          "h" : 107,
          "resize" : "fit",
          "w" : 500
        }, {
          "h" : 107,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 107,
          "resize" : "fit",
          "w" : 500
        }, {
          "h" : 107,
          "resize" : "fit",
          "w" : 500
        }, {
          "h" : 73,
          "resize" : "fit",
          "w" : 340
        } ],
        "display_url" : "pic.twitter.com/PDhpxmuS"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : {
    },
    "id_str" : "279153320508149761",
    "text" : "What? Da bin ich ja erleichtert D: http://t.co/PDhpxmuS",
    "id" : 279153320508149761,
    "created_at" : "Thu Dec 13 09:18:33 +0000 2012",
    "user" : {
      "name" : "Weltraumpr\u00E4sidentin",
      "screen_name" : "tschistka",
      "protected" : false,
      "id_str" : "365378363",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/3480626152/888b5b5a59f679a4ab54043c6237f33f_normal.jpeg",
      "id" : 365378363,
      "verified" : false
    }
  },
  "id" : 279205186919096320,
  "created_at" : "Thu Dec 13 12:44:38 +0000 2012",
  "user" : {
    "name" : "Felix",
    "screen_name" : "nicidienase",
    "protected" : false,
    "id_str" : "22396883",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3125784966/8223a4c5c9535be22d15c82ec829c2df_normal.jpeg",
    "id" : 22396883,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Darth Vader",
      "screen_name" : "DepressedDarth",
      "indices" : [ 3, 18 ],
      "id_str" : "125122481",
      "id" : 125122481
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "MyFavoriteMovieQuote",
      "indices" : [ 20, 41 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "278646413020241920",
  "text" : "RT @DepressedDarth: #MyFavoriteMovieQuote No... I am your father.",
  "retweeted_status" : {
    "source" : "web",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "MyFavoriteMovieQuote",
        "indices" : [ 0, 21 ]
      } ],
      "urls" : [ ]
    },
    "geo" : {
    },
    "id_str" : "278601033670860800",
    "text" : "#MyFavoriteMovieQuote No... I am your father.",
    "id" : 278601033670860800,
    "created_at" : "Tue Dec 11 20:43:57 +0000 2012",
    "user" : {
      "name" : "Darth Vader",
      "screen_name" : "DepressedDarth",
      "protected" : false,
      "id_str" : "125122481",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/1125323984/darthvader_normal.jpg",
      "id" : 125122481,
      "verified" : false
    }
  },
  "id" : 278646413020241920,
  "created_at" : "Tue Dec 11 23:44:16 +0000 2012",
  "user" : {
    "name" : "Felix",
    "screen_name" : "nicidienase",
    "protected" : false,
    "id_str" : "22396883",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3125784966/8223a4c5c9535be22d15c82ec829c2df_normal.jpeg",
    "id" : 22396883,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "MyFavoriteMovieQuote",
      "indices" : [ 24, 45 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "278646255297630208",
  "text" : "\"I love you!\" \"I know.\" #MyFavoriteMovieQuote",
  "id" : 278646255297630208,
  "created_at" : "Tue Dec 11 23:43:38 +0000 2012",
  "user" : {
    "name" : "Felix",
    "screen_name" : "nicidienase",
    "protected" : false,
    "id_str" : "22396883",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3125784966/8223a4c5c9535be22d15c82ec829c2df_normal.jpeg",
    "id" : 22396883,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 32, 52 ],
      "url" : "http://t.co/9WwTfRXP",
      "expanded_url" : "http://erkin.github.com/ponysay/",
      "display_url" : "erkin.github.com/ponysay/"
    } ]
  },
  "geo" : {
  },
  "id_str" : "278625297606258688",
  "text" : "Mehr Ponys f\u00FCr die Commandline: http://t.co/9WwTfRXP AWESOME!!!",
  "id" : 278625297606258688,
  "created_at" : "Tue Dec 11 22:20:22 +0000 2012",
  "user" : {
    "name" : "Felix",
    "screen_name" : "nicidienase",
    "protected" : false,
    "id_str" : "22396883",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3125784966/8223a4c5c9535be22d15c82ec829c2df_normal.jpeg",
    "id" : 22396883,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "p\u00F6belm\u00F6bel",
      "screen_name" : "ZornEm",
      "indices" : [ 0, 7 ],
      "id_str" : "523189643",
      "id" : 523189643
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "278378769436246017",
  "geo" : {
  },
  "id_str" : "278431703696031744",
  "in_reply_to_user_id" : 523189643,
  "text" : "@ZornEm Da h\u00E4lt der Hogwards Express",
  "id" : 278431703696031744,
  "in_reply_to_status_id" : 278378769436246017,
  "created_at" : "Tue Dec 11 09:31:05 +0000 2012",
  "in_reply_to_screen_name" : "ZornEm",
  "in_reply_to_user_id_str" : "523189643",
  "user" : {
    "name" : "Felix",
    "screen_name" : "nicidienase",
    "protected" : false,
    "id_str" : "22396883",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3125784966/8223a4c5c9535be22d15c82ec829c2df_normal.jpeg",
    "id" : 22396883,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Not Safe For Work",
      "screen_name" : "me_nsfw",
      "indices" : [ 5, 13 ],
      "id_str" : "198895800",
      "id" : 198895800
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "278294137256673280",
  "text" : "ROFL @me_nsfw auf 45 auf noch schneller h\u00F6ren.",
  "id" : 278294137256673280,
  "created_at" : "Tue Dec 11 00:24:27 +0000 2012",
  "user" : {
    "name" : "Felix",
    "screen_name" : "nicidienase",
    "protected" : false,
    "id_str" : "22396883",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3125784966/8223a4c5c9535be22d15c82ec829c2df_normal.jpeg",
    "id" : 22396883,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "*andy",
      "screen_name" : "derGeruhn",
      "indices" : [ 0, 10 ],
      "id_str" : "936437276",
      "id" : 936437276
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "278288044229001216",
  "geo" : {
  },
  "id_str" : "278291559550697472",
  "in_reply_to_user_id" : 936437276,
  "text" : "@derGeruhn wenn das mit mehr als nur einer klappt kannst du zu \"Wetten Dass..?\" gehn.",
  "id" : 278291559550697472,
  "in_reply_to_status_id" : 278288044229001216,
  "created_at" : "Tue Dec 11 00:14:12 +0000 2012",
  "in_reply_to_screen_name" : "derGeruhn",
  "in_reply_to_user_id_str" : "936437276",
  "user" : {
    "name" : "Felix",
    "screen_name" : "nicidienase",
    "protected" : false,
    "id_str" : "22396883",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3125784966/8223a4c5c9535be22d15c82ec829c2df_normal.jpeg",
    "id" : 22396883,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "278288357799391232",
  "text" : "Arg. Den Typo entdecken und im gleichem Moment auf senden dr\u00FCcken.",
  "id" : 278288357799391232,
  "created_at" : "Tue Dec 11 00:01:29 +0000 2012",
  "user" : {
    "name" : "Felix",
    "screen_name" : "nicidienase",
    "protected" : false,
    "id_str" : "22396883",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3125784966/8223a4c5c9535be22d15c82ec829c2df_normal.jpeg",
    "id" : 22396883,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "psy",
      "screen_name" : "psycon",
      "indices" : [ 0, 7 ],
      "id_str" : "87286054",
      "id" : 87286054
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "278248090845212672",
  "geo" : {
  },
  "id_str" : "278287898527297536",
  "in_reply_to_user_id" : 87286054,
  "text" : "@psycon K\u00F6nnte ich auch mal ausprobieren. Kannst mir bei Gelegenheit ja mal erz\u00E4hlen was da so viel toller bis als screen.",
  "id" : 278287898527297536,
  "in_reply_to_status_id" : 278248090845212672,
  "created_at" : "Mon Dec 10 23:59:40 +0000 2012",
  "in_reply_to_screen_name" : "psycon",
  "in_reply_to_user_id_str" : "87286054",
  "user" : {
    "name" : "Felix",
    "screen_name" : "nicidienase",
    "protected" : false,
    "id_str" : "22396883",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3125784966/8223a4c5c9535be22d15c82ec829c2df_normal.jpeg",
    "id" : 22396883,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "psy",
      "screen_name" : "psycon",
      "indices" : [ 0, 7 ],
      "id_str" : "87286054",
      "id" : 87286054
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "278212740026351616",
  "geo" : {
  },
  "id_str" : "278214853594853376",
  "in_reply_to_user_id" : 87286054,
  "text" : "@psycon Jetzt erst? Den hatte ich schon am Samstag abend.",
  "id" : 278214853594853376,
  "in_reply_to_status_id" : 278212740026351616,
  "created_at" : "Mon Dec 10 19:09:24 +0000 2012",
  "in_reply_to_screen_name" : "psycon",
  "in_reply_to_user_id_str" : "87286054",
  "user" : {
    "name" : "Felix",
    "screen_name" : "nicidienase",
    "protected" : false,
    "id_str" : "22396883",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3125784966/8223a4c5c9535be22d15c82ec829c2df_normal.jpeg",
    "id" : 22396883,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Freak|kaerF",
      "screen_name" : "FreakkaerF",
      "indices" : [ 3, 14 ],
      "id_str" : "39258305",
      "id" : 39258305
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 59, 79 ],
      "url" : "http://t.co/k5uAEIki",
      "expanded_url" : "http://twitpic.com/bkmeup",
      "display_url" : "twitpic.com/bkmeup"
    } ]
  },
  "geo" : {
  },
  "id_str" : "278137736219729920",
  "text" : "RT @FreakkaerF: Oh, 197. Geburtstag von Ada Lovelace &lt;3 http://t.co/k5uAEIki",
  "retweeted_status" : {
    "source" : "<a href=\"http://sites.google.com/site/yorufukurou/\" rel=\"nofollow\">YoruFukurou</a>",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 43, 63 ],
        "url" : "http://t.co/k5uAEIki",
        "expanded_url" : "http://twitpic.com/bkmeup",
        "display_url" : "twitpic.com/bkmeup"
      } ]
    },
    "geo" : {
    },
    "id_str" : "277927308164227072",
    "text" : "Oh, 197. Geburtstag von Ada Lovelace &lt;3 http://t.co/k5uAEIki",
    "id" : 277927308164227072,
    "created_at" : "Mon Dec 10 00:06:48 +0000 2012",
    "user" : {
      "name" : "Freak|kaerF",
      "screen_name" : "FreakkaerF",
      "protected" : false,
      "id_str" : "39258305",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/3267528915/114caa206499d7f511144d62f97d3ec5_normal.png",
      "id" : 39258305,
      "verified" : false
    }
  },
  "id" : 278137736219729920,
  "created_at" : "Mon Dec 10 14:02:58 +0000 2012",
  "user" : {
    "name" : "Felix",
    "screen_name" : "nicidienase",
    "protected" : false,
    "id_str" : "22396883",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3125784966/8223a4c5c9535be22d15c82ec829c2df_normal.jpeg",
    "id" : 22396883,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "psy",
      "screen_name" : "psycon",
      "indices" : [ 0, 7 ],
      "id_str" : "87286054",
      "id" : 87286054
    }, {
      "name" : "Sturzelchen.",
      "screen_name" : "randsturz",
      "indices" : [ 8, 18 ],
      "id_str" : "73659102",
      "id" : 73659102
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "277883413288062976",
  "geo" : {
  },
  "id_str" : "277884270037577728",
  "in_reply_to_user_id" : 87286054,
  "text" : "@psycon @randsturz Der Spruch is doch Quatsch. Kannst genau so gut sagen: \"Wof\u00FCr brauchst du ein Bad? Duschen kannst du wenns regnet!\"",
  "id" : 277884270037577728,
  "in_reply_to_status_id" : 277883413288062976,
  "created_at" : "Sun Dec 09 21:15:47 +0000 2012",
  "in_reply_to_screen_name" : "psycon",
  "in_reply_to_user_id_str" : "87286054",
  "user" : {
    "name" : "Felix",
    "screen_name" : "nicidienase",
    "protected" : false,
    "id_str" : "22396883",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3125784966/8223a4c5c9535be22d15c82ec829c2df_normal.jpeg",
    "id" : 22396883,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://instagram.com\" rel=\"nofollow\">Instagram</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 14, 34 ],
      "url" : "http://t.co/2uulAXbN",
      "expanded_url" : "http://instagr.am/p/TBElVGl0XA/",
      "display_url" : "instagr.am/p/TBElVGl0XA/"
    } ]
  },
  "geo" : {
  },
  "id_str" : "277760372679790592",
  "text" : "Guten Morgen! http://t.co/2uulAXbN",
  "id" : 277760372679790592,
  "created_at" : "Sun Dec 09 13:03:28 +0000 2012",
  "user" : {
    "name" : "Felix",
    "screen_name" : "nicidienase",
    "protected" : false,
    "id_str" : "22396883",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3125784966/8223a4c5c9535be22d15c82ec829c2df_normal.jpeg",
    "id" : 22396883,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Henni",
      "screen_name" : "heeeeenni",
      "indices" : [ 3, 13 ],
      "id_str" : "61169351",
      "id" : 61169351
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "277749802794614784",
  "text" : "RT @heeeeenni: Alle so: \"Yeah, Weihnachten, Familie, Geschenke!\"\nIch so: \"Yeah, Weihnachten, neue Doctor Who Folge!\"",
  "retweeted_status" : {
    "source" : "web",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : {
    },
    "id_str" : "277718186101706752",
    "text" : "Alle so: \"Yeah, Weihnachten, Familie, Geschenke!\"\nIch so: \"Yeah, Weihnachten, neue Doctor Who Folge!\"",
    "id" : 277718186101706752,
    "created_at" : "Sun Dec 09 10:15:49 +0000 2012",
    "user" : {
      "name" : "Henni",
      "screen_name" : "heeeeenni",
      "protected" : false,
      "id_str" : "61169351",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/3422597951/ec7dc67fcc63dda9158642543b8a9c8d_normal.jpeg",
      "id" : 61169351,
      "verified" : false
    }
  },
  "id" : 277749802794614784,
  "created_at" : "Sun Dec 09 12:21:27 +0000 2012",
  "user" : {
    "name" : "Felix",
    "screen_name" : "nicidienase",
    "protected" : false,
    "id_str" : "22396883",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3125784966/8223a4c5c9535be22d15c82ec829c2df_normal.jpeg",
    "id" : 22396883,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "stoffeldear",
      "screen_name" : "stoffeldear",
      "indices" : [ 0, 12 ],
      "id_str" : "79704350",
      "id" : 79704350
    }, {
      "name" : "kamikaze.de",
      "screen_name" : "lonkamikaze",
      "indices" : [ 13, 25 ],
      "id_str" : "935331409",
      "id" : 935331409
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "277541586924093440",
  "geo" : {
  },
  "id_str" : "277545045220020224",
  "in_reply_to_user_id" : 79704350,
  "text" : "@stoffeldear @lonkamikaze DONE! Vom Trockenfutter sind sie heute irgendwie nicht so begeistert. Da war noch ein ganzer Napf voll da.",
  "id" : 277545045220020224,
  "in_reply_to_status_id" : 277541586924093440,
  "created_at" : "Sat Dec 08 22:47:49 +0000 2012",
  "in_reply_to_screen_name" : "stoffeldear",
  "in_reply_to_user_id_str" : "79704350",
  "user" : {
    "name" : "Felix",
    "screen_name" : "nicidienase",
    "protected" : false,
    "id_str" : "22396883",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3125784966/8223a4c5c9535be22d15c82ec829c2df_normal.jpeg",
    "id" : 22396883,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Uwe Lancier",
      "screen_name" : "Ulan_ka",
      "indices" : [ 0, 8 ],
      "id_str" : "379173142",
      "id" : 379173142
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "277465333126799361",
  "geo" : {
  },
  "id_str" : "277506895651143680",
  "in_reply_to_user_id" : 379173142,
  "text" : "@Ulan_ka  Noch sind die N\u00E4pfe gut mit Trockenfutter gef\u00FCllt. Und Dick stromert bei uns rum und sucht anscheinend was besseres zu Essen.",
  "id" : 277506895651143680,
  "in_reply_to_status_id" : 277465333126799361,
  "created_at" : "Sat Dec 08 20:16:14 +0000 2012",
  "in_reply_to_screen_name" : "Ulan_ka",
  "in_reply_to_user_id_str" : "379173142",
  "user" : {
    "name" : "Felix",
    "screen_name" : "nicidienase",
    "protected" : false,
    "id_str" : "22396883",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3125784966/8223a4c5c9535be22d15c82ec829c2df_normal.jpeg",
    "id" : 22396883,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "IveBeenExpectingYouMrBond",
      "indices" : [ 84, 110 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "277505904805564418",
  "text" : "Mit Katze auf dem Scho\u00DF im Drehsessel. F\u00FChle mich ein bissl wie ein Bond-B\u00F6sewicht. #IveBeenExpectingYouMrBond",
  "id" : 277505904805564418,
  "created_at" : "Sat Dec 08 20:12:18 +0000 2012",
  "user" : {
    "name" : "Felix",
    "screen_name" : "nicidienase",
    "protected" : false,
    "id_str" : "22396883",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3125784966/8223a4c5c9535be22d15c82ec829c2df_normal.jpeg",
    "id" : 22396883,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "$(RandomName)",
      "screen_name" : "Ik4ru5",
      "indices" : [ 0, 7 ],
      "id_str" : "48294441",
      "id" : 48294441
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 8, 28 ],
      "url" : "http://t.co/Eea2vVwy",
      "expanded_url" : "http://musicforprogramming.net/",
      "display_url" : "musicforprogramming.net"
    }, {
      "indices" : [ 33, 53 ],
      "url" : "http://t.co/nqwClQBz",
      "expanded_url" : "http://www.kraftfuttermischwerk.de/blogg/?page_id=1487",
      "display_url" : "kraftfuttermischwerk.de/blogg/?page_id\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "277379163873222656",
  "geo" : {
  },
  "id_str" : "277388653121126400",
  "in_reply_to_user_id" : 48294441,
  "text" : "@Ik4ru5 http://t.co/Eea2vVwy und http://t.co/nqwClQBz",
  "id" : 277388653121126400,
  "in_reply_to_status_id" : 277379163873222656,
  "created_at" : "Sat Dec 08 12:26:23 +0000 2012",
  "in_reply_to_screen_name" : "Ik4ru5",
  "in_reply_to_user_id_str" : "48294441",
  "user" : {
    "name" : "Felix",
    "screen_name" : "nicidienase",
    "protected" : false,
    "id_str" : "22396883",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3125784966/8223a4c5c9535be22d15c82ec829c2df_normal.jpeg",
    "id" : 22396883,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kate H.",
      "screen_name" : "elaoe7",
      "indices" : [ 0, 7 ],
      "id_str" : "149650777",
      "id" : 149650777
    }, {
      "name" : "Mario Sixtus",
      "screen_name" : "sixtus",
      "indices" : [ 13, 20 ],
      "id_str" : "9334352",
      "id" : 9334352
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 97, 117 ],
      "url" : "http://t.co/AVG5W7oc",
      "expanded_url" : "http://bit.ly/WPrjsm",
      "display_url" : "bit.ly/WPrjsm"
    } ]
  },
  "geo" : {
  },
  "id_str" : "277370792075984896",
  "in_reply_to_user_id" : 149650777,
  "text" : "@elaoe7  RT \"@sixtus: \u201CBerliners *always* say, 'That was nothing \u2013 last winter was much worse.'\u201D http://t.co/AVG5W7oc\"",
  "id" : 277370792075984896,
  "created_at" : "Sat Dec 08 11:15:24 +0000 2012",
  "in_reply_to_screen_name" : "elaoe7",
  "in_reply_to_user_id_str" : "149650777",
  "user" : {
    "name" : "Felix",
    "screen_name" : "nicidienase",
    "protected" : false,
    "id_str" : "22396883",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3125784966/8223a4c5c9535be22d15c82ec829c2df_normal.jpeg",
    "id" : 22396883,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "neingeist",
      "screen_name" : "neingeist",
      "indices" : [ 0, 10 ],
      "id_str" : "11193712",
      "id" : 11193712
    }, {
      "name" : "Haifischfutter",
      "screen_name" : "schmutzreich",
      "indices" : [ 11, 24 ],
      "id_str" : "52685173",
      "id" : 52685173
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "277074856305115138",
  "geo" : {
  },
  "id_str" : "277076068660289536",
  "in_reply_to_user_id" : 11193712,
  "text" : "@neingeist @schmutzreich Ne kleinsche M\u00FCtze k\u00F6nnte ich mir vorstellen. Aber wie sieht ne M\u00F6bius-M\u00FCtze aus?",
  "id" : 277076068660289536,
  "in_reply_to_status_id" : 277074856305115138,
  "created_at" : "Fri Dec 07 15:44:17 +0000 2012",
  "in_reply_to_screen_name" : "neingeist",
  "in_reply_to_user_id_str" : "11193712",
  "user" : {
    "name" : "Felix",
    "screen_name" : "nicidienase",
    "protected" : false,
    "id_str" : "22396883",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3125784966/8223a4c5c9535be22d15c82ec829c2df_normal.jpeg",
    "id" : 22396883,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "neingeist",
      "screen_name" : "neingeist",
      "indices" : [ 0, 10 ],
      "id_str" : "11193712",
      "id" : 11193712
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "277069611244089344",
  "geo" : {
  },
  "id_str" : "277074373481988097",
  "in_reply_to_user_id" : 11193712,
  "text" : "@neingeist und dann noch ein M\u00F6bius-Schal!",
  "id" : 277074373481988097,
  "in_reply_to_status_id" : 277069611244089344,
  "created_at" : "Fri Dec 07 15:37:33 +0000 2012",
  "in_reply_to_screen_name" : "neingeist",
  "in_reply_to_user_id_str" : "11193712",
  "user" : {
    "name" : "Felix",
    "screen_name" : "nicidienase",
    "protected" : false,
    "id_str" : "22396883",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3125784966/8223a4c5c9535be22d15c82ec829c2df_normal.jpeg",
    "id" : 22396883,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Singsalad",
      "screen_name" : "Singsalad",
      "indices" : [ 0, 10 ],
      "id_str" : "558020804",
      "id" : 558020804
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "277054598835998720",
  "geo" : {
  },
  "id_str" : "277071738184015872",
  "in_reply_to_user_id" : 558020804,
  "text" : "@Singsalad Sch\u00F6nen Urlaub! Lasst euch nicht von L\u00F6wen fressen ;)",
  "id" : 277071738184015872,
  "in_reply_to_status_id" : 277054598835998720,
  "created_at" : "Fri Dec 07 15:27:04 +0000 2012",
  "in_reply_to_screen_name" : "Singsalad",
  "in_reply_to_user_id_str" : "558020804",
  "user" : {
    "name" : "Felix",
    "screen_name" : "nicidienase",
    "protected" : false,
    "id_str" : "22396883",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3125784966/8223a4c5c9535be22d15c82ec829c2df_normal.jpeg",
    "id" : 22396883,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Cherubim",
      "screen_name" : "Donnerbeutel",
      "indices" : [ 3, 16 ],
      "id_str" : "116280930",
      "id" : 116280930
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "277057030978670593",
  "text" : "RT @Donnerbeutel: Aufgrund eines Fehlers in der Matrix kann es aktuell zu Pixelfehlern kommen. Diese \u00E4u\u00DFern sich durch durch die Luft fl ...",
  "retweeted_status" : {
    "source" : "<a href=\"http://www.tweetdeck.com\" rel=\"nofollow\">TweetDeck</a>",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : {
    },
    "id_str" : "277013539284209664",
    "text" : "Aufgrund eines Fehlers in der Matrix kann es aktuell zu Pixelfehlern kommen. Diese \u00E4u\u00DFern sich durch durch die Luft fliegende, wei\u00DFe Punkte.",
    "id" : 277013539284209664,
    "created_at" : "Fri Dec 07 11:35:49 +0000 2012",
    "user" : {
      "name" : "Cherubim",
      "screen_name" : "Donnerbeutel",
      "protected" : false,
      "id_str" : "116280930",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/3096897578/d33764698acad0209bc6ee7f182dec30_normal.jpeg",
      "id" : 116280930,
      "verified" : false
    }
  },
  "id" : 277057030978670593,
  "created_at" : "Fri Dec 07 14:28:38 +0000 2012",
  "user" : {
    "name" : "Felix",
    "screen_name" : "nicidienase",
    "protected" : false,
    "id_str" : "22396883",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3125784966/8223a4c5c9535be22d15c82ec829c2df_normal.jpeg",
    "id" : 22396883,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Anjuna Atreides",
      "screen_name" : "chaotin",
      "indices" : [ 3, 11 ],
      "id_str" : "324442079",
      "id" : 324442079
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "276980973084753920",
  "text" : "RT @chaotin: Nerds. \"Es hat bisher gut funktioniert, aber ich benutz jetzt was v\u00F6llig neues um dasselbe zu tun - was nicht ganz so gut f ...",
  "retweeted_status" : {
    "source" : "<a href=\"http://sites.google.com/site/yorufukurou/\" rel=\"nofollow\">YoruFukurou</a>",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : {
    },
    "id_str" : "276824134028238848",
    "text" : "Nerds. \"Es hat bisher gut funktioniert, aber ich benutz jetzt was v\u00F6llig neues um dasselbe zu tun - was nicht ganz so gut funktioniert...\"",
    "id" : 276824134028238848,
    "created_at" : "Thu Dec 06 23:03:11 +0000 2012",
    "user" : {
      "name" : "Anjuna Atreides",
      "screen_name" : "chaotin",
      "protected" : false,
      "id_str" : "324442079",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/3480011300/a786c904cd861ecd79015e6f3ff4afb9_normal.png",
      "id" : 324442079,
      "verified" : false
    }
  },
  "id" : 276980973084753920,
  "created_at" : "Fri Dec 07 09:26:24 +0000 2012",
  "user" : {
    "name" : "Felix",
    "screen_name" : "nicidienase",
    "protected" : false,
    "id_str" : "22396883",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3125784966/8223a4c5c9535be22d15c82ec829c2df_normal.jpeg",
    "id" : 22396883,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Deutsche Lufthansa ",
      "screen_name" : "Lufthansa_DE",
      "indices" : [ 3, 16 ],
      "id_str" : "25360913",
      "id" : 25360913
    } ],
    "media" : [ {
      "expanded_url" : "http://twitter.com/Lufthansa_DE/status/276627928614318080/photo/1",
      "indices" : [ 69, 89 ],
      "url" : "http://t.co/BOuixW1j",
      "media_url" : "http://pbs.twimg.com/media/A9bHoqyCMAAVSzr.jpg",
      "id_str" : "276627928622706688",
      "id" : 276627928622706688,
      "media_url_https" : "https://pbs.twimg.com/media/A9bHoqyCMAAVSzr.jpg",
      "sizes" : [ {
        "h" : 683,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 227,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 683,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 400,
        "resize" : "fit",
        "w" : 600
      } ],
      "display_url" : "pic.twitter.com/BOuixW1j"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "276802934992420866",
  "text" : "RT @Lufthansa_DE: Hiihihi, bitte nicht \u2013 ich bin doch SOOO kitzelig! http://t.co/BOuixW1j",
  "retweeted_status" : {
    "source" : "web",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "http://twitter.com/Lufthansa_DE/status/276627928614318080/photo/1",
        "indices" : [ 51, 71 ],
        "url" : "http://t.co/BOuixW1j",
        "media_url" : "http://pbs.twimg.com/media/A9bHoqyCMAAVSzr.jpg",
        "id_str" : "276627928622706688",
        "id" : 276627928622706688,
        "media_url_https" : "https://pbs.twimg.com/media/A9bHoqyCMAAVSzr.jpg",
        "sizes" : [ {
          "h" : 683,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 227,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 683,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 400,
          "resize" : "fit",
          "w" : 600
        } ],
        "display_url" : "pic.twitter.com/BOuixW1j"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : {
    },
    "id_str" : "276627928614318080",
    "text" : "Hiihihi, bitte nicht \u2013 ich bin doch SOOO kitzelig! http://t.co/BOuixW1j",
    "id" : 276627928614318080,
    "created_at" : "Thu Dec 06 10:03:32 +0000 2012",
    "user" : {
      "name" : "Deutsche Lufthansa ",
      "screen_name" : "Lufthansa_DE",
      "protected" : false,
      "id_str" : "25360913",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/2965991040/ee70bcfa9aba715f279d70c3928368fa_normal.jpeg",
      "id" : 25360913,
      "verified" : true
    }
  },
  "id" : 276802934992420866,
  "created_at" : "Thu Dec 06 21:38:57 +0000 2012",
  "user" : {
    "name" : "Felix",
    "screen_name" : "nicidienase",
    "protected" : false,
    "id_str" : "22396883",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3125784966/8223a4c5c9535be22d15c82ec829c2df_normal.jpeg",
    "id" : 22396883,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "kamikaze.de",
      "screen_name" : "lonkamikaze",
      "indices" : [ 0, 12 ],
      "id_str" : "935331409",
      "id" : 935331409
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "276414433796976640",
  "geo" : {
  },
  "id_str" : "276460203430518784",
  "in_reply_to_user_id" : 935331409,
  "text" : "@lonkamikaze I think that's probably the one thing Emacs and vi users can agree on. The other one is still better than nano.",
  "id" : 276460203430518784,
  "in_reply_to_status_id" : 276414433796976640,
  "created_at" : "Wed Dec 05 22:57:03 +0000 2012",
  "in_reply_to_screen_name" : "lonkamikaze",
  "in_reply_to_user_id_str" : "935331409",
  "user" : {
    "name" : "Felix",
    "screen_name" : "nicidienase",
    "protected" : false,
    "id_str" : "22396883",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3125784966/8223a4c5c9535be22d15c82ec829c2df_normal.jpeg",
    "id" : 22396883,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 30, 50 ],
      "url" : "http://t.co/hTKuj0O8",
      "expanded_url" : "http://vimeo.com/m/54526179",
      "display_url" : "vimeo.com/m/54526179"
    } ]
  },
  "geo" : {
  },
  "id_str" : "276431851504148480",
  "text" : "Last Christmas, Gangnam Style http://t.co/hTKuj0O8",
  "id" : 276431851504148480,
  "created_at" : "Wed Dec 05 21:04:23 +0000 2012",
  "user" : {
    "name" : "Felix",
    "screen_name" : "nicidienase",
    "protected" : false,
    "id_str" : "22396883",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3125784966/8223a4c5c9535be22d15c82ec829c2df_normal.jpeg",
    "id" : 22396883,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "*andy",
      "screen_name" : "derGeruhn",
      "indices" : [ 3, 13 ],
      "id_str" : "936437276",
      "id" : 936437276
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "mlp",
      "indices" : [ 106, 110 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "276382327783976960",
  "text" : "RT @derGeruhn: I never thought I'd live in a world where ponies would be considered manlier than vampires #mlp",
  "retweeted_status" : {
    "source" : "web",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "mlp",
        "indices" : [ 91, 95 ]
      } ],
      "urls" : [ ]
    },
    "geo" : {
    },
    "id_str" : "276335799300145152",
    "text" : "I never thought I'd live in a world where ponies would be considered manlier than vampires #mlp",
    "id" : 276335799300145152,
    "created_at" : "Wed Dec 05 14:42:43 +0000 2012",
    "user" : {
      "name" : "*andy",
      "screen_name" : "derGeruhn",
      "protected" : false,
      "id_str" : "936437276",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/3034420321/a4487789b515735fbc9522da5029aa43_normal.png",
      "id" : 936437276,
      "verified" : false
    }
  },
  "id" : 276382327783976960,
  "created_at" : "Wed Dec 05 17:47:36 +0000 2012",
  "user" : {
    "name" : "Felix",
    "screen_name" : "nicidienase",
    "protected" : false,
    "id_str" : "22396883",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3125784966/8223a4c5c9535be22d15c82ec829c2df_normal.jpeg",
    "id" : 22396883,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Katergasmus.",
      "screen_name" : "rotesnichts",
      "indices" : [ 3, 15 ],
      "id_str" : "347822259",
      "id" : 347822259
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "276380571620483074",
  "text" : "RT @rotesnichts: Und eine einzelne Stange Twix ist dann was?\n\nEin Unix?",
  "retweeted_status" : {
    "source" : "<a href=\"http://twicca.r246.jp/\" rel=\"nofollow\">twicca</a>",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : {
    },
    "id_str" : "276253008285818880",
    "text" : "Und eine einzelne Stange Twix ist dann was?\n\nEin Unix?",
    "id" : 276253008285818880,
    "created_at" : "Wed Dec 05 09:13:44 +0000 2012",
    "user" : {
      "name" : "Katergasmus.",
      "screen_name" : "rotesnichts",
      "protected" : false,
      "id_str" : "347822259",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/2879390738/9f6d9d95a987e4333d835ab74ab771ee_normal.jpeg",
      "id" : 347822259,
      "verified" : false
    }
  },
  "id" : 276380571620483074,
  "created_at" : "Wed Dec 05 17:40:37 +0000 2012",
  "user" : {
    "name" : "Felix",
    "screen_name" : "nicidienase",
    "protected" : false,
    "id_str" : "22396883",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3125784966/8223a4c5c9535be22d15c82ec829c2df_normal.jpeg",
    "id" : 22396883,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "WarFrog",
      "screen_name" : "WarFrog123",
      "indices" : [ 0, 11 ],
      "id_str" : "604042793",
      "id" : 604042793
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "276339770660106241",
  "geo" : {
  },
  "id_str" : "276340281224335361",
  "in_reply_to_user_id" : 604042793,
  "text" : "@WarFrog123 ne, bin arbeiten.",
  "id" : 276340281224335361,
  "in_reply_to_status_id" : 276339770660106241,
  "created_at" : "Wed Dec 05 15:00:31 +0000 2012",
  "in_reply_to_screen_name" : "WarFrog123",
  "in_reply_to_user_id_str" : "604042793",
  "user" : {
    "name" : "Felix",
    "screen_name" : "nicidienase",
    "protected" : false,
    "id_str" : "22396883",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3125784966/8223a4c5c9535be22d15c82ec829c2df_normal.jpeg",
    "id" : 22396883,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "psy",
      "screen_name" : "psycon",
      "indices" : [ 2, 9 ],
      "id_str" : "87286054",
      "id" : 87286054
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "276230377012621312",
  "geo" : {
  },
  "id_str" : "276311998428491779",
  "in_reply_to_user_id" : 87286054,
  "text" : ". @psycon Ein GPN-Pulli Semaphor!!",
  "id" : 276311998428491779,
  "in_reply_to_status_id" : 276230377012621312,
  "created_at" : "Wed Dec 05 13:08:08 +0000 2012",
  "in_reply_to_screen_name" : "psycon",
  "in_reply_to_user_id_str" : "87286054",
  "user" : {
    "name" : "Felix",
    "screen_name" : "nicidienase",
    "protected" : false,
    "id_str" : "22396883",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3125784966/8223a4c5c9535be22d15c82ec829c2df_normal.jpeg",
    "id" : 22396883,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "psy",
      "screen_name" : "psycon",
      "indices" : [ 3, 10 ],
      "id_str" : "87286054",
      "id" : 87286054
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "GPN12",
      "indices" : [ 55, 61 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "276311466397806592",
  "text" : "RT @psycon: K\u00F6nnen wir bitte einen \"Wer tr\u00E4gt wann den #GPN12 Pulli\" Kalender einrichten? Mit voraussichtlichem Bewegungsradius und gepl ...",
  "retweeted_status" : {
    "source" : "web",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "GPN12",
        "indices" : [ 43, 49 ]
      } ],
      "urls" : [ ]
    },
    "geo" : {
    },
    "id_str" : "276230377012621312",
    "text" : "K\u00F6nnen wir bitte einen \"Wer tr\u00E4gt wann den #GPN12 Pulli\" Kalender einrichten? Mit voraussichtlichem Bewegungsradius und geplanter Route!",
    "id" : 276230377012621312,
    "created_at" : "Wed Dec 05 07:43:48 +0000 2012",
    "user" : {
      "name" : "psy",
      "screen_name" : "psycon",
      "protected" : false,
      "id_str" : "87286054",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/2620981046/xkjfqh2iy0xp1lxx6cl1_normal.jpeg",
      "id" : 87286054,
      "verified" : false
    }
  },
  "id" : 276311466397806592,
  "created_at" : "Wed Dec 05 13:06:01 +0000 2012",
  "user" : {
    "name" : "Felix",
    "screen_name" : "nicidienase",
    "protected" : false,
    "id_str" : "22396883",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3125784966/8223a4c5c9535be22d15c82ec829c2df_normal.jpeg",
    "id" : 22396883,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Julia",
      "screen_name" : "seekuhkoenigin",
      "indices" : [ 3, 18 ],
      "id_str" : "373310584",
      "id" : 373310584
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "276117486120861697",
  "text" : "RT @seekuhkoenigin: Vielleicht gehe ich morgen mal fr\u00FCh ins Bett.",
  "retweeted_status" : {
    "source" : "<a href=\"http://tapbots.com/tweetbot\" rel=\"nofollow\">Tweetbot for iOS</a>",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : {
    },
    "id_str" : "276100815188553728",
    "text" : "Vielleicht gehe ich morgen mal fr\u00FCh ins Bett.",
    "id" : 276100815188553728,
    "created_at" : "Tue Dec 04 23:08:58 +0000 2012",
    "user" : {
      "name" : "Julia",
      "screen_name" : "seekuhkoenigin",
      "protected" : false,
      "id_str" : "373310584",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/3370240908/adddc78e0125abdd0ab70d44df6d5e30_normal.jpeg",
      "id" : 373310584,
      "verified" : false
    }
  },
  "id" : 276117486120861697,
  "created_at" : "Wed Dec 05 00:15:13 +0000 2012",
  "user" : {
    "name" : "Felix",
    "screen_name" : "nicidienase",
    "protected" : false,
    "id_str" : "22396883",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3125784966/8223a4c5c9535be22d15c82ec829c2df_normal.jpeg",
    "id" : 22396883,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "DirtyMind",
      "indices" : [ 82, 92 ]
    }, {
      "text" : "SoftwareEngineering",
      "indices" : [ 93, 113 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "275920888145256448",
  "text" : "\"Welche Schnittstelle stelle ich zur Verf\u00FCgung das ich ordentlich benutzt werde.\" #DirtyMind #SoftwareEngineering",
  "id" : 275920888145256448,
  "created_at" : "Tue Dec 04 11:14:00 +0000 2012",
  "user" : {
    "name" : "Felix",
    "screen_name" : "nicidienase",
    "protected" : false,
    "id_str" : "22396883",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3125784966/8223a4c5c9535be22d15c82ec829c2df_normal.jpeg",
    "id" : 22396883,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/tweetbutton\" rel=\"nofollow\">Tweet Button</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 53, 73 ],
      "url" : "http://t.co/6UOFAnP0",
      "expanded_url" : "http://youtu.be/CSlnZxvi37s",
      "display_url" : "youtu.be/CSlnZxvi37s"
    } ]
  },
  "geo" : {
  },
  "id_str" : "275711775113105408",
  "text" : "OMG, wie awesome ist das den? MLP: Fighting is Magic http://t.co/6UOFAnP0",
  "id" : 275711775113105408,
  "created_at" : "Mon Dec 03 21:23:04 +0000 2012",
  "user" : {
    "name" : "Felix",
    "screen_name" : "nicidienase",
    "protected" : false,
    "id_str" : "22396883",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3125784966/8223a4c5c9535be22d15c82ec829c2df_normal.jpeg",
    "id" : 22396883,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Eva ",
      "screen_name" : "SchokoPralini",
      "indices" : [ 0, 14 ],
      "id_str" : "575695094",
      "id" : 575695094
    } ],
    "media" : [ {
      "expanded_url" : "http://twitter.com/nicidienase/status/275229667458424832/photo/1",
      "indices" : [ 19, 39 ],
      "url" : "http://t.co/tHOkTxqq",
      "media_url" : "http://pbs.twimg.com/media/A9HP7KFCIAARapJ.jpg",
      "id_str" : "275229667471007744",
      "id" : 275229667471007744,
      "media_url_https" : "https://pbs.twimg.com/media/A9HP7KFCIAARapJ.jpg",
      "sizes" : [ {
        "h" : 1365,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 2560,
        "resize" : "fit",
        "w" : 1920
      }, {
        "h" : 453,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 800,
        "resize" : "fit",
        "w" : 600
      } ],
      "display_url" : "pic.twitter.com/tHOkTxqq"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "275229667458424832",
  "in_reply_to_user_id" : 575695094,
  "text" : "@SchokoPralini mmh http://t.co/tHOkTxqq",
  "id" : 275229667458424832,
  "created_at" : "Sun Dec 02 13:27:22 +0000 2012",
  "in_reply_to_screen_name" : "SchokoPralini",
  "in_reply_to_user_id_str" : "575695094",
  "user" : {
    "name" : "Felix",
    "screen_name" : "nicidienase",
    "protected" : false,
    "id_str" : "22396883",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3125784966/8223a4c5c9535be22d15c82ec829c2df_normal.jpeg",
    "id" : 22396883,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "WarFrog",
      "screen_name" : "WarFrog123",
      "indices" : [ 0, 11 ],
      "id_str" : "604042793",
      "id" : 604042793
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "274860301562810369",
  "geo" : {
  },
  "id_str" : "274860447855955969",
  "in_reply_to_user_id" : 604042793,
  "text" : "@WarFrog123 lol",
  "id" : 274860447855955969,
  "in_reply_to_status_id" : 274860301562810369,
  "created_at" : "Sat Dec 01 13:00:12 +0000 2012",
  "in_reply_to_screen_name" : "WarFrog123",
  "in_reply_to_user_id_str" : "604042793",
  "user" : {
    "name" : "Felix",
    "screen_name" : "nicidienase",
    "protected" : false,
    "id_str" : "22396883",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3125784966/8223a4c5c9535be22d15c82ec829c2df_normal.jpeg",
    "id" : 22396883,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "WarFrog",
      "screen_name" : "WarFrog123",
      "indices" : [ 0, 11 ],
      "id_str" : "604042793",
      "id" : 604042793
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "274860055462047744",
  "geo" : {
  },
  "id_str" : "274860163507306497",
  "in_reply_to_user_id" : 604042793,
  "text" : "@WarFrog123 ne, wo?",
  "id" : 274860163507306497,
  "in_reply_to_status_id" : 274860055462047744,
  "created_at" : "Sat Dec 01 12:59:04 +0000 2012",
  "in_reply_to_screen_name" : "WarFrog123",
  "in_reply_to_user_id_str" : "604042793",
  "user" : {
    "name" : "Felix",
    "screen_name" : "nicidienase",
    "protected" : false,
    "id_str" : "22396883",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3125784966/8223a4c5c9535be22d15c82ec829c2df_normal.jpeg",
    "id" : 22396883,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "WarFrog",
      "screen_name" : "WarFrog123",
      "indices" : [ 0, 11 ],
      "id_str" : "604042793",
      "id" : 604042793
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "274855422295408640",
  "geo" : {
  },
  "id_str" : "274859031548526593",
  "in_reply_to_user_id" : 604042793,
  "text" : "@WarFrog123 awww",
  "id" : 274859031548526593,
  "in_reply_to_status_id" : 274855422295408640,
  "created_at" : "Sat Dec 01 12:54:34 +0000 2012",
  "in_reply_to_screen_name" : "WarFrog123",
  "in_reply_to_user_id_str" : "604042793",
  "user" : {
    "name" : "Felix",
    "screen_name" : "nicidienase",
    "protected" : false,
    "id_str" : "22396883",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3125784966/8223a4c5c9535be22d15c82ec829c2df_normal.jpeg",
    "id" : 22396883,
    "verified" : false
  }
} ]