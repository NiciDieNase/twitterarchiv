Grailbird.data.tweets_2010_12 = 
 [ {
  "source" : "<a href=\"http://tweed.pivotallabs.com\" rel=\"nofollow\">Tweed webOS</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 48.899633, 8.685049 ]
  },
  "id_str" : "20640490206527488",
  "text" : "Dank Taxigutschein jetzt endlich daheim. Gut n8",
  "id" : 20640490206527488,
  "created_at" : "Fri Dec 31 00:40:51 +0000 2010",
  "user" : {
    "name" : "Felix",
    "screen_name" : "nicidienase",
    "protected" : false,
    "id_str" : "22396883",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3125784966/8223a4c5c9535be22d15c82ec829c2df_normal.jpeg",
    "id" : 22396883,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://tweed.pivotallabs.com\" rel=\"nofollow\">Tweed webOS</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "27C3",
      "indices" : [ 20, 25 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 49.188496, 8.49897 ]
  },
  "id_str" : "20628240867528705",
  "text" : "Auf dem Heimweg vom #27C3 im ICE mit ~42min Versp\u00E4tung auf Platz 42, und ich merks erst nach 5h. http://twitpic.com/3lcfie",
  "id" : 20628240867528705,
  "created_at" : "Thu Dec 30 23:52:10 +0000 2010",
  "user" : {
    "name" : "Felix",
    "screen_name" : "nicidienase",
    "protected" : false,
    "id_str" : "22396883",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3125784966/8223a4c5c9535be22d15c82ec829c2df_normal.jpeg",
    "id" : 22396883,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://tweed.pivotallabs.com\" rel=\"nofollow\">Tweed webOS</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.100486, 8.658414 ]
  },
  "id_str" : "20612338646261760",
  "text" : "\"Die Weiterfahrt verz\u00F6gert sich aus unbekannten Gr\u00FCnden\" Als ob wir nicht schon genug Versp\u00E4tung h\u00E4tten.",
  "id" : 20612338646261760,
  "created_at" : "Thu Dec 30 22:48:59 +0000 2010",
  "user" : {
    "name" : "Felix",
    "screen_name" : "nicidienase",
    "protected" : false,
    "id_str" : "22396883",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3125784966/8223a4c5c9535be22d15c82ec829c2df_normal.jpeg",
    "id" : 22396883,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://tweed.pivotallabs.com\" rel=\"nofollow\">Tweed webOS</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ICE877",
      "indices" : [ 0, 7 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.337098, 9.497627 ]
  },
  "id_str" : "20598804537417729",
  "text" : "#ICE877 hat inzwischen \u00FCber 40min Versp\u00E4tung.Umstieg in MH wird nix mehr.Bin mal gespannt ob ich \u00FCber KA vor Sonnenaufgang noch heim komme.",
  "id" : 20598804537417729,
  "created_at" : "Thu Dec 30 21:55:12 +0000 2010",
  "user" : {
    "name" : "Felix",
    "screen_name" : "nicidienase",
    "protected" : false,
    "id_str" : "22396883",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3125784966/8223a4c5c9535be22d15c82ec829c2df_normal.jpeg",
    "id" : 22396883,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://tweed.pivotallabs.com\" rel=\"nofollow\">Tweed webOS</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 52.52419, 13.371297 ]
  },
  "id_str" : "20540104539901952",
  "text" : "Endlich sitz ich im Zug. Jetzt schau ich mir erst mal noch die Keynote an die ich am Mo verpasst hab und hoff das ich irgendwann heim komme.",
  "id" : 20540104539901952,
  "created_at" : "Thu Dec 30 18:01:57 +0000 2010",
  "user" : {
    "name" : "Felix",
    "screen_name" : "nicidienase",
    "protected" : false,
    "id_str" : "22396883",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3125784966/8223a4c5c9535be22d15c82ec829c2df_normal.jpeg",
    "id" : 22396883,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://tweed.pivotallabs.com\" rel=\"nofollow\">Tweed webOS</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ICE877",
      "indices" : [ 25, 32 ]
    }, {
      "text" : "bahn",
      "indices" : [ 33, 38 ]
    }, {
      "text" : "fail",
      "indices" : [ 39, 44 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 52.524055, 13.370471 ]
  },
  "id_str" : "20533983649464320",
  "text" : "Yuchuu jetzt sinds 20min #ICE877 #bahn #fail",
  "id" : 20533983649464320,
  "created_at" : "Thu Dec 30 17:37:37 +0000 2010",
  "user" : {
    "name" : "Felix",
    "screen_name" : "nicidienase",
    "protected" : false,
    "id_str" : "22396883",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3125784966/8223a4c5c9535be22d15c82ec829c2df_normal.jpeg",
    "id" : 22396883,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://tweed.pivotallabs.com\" rel=\"nofollow\">Tweed webOS</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "27C3",
      "indices" : [ 0, 5 ]
    }, {
      "text" : "ICE877",
      "indices" : [ 15, 22 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 52.52419, 13.371297 ]
  },
  "id_str" : "20532362517422081",
  "text" : "#27C3 ade. Und #ICE877 hat gleich mal 15min Versp\u00E4tung. Da h\u00E4tte ich mir die Security Nightmares noch anh\u00F6ren k\u00F6nnen.",
  "id" : 20532362517422081,
  "created_at" : "Thu Dec 30 17:31:11 +0000 2010",
  "user" : {
    "name" : "Felix",
    "screen_name" : "nicidienase",
    "protected" : false,
    "id_str" : "22396883",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3125784966/8223a4c5c9535be22d15c82ec829c2df_normal.jpeg",
    "id" : 22396883,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://tweed.pivotallabs.com\" rel=\"nofollow\">Tweed webOS</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "27C3",
      "indices" : [ 0, 5 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 52.521873, 13.416036 ]
  },
  "id_str" : "20419271624495104",
  "text" : "#27C3 Tag 4 Heute hab ichs das erste mal ins bcc gesch\u00E4ft bevor die ersten Talk anfangen.",
  "id" : 20419271624495104,
  "created_at" : "Thu Dec 30 10:01:48 +0000 2010",
  "user" : {
    "name" : "Felix",
    "screen_name" : "nicidienase",
    "protected" : false,
    "id_str" : "22396883",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3125784966/8223a4c5c9535be22d15c82ec829c2df_normal.jpeg",
    "id" : 22396883,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://tweed.pivotallabs.com\" rel=\"nofollow\">Tweed webOS</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "27C3",
      "indices" : [ 32, 37 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 49.4794, 8.468279 ]
  },
  "id_str" : "19265918915837952",
  "text" : "Ich sitz im ICE 874 nach Berlin #27C3 ich komme!",
  "id" : 19265918915837952,
  "created_at" : "Mon Dec 27 05:38:47 +0000 2010",
  "user" : {
    "name" : "Felix",
    "screen_name" : "nicidienase",
    "protected" : false,
    "id_str" : "22396883",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3125784966/8223a4c5c9535be22d15c82ec829c2df_normal.jpeg",
    "id" : 22396883,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.bravenewcode.com/products/wordtwit\" rel=\"nofollow\">WordTwit Plugin</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "17324141770182656",
  "text" : "Neuer Blog-Beitrag, Meine neue SSD - http://tinyurl.com/28hnklc",
  "id" : 17324141770182656,
  "created_at" : "Tue Dec 21 21:02:51 +0000 2010",
  "user" : {
    "name" : "Felix",
    "screen_name" : "nicidienase",
    "protected" : false,
    "id_str" : "22396883",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3125784966/8223a4c5c9535be22d15c82ec829c2df_normal.jpeg",
    "id" : 22396883,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://tweed.pivotallabs.com\" rel=\"nofollow\">Tweed webOS</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "~PsYCoN~",
      "screen_name" : "nocysp",
      "indices" : [ 0, 7 ],
      "id_str" : "14010592",
      "id" : 14010592
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "16953035091607552",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 49.008169, 8.411841 ]
  },
  "id_str" : "17031927961747456",
  "in_reply_to_user_id" : 87286054,
  "text" : "@nocysp mmh, schaut lecker aus.",
  "id" : 17031927961747456,
  "in_reply_to_status_id" : 16953035091607552,
  "created_at" : "Tue Dec 21 01:41:42 +0000 2010",
  "in_reply_to_screen_name" : "psycon",
  "in_reply_to_user_id_str" : "87286054",
  "user" : {
    "name" : "Felix",
    "screen_name" : "nicidienase",
    "protected" : false,
    "id_str" : "22396883",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3125784966/8223a4c5c9535be22d15c82ec829c2df_normal.jpeg",
    "id" : 22396883,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://tweed.pivotallabs.com\" rel=\"nofollow\">Tweed webOS</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Anas Qtiesh",
      "screen_name" : "anasqtiesh",
      "indices" : [ 3, 14 ],
      "id_str" : "1158309006",
      "id" : 1158309006
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "15694710735634432",
  "text" : "RT @anasqtiesh: \"Share government's secrets, go to jail. Share normal people's secrets, TIME man of the year!\"",
  "retweeted_status" : {
    "source" : "web",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : {
    },
    "id_str" : "15217054495805440",
    "text" : "\"Share government's secrets, go to jail. Share normal people's secrets, TIME man of the year!\"",
    "id" : 15217054495805440,
    "created_at" : "Thu Dec 16 01:30:03 +0000 2010",
    "user" : {
      "name" : "Anas Qtiesh",
      "screen_name" : "anas",
      "protected" : false,
      "id_str" : "17156208",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/3280010958/63ae55f877b57ca283834476560fb9ec_normal.jpeg",
      "id" : 17156208,
      "verified" : false
    }
  },
  "id" : 15694710735634432,
  "created_at" : "Fri Dec 17 09:08:05 +0000 2010",
  "user" : {
    "name" : "Felix",
    "screen_name" : "nicidienase",
    "protected" : false,
    "id_str" : "22396883",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3125784966/8223a4c5c9535be22d15c82ec829c2df_normal.jpeg",
    "id" : 22396883,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://tweed.pivotallabs.com\" rel=\"nofollow\">Tweed webOS</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mario Sixtus",
      "screen_name" : "sixtus",
      "indices" : [ 3, 10 ],
      "id_str" : "9334352",
      "id" : 9334352
    }, {
      "name" : "Jimmy Wales",
      "screen_name" : "jimmy_wales",
      "indices" : [ 18, 30 ],
      "id_str" : "49793",
      "id" : 49793
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "15058281638662144",
  "text" : "RT @sixtus: Huch! @jimmy_wales hat sich rasiert! http://de.wikipedia.org/wiki/Wikipedia:Hauptseite",
  "retweeted_status" : {
    "source" : "web",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Jimmy Wales",
        "screen_name" : "jimmy_wales",
        "indices" : [ 6, 18 ],
        "id_str" : "49793",
        "id" : 49793
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : {
    },
    "id_str" : "15009562570522625",
    "text" : "Huch! @jimmy_wales hat sich rasiert! http://de.wikipedia.org/wiki/Wikipedia:Hauptseite",
    "id" : 15009562570522625,
    "created_at" : "Wed Dec 15 11:45:33 +0000 2010",
    "user" : {
      "name" : "Mario Sixtus",
      "screen_name" : "sixtus",
      "protected" : false,
      "id_str" : "9334352",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/274542155/mario_normal.gif",
      "id" : 9334352,
      "verified" : true
    }
  },
  "id" : 15058281638662144,
  "created_at" : "Wed Dec 15 14:59:08 +0000 2010",
  "user" : {
    "name" : "Felix",
    "screen_name" : "nicidienase",
    "protected" : false,
    "id_str" : "22396883",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3125784966/8223a4c5c9535be22d15c82ec829c2df_normal.jpeg",
    "id" : 22396883,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://tweed.pivotallabs.com\" rel=\"nofollow\">Tweed webOS</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "bruno decock",
      "screen_name" : "brunodecock",
      "indices" : [ 3, 15 ],
      "id_str" : "18240896",
      "id" : 18240896
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "14842724918231040",
  "text" : "RT @brunodecock: \u2588\u2588\u2588\u2588\u2588 \u2588\u2588 \u2588 \u2588\u2588\u2588\u2588 everything \u2588\u2588\u2588 \u2588\u2588\u2588\u2588\u2588 is\u2588\u2588\u2588\u2588\u2588 \u2588\u2588\u2588\u2588 \u2588\u2588\u2588\u2588 fine \u2588\u2588\u2588\u2588 \u2588\u2588\u2588 \u2588 \u2588\u2588\u2588\u2588\u2588\u2588 love. \u2588\u2588\u2588\u2588\u2588 \u2588\u2588\u2588\u2588\u2588\u2588\u2588 \u2588\u2588\u2588 your \u2588\u2588\u2588\u2588\u2588 \u2588\u2588\u2588\u2588 g ...",
  "retweeted_status" : {
    "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "wikileaks",
        "indices" : [ 129, 139 ]
      } ],
      "urls" : [ ]
    },
    "geo" : {
    },
    "id_str" : "14590086242902016",
    "text" : "\u2588\u2588\u2588\u2588\u2588 \u2588\u2588 \u2588 \u2588\u2588\u2588\u2588 everything \u2588\u2588\u2588 \u2588\u2588\u2588\u2588\u2588 is\u2588\u2588\u2588\u2588\u2588 \u2588\u2588\u2588\u2588 \u2588\u2588\u2588\u2588 fine \u2588\u2588\u2588\u2588 \u2588\u2588\u2588 \u2588 \u2588\u2588\u2588\u2588\u2588\u2588 love. \u2588\u2588\u2588\u2588\u2588 \u2588\u2588\u2588\u2588\u2588\u2588\u2588 \u2588\u2588\u2588 your \u2588\u2588\u2588\u2588\u2588 \u2588\u2588\u2588\u2588 government #wikileaks",
    "id" : 14590086242902016,
    "created_at" : "Tue Dec 14 07:58:42 +0000 2010",
    "user" : {
      "name" : "bruno decock",
      "screen_name" : "brunodecock",
      "protected" : false,
      "id_str" : "18240896",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/2626266545/ytm1nstrm5c7rfaabfrq_normal.png",
      "id" : 18240896,
      "verified" : false
    }
  },
  "id" : 14842724918231040,
  "created_at" : "Wed Dec 15 00:42:36 +0000 2010",
  "user" : {
    "name" : "Felix",
    "screen_name" : "nicidienase",
    "protected" : false,
    "id_str" : "22396883",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3125784966/8223a4c5c9535be22d15c82ec829c2df_normal.jpeg",
    "id" : 22396883,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://tweed.pivotallabs.com\" rel=\"nofollow\">Tweed webOS</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Gary Whitta",
      "screen_name" : "garywhitta",
      "indices" : [ 3, 14 ],
      "id_str" : "14563376",
      "id" : 14563376
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "14581103205552128",
  "text" : "RT @garywhitta: Q: How did Darth Vader know what Luke Skywalker got him for Christmas? A: He felt his presents.",
  "retweeted_status" : {
    "source" : "<a href=\"http://www.tweetdeck.com\" rel=\"nofollow\">TweetDeck</a>",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : {
    },
    "id_str" : "14127858532220929",
    "text" : "Q: How did Darth Vader know what Luke Skywalker got him for Christmas? A: He felt his presents.",
    "id" : 14127858532220929,
    "created_at" : "Mon Dec 13 01:21:58 +0000 2010",
    "user" : {
      "name" : "Gary Whitta",
      "screen_name" : "garywhitta",
      "protected" : false,
      "id_str" : "14563376",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/2282682725/v168sw9svi332mlkjcro_normal.jpeg",
      "id" : 14563376,
      "verified" : true
    }
  },
  "id" : 14581103205552128,
  "created_at" : "Tue Dec 14 07:23:00 +0000 2010",
  "user" : {
    "name" : "Felix",
    "screen_name" : "nicidienase",
    "protected" : false,
    "id_str" : "22396883",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3125784966/8223a4c5c9535be22d15c82ec829c2df_normal.jpeg",
    "id" : 22396883,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://tweed.pivotallabs.com\" rel=\"nofollow\">Tweed webOS</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Wil Wheaton",
      "screen_name" : "wilw",
      "indices" : [ 3, 8 ],
      "id_str" : "1183041",
      "id" : 1183041
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "14580422713286656",
  "text" : "RT @wilw: Assuming that you've heard it is breathtaking, everything you've heard about Daft punk's Tron: Legacy soundtrack is true.",
  "retweeted_status" : {
    "source" : "web",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : {
    },
    "id_str" : "14103029687001088",
    "text" : "Assuming that you've heard it is breathtaking, everything you've heard about Daft punk's Tron: Legacy soundtrack is true.",
    "id" : 14103029687001088,
    "created_at" : "Sun Dec 12 23:43:18 +0000 2010",
    "user" : {
      "name" : "Wil Wheaton",
      "screen_name" : "wilw",
      "protected" : false,
      "id_str" : "1183041",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/2449509523/f0gkhyhpwmv7m6ncyxbl_normal.png",
      "id" : 1183041,
      "verified" : true
    }
  },
  "id" : 14580422713286656,
  "created_at" : "Tue Dec 14 07:20:18 +0000 2010",
  "user" : {
    "name" : "Felix",
    "screen_name" : "nicidienase",
    "protected" : false,
    "id_str" : "22396883",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3125784966/8223a4c5c9535be22d15c82ec829c2df_normal.jpeg",
    "id" : 22396883,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://tweed.pivotallabs.com\" rel=\"nofollow\">Tweed webOS</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 49.010616, 8.397291 ]
  },
  "id_str" : "14579885095784448",
  "text" : "Erkenntniss des Tages: Barabend bis nachts um drei macht Spa\u00DF, Mathe am n\u00E4chsten Morgen dann nicht mehr so sehr.",
  "id" : 14579885095784448,
  "created_at" : "Tue Dec 14 07:18:10 +0000 2010",
  "user" : {
    "name" : "Felix",
    "screen_name" : "nicidienase",
    "protected" : false,
    "id_str" : "22396883",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3125784966/8223a4c5c9535be22d15c82ec829c2df_normal.jpeg",
    "id" : 22396883,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://tweed.pivotallabs.com\" rel=\"nofollow\">Tweed webOS</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ron Paul",
      "screen_name" : "RepRonPaul",
      "indices" : [ 3, 14 ],
      "id_str" : "76966145",
      "id" : 76966145
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "12055890765025280",
  "text" : "RT @RepRonPaul: Re: Wikileaks- In a free society, we are supposed to know the truth. In a society where truth becomes treason, we are in ...",
  "retweeted_status" : {
    "source" : "web",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : {
    },
    "id_str" : "10716266021003264",
    "text" : "Re: Wikileaks- In a free society, we are supposed to know the truth. In a society where truth becomes treason, we are in big trouble.",
    "id" : 10716266021003264,
    "created_at" : "Fri Dec 03 15:25:31 +0000 2010",
    "user" : {
      "name" : "Ron Paul",
      "screen_name" : "RepRonPaul",
      "protected" : false,
      "id_str" : "76966145",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/433694808/Dr_Paul_small_normal.jpg",
      "id" : 76966145,
      "verified" : true
    }
  },
  "id" : 12055890765025280,
  "created_at" : "Tue Dec 07 08:08:43 +0000 2010",
  "user" : {
    "name" : "Felix",
    "screen_name" : "nicidienase",
    "protected" : false,
    "id_str" : "22396883",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3125784966/8223a4c5c9535be22d15c82ec829c2df_normal.jpeg",
    "id" : 22396883,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://tweed.pivotallabs.com\" rel=\"nofollow\">Tweed webOS</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mr. Undertaker \u2122 \uF8FF ",
      "screen_name" : "leichenwagen",
      "indices" : [ 3, 16 ],
      "id_str" : "111875264",
      "id" : 111875264
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "12052420339179520",
  "text" : "RT @leichenwagen: Erst wenn der letzte Programmierer eingesperrt\nund die letzte Idee patentiert ist, werdet ihr merken,\nda\u00DF Anw\u00E4lte nich ...",
  "retweeted_status" : {
    "source" : "web",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : {
    },
    "id_str" : "10752348485849088",
    "text" : "Erst wenn der letzte Programmierer eingesperrt\nund die letzte Idee patentiert ist, werdet ihr merken,\nda\u00DF Anw\u00E4lte nicht programmieren k\u00F6nnen",
    "id" : 10752348485849088,
    "created_at" : "Fri Dec 03 17:48:54 +0000 2010",
    "user" : {
      "name" : "Mr. Undertaker \u2122 \uF8FF ",
      "screen_name" : "leichenwagen",
      "protected" : false,
      "id_str" : "111875264",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/1310897726/boris2_normal.jpg",
      "id" : 111875264,
      "verified" : false
    }
  },
  "id" : 12052420339179520,
  "created_at" : "Tue Dec 07 07:54:55 +0000 2010",
  "user" : {
    "name" : "Felix",
    "screen_name" : "nicidienase",
    "protected" : false,
    "id_str" : "22396883",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3125784966/8223a4c5c9535be22d15c82ec829c2df_normal.jpeg",
    "id" : 22396883,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://tweed.pivotallabs.com\" rel=\"nofollow\">Tweed webOS</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 49.015353, 8.392763 ]
  },
  "id_str" : "9955781394833408",
  "text" : "Maschbauersprech f\u00FCr \"Rauchen nur im Freien erlaubt!\" http://twitpic.com/3bw257",
  "id" : 9955781394833408,
  "created_at" : "Wed Dec 01 13:03:37 +0000 2010",
  "user" : {
    "name" : "Felix",
    "screen_name" : "nicidienase",
    "protected" : false,
    "id_str" : "22396883",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3125784966/8223a4c5c9535be22d15c82ec829c2df_normal.jpeg",
    "id" : 22396883,
    "verified" : false
  }
} ]