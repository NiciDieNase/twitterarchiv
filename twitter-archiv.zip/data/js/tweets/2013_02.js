Grailbird.data.tweets_2013_02 = 
 [ {
  "source" : "<a href=\"http://www.tweetlanes.com\" rel=\"nofollow\">Tweet Lanes</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Fiona",
      "screen_name" : "Fotografiona",
      "indices" : [ 3, 16 ],
      "id_str" : "59090320",
      "id" : 59090320
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 110, 132 ],
      "url" : "http://t.co/CRj7sYWcuc",
      "expanded_url" : "http://www.youtube.com/watch?v=nKIu9yen5nc",
      "display_url" : "youtube.com/watch?v=nKIu9y\u2026"
    } ]
  },
  "geo" : {
  },
  "id_str" : "306775085560262656",
  "text" : "RT @Fotografiona: Infomercial mit Gates, Zuckerberg und Nicht-so-typischen-Nerds \u00FCber das Programmierenlernen http://t.co/CRj7sYWcuc (da ...",
  "retweeted_status" : {
    "source" : "web",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Jens Ohlig",
        "screen_name" : "johl",
        "indices" : [ 123, 128 ],
        "id_str" : "1147751",
        "id" : 1147751
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 92, 114 ],
        "url" : "http://t.co/CRj7sYWcuc",
        "expanded_url" : "http://www.youtube.com/watch?v=nKIu9yen5nc",
        "display_url" : "youtube.com/watch?v=nKIu9y\u2026"
      } ]
    },
    "geo" : {
    },
    "id_str" : "306685741394714624",
    "text" : "Infomercial mit Gates, Zuckerberg und Nicht-so-typischen-Nerds \u00FCber das Programmierenlernen http://t.co/CRj7sYWcuc (danke .@johl)",
    "id" : 306685741394714624,
    "created_at" : "Wed Feb 27 08:42:33 +0000 2013",
    "user" : {
      "name" : "Fiona",
      "screen_name" : "Fotografiona",
      "protected" : false,
      "id_str" : "59090320",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/2546078946/lfyc2rzsxw67cbv89x37_normal.jpeg",
      "id" : 59090320,
      "verified" : false
    }
  },
  "id" : 306775085560262656,
  "created_at" : "Wed Feb 27 14:37:34 +0000 2013",
  "user" : {
    "name" : "Felix",
    "screen_name" : "nicidienase",
    "protected" : false,
    "id_str" : "22396883",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3125784966/8223a4c5c9535be22d15c82ec829c2df_normal.jpeg",
    "id" : 22396883,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.tweetlanes.com\" rel=\"nofollow\">Tweet Lanes</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "RaumZeitLabor",
      "screen_name" : "RaumZeitLabor",
      "indices" : [ 3, 17 ],
      "id_str" : "114430885",
      "id" : 114430885
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 114, 135 ],
      "url" : "https://t.co/atLiUZKo",
      "expanded_url" : "https://raumzeitlabor.de/blog/1-raumzeitlabor-ponylasagneparty",
      "display_url" : "raumzeitlabor.de/blog/1-raumzei\u2026"
    } ]
  },
  "geo" : {
  },
  "id_str" : "304199447640940545",
  "text" : "RT @RaumZeitLabor: Wieder kein Pferdefleisch im Essen? Bei der 1. RaumZeitLabor PonyLasagneParty \u00E4ndert sich das! https://t.co/atLiUZKo  ...",
  "retweeted_status" : {
    "source" : "<a href=\"http://www.GroupTweet.com\" rel=\"nofollow\">GroupTweet</a>",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "ponylasagne",
        "indices" : [ 117, 129 ]
      } ],
      "urls" : [ {
        "indices" : [ 95, 116 ],
        "url" : "https://t.co/atLiUZKo",
        "expanded_url" : "https://raumzeitlabor.de/blog/1-raumzeitlabor-ponylasagneparty",
        "display_url" : "raumzeitlabor.de/blog/1-raumzei\u2026"
      } ]
    },
    "geo" : {
    },
    "id_str" : "304161688373063680",
    "text" : "Wieder kein Pferdefleisch im Essen? Bei der 1. RaumZeitLabor PonyLasagneParty \u00E4ndert sich das! https://t.co/atLiUZKo #ponylasagne",
    "id" : 304161688373063680,
    "created_at" : "Wed Feb 20 09:32:52 +0000 2013",
    "user" : {
      "name" : "RaumZeitLabor",
      "screen_name" : "RaumZeitLabor",
      "protected" : false,
      "id_str" : "114430885",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/3201100954/fe6b83df2e9009a40722d69f9a8a7144_normal.jpeg",
      "id" : 114430885,
      "verified" : false
    }
  },
  "id" : 304199447640940545,
  "created_at" : "Wed Feb 20 12:02:54 +0000 2013",
  "user" : {
    "name" : "Felix",
    "screen_name" : "nicidienase",
    "protected" : false,
    "id_str" : "22396883",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3125784966/8223a4c5c9535be22d15c82ec829c2df_normal.jpeg",
    "id" : 22396883,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.tweetlanes.com\" rel=\"nofollow\">Tweet Lanes</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The Hacker Academy",
      "screen_name" : "hackeracademy",
      "indices" : [ 3, 17 ],
      "id_str" : "41374518",
      "id" : 41374518
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "304001631241007105",
  "text" : "RT @hackeracademy: Oh, you found a remote OpenSSH 0-day on Pastebin? Well you should definitely run that... as root... on your own box.  ...",
  "retweeted_status" : {
    "source" : "<a href=\"http://www.hootsuite.com\" rel=\"nofollow\">HootSuite</a>",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 117, 137 ],
        "url" : "http://t.co/gFGblIoO",
        "expanded_url" : "http://ow.ly/hR8oR",
        "display_url" : "ow.ly/hR8oR"
      } ]
    },
    "geo" : {
    },
    "id_str" : "303929600084418560",
    "text" : "Oh, you found a remote OpenSSH 0-day on Pastebin? Well you should definitely run that... as root... on your own box. http://t.co/gFGblIoO",
    "id" : 303929600084418560,
    "created_at" : "Tue Feb 19 18:10:38 +0000 2013",
    "user" : {
      "name" : "The Hacker Academy",
      "screen_name" : "hackeracademy",
      "protected" : false,
      "id_str" : "41374518",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/1168621468/thaTwitLogo_normal.jpg",
      "id" : 41374518,
      "verified" : false
    }
  },
  "id" : 304001631241007105,
  "created_at" : "Tue Feb 19 22:56:51 +0000 2013",
  "user" : {
    "name" : "Felix",
    "screen_name" : "nicidienase",
    "protected" : false,
    "id_str" : "22396883",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3125784966/8223a4c5c9535be22d15c82ec829c2df_normal.jpeg",
    "id" : 22396883,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.tweetlanes.com\" rel=\"nofollow\">Tweet Lanes for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Darth Vader",
      "screen_name" : "DepressedDarth",
      "indices" : [ 3, 18 ],
      "id_str" : "125122481",
      "id" : 125122481
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "302960237701382144",
  "text" : "RT @DepressedDarth: Dear JJ Abrams,\n\nIf you screw up the new Star Wars movie, I will start calling you Jar Jar Abrams.\n\nSincerely,\n\nDarth.",
  "retweeted_status" : {
    "source" : "web",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : {
    },
    "id_str" : "302817666001948672",
    "text" : "Dear JJ Abrams,\n\nIf you screw up the new Star Wars movie, I will start calling you Jar Jar Abrams.\n\nSincerely,\n\nDarth.",
    "id" : 302817666001948672,
    "created_at" : "Sat Feb 16 16:32:12 +0000 2013",
    "user" : {
      "name" : "Darth Vader",
      "screen_name" : "DepressedDarth",
      "protected" : false,
      "id_str" : "125122481",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/1125323984/darthvader_normal.jpg",
      "id" : 125122481,
      "verified" : false
    }
  },
  "id" : 302960237701382144,
  "created_at" : "Sun Feb 17 01:58:44 +0000 2013",
  "user" : {
    "name" : "Felix",
    "screen_name" : "nicidienase",
    "protected" : false,
    "id_str" : "22396883",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3125784966/8223a4c5c9535be22d15c82ec829c2df_normal.jpeg",
    "id" : 22396883,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.tweetlanes.com\" rel=\"nofollow\">Tweet Lanes for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mikael",
      "screen_name" : "ill_defined",
      "indices" : [ 3, 15 ],
      "id_str" : "938803867",
      "id" : 938803867
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "302958998590726144",
  "text" : "RT @ill_defined: Studenten der F\u00E4cher, die mit \u201EWirtschafts-\u201C beginnen, kann ich nicht ernst nehmen.",
  "retweeted_status" : {
    "source" : "web",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : {
    },
    "id_str" : "302759677383557120",
    "text" : "Studenten der F\u00E4cher, die mit \u201EWirtschafts-\u201C beginnen, kann ich nicht ernst nehmen.",
    "id" : 302759677383557120,
    "created_at" : "Sat Feb 16 12:41:46 +0000 2013",
    "user" : {
      "name" : "Mikael",
      "screen_name" : "ill_defined",
      "protected" : false,
      "id_str" : "938803867",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/2830742885/3e6d77e2be43c6b19e9c49a5372d2617_normal.png",
      "id" : 938803867,
      "verified" : false
    }
  },
  "id" : 302958998590726144,
  "created_at" : "Sun Feb 17 01:53:48 +0000 2013",
  "user" : {
    "name" : "Felix",
    "screen_name" : "nicidienase",
    "protected" : false,
    "id_str" : "22396883",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3125784966/8223a4c5c9535be22d15c82ec829c2df_normal.jpeg",
    "id" : 22396883,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.tweetlanes.com\" rel=\"nofollow\">Tweet Lanes for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Chrissie",
      "screen_name" : "SuddenGrey",
      "indices" : [ 49, 60 ],
      "id_str" : "99951977",
      "id" : 99951977
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 98, 118 ],
      "url" : "http://t.co/aCG4zI3p",
      "expanded_url" : "http://www.youtube.com/watch?v=PpccpglnNf0&feature=share",
      "display_url" : "youtube.com/watch?v=Ppccpg\u2026"
    } ]
  },
  "geo" : {
  },
  "id_str" : "302547561158438912",
  "text" : "Ich lach mich schlapp. Das letzte is das beste. \"@SuddenGrey: Ich heul gleich XD Ist das geil!!!! http://t.co/aCG4zI3p HAHAHA\"",
  "id" : 302547561158438912,
  "created_at" : "Fri Feb 15 22:38:54 +0000 2013",
  "user" : {
    "name" : "Felix",
    "screen_name" : "nicidienase",
    "protected" : false,
    "id_str" : "22396883",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3125784966/8223a4c5c9535be22d15c82ec829c2df_normal.jpeg",
    "id" : 22396883,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.tweetlanes.com\" rel=\"nofollow\">Tweet Lanes for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Iddo Friedberg",
      "screen_name" : "iddux",
      "indices" : [ 3, 9 ],
      "id_str" : "15276911",
      "id" : 15276911
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 33, 53 ],
      "url" : "http://t.co/qAasFmGd",
      "expanded_url" : "http://i.imgur.com/tc0VMmD.png",
      "display_url" : "i.imgur.com/tc0VMmD.png"
    } ]
  },
  "geo" : {
  },
  "id_str" : "302471722236534786",
  "text" : "RT @iddux: Seems relevant today: http://t.co/qAasFmGd",
  "retweeted_status" : {
    "source" : "<a href=\"http://www.tweetdeck.com\" rel=\"nofollow\">TweetDeck</a>",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 22, 42 ],
        "url" : "http://t.co/qAasFmGd",
        "expanded_url" : "http://i.imgur.com/tc0VMmD.png",
        "display_url" : "i.imgur.com/tc0VMmD.png"
      } ]
    },
    "geo" : {
    },
    "id_str" : "302445831716483072",
    "text" : "Seems relevant today: http://t.co/qAasFmGd",
    "id" : 302445831716483072,
    "created_at" : "Fri Feb 15 15:54:40 +0000 2013",
    "user" : {
      "name" : "Iddo Friedberg",
      "screen_name" : "iddux",
      "protected" : false,
      "id_str" : "15276911",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/2563352775/nsv4e01l3aqa0f2n3rsh_normal.png",
      "id" : 15276911,
      "verified" : false
    }
  },
  "id" : 302471722236534786,
  "created_at" : "Fri Feb 15 17:37:32 +0000 2013",
  "user" : {
    "name" : "Felix",
    "screen_name" : "nicidienase",
    "protected" : false,
    "id_str" : "22396883",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3125784966/8223a4c5c9535be22d15c82ec829c2df_normal.jpeg",
    "id" : 22396883,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.tweetlanes.com\" rel=\"nofollow\">Tweet Lanes for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Das Sofakissen",
      "screen_name" : "sofakissen",
      "indices" : [ 3, 14 ],
      "id_str" : "16084074",
      "id" : 16084074
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "302461621245181952",
  "text" : "RT @sofakissen: Kommt ein Pferd in die Bar. Sagt der Barkeeper: \"Warum so ein lasagnes Gesicht?\"",
  "retweeted_status" : {
    "source" : "<a href=\"http://www.tweetdeck.com\" rel=\"nofollow\">TweetDeck</a>",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : {
    },
    "id_str" : "302419357152198656",
    "text" : "Kommt ein Pferd in die Bar. Sagt der Barkeeper: \"Warum so ein lasagnes Gesicht?\"",
    "id" : 302419357152198656,
    "created_at" : "Fri Feb 15 14:09:28 +0000 2013",
    "user" : {
      "name" : "Das Sofakissen",
      "screen_name" : "sofakissen",
      "protected" : false,
      "id_str" : "16084074",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/2903267134/d52123f1486111302bf0cb277a671267_normal.png",
      "id" : 16084074,
      "verified" : false
    }
  },
  "id" : 302461621245181952,
  "created_at" : "Fri Feb 15 16:57:24 +0000 2013",
  "user" : {
    "name" : "Felix",
    "screen_name" : "nicidienase",
    "protected" : false,
    "id_str" : "22396883",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3125784966/8223a4c5c9535be22d15c82ec829c2df_normal.jpeg",
    "id" : 22396883,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.tweetlanes.com\" rel=\"nofollow\">Tweet Lanes for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Senficon",
      "screen_name" : "Senficon",
      "indices" : [ 3, 12 ],
      "id_str" : "14861745",
      "id" : 14861745
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 39, 59 ],
      "url" : "http://t.co/WU9wG17w",
      "expanded_url" : "http://i.imgur.com/eKgAP6O.jpg",
      "display_url" : "i.imgur.com/eKgAP6O.jpg"
    } ]
  },
  "geo" : {
  },
  "id_str" : "301850840925364224",
  "text" : "RT @Senficon: Wie genial ist das denn? http://t.co/WU9wG17w  Aber wenn ich versuche, diesen Trend zu starten, schaut man mich sicher doo ...",
  "retweeted_status" : {
    "source" : "web",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 25, 45 ],
        "url" : "http://t.co/WU9wG17w",
        "expanded_url" : "http://i.imgur.com/eKgAP6O.jpg",
        "display_url" : "i.imgur.com/eKgAP6O.jpg"
      } ]
    },
    "geo" : {
    },
    "id_str" : "301786782436032515",
    "text" : "Wie genial ist das denn? http://t.co/WU9wG17w  Aber wenn ich versuche, diesen Trend zu starten, schaut man mich sicher doof an.",
    "id" : 301786782436032515,
    "created_at" : "Wed Feb 13 20:15:50 +0000 2013",
    "user" : {
      "name" : "Senficon",
      "screen_name" : "Senficon",
      "protected" : false,
      "id_str" : "14861745",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/3420632576/3246dd64cd120b4b49b9a586cf7a6b56_normal.png",
      "id" : 14861745,
      "verified" : false
    }
  },
  "id" : 301850840925364224,
  "created_at" : "Thu Feb 14 00:30:23 +0000 2013",
  "user" : {
    "name" : "Felix",
    "screen_name" : "nicidienase",
    "protected" : false,
    "id_str" : "22396883",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3125784966/8223a4c5c9535be22d15c82ec829c2df_normal.jpeg",
    "id" : 22396883,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.tweetlanes.com\" rel=\"nofollow\">Tweet Lanes for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Martin Bottomley",
      "screen_name" : "_mfab",
      "indices" : [ 3, 9 ],
      "id_str" : "265044213",
      "id" : 265044213
    }, {
      "name" : "Anil Dash",
      "screen_name" : "anildash",
      "indices" : [ 30, 39 ],
      "id_str" : "36823",
      "id" : 36823
    }, {
      "name" : "The White House",
      "screen_name" : "whitehouse",
      "indices" : [ 61, 72 ],
      "id_str" : "30313925",
      "id" : 30313925
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "301510209464045569",
  "text" : "RT @_mfab: I'm speechless. RT @anildash: Oh shit, y'all: The @whitehouse has a DUBSTEP TRAILER for State of the Union speech. http://t.c ...",
  "retweeted_status" : {
    "source" : "<a href=\"http://www.tweetdeck.com\" rel=\"nofollow\">TweetDeck</a>",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Anil Dash",
        "screen_name" : "anildash",
        "indices" : [ 19, 28 ],
        "id_str" : "36823",
        "id" : 36823
      }, {
        "name" : "The White House",
        "screen_name" : "whitehouse",
        "indices" : [ 50, 61 ],
        "id_str" : "30313925",
        "id" : 30313925
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 115, 135 ],
        "url" : "http://t.co/nWJ1fHU0",
        "expanded_url" : "http://2.dashes.com/YaUSX3",
        "display_url" : "2.dashes.com/YaUSX3"
      } ]
    },
    "geo" : {
    },
    "id_str" : "301451508195676161",
    "text" : "I'm speechless. RT @anildash: Oh shit, y'all: The @whitehouse has a DUBSTEP TRAILER for State of the Union speech. http://t.co/nWJ1fHU0",
    "id" : 301451508195676161,
    "created_at" : "Tue Feb 12 22:03:34 +0000 2013",
    "user" : {
      "name" : "Martin Bottomley",
      "screen_name" : "_mfab",
      "protected" : false,
      "id_str" : "265044213",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/3149474062/6241d9234509f2583ee7206292975809_normal.jpeg",
      "id" : 265044213,
      "verified" : false
    }
  },
  "id" : 301510209464045569,
  "created_at" : "Wed Feb 13 01:56:50 +0000 2013",
  "user" : {
    "name" : "Felix",
    "screen_name" : "nicidienase",
    "protected" : false,
    "id_str" : "22396883",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3125784966/8223a4c5c9535be22d15c82ec829c2df_normal.jpeg",
    "id" : 22396883,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.tweetlanes.com\" rel=\"nofollow\">Tweet Lanes for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Uwe Lancier",
      "screen_name" : "Ulan_ka",
      "indices" : [ 3, 11 ],
      "id_str" : "379173142",
      "id" : 379173142
    }, {
      "name" : "Pope Francis",
      "screen_name" : "Pontifex",
      "indices" : [ 52, 61 ],
      "id_str" : "500704345",
      "id" : 500704345
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "301018226589057024",
  "text" : "RT @Ulan_ka: Und GOTT sprach: Ich stehe voll hinter @Pontifex er genie\u00DFt mein vollstes Vertrauen.",
  "retweeted_status" : {
    "source" : "web",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Pope Francis",
        "screen_name" : "Pontifex",
        "indices" : [ 39, 48 ],
        "id_str" : "500704345",
        "id" : 500704345
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : {
    },
    "id_str" : "300923034791985153",
    "text" : "Und GOTT sprach: Ich stehe voll hinter @Pontifex er genie\u00DFt mein vollstes Vertrauen.",
    "id" : 300923034791985153,
    "created_at" : "Mon Feb 11 11:03:37 +0000 2013",
    "user" : {
      "name" : "Uwe Lancier",
      "screen_name" : "Ulan_ka",
      "protected" : false,
      "id_str" : "379173142",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/1977104421/profile_normal.jpg",
      "id" : 379173142,
      "verified" : false
    }
  },
  "id" : 301018226589057024,
  "created_at" : "Mon Feb 11 17:21:52 +0000 2013",
  "user" : {
    "name" : "Felix",
    "screen_name" : "nicidienase",
    "protected" : false,
    "id_str" : "22396883",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3125784966/8223a4c5c9535be22d15c82ec829c2df_normal.jpeg",
    "id" : 22396883,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.tweetlanes.com\" rel=\"nofollow\">Tweet Lanes for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ingo Ebel",
      "screen_name" : "ingoebel",
      "indices" : [ 3, 12 ],
      "id_str" : "16783197",
      "id" : 16783197
    }, {
      "name" : "Marc \u2605\u2605\u2605\u2605\u2606  ",
      "screen_name" : "rb2k",
      "indices" : [ 25, 30 ],
      "id_str" : "4086651",
      "id" : 4086651
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "300602947891519488",
  "text" : "RT @ingoebel: Geil :) RT @rb2k: traceroute 216.81.59.173",
  "retweeted_status" : {
    "source" : "<a href=\"http://www.echofon.com/\" rel=\"nofollow\">Echofon</a>",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Marc \u2605\u2605\u2605\u2605\u2606  ",
        "screen_name" : "rb2k",
        "indices" : [ 11, 16 ],
        "id_str" : "4086651",
        "id" : 4086651
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : {
    },
    "id_str" : "300318489401491457",
    "text" : "Geil :) RT @rb2k: traceroute 216.81.59.173",
    "id" : 300318489401491457,
    "created_at" : "Sat Feb 09 19:01:22 +0000 2013",
    "user" : {
      "name" : "Ingo Ebel",
      "screen_name" : "ingoebel",
      "protected" : false,
      "id_str" : "16783197",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/3325056978/5e20813a082f848ee2ebd4e86e8882bb_normal.jpeg",
      "id" : 16783197,
      "verified" : false
    }
  },
  "id" : 300602947891519488,
  "created_at" : "Sun Feb 10 13:51:42 +0000 2013",
  "user" : {
    "name" : "Felix",
    "screen_name" : "nicidienase",
    "protected" : false,
    "id_str" : "22396883",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3125784966/8223a4c5c9535be22d15c82ec829c2df_normal.jpeg",
    "id" : 22396883,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.tweetlanes.com\" rel=\"nofollow\">Tweet Lanes for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "neingeist",
      "screen_name" : "neingeist",
      "indices" : [ 0, 10 ],
      "id_str" : "11193712",
      "id" : 11193712
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "299312782707412992",
  "geo" : {
  },
  "id_str" : "299323596784939008",
  "in_reply_to_user_id" : 11193712,
  "text" : "@neingeist Ich meine ich h\u00E4tte mal was von einer \"Seekuh\" geh\u00F6rt. Kann aber auch nur eine inoffizieller Name gewesen sein.",
  "id" : 299323596784939008,
  "in_reply_to_status_id" : 299312782707412992,
  "created_at" : "Thu Feb 07 01:08:01 +0000 2013",
  "in_reply_to_screen_name" : "neingeist",
  "in_reply_to_user_id_str" : "11193712",
  "user" : {
    "name" : "Felix",
    "screen_name" : "nicidienase",
    "protected" : false,
    "id_str" : "22396883",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3125784966/8223a4c5c9535be22d15c82ec829c2df_normal.jpeg",
    "id" : 22396883,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "God",
      "screen_name" : "TheTweetOfGod",
      "indices" : [ 3, 17 ],
      "id_str" : "204832963",
      "id" : 204832963
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "299297579005517825",
  "text" : "RT @TheTweetOfGod: \"Scientology\" is a combination of \"scient-,\" meaning \"science,\" and \"-ology,\" meaning \"science.\" And it just gets stu ...",
  "retweeted_status" : {
    "source" : "<a href=\"http://twitter.com/#!/download/ipad\" rel=\"nofollow\">Twitter for iPad</a>",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : {
    },
    "id_str" : "299223993783840769",
    "text" : "\"Scientology\" is a combination of \"scient-,\" meaning \"science,\" and \"-ology,\" meaning \"science.\" And it just gets stupider from there.",
    "id" : 299223993783840769,
    "created_at" : "Wed Feb 06 18:32:14 +0000 2013",
    "user" : {
      "name" : "God",
      "screen_name" : "TheTweetOfGod",
      "protected" : false,
      "id_str" : "204832963",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/2742932141/29629cdc8a95294b493a1ce79312ef63_normal.jpeg",
      "id" : 204832963,
      "verified" : false
    }
  },
  "id" : 299297579005517825,
  "created_at" : "Wed Feb 06 23:24:38 +0000 2013",
  "user" : {
    "name" : "Felix",
    "screen_name" : "nicidienase",
    "protected" : false,
    "id_str" : "22396883",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3125784966/8223a4c5c9535be22d15c82ec829c2df_normal.jpeg",
    "id" : 22396883,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.tweetlanes.com\" rel=\"nofollow\">Tweet Lanes for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "fukami",
      "screen_name" : "fukami",
      "indices" : [ 3, 10 ],
      "id_str" : "1209301",
      "id" : 1209301
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 66, 86 ],
      "url" : "http://t.co/qS2BvwuV",
      "expanded_url" : "http://www.youtube.com/watch?v=WqE9zIp0Muk",
      "display_url" : "youtube.com/watch?v=WqE9zI\u2026"
    } ]
  },
  "geo" : {
  },
  "id_str" : "298991783008948224",
  "text" : "RT @fukami: Das ist ja mal geil! Compressorheads \u201EBlitzkrieg Bop\u201D http://t.co/qS2BvwuV",
  "retweeted_status" : {
    "source" : "<a href=\"http://tapbots.com/software/tweetbot/mac\" rel=\"nofollow\">Tweetbot for Mac</a>",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 54, 74 ],
        "url" : "http://t.co/qS2BvwuV",
        "expanded_url" : "http://www.youtube.com/watch?v=WqE9zIp0Muk",
        "display_url" : "youtube.com/watch?v=WqE9zI\u2026"
      } ]
    },
    "geo" : {
    },
    "id_str" : "298930599450771456",
    "text" : "Das ist ja mal geil! Compressorheads \u201EBlitzkrieg Bop\u201D http://t.co/qS2BvwuV",
    "id" : 298930599450771456,
    "created_at" : "Tue Feb 05 23:06:23 +0000 2013",
    "user" : {
      "name" : "fukami",
      "screen_name" : "fukami",
      "protected" : false,
      "id_str" : "1209301",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/772745887/fukami-twitter_normal.jpg",
      "id" : 1209301,
      "verified" : false
    }
  },
  "id" : 298991783008948224,
  "created_at" : "Wed Feb 06 03:09:30 +0000 2013",
  "user" : {
    "name" : "Felix",
    "screen_name" : "nicidienase",
    "protected" : false,
    "id_str" : "22396883",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3125784966/8223a4c5c9535be22d15c82ec829c2df_normal.jpeg",
    "id" : 22396883,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.tweetlanes.com\" rel=\"nofollow\">Tweet Lanes for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kathrin Ganz",
      "screen_name" : "ihdl",
      "indices" : [ 3, 8 ],
      "id_str" : "14278506",
      "id" : 14278506
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "298989584396734464",
  "text" : "RT @ihdl: wenn irgendwann politiker_innen in die bredoullie kommen, weil sie ihren code nicht ordentlich dokumentiert haben, lache ich w ...",
  "retweeted_status" : {
    "source" : "<a href=\"http://www.echofon.com/\" rel=\"nofollow\">Echofon</a>",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : {
    },
    "id_str" : "298899082330648576",
    "text" : "wenn irgendwann politiker_innen in die bredoullie kommen, weil sie ihren code nicht ordentlich dokumentiert haben, lache ich wieder mit",
    "id" : 298899082330648576,
    "created_at" : "Tue Feb 05 21:01:09 +0000 2013",
    "user" : {
      "name" : "Kathrin Ganz",
      "screen_name" : "ihdl",
      "protected" : false,
      "id_str" : "14278506",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/1529694471/Bildschirmfoto_2011-09-05_um_14.52.04_normal.png",
      "id" : 14278506,
      "verified" : false
    }
  },
  "id" : 298989584396734464,
  "created_at" : "Wed Feb 06 03:00:46 +0000 2013",
  "user" : {
    "name" : "Felix",
    "screen_name" : "nicidienase",
    "protected" : false,
    "id_str" : "22396883",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3125784966/8223a4c5c9535be22d15c82ec829c2df_normal.jpeg",
    "id" : 22396883,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.tweetlanes.com\" rel=\"nofollow\">Tweet Lanes for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Eva Eichhorn",
      "screen_name" : "MamsellChaos",
      "indices" : [ 3, 16 ],
      "id_str" : "140774041",
      "id" : 140774041
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 59, 79 ],
      "url" : "http://t.co/sCxy73z6",
      "expanded_url" : "http://www.ebay.de/itm/300856918252?ssPageName=STRK:MESELX:IT&_trksid=p3984.m1555.l2649#ht_2340wt_1156",
      "display_url" : "ebay.de/itm/3008569182\u2026"
    } ]
  },
  "geo" : {
  },
  "id_str" : "298653440152834050",
  "text" : "RT @MamsellChaos: Will jemand von euch DEN Datenkraken? :D http://t.co/sCxy73z6",
  "retweeted_status" : {
    "source" : "<a href=\"http://tapbots.com/software/tweetbot/mac\" rel=\"nofollow\">Tweetbot for Mac</a>",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 41, 61 ],
        "url" : "http://t.co/sCxy73z6",
        "expanded_url" : "http://www.ebay.de/itm/300856918252?ssPageName=STRK:MESELX:IT&_trksid=p3984.m1555.l2649#ht_2340wt_1156",
        "display_url" : "ebay.de/itm/3008569182\u2026"
      } ]
    },
    "geo" : {
    },
    "id_str" : "298411242320699392",
    "text" : "Will jemand von euch DEN Datenkraken? :D http://t.co/sCxy73z6",
    "id" : 298411242320699392,
    "created_at" : "Mon Feb 04 12:42:39 +0000 2013",
    "user" : {
      "name" : "Eva Eichhorn",
      "screen_name" : "MamsellChaos",
      "protected" : false,
      "id_str" : "140774041",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/3231510280/b59cd7b5771078fb646882e5e5882940_normal.jpeg",
      "id" : 140774041,
      "verified" : false
    }
  },
  "id" : 298653440152834050,
  "created_at" : "Tue Feb 05 04:45:03 +0000 2013",
  "user" : {
    "name" : "Felix",
    "screen_name" : "nicidienase",
    "protected" : false,
    "id_str" : "22396883",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3125784966/8223a4c5c9535be22d15c82ec829c2df_normal.jpeg",
    "id" : 22396883,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.tweetlanes.com\" rel=\"nofollow\">Tweet Lanes for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Uwe Lancier",
      "screen_name" : "Ulan_ka",
      "indices" : [ 3, 11 ],
      "id_str" : "379173142",
      "id" : 379173142
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 69, 89 ],
      "url" : "http://t.co/RWSfi1Hw",
      "expanded_url" : "http://www.amazon.de/Nagelzange-Edelstahl-20/dp/B009J7526M/ref=sr_1_480?s=kitchen&ie=UTF8",
      "display_url" : "amazon.de/Nagelzange-Ede\u2026"
    } ]
  },
  "geo" : {
  },
  "id_str" : "297452437000814592",
  "text" : "RT @Ulan_ka: Amazon bietet Nagelzangen auch f\u00FCr hoffnungslose F\u00E4lle: http://t.co/RWSfi1Hw",
  "retweeted_status" : {
    "source" : "web",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 56, 76 ],
        "url" : "http://t.co/RWSfi1Hw",
        "expanded_url" : "http://www.amazon.de/Nagelzange-Edelstahl-20/dp/B009J7526M/ref=sr_1_480?s=kitchen&ie=UTF8",
        "display_url" : "amazon.de/Nagelzange-Ede\u2026"
      } ]
    },
    "geo" : {
    },
    "id_str" : "297338279001468930",
    "text" : "Amazon bietet Nagelzangen auch f\u00FCr hoffnungslose F\u00E4lle: http://t.co/RWSfi1Hw",
    "id" : 297338279001468930,
    "created_at" : "Fri Feb 01 13:39:04 +0000 2013",
    "user" : {
      "name" : "Uwe Lancier",
      "screen_name" : "Ulan_ka",
      "protected" : false,
      "id_str" : "379173142",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/1977104421/profile_normal.jpg",
      "id" : 379173142,
      "verified" : false
    }
  },
  "id" : 297452437000814592,
  "created_at" : "Fri Feb 01 21:12:42 +0000 2013",
  "user" : {
    "name" : "Felix",
    "screen_name" : "nicidienase",
    "protected" : false,
    "id_str" : "22396883",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3125784966/8223a4c5c9535be22d15c82ec829c2df_normal.jpeg",
    "id" : 22396883,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.tweetlanes.com\" rel=\"nofollow\">Tweet Lanes for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Guillermo Rauch",
      "screen_name" : "rauchg",
      "indices" : [ 3, 10 ],
      "id_str" : "15540222",
      "id" : 15540222
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "297439902260400129",
  "text" : "RT @rauchg: Just like `cd -`, `git checkout -` will take you to the previous branch you were on.",
  "retweeted_status" : {
    "source" : "web",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : {
    },
    "id_str" : "297094427451736064",
    "text" : "Just like `cd -`, `git checkout -` will take you to the previous branch you were on.",
    "id" : 297094427451736064,
    "created_at" : "Thu Jan 31 21:30:05 +0000 2013",
    "user" : {
      "name" : "Guillermo Rauch",
      "screen_name" : "rauchg",
      "protected" : false,
      "id_str" : "15540222",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/1867093513/photo_normal.png",
      "id" : 15540222,
      "verified" : false
    }
  },
  "id" : 297439902260400129,
  "created_at" : "Fri Feb 01 20:22:53 +0000 2013",
  "user" : {
    "name" : "Felix",
    "screen_name" : "nicidienase",
    "protected" : false,
    "id_str" : "22396883",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3125784966/8223a4c5c9535be22d15c82ec829c2df_normal.jpeg",
    "id" : 22396883,
    "verified" : false
  }
} ]