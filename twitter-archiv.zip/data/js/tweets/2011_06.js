Grailbird.data.tweets_2011_06 = 
 [ {
  "source" : "<a href=\"http://getspaz.com\" rel=\"nofollow\">Spaz</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Eve",
      "screen_name" : "ChiisanaIchigo",
      "indices" : [ 0, 15 ],
      "id_str" : "187553346",
      "id" : 187553346
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "80950162771554304",
  "geo" : {
  },
  "id_str" : "81003083529863169",
  "in_reply_to_user_id" : 187553346,
  "text" : "@ChiisanaIchigo Na dann musst du mal bissl Lobbying machen und die alle zu Jabber konvertieren!",
  "id" : 81003083529863169,
  "in_reply_to_status_id" : 80950162771554304,
  "created_at" : "Wed Jun 15 14:20:14 +0000 2011",
  "in_reply_to_screen_name" : "ChiisanaIchigo",
  "in_reply_to_user_id_str" : "187553346",
  "user" : {
    "name" : "Felix",
    "screen_name" : "nicidienase",
    "protected" : false,
    "id_str" : "22396883",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3125784966/8223a4c5c9535be22d15c82ec829c2df_normal.jpeg",
    "id" : 22396883,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://getspaz.com\" rel=\"nofollow\">Spaz</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sebastian",
      "screen_name" : "bastian83",
      "indices" : [ 3, 13 ],
      "id_str" : "19018639",
      "id" : 19018639
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "81001906478129153",
  "text" : "RT @bastian83: Today: Big Casting. Integers and Floats welcome",
  "retweeted_status" : {
    "source" : "<a href=\"http://itunes.apple.com/us/app/twitter/id409789998?mt=12\" rel=\"nofollow\">Twitter for Mac</a>",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : {
    },
    "id_str" : "80896959711428608",
    "text" : "Today: Big Casting. Integers and Floats welcome",
    "id" : 80896959711428608,
    "created_at" : "Wed Jun 15 07:18:32 +0000 2011",
    "user" : {
      "name" : "Sebastian",
      "screen_name" : "bastian83",
      "protected" : false,
      "id_str" : "19018639",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/512477337/Foto-am-07-09-2009-um-14.37_normal.jpg",
      "id" : 19018639,
      "verified" : false
    }
  },
  "id" : 81001906478129153,
  "created_at" : "Wed Jun 15 14:15:34 +0000 2011",
  "user" : {
    "name" : "Felix",
    "screen_name" : "nicidienase",
    "protected" : false,
    "id_str" : "22396883",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3125784966/8223a4c5c9535be22d15c82ec829c2df_normal.jpeg",
    "id" : 22396883,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://getspaz.com\" rel=\"nofollow\">Spaz</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Eve",
      "screen_name" : "ChiisanaIchigo",
      "indices" : [ 0, 15 ],
      "id_str" : "187553346",
      "id" : 187553346
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "80662083410206720",
  "geo" : {
  },
  "id_str" : "80752314494889984",
  "in_reply_to_user_id" : 187553346,
  "text" : "@ChiisanaIchigo Wer benutzt den auch noch MSN??",
  "id" : 80752314494889984,
  "in_reply_to_status_id" : 80662083410206720,
  "created_at" : "Tue Jun 14 21:43:46 +0000 2011",
  "in_reply_to_screen_name" : "ChiisanaIchigo",
  "in_reply_to_user_id_str" : "187553346",
  "user" : {
    "name" : "Felix",
    "screen_name" : "nicidienase",
    "protected" : false,
    "id_str" : "22396883",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3125784966/8223a4c5c9535be22d15c82ec829c2df_normal.jpeg",
    "id" : 22396883,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://getspaz.com\" rel=\"nofollow\">Spaz</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Matthew de Carteret",
      "screen_name" : "lordparody",
      "indices" : [ 3, 14 ],
      "id_str" : "20744958",
      "id" : 20744958
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "80390548908806144",
  "text" : "RT @lordparody: My new security slogan. \"Better Safe Than Sony\"",
  "retweeted_status" : {
    "source" : "<a href=\"http://www.tweetdeck.com\" rel=\"nofollow\">TweetDeck</a>",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : {
    },
    "id_str" : "71508473011113985",
    "text" : "My new security slogan. \"Better Safe Than Sony\"",
    "id" : 71508473011113985,
    "created_at" : "Fri May 20 09:32:03 +0000 2011",
    "user" : {
      "name" : "Matthew de Carteret",
      "screen_name" : "lordparody",
      "protected" : false,
      "id_str" : "20744958",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/1611803358/sylly1_normal.JPG",
      "id" : 20744958,
      "verified" : false
    }
  },
  "id" : 80390548908806144,
  "created_at" : "Mon Jun 13 21:46:15 +0000 2011",
  "user" : {
    "name" : "Felix",
    "screen_name" : "nicidienase",
    "protected" : false,
    "id_str" : "22396883",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3125784966/8223a4c5c9535be22d15c82ec829c2df_normal.jpeg",
    "id" : 22396883,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://getspaz.com\" rel=\"nofollow\">Spaz</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "h0uz3",
      "screen_name" : "h0uz3",
      "indices" : [ 3, 9 ],
      "id_str" : "15730216",
      "id" : 15730216
    }, {
      "name" : "shackspace",
      "screen_name" : "shackspace",
      "indices" : [ 41, 52 ],
      "id_str" : "106674917",
      "id" : 106674917
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "79883970875109376",
  "text" : "RT @h0uz3: Das Video mit dem Rundgang im @shackspace ist nun online: http://vimeo.com/24981263",
  "retweeted_status" : {
    "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Tweetie for Mac</a>",
    "entities" : {
      "user_mentions" : [ {
        "name" : "shackspace",
        "screen_name" : "shackspace",
        "indices" : [ 30, 41 ],
        "id_str" : "106674917",
        "id" : 106674917
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : {
    },
    "id_str" : "79811299109908480",
    "text" : "Das Video mit dem Rundgang im @shackspace ist nun online: http://vimeo.com/24981263",
    "id" : 79811299109908480,
    "created_at" : "Sun Jun 12 07:24:31 +0000 2011",
    "user" : {
      "name" : "h0uz3",
      "screen_name" : "h0uz3",
      "protected" : false,
      "id_str" : "15730216",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/1511702544/myPony_normal.png",
      "id" : 15730216,
      "verified" : false
    }
  },
  "id" : 79883970875109376,
  "created_at" : "Sun Jun 12 12:13:17 +0000 2011",
  "user" : {
    "name" : "Felix",
    "screen_name" : "nicidienase",
    "protected" : false,
    "id_str" : "22396883",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3125784966/8223a4c5c9535be22d15c82ec829c2df_normal.jpeg",
    "id" : 22396883,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://getspaz.com\" rel=\"nofollow\">Spaz</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ulf",
      "screen_name" : "Kulf",
      "indices" : [ 3, 8 ],
      "id_str" : "20429503",
      "id" : 20429503
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "79882248240898048",
  "text" : "RT @Kulf: Erst wenn der letzte Programmierer eingesperrt und die letzte Idee patentiert ist, werdet ihr merken, da\u00DF Anw\u00E4lte nicht progra ...",
  "retweeted_status" : {
    "source" : "<a href=\"http://carbonwebos.com\" rel=\"nofollow\">Carbon for webOS</a>",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : {
    },
    "id_str" : "79530044170571776",
    "text" : "Erst wenn der letzte Programmierer eingesperrt und die letzte Idee patentiert ist, werdet ihr merken, da\u00DF Anw\u00E4lte nicht programmieren k\u00F6nnen",
    "id" : 79530044170571776,
    "created_at" : "Sat Jun 11 12:46:54 +0000 2011",
    "user" : {
      "name" : "Ulf",
      "screen_name" : "Kulf",
      "protected" : false,
      "id_str" : "20429503",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/1391245005/b971aa93-27f5-4811-ab4e-03ee9ea96175_normal.png",
      "id" : 20429503,
      "verified" : false
    }
  },
  "id" : 79882248240898048,
  "created_at" : "Sun Jun 12 12:06:26 +0000 2011",
  "user" : {
    "name" : "Felix",
    "screen_name" : "nicidienase",
    "protected" : false,
    "id_str" : "22396883",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3125784966/8223a4c5c9535be22d15c82ec829c2df_normal.jpeg",
    "id" : 22396883,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.bravenewcode.com/products/wordtwit\" rel=\"nofollow\">WordTwit Plugin</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "79560696358113280",
  "text" : "Neuer Blog Beitrag, Meine neue SSD - http://tinyurl.com/62tt24u",
  "id" : 79560696358113280,
  "created_at" : "Sat Jun 11 14:48:42 +0000 2011",
  "user" : {
    "name" : "Felix",
    "screen_name" : "nicidienase",
    "protected" : false,
    "id_str" : "22396883",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3125784966/8223a4c5c9535be22d15c82ec829c2df_normal.jpeg",
    "id" : 22396883,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://getspaz.com\" rel=\"nofollow\">Spaz</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "neingeist",
      "screen_name" : "neingeist",
      "indices" : [ 3, 13 ],
      "id_str" : "11193712",
      "id" : 11193712
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "gpn11",
      "indices" : [ 61, 67 ]
    } ],
    "urls" : [ {
      "indices" : [ 69, 88 ],
      "url" : "http://t.co/FoJ6ySk",
      "expanded_url" : "http://twitpic.com/59iufn",
      "display_url" : "twitpic.com/59iufn"
    } ]
  },
  "geo" : {
  },
  "id_str" : "79360071850668033",
  "text" : "RT @neingeist: Auch die Treppe macht bereits Werbung f\u00FCr die #gpn11. http://t.co/FoJ6ySk",
  "retweeted_status" : {
    "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "gpn11",
        "indices" : [ 46, 52 ]
      } ],
      "urls" : [ {
        "indices" : [ 54, 73 ],
        "url" : "http://t.co/FoJ6ySk",
        "expanded_url" : "http://twitpic.com/59iufn",
        "display_url" : "twitpic.com/59iufn"
      } ]
    },
    "geo" : {
    },
    "id_str" : "79162283758071808",
    "text" : "Auch die Treppe macht bereits Werbung f\u00FCr die #gpn11. http://t.co/FoJ6ySk",
    "id" : 79162283758071808,
    "created_at" : "Fri Jun 10 12:25:33 +0000 2011",
    "user" : {
      "name" : "neingeist",
      "screen_name" : "neingeist",
      "protected" : false,
      "id_str" : "11193712",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/3506751329/a8c317b7b69ff0f8eef00b9cb842cbc0_normal.png",
      "id" : 11193712,
      "verified" : false
    }
  },
  "id" : 79360071850668033,
  "created_at" : "Sat Jun 11 01:31:30 +0000 2011",
  "user" : {
    "name" : "Felix",
    "screen_name" : "nicidienase",
    "protected" : false,
    "id_str" : "22396883",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3125784966/8223a4c5c9535be22d15c82ec829c2df_normal.jpeg",
    "id" : 22396883,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://getspaz.com\" rel=\"nofollow\">Spaz</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "S\u00F8ren",
      "screen_name" : "svindlerdk",
      "indices" : [ 3, 14 ],
      "id_str" : "17324679",
      "id" : 17324679
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "protolol",
      "indices" : [ 107, 116 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "78979595243765760",
  "text" : "RT @svindlerdk: There are 10 possibilities when you tell a binary joke. Either people get it or they don't #protolol",
  "retweeted_status" : {
    "source" : "<a href=\"http://www.tweetdeck.com\" rel=\"nofollow\">TweetDeck</a>",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "protolol",
        "indices" : [ 91, 100 ]
      } ],
      "urls" : [ ]
    },
    "geo" : {
    },
    "id_str" : "78826625449463809",
    "text" : "There are 10 possibilities when you tell a binary joke. Either people get it or they don't #protolol",
    "id" : 78826625449463809,
    "created_at" : "Thu Jun 09 14:11:46 +0000 2011",
    "user" : {
      "name" : "S\u00F8ren",
      "screen_name" : "svindlerdk",
      "protected" : false,
      "id_str" : "17324679",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/2602531627/6e359ymozyyjodg0a0wp_normal.jpeg",
      "id" : 17324679,
      "verified" : false
    }
  },
  "id" : 78979595243765760,
  "created_at" : "Fri Jun 10 00:19:37 +0000 2011",
  "user" : {
    "name" : "Felix",
    "screen_name" : "nicidienase",
    "protected" : false,
    "id_str" : "22396883",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3125784966/8223a4c5c9535be22d15c82ec829c2df_normal.jpeg",
    "id" : 22396883,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://getspaz.com\" rel=\"nofollow\">Spaz</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "monoxyd",
      "screen_name" : "monoxyd",
      "indices" : [ 14, 22 ],
      "id_str" : "14085052",
      "id" : 14085052
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "72593644191891457",
  "geo" : {
  },
  "id_str" : "78968892197830656",
  "in_reply_to_user_id" : 14085052,
  "text" : "Cool, ich bin @monoxyd 's 1000. Follower. Und merk das erst nach \u00FCber 2 Wochen. Ich muss wieder \u00F6fters Twitter lesen.",
  "id" : 78968892197830656,
  "in_reply_to_status_id" : 72593644191891457,
  "created_at" : "Thu Jun 09 23:37:05 +0000 2011",
  "in_reply_to_screen_name" : "monoxyd",
  "in_reply_to_user_id_str" : "14085052",
  "user" : {
    "name" : "Felix",
    "screen_name" : "nicidienase",
    "protected" : false,
    "id_str" : "22396883",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3125784966/8223a4c5c9535be22d15c82ec829c2df_normal.jpeg",
    "id" : 22396883,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "James Bladel",
      "screen_name" : "Bladel",
      "indices" : [ 3, 10 ],
      "id_str" : "17073304",
      "id" : 17073304
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "protolol",
      "indices" : [ 91, 100 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "77786476569567232",
  "text" : "RT @Bladel: The best thing about recursive jokes is the best thing about recursive jokes.  #protolol",
  "retweeted_status" : {
    "source" : "<a href=\"http://www.tweetdeck.com\" rel=\"nofollow\">TweetDeck</a>",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "protolol",
        "indices" : [ 79, 88 ]
      } ],
      "urls" : [ ]
    },
    "geo" : {
    },
    "id_str" : "77783441596350465",
    "text" : "The best thing about recursive jokes is the best thing about recursive jokes.  #protolol",
    "id" : 77783441596350465,
    "created_at" : "Mon Jun 06 17:06:32 +0000 2011",
    "user" : {
      "name" : "James Bladel",
      "screen_name" : "Bladel",
      "protected" : false,
      "id_str" : "17073304",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/2942672818/e93361e07feae736f71dbe54d03f5a6d_normal.jpeg",
      "id" : 17073304,
      "verified" : false
    }
  },
  "id" : 77786476569567232,
  "created_at" : "Mon Jun 06 17:18:35 +0000 2011",
  "user" : {
    "name" : "Felix",
    "screen_name" : "nicidienase",
    "protected" : false,
    "id_str" : "22396883",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3125784966/8223a4c5c9535be22d15c82ec829c2df_normal.jpeg",
    "id" : 22396883,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Yoz Grahame",
      "screen_name" : "yoz",
      "indices" : [ 3, 7 ],
      "id_str" : "12329",
      "id" : 12329
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "protolol",
      "indices" : [ 88, 97 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "77778805439205376",
  "text" : "RT @yoz: order best is tell that The you thing can about jokes BitTorrent  them in any. #protolol",
  "retweeted_status" : {
    "source" : "<a href=\"http://www.echofon.com/\" rel=\"nofollow\">Echofon</a>",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "protolol",
        "indices" : [ 79, 88 ]
      } ],
      "urls" : [ ]
    },
    "geo" : {
    },
    "id_str" : "77504565829836800",
    "text" : "order best is tell that The you thing can about jokes BitTorrent  them in any. #protolol",
    "id" : 77504565829836800,
    "created_at" : "Sun Jun 05 22:38:23 +0000 2011",
    "user" : {
      "name" : "Yoz Grahame",
      "screen_name" : "yoz",
      "protected" : false,
      "id_str" : "12329",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/2284692058/d1dnhhikm2n9d16jc2ku_normal.png",
      "id" : 12329,
      "verified" : false
    }
  },
  "id" : 77778805439205376,
  "created_at" : "Mon Jun 06 16:48:06 +0000 2011",
  "user" : {
    "name" : "Felix",
    "screen_name" : "nicidienase",
    "protected" : false,
    "id_str" : "22396883",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3125784966/8223a4c5c9535be22d15c82ec829c2df_normal.jpeg",
    "id" : 22396883,
    "verified" : false
  }
} ]