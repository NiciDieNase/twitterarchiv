Grailbird.data.tweets_2009_07 = 
 [ {
  "source" : "<a href=\"https://launchpad.net/gwibber/\" rel=\"nofollow\">Gwibber</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "2915207036",
  "text" : "Daheim in PF, aber net lang. So oder Mo gehts wieder zur\u00FCck nach KA zum Lernen.",
  "id" : 2915207036,
  "created_at" : "Wed Jul 29 19:25:17 +0000 2009",
  "user" : {
    "name" : "Felix",
    "screen_name" : "nicidienase",
    "protected" : false,
    "id_str" : "22396883",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3125784966/8223a4c5c9535be22d15c82ec829c2df_normal.jpeg",
    "id" : 22396883,
    "verified" : false
  }
}, {
  "source" : "<a href=\"https://launchpad.net/gwibber/\" rel=\"nofollow\">Gwibber</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tim Pritlove",
      "screen_name" : "timpritlove",
      "indices" : [ 3, 15 ],
      "id_str" : "11268812",
      "id" : 11268812
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Zensursula",
      "indices" : [ 57, 68 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "2783923308",
  "geo" : {
  },
  "id_str" : "2787243963",
  "in_reply_to_user_id" : 11268812,
  "text" : "RT @timpritlove: So h\u00E4tte eigentlich die Abstimmung \u00FCber #Zensursula im Bundestag laufen m\u00FCssen: http://bit.ly/161L6S",
  "id" : 2787243963,
  "in_reply_to_status_id" : 2783923308,
  "created_at" : "Wed Jul 22 23:00:45 +0000 2009",
  "in_reply_to_screen_name" : "timpritlove",
  "in_reply_to_user_id_str" : "11268812",
  "user" : {
    "name" : "Felix",
    "screen_name" : "nicidienase",
    "protected" : false,
    "id_str" : "22396883",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3125784966/8223a4c5c9535be22d15c82ec829c2df_normal.jpeg",
    "id" : 22396883,
    "verified" : false
  }
}, {
  "source" : "<a href=\"https://launchpad.net/gwibber/\" rel=\"nofollow\">Gwibber</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "thebigbangtheory",
      "indices" : [ 65, 82 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "2583466158",
  "text" : "Die deutsche Synchronstimme von Raj ist die schlimmste von allen #thebigbangtheory",
  "id" : 2583466158,
  "created_at" : "Sat Jul 11 13:16:29 +0000 2009",
  "user" : {
    "name" : "Felix",
    "screen_name" : "nicidienase",
    "protected" : false,
    "id_str" : "22396883",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3125784966/8223a4c5c9535be22d15c82ec829c2df_normal.jpeg",
    "id" : 22396883,
    "verified" : false
  }
}, {
  "source" : "<a href=\"https://launchpad.net/gwibber/\" rel=\"nofollow\">Gwibber</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "thebigbangtheory",
      "indices" : [ 0, 17 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "2583238068",
  "text" : "#thebigbangtheory: b\u00E4\u00E4\u00E4\u00E4h die deutsche Synchro is ja gr\u00E4sslich",
  "id" : 2583238068,
  "created_at" : "Sat Jul 11 12:48:33 +0000 2009",
  "user" : {
    "name" : "Felix",
    "screen_name" : "nicidienase",
    "protected" : false,
    "id_str" : "22396883",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3125784966/8223a4c5c9535be22d15c82ec829c2df_normal.jpeg",
    "id" : 22396883,
    "verified" : false
  }
}, {
  "source" : "<a href=\"https://launchpad.net/gwibber/\" rel=\"nofollow\">Gwibber</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "thebigbangtheory",
      "indices" : [ 25, 42 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "2488417683",
  "text" : "N\u00E4chsten Samstag startet #thebigbangtheory auf pro7, bin mal gespannt ob die deutsche Synchro was taugt",
  "id" : 2488417683,
  "created_at" : "Sun Jul 05 23:00:51 +0000 2009",
  "user" : {
    "name" : "Felix",
    "screen_name" : "nicidienase",
    "protected" : false,
    "id_str" : "22396883",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3125784966/8223a4c5c9535be22d15c82ec829c2df_normal.jpeg",
    "id" : 22396883,
    "verified" : false
  }
}, {
  "source" : "<a href=\"https://launchpad.net/gwibber/\" rel=\"nofollow\">Gwibber</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "piraten",
      "indices" : [ 0, 8 ]
    }, {
      "text" : "gr\u00FCne",
      "indices" : [ 10, 16 ]
    }, {
      "text" : "cdu",
      "indices" : [ 18, 22 ]
    }, {
      "text" : "csu",
      "indices" : [ 24, 28 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "2456463790",
  "text" : "#piraten+ #gr\u00FCne+ #cdu- #csu-",
  "id" : 2456463790,
  "created_at" : "Fri Jul 03 16:58:29 +0000 2009",
  "user" : {
    "name" : "Felix",
    "screen_name" : "nicidienase",
    "protected" : false,
    "id_str" : "22396883",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3125784966/8223a4c5c9535be22d15c82ec829c2df_normal.jpeg",
    "id" : 22396883,
    "verified" : false
  }
} ]