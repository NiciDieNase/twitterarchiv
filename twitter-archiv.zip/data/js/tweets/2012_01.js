Grailbird.data.tweets_2012_01 = 
 [ {
  "source" : "<a href=\"http://getspaz.com\" rel=\"nofollow\">Spaz</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 50, 70 ],
      "url" : "http://t.co/nUG3e5Dv",
      "expanded_url" : "http://twitpic.com/8dqge5",
      "display_url" : "twitpic.com/8dqge5"
    } ]
  },
  "geo" : {
  },
  "id_str" : "164111981962469376",
  "text" : "Soll ich mich auch mal so ne Nerd-Brille zulegen? http://t.co/nUG3e5Dv",
  "id" : 164111981962469376,
  "created_at" : "Mon Jan 30 22:25:20 +0000 2012",
  "user" : {
    "name" : "Felix",
    "screen_name" : "nicidienase",
    "protected" : false,
    "id_str" : "22396883",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3125784966/8223a4c5c9535be22d15c82ec829c2df_normal.jpeg",
    "id" : 22396883,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://getspaz.com\" rel=\"nofollow\">Spaz HD for webOS</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "maltejk",
      "screen_name" : "maltejk",
      "indices" : [ 3, 11 ],
      "id_str" : "66683044",
      "id" : 66683044
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "vds",
      "indices" : [ 89, 93 ]
    }, {
      "text" : "ac",
      "indices" : [ 133, 136 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "164004233081925633",
  "text" : "RT @maltejk: Oh, Erpresser in Brandenburg gerade wegen seinem Mobiltelefon geortet. Ohne #vds. Merkste wat? Genau, braucht man nich. #ac ...",
  "retweeted_status" : {
    "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "vds",
        "indices" : [ 76, 80 ]
      }, {
        "text" : "acta",
        "indices" : [ 120, 125 ]
      } ],
      "urls" : [ ]
    },
    "geo" : {
    },
    "id_str" : "163985955890532355",
    "text" : "Oh, Erpresser in Brandenburg gerade wegen seinem Mobiltelefon geortet. Ohne #vds. Merkste wat? Genau, braucht man nich. #acta auch nicht.",
    "id" : 163985955890532355,
    "created_at" : "Mon Jan 30 14:04:33 +0000 2012",
    "user" : {
      "name" : "maltejk",
      "screen_name" : "maltejk",
      "protected" : false,
      "id_str" : "66683044",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/1756449114/epic_twitter_kittah_by_dino_kleinerdrei_normal.png",
      "id" : 66683044,
      "verified" : false
    }
  },
  "id" : 164004233081925633,
  "created_at" : "Mon Jan 30 15:17:10 +0000 2012",
  "user" : {
    "name" : "Felix",
    "screen_name" : "nicidienase",
    "protected" : false,
    "id_str" : "22396883",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3125784966/8223a4c5c9535be22d15c82ec829c2df_normal.jpeg",
    "id" : 22396883,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://getspaz.com\" rel=\"nofollow\">Spaz</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tim Pritlove",
      "screen_name" : "timpritlove",
      "indices" : [ 3, 15 ],
      "id_str" : "11268812",
      "id" : 11268812
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 25, 45 ],
      "url" : "http://t.co/T4HYf34X",
      "expanded_url" : "http://www.flickr.com/photos/lasern/6783837177/in/photostream/lightbox/",
      "display_url" : "flickr.com/photos/lasern/\u2026"
    }, {
      "indices" : [ 55, 75 ],
      "url" : "http://t.co/RNYIbDp8",
      "expanded_url" : "http://www.flickr.com/photos/lasern/6783829829/in/photostream/lightbox/",
      "display_url" : "flickr.com/photos/lasern/\u2026"
    } ]
  },
  "geo" : {
  },
  "id_str" : "163801696143806465",
  "text" : "RT @timpritlove: Vorher: http://t.co/T4HYf34X Nachher: http://t.co/RNYIbDp8",
  "retweeted_status" : {
    "source" : "<a href=\"http://www.echofon.com/\" rel=\"nofollow\">Echofon</a>",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 8, 28 ],
        "url" : "http://t.co/T4HYf34X",
        "expanded_url" : "http://www.flickr.com/photos/lasern/6783837177/in/photostream/lightbox/",
        "display_url" : "flickr.com/photos/lasern/\u2026"
      }, {
        "indices" : [ 38, 58 ],
        "url" : "http://t.co/RNYIbDp8",
        "expanded_url" : "http://www.flickr.com/photos/lasern/6783829829/in/photostream/lightbox/",
        "display_url" : "flickr.com/photos/lasern/\u2026"
      } ]
    },
    "geo" : {
    },
    "id_str" : "163798706070626304",
    "text" : "Vorher: http://t.co/T4HYf34X Nachher: http://t.co/RNYIbDp8",
    "id" : 163798706070626304,
    "created_at" : "Mon Jan 30 01:40:29 +0000 2012",
    "user" : {
      "name" : "Tim Pritlove",
      "screen_name" : "timpritlove",
      "protected" : false,
      "id_str" : "11268812",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/2332275606/Tim_Pritlove_2009_Avatar_512x512_normal.jpg",
      "id" : 11268812,
      "verified" : true
    }
  },
  "id" : 163801696143806465,
  "created_at" : "Mon Jan 30 01:52:22 +0000 2012",
  "user" : {
    "name" : "Felix",
    "screen_name" : "nicidienase",
    "protected" : false,
    "id_str" : "22396883",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3125784966/8223a4c5c9535be22d15c82ec829c2df_normal.jpeg",
    "id" : 22396883,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://getspaz.com\" rel=\"nofollow\">Spaz HD for webOS</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 75, 95 ],
      "url" : "http://t.co/OkEbL9nI",
      "expanded_url" : "http://james-iry.blogspot.com/2009/05/brief-incomplete-and-mostly-wrong.html",
      "display_url" : "james-iry.blogspot.com/2009/05/brief-\u2026"
    } ]
  },
  "geo" : {
  },
  "id_str" : "162493733697372160",
  "text" : "\"A Brief, Incomplete, and Mostly Wrong History of Programming Languages\" - http://t.co/OkEbL9nI",
  "id" : 162493733697372160,
  "created_at" : "Thu Jan 26 11:14:59 +0000 2012",
  "user" : {
    "name" : "Felix",
    "screen_name" : "nicidienase",
    "protected" : false,
    "id_str" : "22396883",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3125784966/8223a4c5c9535be22d15c82ec829c2df_normal.jpeg",
    "id" : 22396883,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://getspaz.com\" rel=\"nofollow\">Spaz</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "162202428907855873",
  "text" : "Yeay, letztes Labor ausm 2. Semester abgegeben. Endlich das Grundstudium fertig.",
  "id" : 162202428907855873,
  "created_at" : "Wed Jan 25 15:57:27 +0000 2012",
  "user" : {
    "name" : "Felix",
    "screen_name" : "nicidienase",
    "protected" : false,
    "id_str" : "22396883",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3125784966/8223a4c5c9535be22d15c82ec829c2df_normal.jpeg",
    "id" : 22396883,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://getspaz.com\" rel=\"nofollow\">Spaz HD for webOS</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Not Safe For Work",
      "screen_name" : "me_nsfw",
      "indices" : [ 37, 45 ],
      "id_str" : "198895800",
      "id" : 198895800
    }, {
      "name" : "CRE",
      "screen_name" : "me_CRE",
      "indices" : [ 89, 96 ],
      "id_str" : "185611778",
      "id" : 185611778
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "162172663689773056",
  "text" : "Ich freu mich ja \u00FCber die neue Folge @me_nsfw aber ich hab noch so viel ungeh\u00F6rte Folgen @me_cre",
  "id" : 162172663689773056,
  "created_at" : "Wed Jan 25 13:59:10 +0000 2012",
  "user" : {
    "name" : "Felix",
    "screen_name" : "nicidienase",
    "protected" : false,
    "id_str" : "22396883",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3125784966/8223a4c5c9535be22d15c82ec829c2df_normal.jpeg",
    "id" : 22396883,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://getspaz.com\" rel=\"nofollow\">Spaz</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "psy",
      "screen_name" : "psycon",
      "indices" : [ 3, 10 ],
      "id_str" : "87286054",
      "id" : 87286054
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 57, 77 ],
      "url" : "http://t.co/VTeTEl9q",
      "expanded_url" : "http://www.kreartivfabrik.de/static/portfolio/Postkarte-Hobbys-print_Seite_1_jpg_600x600_q85.jpg",
      "display_url" : "kreartivfabrik.de/static/portfol\u2026"
    } ]
  },
  "geo" : {
  },
  "id_str" : "161594282657054720",
  "text" : "RT @psycon: \"Hobbys? Halts Maul! Ich studier' Bachelor!\" http://t.co/VTeTEl9q",
  "retweeted_status" : {
    "source" : "web",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 45, 65 ],
        "url" : "http://t.co/VTeTEl9q",
        "expanded_url" : "http://www.kreartivfabrik.de/static/portfolio/Postkarte-Hobbys-print_Seite_1_jpg_600x600_q85.jpg",
        "display_url" : "kreartivfabrik.de/static/portfol\u2026"
      } ]
    },
    "geo" : {
    },
    "id_str" : "161562420110819328",
    "text" : "\"Hobbys? Halts Maul! Ich studier' Bachelor!\" http://t.co/VTeTEl9q",
    "id" : 161562420110819328,
    "created_at" : "Mon Jan 23 21:34:17 +0000 2012",
    "user" : {
      "name" : "psy",
      "screen_name" : "psycon",
      "protected" : false,
      "id_str" : "87286054",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/2620981046/xkjfqh2iy0xp1lxx6cl1_normal.jpeg",
      "id" : 87286054,
      "verified" : false
    }
  },
  "id" : 161594282657054720,
  "created_at" : "Mon Jan 23 23:40:53 +0000 2012",
  "user" : {
    "name" : "Felix",
    "screen_name" : "nicidienase",
    "protected" : false,
    "id_str" : "22396883",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3125784966/8223a4c5c9535be22d15c82ec829c2df_normal.jpeg",
    "id" : 22396883,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://getspaz.com\" rel=\"nofollow\">Spaz</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Andre Martens",
      "screen_name" : "Brainvibes",
      "indices" : [ 3, 14 ],
      "id_str" : "50991083",
      "id" : 50991083
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "161594095704350721",
  "text" : "RT @Brainvibes: Kaum nimmt Guttenberg kein Haargel mehr, geht Schlecker pleite. Das kann kein Zufall sein!",
  "retweeted_status" : {
    "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : {
    },
    "id_str" : "161004429439549440",
    "text" : "Kaum nimmt Guttenberg kein Haargel mehr, geht Schlecker pleite. Das kann kein Zufall sein!",
    "id" : 161004429439549440,
    "created_at" : "Sun Jan 22 08:37:01 +0000 2012",
    "user" : {
      "name" : "Andre Martens",
      "screen_name" : "Brainvibes",
      "protected" : false,
      "id_str" : "50991083",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/3502586705/4ad2c2696dacf52c49d3b58f54b2c14f_normal.jpeg",
      "id" : 50991083,
      "verified" : false
    }
  },
  "id" : 161594095704350721,
  "created_at" : "Mon Jan 23 23:40:09 +0000 2012",
  "user" : {
    "name" : "Felix",
    "screen_name" : "nicidienase",
    "protected" : false,
    "id_str" : "22396883",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3125784966/8223a4c5c9535be22d15c82ec829c2df_normal.jpeg",
    "id" : 22396883,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://getspaz.com\" rel=\"nofollow\">Spaz</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "160791517231984640",
  "text" : "Physikertheater. Der Gaede-H\u00F6rsaal ist mal wieder brechend voll.",
  "id" : 160791517231984640,
  "created_at" : "Sat Jan 21 18:30:59 +0000 2012",
  "user" : {
    "name" : "Felix",
    "screen_name" : "nicidienase",
    "protected" : false,
    "id_str" : "22396883",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3125784966/8223a4c5c9535be22d15c82ec829c2df_normal.jpeg",
    "id" : 22396883,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://getspaz.com\" rel=\"nofollow\">Spaz</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Holger Klein",
      "screen_name" : "holgi",
      "indices" : [ 3, 9 ],
      "id_str" : "3068271",
      "id" : 3068271
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "160412071584993281",
  "text" : "RT @holgi: \"I am the king of nerds. If anyone displeases me, i don't help them setup their printer.\" (L. Hofstadter)",
  "retweeted_status" : {
    "source" : "<a href=\"http://www.echofon.com/\" rel=\"nofollow\">Echofon</a>",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : {
    },
    "id_str" : "160367601057411072",
    "text" : "\"I am the king of nerds. If anyone displeases me, i don't help them setup their printer.\" (L. Hofstadter)",
    "id" : 160367601057411072,
    "created_at" : "Fri Jan 20 14:26:30 +0000 2012",
    "user" : {
      "name" : "Holger Klein",
      "screen_name" : "holgi",
      "protected" : false,
      "id_str" : "3068271",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/14606372/ich1_normal.jpg",
      "id" : 3068271,
      "verified" : false
    }
  },
  "id" : 160412071584993281,
  "created_at" : "Fri Jan 20 17:23:12 +0000 2012",
  "user" : {
    "name" : "Felix",
    "screen_name" : "nicidienase",
    "protected" : false,
    "id_str" : "22396883",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3125784966/8223a4c5c9535be22d15c82ec829c2df_normal.jpeg",
    "id" : 22396883,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://getspaz.com\" rel=\"nofollow\">Spaz</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "159099835293777920",
  "text" : "Good night cruel world. Hoffentlich wache ich morgen mit besserer Laune wieder auf!",
  "id" : 159099835293777920,
  "created_at" : "Tue Jan 17 02:28:51 +0000 2012",
  "user" : {
    "name" : "Felix",
    "screen_name" : "nicidienase",
    "protected" : false,
    "id_str" : "22396883",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3125784966/8223a4c5c9535be22d15c82ec829c2df_normal.jpeg",
    "id" : 22396883,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://getspaz.com\" rel=\"nofollow\">Spaz</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "159097337451528192",
  "text" : "Sometimes Life SUCKS!!!",
  "id" : 159097337451528192,
  "created_at" : "Tue Jan 17 02:18:55 +0000 2012",
  "user" : {
    "name" : "Felix",
    "screen_name" : "nicidienase",
    "protected" : false,
    "id_str" : "22396883",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3125784966/8223a4c5c9535be22d15c82ec829c2df_normal.jpeg",
    "id" : 22396883,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://getspaz.com\" rel=\"nofollow\">Spaz</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "159093384278052864",
  "text" : "Sometimes Life sucks!!",
  "id" : 159093384278052864,
  "created_at" : "Tue Jan 17 02:03:13 +0000 2012",
  "user" : {
    "name" : "Felix",
    "screen_name" : "nicidienase",
    "protected" : false,
    "id_str" : "22396883",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3125784966/8223a4c5c9535be22d15c82ec829c2df_normal.jpeg",
    "id" : 22396883,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://getspaz.com\" rel=\"nofollow\">Spaz</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "158292539512864768",
  "text" : "Mmmhhh, selbst gekochte Bolognese.",
  "id" : 158292539512864768,
  "created_at" : "Sat Jan 14 21:00:57 +0000 2012",
  "user" : {
    "name" : "Felix",
    "screen_name" : "nicidienase",
    "protected" : false,
    "id_str" : "22396883",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3125784966/8223a4c5c9535be22d15c82ec829c2df_normal.jpeg",
    "id" : 22396883,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://getspaz.com\" rel=\"nofollow\">Spaz HD for webOS</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "psy",
      "screen_name" : "psycon",
      "indices" : [ 3, 10 ],
      "id_str" : "87286054",
      "id" : 87286054
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "156315897299079169",
  "text" : "RT @psycon: OH: \"Break-Even-Point: Der Punkt an dem man aufh\u00F6ren sollte zu saufen weil man gerade brechen kann.\"",
  "retweeted_status" : {
    "source" : "<a href=\"http://www.htc.com\" rel=\"nofollow\">  HTC Peep</a>",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : {
    },
    "id_str" : "156315395572244480",
    "text" : "OH: \"Break-Even-Point: Der Punkt an dem man aufh\u00F6ren sollte zu saufen weil man gerade brechen kann.\"",
    "id" : 156315395572244480,
    "created_at" : "Mon Jan 09 10:04:29 +0000 2012",
    "user" : {
      "name" : "psy",
      "screen_name" : "psycon",
      "protected" : false,
      "id_str" : "87286054",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/2620981046/xkjfqh2iy0xp1lxx6cl1_normal.jpeg",
      "id" : 87286054,
      "verified" : false
    }
  },
  "id" : 156315897299079169,
  "created_at" : "Mon Jan 09 10:06:28 +0000 2012",
  "user" : {
    "name" : "Felix",
    "screen_name" : "nicidienase",
    "protected" : false,
    "id_str" : "22396883",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3125784966/8223a4c5c9535be22d15c82ec829c2df_normal.jpeg",
    "id" : 22396883,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://getspaz.com\" rel=\"nofollow\">Spaz HD for webOS</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Frank Rieger",
      "screen_name" : "frank_rieger",
      "indices" : [ 3, 16 ],
      "id_str" : "53016156",
      "id" : 53016156
    }, {
      "name" : "Frank + Fefe",
      "screen_name" : "Alternativlos",
      "indices" : [ 63, 77 ],
      "id_str" : "174415609",
      "id" : 174415609
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Schramm",
      "indices" : [ 24, 32 ]
    }, {
      "text" : "mynewpresident",
      "indices" : [ 98, 113 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "154165447196024832",
  "text" : "RT @frank_rieger: Georg #Schramm als neuer Bundespr\u00E4sident ist @alternativlos und unausweichlich. #mynewpresident",
  "retweeted_status" : {
    "source" : "web",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Frank + Fefe",
        "screen_name" : "Alternativlos",
        "indices" : [ 45, 59 ],
        "id_str" : "174415609",
        "id" : 174415609
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "Schramm",
        "indices" : [ 6, 14 ]
      }, {
        "text" : "mynewpresident",
        "indices" : [ 80, 95 ]
      } ],
      "urls" : [ ]
    },
    "geo" : {
    },
    "id_str" : "153897006568456192",
    "text" : "Georg #Schramm als neuer Bundespr\u00E4sident ist @alternativlos und unausweichlich. #mynewpresident",
    "id" : 153897006568456192,
    "created_at" : "Mon Jan 02 17:54:40 +0000 2012",
    "user" : {
      "name" : "Frank Rieger",
      "screen_name" : "frank_rieger",
      "protected" : false,
      "id_str" : "53016156",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/293948630/twitter_icon_normal.JPG",
      "id" : 53016156,
      "verified" : false
    }
  },
  "id" : 154165447196024832,
  "created_at" : "Tue Jan 03 11:41:21 +0000 2012",
  "user" : {
    "name" : "Felix",
    "screen_name" : "nicidienase",
    "protected" : false,
    "id_str" : "22396883",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3125784966/8223a4c5c9535be22d15c82ec829c2df_normal.jpeg",
    "id" : 22396883,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://getspaz.com\" rel=\"nofollow\">Spaz</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kate H.",
      "screen_name" : "elaoe7",
      "indices" : [ 0, 7 ],
      "id_str" : "149650777",
      "id" : 149650777
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "153526010544001024",
  "geo" : {
  },
  "id_str" : "153529616819167233",
  "in_reply_to_user_id" : 149650777,
  "text" : "@elaoe7 Ein Wunder von Biblischen Ausma\u00DFen! Ein Prost auf den hl. Silvester!",
  "id" : 153529616819167233,
  "in_reply_to_status_id" : 153526010544001024,
  "created_at" : "Sun Jan 01 17:34:47 +0000 2012",
  "in_reply_to_screen_name" : "elaoe7",
  "in_reply_to_user_id_str" : "149650777",
  "user" : {
    "name" : "Felix",
    "screen_name" : "nicidienase",
    "protected" : false,
    "id_str" : "22396883",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3125784966/8223a4c5c9535be22d15c82ec829c2df_normal.jpeg",
    "id" : 22396883,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://getspaz.com\" rel=\"nofollow\">Spaz</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "28c3",
      "indices" : [ 66, 71 ]
    }, {
      "text" : "pentanews",
      "indices" : [ 72, 82 ]
    } ],
    "urls" : [ {
      "indices" : [ 83, 103 ],
      "url" : "http://t.co/CVAzkPrU",
      "expanded_url" : "http://twitpic.com/81hdkh",
      "display_url" : "twitpic.com/81hdkh"
    } ]
  },
  "geo" : {
  },
  "id_str" : "153291611093217281",
  "text" : "PENIS PENIS PENIS PENIS PENIS PENIS PENIS PENIS PENIS PENIS PENIS #28c3 #pentanews http://t.co/CVAzkPrU",
  "id" : 153291611093217281,
  "created_at" : "Sun Jan 01 01:49:02 +0000 2012",
  "user" : {
    "name" : "Felix",
    "screen_name" : "nicidienase",
    "protected" : false,
    "id_str" : "22396883",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3125784966/8223a4c5c9535be22d15c82ec829c2df_normal.jpeg",
    "id" : 22396883,
    "verified" : false
  }
} ]