Grailbird.data.tweets_2011_07 = 
 [ {
  "source" : "<a href=\"http://getspaz.com\" rel=\"nofollow\">Spaz</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "97476324628766720",
  "text" : "Neue Deko in der Fachschaft http://twitpic.com/5yj3k5",
  "id" : 97476324628766720,
  "created_at" : "Sun Jul 31 01:19:01 +0000 2011",
  "user" : {
    "name" : "Felix",
    "screen_name" : "nicidienase",
    "protected" : false,
    "id_str" : "22396883",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3125784966/8223a4c5c9535be22d15c82ec829c2df_normal.jpeg",
    "id" : 22396883,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://getspaz.com\" rel=\"nofollow\">Spaz</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "96676081737805824",
  "text" : "Heute die letzte Note erfahren. Alles bestanden. Bin mit fast allen Noten zufrieden. Jetzt k\u00F6nnen die Ferien richtig anfangen!!",
  "id" : 96676081737805824,
  "created_at" : "Thu Jul 28 20:19:08 +0000 2011",
  "user" : {
    "name" : "Felix",
    "screen_name" : "nicidienase",
    "protected" : false,
    "id_str" : "22396883",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3125784966/8223a4c5c9535be22d15c82ec829c2df_normal.jpeg",
    "id" : 22396883,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://getspaz.com\" rel=\"nofollow\">Spaz</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dominik Jungowski",
      "screen_name" : "djungowski",
      "indices" : [ 3, 14 ],
      "id_str" : "52203246",
      "id" : 52203246
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "schlechtenerdwitze",
      "indices" : [ 73, 92 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "96201545988837376",
  "text" : "RT @djungowski: Wie nennt man eine Dokumentation \u00FCber Admins? Sudoku! :D #schlechtenerdwitze",
  "retweeted_status" : {
    "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "schlechtenerdwitze",
        "indices" : [ 57, 76 ]
      } ],
      "urls" : [ ]
    },
    "geo" : {
    },
    "id_str" : "95985950785667073",
    "text" : "Wie nennt man eine Dokumentation \u00FCber Admins? Sudoku! :D #schlechtenerdwitze",
    "id" : 95985950785667073,
    "created_at" : "Tue Jul 26 22:36:48 +0000 2011",
    "user" : {
      "name" : "Dominik Jungowski",
      "screen_name" : "djungowski",
      "protected" : false,
      "id_str" : "52203246",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/1593664040/pilz_normal.jpg",
      "id" : 52203246,
      "verified" : false
    }
  },
  "id" : 96201545988837376,
  "created_at" : "Wed Jul 27 12:53:30 +0000 2011",
  "user" : {
    "name" : "Felix",
    "screen_name" : "nicidienase",
    "protected" : false,
    "id_str" : "22396883",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3125784966/8223a4c5c9535be22d15c82ec829c2df_normal.jpeg",
    "id" : 22396883,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://getspaz.com\" rel=\"nofollow\">Spaz</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Katharina Borchert",
      "screen_name" : "lyssaslounge",
      "indices" : [ 3, 16 ],
      "id_str" : "2513671",
      "id" : 2513671
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "93989951494045696",
  "text" : "RT @lyssaslounge: Of course the German Summer (TM) is entirely cloud based which makes it easily scalable across many countries.",
  "retweeted_status" : {
    "source" : "web",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : {
    },
    "id_str" : "93941575142481920",
    "text" : "Of course the German Summer (TM) is entirely cloud based which makes it easily scalable across many countries.",
    "id" : 93941575142481920,
    "created_at" : "Thu Jul 21 07:13:11 +0000 2011",
    "user" : {
      "name" : "Katharina Borchert",
      "screen_name" : "lyssaslounge",
      "protected" : false,
      "id_str" : "2513671",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/30350792/lyssa300dpi_normal.jpg",
      "id" : 2513671,
      "verified" : false
    }
  },
  "id" : 93989951494045696,
  "created_at" : "Thu Jul 21 10:25:25 +0000 2011",
  "user" : {
    "name" : "Felix",
    "screen_name" : "nicidienase",
    "protected" : false,
    "id_str" : "22396883",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3125784966/8223a4c5c9535be22d15c82ec829c2df_normal.jpeg",
    "id" : 22396883,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://getspaz.com\" rel=\"nofollow\">Spaz</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jeremiah Owyang",
      "screen_name" : "jowyang",
      "indices" : [ 3, 11 ],
      "id_str" : "79543",
      "id" : 79543
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "92227337449504769",
  "text" : "RT @jowyang: Let's start a flashmob: When the space shuttle returns, everyone dress up up in Ape outfits.",
  "retweeted_status" : {
    "source" : "web",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : {
    },
    "id_str" : "91925413147840513",
    "text" : "Let's start a flashmob: When the space shuttle returns, everyone dress up up in Ape outfits.",
    "id" : 91925413147840513,
    "created_at" : "Fri Jul 15 17:41:41 +0000 2011",
    "user" : {
      "name" : "Jeremiah Owyang",
      "screen_name" : "jowyang",
      "protected" : false,
      "id_str" : "79543",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/3344158378/c2d273e83a9f7eff27fc1e1fa4bf4b6a_normal.jpeg",
      "id" : 79543,
      "verified" : true
    }
  },
  "id" : 92227337449504769,
  "created_at" : "Sat Jul 16 13:41:25 +0000 2011",
  "user" : {
    "name" : "Felix",
    "screen_name" : "nicidienase",
    "protected" : false,
    "id_str" : "22396883",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3125784966/8223a4c5c9535be22d15c82ec829c2df_normal.jpeg",
    "id" : 22396883,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://getspaz.com\" rel=\"nofollow\">Spaz</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "91440678386675712",
  "text" : "Klausuren rum jetzt gibt's erst mal totes Tier zum Feiern! http://twitpic.com/5px31h",
  "id" : 91440678386675712,
  "created_at" : "Thu Jul 14 09:35:31 +0000 2011",
  "user" : {
    "name" : "Felix",
    "screen_name" : "nicidienase",
    "protected" : false,
    "id_str" : "22396883",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3125784966/8223a4c5c9535be22d15c82ec829c2df_normal.jpeg",
    "id" : 22396883,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://getspaz.com\" rel=\"nofollow\">Spaz</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "91379223138279424",
  "text" : "In ner Stunde letzte Klausur! Zur Feier des Tages das schicke Null-Pointer-Shirt in Gold. http://twitpic.com/5puu11",
  "id" : 91379223138279424,
  "created_at" : "Thu Jul 14 05:31:19 +0000 2011",
  "user" : {
    "name" : "Felix",
    "screen_name" : "nicidienase",
    "protected" : false,
    "id_str" : "22396883",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3125784966/8223a4c5c9535be22d15c82ec829c2df_normal.jpeg",
    "id" : 22396883,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://getspaz.com\" rel=\"nofollow\">Spaz</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Eve",
      "screen_name" : "ChiisanaIchigo",
      "indices" : [ 0, 15 ],
      "id_str" : "187553346",
      "id" : 187553346
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "91204424688615424",
  "geo" : {
  },
  "id_str" : "91280176142483457",
  "in_reply_to_user_id" : 187553346,
  "text" : "@ChiisanaIchigo War auch lecker, und langsam sollte ich schlafen, aber f\u00FCr was gibt's Koffein. Klausur is \u00FCbrigens Theo und XML.",
  "id" : 91280176142483457,
  "in_reply_to_status_id" : 91204424688615424,
  "created_at" : "Wed Jul 13 22:57:44 +0000 2011",
  "in_reply_to_screen_name" : "ChiisanaIchigo",
  "in_reply_to_user_id_str" : "187553346",
  "user" : {
    "name" : "Felix",
    "screen_name" : "nicidienase",
    "protected" : false,
    "id_str" : "22396883",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3125784966/8223a4c5c9535be22d15c82ec829c2df_normal.jpeg",
    "id" : 22396883,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://getspaz.com\" rel=\"nofollow\">Spaz</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "91202904215654401",
  "text" : "Pizza!! Und dann noch bissl lernen f\u00FCr die letzte Klausur morgen. http://twitpic.com/5pm8ho",
  "id" : 91202904215654401,
  "created_at" : "Wed Jul 13 17:50:41 +0000 2011",
  "user" : {
    "name" : "Felix",
    "screen_name" : "nicidienase",
    "protected" : false,
    "id_str" : "22396883",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3125784966/8223a4c5c9535be22d15c82ec829c2df_normal.jpeg",
    "id" : 22396883,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://getspaz.com\" rel=\"nofollow\">Spaz</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "88926055875887104",
  "text" : "Halbzeit!! Zwei von vier Klausuren rum!!",
  "id" : 88926055875887104,
  "created_at" : "Thu Jul 07 11:03:18 +0000 2011",
  "user" : {
    "name" : "Felix",
    "screen_name" : "nicidienase",
    "protected" : false,
    "id_str" : "22396883",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3125784966/8223a4c5c9535be22d15c82ec829c2df_normal.jpeg",
    "id" : 22396883,
    "verified" : false
  }
} ]