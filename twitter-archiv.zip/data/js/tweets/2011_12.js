Grailbird.data.tweets_2011_12 = 
 [ {
  "source" : "<a href=\"http://getspaz.com\" rel=\"nofollow\">Spaz</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Holger Klein",
      "screen_name" : "holgi",
      "indices" : [ 0, 6 ],
      "id_str" : "3068271",
      "id" : 3068271
    }, {
      "name" : "Not Safe For Work",
      "screen_name" : "me_nsfw",
      "indices" : [ 36, 44 ],
      "id_str" : "198895800",
      "id" : 198895800
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "152916077414842368",
  "in_reply_to_user_id" : 3068271,
  "text" : "@Holgi erz\u00E4hlt grade in der letzten @me_nsfw Folge von der Kommisarischen Reichsregierung und wir fahren gleich an G\u00F6ttingen vorbei *g*",
  "id" : 152916077414842368,
  "created_at" : "Sat Dec 31 00:56:48 +0000 2011",
  "in_reply_to_screen_name" : "holgi",
  "in_reply_to_user_id_str" : "3068271",
  "user" : {
    "name" : "Felix",
    "screen_name" : "nicidienase",
    "protected" : false,
    "id_str" : "22396883",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3125784966/8223a4c5c9535be22d15c82ec829c2df_normal.jpeg",
    "id" : 22396883,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://getspaz.com\" rel=\"nofollow\">Spaz</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Not Safe For Work",
      "screen_name" : "me_nsfw",
      "indices" : [ 24, 32 ],
      "id_str" : "198895800",
      "id" : 198895800
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "28c3",
      "indices" : [ 14, 19 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "152913143474040832",
  "text" : "Heimfahrt vom #28c3 und @me_nsfw h\u00F6ren",
  "id" : 152913143474040832,
  "created_at" : "Sat Dec 31 00:45:09 +0000 2011",
  "user" : {
    "name" : "Felix",
    "screen_name" : "nicidienase",
    "protected" : false,
    "id_str" : "22396883",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3125784966/8223a4c5c9535be22d15c82ec829c2df_normal.jpeg",
    "id" : 22396883,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://getspaz.com\" rel=\"nofollow\">Spaz</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Not Safe For Work",
      "screen_name" : "me_nsfw",
      "indices" : [ 19, 27 ],
      "id_str" : "198895800",
      "id" : 198895800
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "152912248191467521",
  "text" : "mmmh Speiseadapter @me_nsfw",
  "id" : 152912248191467521,
  "created_at" : "Sat Dec 31 00:41:35 +0000 2011",
  "user" : {
    "name" : "Felix",
    "screen_name" : "nicidienase",
    "protected" : false,
    "id_str" : "22396883",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3125784966/8223a4c5c9535be22d15c82ec829c2df_normal.jpeg",
    "id" : 22396883,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://getspaz.com\" rel=\"nofollow\">Spaz</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "psy",
      "screen_name" : "psycon",
      "indices" : [ 3, 10 ],
      "id_str" : "87286054",
      "id" : 87286054
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "tassebier",
      "indices" : [ 12, 22 ]
    }, {
      "text" : "28c3",
      "indices" : [ 31, 36 ]
    }, {
      "text" : "bierimkopf",
      "indices" : [ 45, 56 ]
    }, {
      "text" : "tschunk",
      "indices" : [ 65, 73 ]
    }, {
      "text" : "nichtindermittesitzenm\u00FCssen",
      "indices" : [ 82, 110 ]
    }, {
      "text" : "heimfahrt",
      "indices" : [ 119, 129 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "152889629685719040",
  "text" : "RT @psycon: #tassebier: check, #28c3: check, #bierimkopf: check, #tschunk: check, #nichtindermittesitzenm\u00FCssen: check, #heimfahrt: in pr ...",
  "retweeted_status" : {
    "source" : "<a href=\"http://www.htc.com\" rel=\"nofollow\">  HTC Peep</a>",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "tassebier",
        "indices" : [ 0, 10 ]
      }, {
        "text" : "28c3",
        "indices" : [ 19, 24 ]
      }, {
        "text" : "bierimkopf",
        "indices" : [ 33, 44 ]
      }, {
        "text" : "tschunk",
        "indices" : [ 53, 61 ]
      }, {
        "text" : "nichtindermittesitzenm\u00FCssen",
        "indices" : [ 70, 98 ]
      }, {
        "text" : "heimfahrt",
        "indices" : [ 107, 117 ]
      } ],
      "urls" : [ ]
    },
    "geo" : {
    },
    "id_str" : "152882849446510593",
    "text" : "#tassebier: check, #28c3: check, #bierimkopf: check, #tschunk: check, #nichtindermittesitzenm\u00FCssen: check, #heimfahrt: in progress",
    "id" : 152882849446510593,
    "created_at" : "Fri Dec 30 22:44:46 +0000 2011",
    "user" : {
      "name" : "psy",
      "screen_name" : "psycon",
      "protected" : false,
      "id_str" : "87286054",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/2620981046/xkjfqh2iy0xp1lxx6cl1_normal.jpeg",
      "id" : 87286054,
      "verified" : false
    }
  },
  "id" : 152889629685719040,
  "created_at" : "Fri Dec 30 23:11:42 +0000 2011",
  "user" : {
    "name" : "Felix",
    "screen_name" : "nicidienase",
    "protected" : false,
    "id_str" : "22396883",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3125784966/8223a4c5c9535be22d15c82ec829c2df_normal.jpeg",
    "id" : 22396883,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://getspaz.com\" rel=\"nofollow\">Spaz</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "CCC Events",
      "screen_name" : "ccc",
      "indices" : [ 3, 7 ],
      "id_str" : "217234313",
      "id" : 217234313
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "28C3",
      "indices" : [ 110, 115 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "152887778122792960",
  "text" : "RT @ccc: Over 9000 bottles of Club-Mate and the whole December production of Flora Power were consumed during #28C3.",
  "retweeted_status" : {
    "source" : "<a href=\"http://tapbots.com/tweetbot\" rel=\"nofollow\">Tweetbot for iOS</a>",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "28C3",
        "indices" : [ 101, 106 ]
      } ],
      "urls" : [ ]
    },
    "geo" : {
    },
    "id_str" : "152811359321600000",
    "text" : "Over 9000 bottles of Club-Mate and the whole December production of Flora Power were consumed during #28C3.",
    "id" : 152811359321600000,
    "created_at" : "Fri Dec 30 18:00:41 +0000 2011",
    "user" : {
      "name" : "CCC Events",
      "screen_name" : "ccc",
      "protected" : false,
      "id_str" : "217234313",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/1234902293/fairydust_reasonably_small_normal.jpg",
      "id" : 217234313,
      "verified" : false
    }
  },
  "id" : 152887778122792960,
  "created_at" : "Fri Dec 30 23:04:21 +0000 2011",
  "user" : {
    "name" : "Felix",
    "screen_name" : "nicidienase",
    "protected" : false,
    "id_str" : "22396883",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3125784966/8223a4c5c9535be22d15c82ec829c2df_normal.jpeg",
    "id" : 22396883,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://getspaz.com\" rel=\"nofollow\">Spaz</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "C3 Infodesk",
      "screen_name" : "c3infodesk",
      "indices" : [ 3, 14 ],
      "id_str" : "230679224",
      "id" : 230679224
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "28c3",
      "indices" : [ 108, 113 ]
    } ],
    "urls" : [ {
      "indices" : [ 114, 134 ],
      "url" : "http://t.co/2yYX7k6i",
      "expanded_url" : "http://www.youtube.com/watch?v=C23E5grsczE",
      "display_url" : "youtube.com/watch?v=C23E5g\u2026"
    } ]
  },
  "geo" : {
  },
  "id_str" : "152887139921702913",
  "text" : "RT @c3infodesk: Btw, die Pausenmusik ist/the break music is \u201EMachine Lullaby\u201C von/from \u201EFear of Ghosts\u201C. ;) #28c3 http://t.co/2yYX7k6i",
  "retweeted_status" : {
    "source" : "web",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "28c3",
        "indices" : [ 92, 97 ]
      } ],
      "urls" : [ {
        "indices" : [ 98, 118 ],
        "url" : "http://t.co/2yYX7k6i",
        "expanded_url" : "http://www.youtube.com/watch?v=C23E5grsczE",
        "display_url" : "youtube.com/watch?v=C23E5g\u2026"
      } ]
    },
    "geo" : {
    },
    "id_str" : "152776872109944834",
    "text" : "Btw, die Pausenmusik ist/the break music is \u201EMachine Lullaby\u201C von/from \u201EFear of Ghosts\u201C. ;) #28c3 http://t.co/2yYX7k6i",
    "id" : 152776872109944834,
    "created_at" : "Fri Dec 30 15:43:39 +0000 2011",
    "user" : {
      "name" : "C3 Infodesk",
      "screen_name" : "c3infodesk",
      "protected" : false,
      "id_str" : "230679224",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/1199085247/fairydust_reasonably_small_normal.jpg",
      "id" : 230679224,
      "verified" : false
    }
  },
  "id" : 152887139921702913,
  "created_at" : "Fri Dec 30 23:01:49 +0000 2011",
  "user" : {
    "name" : "Felix",
    "screen_name" : "nicidienase",
    "protected" : false,
    "id_str" : "22396883",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3125784966/8223a4c5c9535be22d15c82ec829c2df_normal.jpeg",
    "id" : 22396883,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://getspaz.com\" rel=\"nofollow\">Spaz</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "tassebier",
      "indices" : [ 25, 35 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "152846166038552578",
  "text" : "FUCK YOU AUTOCORRECT!!!! #tassebier",
  "id" : 152846166038552578,
  "created_at" : "Fri Dec 30 20:19:00 +0000 2011",
  "user" : {
    "name" : "Felix",
    "screen_name" : "nicidienase",
    "protected" : false,
    "id_str" : "22396883",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3125784966/8223a4c5c9535be22d15c82ec829c2df_normal.jpeg",
    "id" : 22396883,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://getspaz.com\" rel=\"nofollow\">Spaz</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "tassebier",
      "indices" : [ 35, 45 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "152845807517843456",
  "text" : "Scheint autocorrect, bcc nicht Bbc #tassebier",
  "id" : 152845807517843456,
  "created_at" : "Fri Dec 30 20:17:34 +0000 2011",
  "user" : {
    "name" : "Felix",
    "screen_name" : "nicidienase",
    "protected" : false,
    "id_str" : "22396883",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3125784966/8223a4c5c9535be22d15c82ec829c2df_normal.jpeg",
    "id" : 22396883,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://getspaz.com\" rel=\"nofollow\">Spaz</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "tassebier",
      "indices" : [ 39, 49 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "152844492028911618",
  "text" : "Sofas geschleppt im Bbc, jetzt noch ne #tassebier in der cbase bevor zur\u00FCck nach KA geht.",
  "id" : 152844492028911618,
  "created_at" : "Fri Dec 30 20:12:21 +0000 2011",
  "user" : {
    "name" : "Felix",
    "screen_name" : "nicidienase",
    "protected" : false,
    "id_str" : "22396883",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3125784966/8223a4c5c9535be22d15c82ec829c2df_normal.jpeg",
    "id" : 22396883,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://getspaz.com\" rel=\"nofollow\">Spaz HD for webOS</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Detmud",
      "screen_name" : "Detmud",
      "indices" : [ 3, 10 ],
      "id_str" : "15587623",
      "id" : 15587623
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "152460752043769856",
  "text" : "RT @Detmud: Wem immer diese Schei\u00DF antiautorit\u00E4r erzogen Dreckskinder geh\u00F6ren die Leuten st\u00E4ndig ins Gesicht hauen, k\u00FCmmert euch um eure ...",
  "retweeted_status" : {
    "source" : "<a href=\"http://tapbots.com/tweetbot\" rel=\"nofollow\">Tweetbot for iOS</a>",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "28c3",
        "indices" : [ 133, 138 ]
      } ],
      "urls" : [ ]
    },
    "geo" : {
    },
    "id_str" : "152442315271708672",
    "text" : "Wem immer diese Schei\u00DF antiautorit\u00E4r erzogen Dreckskinder geh\u00F6ren die Leuten st\u00E4ndig ins Gesicht hauen, k\u00FCmmert euch um eure Kinder. #28c3",
    "id" : 152442315271708672,
    "created_at" : "Thu Dec 29 17:34:14 +0000 2011",
    "user" : {
      "name" : "Detmud",
      "screen_name" : "Detmud",
      "protected" : false,
      "id_str" : "15587623",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/2080165386/IMG_0046_normal.JPG",
      "id" : 15587623,
      "verified" : false
    }
  },
  "id" : 152460752043769856,
  "created_at" : "Thu Dec 29 18:47:30 +0000 2011",
  "user" : {
    "name" : "Felix",
    "screen_name" : "nicidienase",
    "protected" : false,
    "id_str" : "22396883",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3125784966/8223a4c5c9535be22d15c82ec829c2df_normal.jpeg",
    "id" : 22396883,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://getspaz.com\" rel=\"nofollow\">Spaz</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Alexa",
      "indices" : [ 21, 27 ]
    }, {
      "text" : "28c3",
      "indices" : [ 28, 33 ]
    } ],
    "urls" : [ {
      "indices" : [ 35, 55 ],
      "url" : "http://t.co/wrhAlgoA",
      "expanded_url" : "http://twitpic.com/80a9r6",
      "display_url" : "twitpic.com/80a9r6"
    } ]
  },
  "geo" : {
  },
  "id_str" : "152439268109844481",
  "text" : "Eingang zum Edeka im #Alexa #28c3  http://t.co/wrhAlgoA",
  "id" : 152439268109844481,
  "created_at" : "Thu Dec 29 17:22:08 +0000 2011",
  "user" : {
    "name" : "Felix",
    "screen_name" : "nicidienase",
    "protected" : false,
    "id_str" : "22396883",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3125784966/8223a4c5c9535be22d15c82ec829c2df_normal.jpeg",
    "id" : 22396883,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://getspaz.com\" rel=\"nofollow\">Spaz HD for webOS</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "28c3",
      "indices" : [ 78, 83 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "152429057361977344",
  "text" : "Hackernachwuchs is ja sch\u00F6n aber die kleinen ham immer so nervig hohe Stimmen #28c3",
  "id" : 152429057361977344,
  "created_at" : "Thu Dec 29 16:41:33 +0000 2011",
  "user" : {
    "name" : "Felix",
    "screen_name" : "nicidienase",
    "protected" : false,
    "id_str" : "22396883",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3125784966/8223a4c5c9535be22d15c82ec829c2df_normal.jpeg",
    "id" : 22396883,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://getspaz.com\" rel=\"nofollow\">Spaz HD for webOS</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Eva Eichhorn",
      "screen_name" : "MamsellChaos",
      "indices" : [ 10, 23 ],
      "id_str" : "140774041",
      "id" : 140774041
    }, {
      "name" : "Felix",
      "screen_name" : "nicidienase",
      "indices" : [ 24, 36 ],
      "id_str" : "22396883",
      "id" : 22396883
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "TIIFP",
      "indices" : [ 83, 89 ]
    }, {
      "text" : "28c3",
      "indices" : [ 90, 95 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "152427198647779328",
  "text" : "Danke! RT @MamsellChaos @nicidienase ist ein vorbildlicher stickerversorgungsnerd! #TIIFP #28c3",
  "id" : 152427198647779328,
  "created_at" : "Thu Dec 29 16:34:10 +0000 2011",
  "user" : {
    "name" : "Felix",
    "screen_name" : "nicidienase",
    "protected" : false,
    "id_str" : "22396883",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3125784966/8223a4c5c9535be22d15c82ec829c2df_normal.jpeg",
    "id" : 22396883,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://getspaz.com\" rel=\"nofollow\">Spaz HD for webOS</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Michael Feurer",
      "screen_name" : "bigbluebernd",
      "indices" : [ 0, 13 ],
      "id_str" : "423525026",
      "id" : 423525026
    }, {
      "name" : "Kate H.",
      "screen_name" : "elaoe7",
      "indices" : [ 14, 21 ],
      "id_str" : "149650777",
      "id" : 149650777
    }, {
      "name" : "Abdellah felahi",
      "screen_name" : "psycho",
      "indices" : [ 22, 29 ],
      "id_str" : "188460330",
      "id" : 188460330
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "28c3",
      "indices" : [ 88, 93 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "152403751746027520",
  "geo" : {
  },
  "id_str" : "152404104273076224",
  "in_reply_to_user_id" : 423525026,
  "text" : "@bigbluebernd @elaoe7 @psycho Meint ihr das f\u00E4llt auf wenn wir einfach n paar hier beim #28c3 mitnehmen .... ;-)",
  "id" : 152404104273076224,
  "in_reply_to_status_id" : 152403751746027520,
  "created_at" : "Thu Dec 29 15:02:24 +0000 2011",
  "in_reply_to_screen_name" : "bigbluebernd",
  "in_reply_to_user_id_str" : "423525026",
  "user" : {
    "name" : "Felix",
    "screen_name" : "nicidienase",
    "protected" : false,
    "id_str" : "22396883",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3125784966/8223a4c5c9535be22d15c82ec829c2df_normal.jpeg",
    "id" : 22396883,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://getspaz.com\" rel=\"nofollow\">Spaz HD for webOS</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "psy",
      "screen_name" : "psycon",
      "indices" : [ 14, 21 ],
      "id_str" : "87286054",
      "id" : 87286054
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "B\u00E4llebad",
      "indices" : [ 22, 31 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "152401576500273152",
  "text" : "Ich auch!! RT @psycon #B\u00E4llebad will ich auch daheim haben!",
  "id" : 152401576500273152,
  "created_at" : "Thu Dec 29 14:52:21 +0000 2011",
  "user" : {
    "name" : "Felix",
    "screen_name" : "nicidienase",
    "protected" : false,
    "id_str" : "22396883",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3125784966/8223a4c5c9535be22d15c82ec829c2df_normal.jpeg",
    "id" : 22396883,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://getspaz.com\" rel=\"nofollow\">Spaz HD for webOS</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "152168086278119424",
  "text" : "WTF, WebOS autokorrigiert Infodesk zu Nordirak ... Und autokorrigiert zu unkorrigiert.",
  "id" : 152168086278119424,
  "created_at" : "Wed Dec 28 23:24:33 +0000 2011",
  "user" : {
    "name" : "Felix",
    "screen_name" : "nicidienase",
    "protected" : false,
    "id_str" : "22396883",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3125784966/8223a4c5c9535be22d15c82ec829c2df_normal.jpeg",
    "id" : 22396883,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://getspaz.com\" rel=\"nofollow\">Spaz HD for webOS</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Eva Eichhorn",
      "screen_name" : "MamsellChaos",
      "indices" : [ 0, 13 ],
      "id_str" : "140774041",
      "id" : 140774041
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "152096351453323264",
  "geo" : {
  },
  "id_str" : "152165231764848640",
  "in_reply_to_user_id" : 140774041,
  "text" : "@MamsellChaos Ich hab heute welche in der n\u00E4he vom Infodesk gesehen, wenn du lieb fragst hab ich vielleicht auch noch welche ..",
  "id" : 152165231764848640,
  "in_reply_to_status_id" : 152096351453323264,
  "created_at" : "Wed Dec 28 23:13:13 +0000 2011",
  "in_reply_to_screen_name" : "MamsellChaos",
  "in_reply_to_user_id_str" : "140774041",
  "user" : {
    "name" : "Felix",
    "screen_name" : "nicidienase",
    "protected" : false,
    "id_str" : "22396883",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3125784966/8223a4c5c9535be22d15c82ec829c2df_normal.jpeg",
    "id" : 22396883,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://getspaz.com\" rel=\"nofollow\">Spaz HD for webOS</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Julian Finn",
      "screen_name" : "hdsjulian",
      "indices" : [ 3, 13 ],
      "id_str" : "12192142",
      "id" : 12192142
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "saal2",
      "indices" : [ 24, 30 ]
    }, {
      "text" : "28c3",
      "indices" : [ 97, 102 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "152060203037241344",
  "text" : "RT @hdsjulian: Lerne in #saal2 Mate hat 1.2 mio kW wenn man sie mit Anti-Mate kollidieren l\u00E4sst. #28c3",
  "retweeted_status" : {
    "source" : "<a href=\"http://www.echofon.com/\" rel=\"nofollow\">Echofon</a>",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "saal2",
        "indices" : [ 9, 15 ]
      }, {
        "text" : "28c3",
        "indices" : [ 82, 87 ]
      } ],
      "urls" : [ ]
    },
    "geo" : {
    },
    "id_str" : "152054005181317121",
    "text" : "Lerne in #saal2 Mate hat 1.2 mio kW wenn man sie mit Anti-Mate kollidieren l\u00E4sst. #28c3",
    "id" : 152054005181317121,
    "created_at" : "Wed Dec 28 15:51:14 +0000 2011",
    "user" : {
      "name" : "Julian Finn",
      "screen_name" : "hdsjulian",
      "protected" : false,
      "id_str" : "12192142",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/3396406550/32bf0d90208f78204b064d6a639697b1_normal.png",
      "id" : 12192142,
      "verified" : false
    }
  },
  "id" : 152060203037241344,
  "created_at" : "Wed Dec 28 16:15:52 +0000 2011",
  "user" : {
    "name" : "Felix",
    "screen_name" : "nicidienase",
    "protected" : false,
    "id_str" : "22396883",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3125784966/8223a4c5c9535be22d15c82ec829c2df_normal.jpeg",
    "id" : 22396883,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://getspaz.com\" rel=\"nofollow\">Spaz HD for webOS</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "mlx",
      "screen_name" : "_mlx_",
      "indices" : [ 3, 9 ],
      "id_str" : "48790681",
      "id" : 48790681
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "28c3",
      "indices" : [ 98, 103 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "152019039047266304",
  "text" : "RT @_mlx_: \"I'm not an economist. But to be fair neither are most economists\" Dan Kaminsky at his #28c3 talk :)",
  "retweeted_status" : {
    "source" : "web",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "28c3",
        "indices" : [ 87, 92 ]
      } ],
      "urls" : [ ]
    },
    "geo" : {
    },
    "id_str" : "152017485145718785",
    "text" : "\"I'm not an economist. But to be fair neither are most economists\" Dan Kaminsky at his #28c3 talk :)",
    "id" : 152017485145718785,
    "created_at" : "Wed Dec 28 13:26:07 +0000 2011",
    "user" : {
      "name" : "mlx",
      "screen_name" : "_mlx_",
      "protected" : false,
      "id_str" : "48790681",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/3460350646/daf9025dac83efd87e5b7b9a93bd3070_normal.png",
      "id" : 48790681,
      "verified" : false
    }
  },
  "id" : 152019039047266304,
  "created_at" : "Wed Dec 28 13:32:17 +0000 2011",
  "user" : {
    "name" : "Felix",
    "screen_name" : "nicidienase",
    "protected" : false,
    "id_str" : "22396883",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3125784966/8223a4c5c9535be22d15c82ec829c2df_normal.jpeg",
    "id" : 22396883,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://getspaz.com\" rel=\"nofollow\">Spaz HD for webOS</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Max Winde",
      "screen_name" : "343max",
      "indices" : [ 3, 10 ],
      "id_str" : "2284151",
      "id" : 2284151
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "28c3",
      "indices" : [ 42, 47 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "151785137087070209",
  "text" : "RT @343max: Simultanmateflaschenumwerfen. #28c3",
  "retweeted_status" : {
    "source" : "<a href=\"http://tapbots.com/tweetbot\" rel=\"nofollow\">Tweetbot for iOS</a>",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "28c3",
        "indices" : [ 30, 35 ]
      } ],
      "urls" : [ ]
    },
    "geo" : {
    },
    "id_str" : "151747326539612160",
    "text" : "Simultanmateflaschenumwerfen. #28c3",
    "id" : 151747326539612160,
    "created_at" : "Tue Dec 27 19:32:36 +0000 2011",
    "user" : {
      "name" : "Max Winde",
      "screen_name" : "343max",
      "protected" : false,
      "id_str" : "2284151",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/1573654380/edween_normal.png",
      "id" : 2284151,
      "verified" : false
    }
  },
  "id" : 151785137087070209,
  "created_at" : "Tue Dec 27 22:02:51 +0000 2011",
  "user" : {
    "name" : "Felix",
    "screen_name" : "nicidienase",
    "protected" : false,
    "id_str" : "22396883",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3125784966/8223a4c5c9535be22d15c82ec829c2df_normal.jpeg",
    "id" : 22396883,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://getspaz.com\" rel=\"nofollow\">Spaz HD for webOS</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Eva Eichhorn",
      "screen_name" : "MamsellChaos",
      "indices" : [ 0, 13 ],
      "id_str" : "140774041",
      "id" : 140774041
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "151739386642432000",
  "in_reply_to_user_id" : 140774041,
  "text" : "@MamsellChaos Boblbee-Rucks\u00E4cke sind awesome ;-)",
  "id" : 151739386642432000,
  "created_at" : "Tue Dec 27 19:01:03 +0000 2011",
  "in_reply_to_screen_name" : "MamsellChaos",
  "in_reply_to_user_id_str" : "140774041",
  "user" : {
    "name" : "Felix",
    "screen_name" : "nicidienase",
    "protected" : false,
    "id_str" : "22396883",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3125784966/8223a4c5c9535be22d15c82ec829c2df_normal.jpeg",
    "id" : 22396883,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://getspaz.com\" rel=\"nofollow\">Spaz HD for webOS</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "28c3",
      "indices" : [ 50, 55 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "151728868426915840",
  "text" : "B\u00E4llchenb\u00E4der sind was f\u00FCr Kinder ... und Hacker. #28c3",
  "id" : 151728868426915840,
  "created_at" : "Tue Dec 27 18:19:15 +0000 2011",
  "user" : {
    "name" : "Felix",
    "screen_name" : "nicidienase",
    "protected" : false,
    "id_str" : "22396883",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3125784966/8223a4c5c9535be22d15c82ec829c2df_normal.jpeg",
    "id" : 22396883,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://getspaz.com\" rel=\"nofollow\">Spaz</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "28c3",
      "indices" : [ 80, 85 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "151545282360918016",
  "text" : "Am bcc angekommen. Leider Cashdesk und alles noch zu. Erstmal Fr\u00FChst\u00FCcken geht. #28c3",
  "id" : 151545282360918016,
  "created_at" : "Tue Dec 27 06:09:45 +0000 2011",
  "user" : {
    "name" : "Felix",
    "screen_name" : "nicidienase",
    "protected" : false,
    "id_str" : "22396883",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3125784966/8223a4c5c9535be22d15c82ec829c2df_normal.jpeg",
    "id" : 22396883,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://getspaz.com\" rel=\"nofollow\">Spaz</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "28c3",
      "indices" : [ 23, 28 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "151496970060562432",
  "text" : "Noch 354km bis Berlin. #28c3 here we come.",
  "id" : 151496970060562432,
  "created_at" : "Tue Dec 27 02:57:46 +0000 2011",
  "user" : {
    "name" : "Felix",
    "screen_name" : "nicidienase",
    "protected" : false,
    "id_str" : "22396883",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3125784966/8223a4c5c9535be22d15c82ec829c2df_normal.jpeg",
    "id" : 22396883,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://getspaz.com\" rel=\"nofollow\">Spaz</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "28c3",
      "indices" : [ 132, 137 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "151462943895195649",
  "text" : "Nach kleineren technischen Problemen(klemmender Gurt (mit etwas Gewalt gel\u00F6st)) sind jetzt alle an Bord und es geht weiter Richtung #28c3",
  "id" : 151462943895195649,
  "created_at" : "Tue Dec 27 00:42:34 +0000 2011",
  "user" : {
    "name" : "Felix",
    "screen_name" : "nicidienase",
    "protected" : false,
    "id_str" : "22396883",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3125784966/8223a4c5c9535be22d15c82ec829c2df_normal.jpeg",
    "id" : 22396883,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://getspaz.com\" rel=\"nofollow\">Spaz</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "28c3",
      "indices" : [ 107, 112 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "151355131336724480",
  "text" : "In der S-Bahn nach KA. Da noch ne kleine M\u00FCtze Schlaf und um Mitternacht geht dann los Richtung Berlin zum #28c3",
  "id" : 151355131336724480,
  "created_at" : "Mon Dec 26 17:34:10 +0000 2011",
  "user" : {
    "name" : "Felix",
    "screen_name" : "nicidienase",
    "protected" : false,
    "id_str" : "22396883",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3125784966/8223a4c5c9535be22d15c82ec829c2df_normal.jpeg",
    "id" : 22396883,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://getspaz.com\" rel=\"nofollow\">Spaz HD for webOS</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Andreas Poser",
      "screen_name" : "AndreasPoser",
      "indices" : [ 3, 16 ],
      "id_str" : "45378550",
      "id" : 45378550
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "150671935821463552",
  "text" : "RT @AndreasPoser: Eil! Jesus gibt zu: Ja, ich hab von drei verm\u00F6genden Freunden Sachgeschenke angenommen! Wir stehen aber in keiner gesc ...",
  "retweeted_status" : {
    "source" : "<a href=\"http://twitter.com/#!/download/ipad\" rel=\"nofollow\">Twitter for iPad</a>",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : {
    },
    "id_str" : "150601698497404930",
    "text" : "Eil! Jesus gibt zu: Ja, ich hab von drei verm\u00F6genden Freunden Sachgeschenke angenommen! Wir stehen aber in keiner gesch\u00E4ftlichen Beziehung!\"",
    "id" : 150601698497404930,
    "created_at" : "Sat Dec 24 15:40:17 +0000 2011",
    "user" : {
      "name" : "Andreas Poser",
      "screen_name" : "AndreasPoser",
      "protected" : false,
      "id_str" : "45378550",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/3273319052/fa0a4f4fcba09bb67eb6a47d4fd3e272_normal.jpeg",
      "id" : 45378550,
      "verified" : false
    }
  },
  "id" : 150671935821463552,
  "created_at" : "Sat Dec 24 20:19:23 +0000 2011",
  "user" : {
    "name" : "Felix",
    "screen_name" : "nicidienase",
    "protected" : false,
    "id_str" : "22396883",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3125784966/8223a4c5c9535be22d15c82ec829c2df_normal.jpeg",
    "id" : 22396883,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://getspaz.com\" rel=\"nofollow\">Spaz HD for webOS</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Carrie Fisher",
      "screen_name" : "CarrieFFisher",
      "indices" : [ 3, 17 ],
      "id_str" : "75641903",
      "id" : 75641903
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 68, 88 ],
      "url" : "http://t.co/WReWvQvR",
      "expanded_url" : "http://fb.me/1raTJv5TB",
      "display_url" : "fb.me/1raTJv5TB"
    } ]
  },
  "geo" : {
  },
  "id_str" : "150671865805934592",
  "text" : "RT @CarrieFFisher: Merry Christmas,\nxooxxo Saint Leia of Darthlahem http://t.co/WReWvQvR",
  "retweeted_status" : {
    "source" : "<a href=\"http://www.facebook.com/twitter\" rel=\"nofollow\">Facebook</a>",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 49, 69 ],
        "url" : "http://t.co/WReWvQvR",
        "expanded_url" : "http://fb.me/1raTJv5TB",
        "display_url" : "fb.me/1raTJv5TB"
      } ]
    },
    "geo" : {
    },
    "id_str" : "150641876695912450",
    "text" : "Merry Christmas,\nxooxxo Saint Leia of Darthlahem http://t.co/WReWvQvR",
    "id" : 150641876695912450,
    "created_at" : "Sat Dec 24 18:19:56 +0000 2011",
    "user" : {
      "name" : "Carrie Fisher",
      "screen_name" : "CarrieFFisher",
      "protected" : false,
      "id_str" : "75641903",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/2603124270/pucf3v08lihg1dpbkscb_normal.jpeg",
      "id" : 75641903,
      "verified" : true
    }
  },
  "id" : 150671865805934592,
  "created_at" : "Sat Dec 24 20:19:06 +0000 2011",
  "user" : {
    "name" : "Felix",
    "screen_name" : "nicidienase",
    "protected" : false,
    "id_str" : "22396883",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3125784966/8223a4c5c9535be22d15c82ec829c2df_normal.jpeg",
    "id" : 22396883,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://getspaz.com\" rel=\"nofollow\">Spaz HD for webOS</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Eva Eichhorn",
      "screen_name" : "MamsellChaos",
      "indices" : [ 0, 13 ],
      "id_str" : "140774041",
      "id" : 140774041
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "150375704108867584",
  "geo" : {
  },
  "id_str" : "150377596721438720",
  "in_reply_to_user_id" : 140774041,
  "text" : "@MamsellChaos Zu Fuss oder Fahrrad w\u00E4r ich beeindruckt gewesen ;-)",
  "id" : 150377596721438720,
  "in_reply_to_status_id" : 150375704108867584,
  "created_at" : "Sat Dec 24 00:49:47 +0000 2011",
  "in_reply_to_screen_name" : "MamsellChaos",
  "in_reply_to_user_id_str" : "140774041",
  "user" : {
    "name" : "Felix",
    "screen_name" : "nicidienase",
    "protected" : false,
    "id_str" : "22396883",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3125784966/8223a4c5c9535be22d15c82ec829c2df_normal.jpeg",
    "id" : 22396883,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://getspaz.com\" rel=\"nofollow\">Spaz HD for webOS</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Eva Eichhorn",
      "screen_name" : "MamsellChaos",
      "indices" : [ 0, 13 ],
      "id_str" : "140774041",
      "id" : 140774041
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "150299505269538816",
  "geo" : {
  },
  "id_str" : "150373801992007680",
  "in_reply_to_user_id" : 140774041,
  "text" : "@MamsellChaos Das kommt auf das Verkehrsmittel an.",
  "id" : 150373801992007680,
  "in_reply_to_status_id" : 150299505269538816,
  "created_at" : "Sat Dec 24 00:34:42 +0000 2011",
  "in_reply_to_screen_name" : "MamsellChaos",
  "in_reply_to_user_id_str" : "140774041",
  "user" : {
    "name" : "Felix",
    "screen_name" : "nicidienase",
    "protected" : false,
    "id_str" : "22396883",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3125784966/8223a4c5c9535be22d15c82ec829c2df_normal.jpeg",
    "id" : 22396883,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://getspaz.com\" rel=\"nofollow\">Spaz</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "neingeist",
      "screen_name" : "neingeist",
      "indices" : [ 3, 13 ],
      "id_str" : "11193712",
      "id" : 11193712
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "149849822260768768",
  "text" : "RT @neingeist: Kondome aus LaTeX!",
  "retweeted_status" : {
    "source" : "<a href=\"http://seesmic.com/\" rel=\"nofollow\">Seesmic</a>",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : {
    },
    "id_str" : "149846097400041472",
    "text" : "Kondome aus LaTeX!",
    "id" : 149846097400041472,
    "created_at" : "Thu Dec 22 13:37:48 +0000 2011",
    "user" : {
      "name" : "neingeist",
      "screen_name" : "neingeist",
      "protected" : false,
      "id_str" : "11193712",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/3506751329/a8c317b7b69ff0f8eef00b9cb842cbc0_normal.png",
      "id" : 11193712,
      "verified" : false
    }
  },
  "id" : 149849822260768768,
  "created_at" : "Thu Dec 22 13:52:36 +0000 2011",
  "user" : {
    "name" : "Felix",
    "screen_name" : "nicidienase",
    "protected" : false,
    "id_str" : "22396883",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3125784966/8223a4c5c9535be22d15c82ec829c2df_normal.jpeg",
    "id" : 22396883,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://getspaz.com\" rel=\"nofollow\">Spaz</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "CRE",
      "screen_name" : "me_CRE",
      "indices" : [ 19, 26 ],
      "id_str" : "185611778",
      "id" : 185611778
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "149782257354289152",
  "text" : "Das neue Intro von @me_CRE klingt ja echt wichtig und dramatisch.",
  "id" : 149782257354289152,
  "created_at" : "Thu Dec 22 09:24:07 +0000 2011",
  "user" : {
    "name" : "Felix",
    "screen_name" : "nicidienase",
    "protected" : false,
    "id_str" : "22396883",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3125784966/8223a4c5c9535be22d15c82ec829c2df_normal.jpeg",
    "id" : 22396883,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://getspaz.com\" rel=\"nofollow\">Spaz HD for webOS</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "149325453784649728",
  "text" : "Damn it! Bis um 4 gecodet und um 8 schon wieder Vorlesung, das kann nix werden. Aber immerhin hab ich das Softwarelab-Zeug jetzt fast fertig",
  "id" : 149325453784649728,
  "created_at" : "Wed Dec 21 03:08:57 +0000 2011",
  "user" : {
    "name" : "Felix",
    "screen_name" : "nicidienase",
    "protected" : false,
    "id_str" : "22396883",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3125784966/8223a4c5c9535be22d15c82ec829c2df_normal.jpeg",
    "id" : 22396883,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://getspaz.com\" rel=\"nofollow\">Spaz</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "JoernPL",
      "screen_name" : "JoernPL",
      "indices" : [ 3, 11 ],
      "id_str" : "17388789",
      "id" : 17388789
    }, {
      "name" : "linuxmagazin",
      "screen_name" : "linuxmagazin",
      "indices" : [ 24, 37 ],
      "id_str" : "16024410",
      "id" : 16024410
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 93, 113 ],
      "url" : "http://t.co/Qwda8tlS",
      "expanded_url" : "http://bit.ly/rN13fb",
      "display_url" : "bit.ly/rN13fb"
    } ]
  },
  "geo" : {
  },
  "id_str" : "148770222235582464",
  "text" : "RT @JoernPL: Artikel im @linuxmagazin: Gr\u00FCne Abgeordnete setzen PGP/GnuPG im Bundestag durch http://t.co/Qwda8tlS",
  "retweeted_status" : {
    "source" : "web",
    "entities" : {
      "user_mentions" : [ {
        "name" : "linuxmagazin",
        "screen_name" : "linuxmagazin",
        "indices" : [ 11, 24 ],
        "id_str" : "16024410",
        "id" : 16024410
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 80, 100 ],
        "url" : "http://t.co/Qwda8tlS",
        "expanded_url" : "http://bit.ly/rN13fb",
        "display_url" : "bit.ly/rN13fb"
      } ]
    },
    "geo" : {
    },
    "id_str" : "148734950332579840",
    "text" : "Artikel im @linuxmagazin: Gr\u00FCne Abgeordnete setzen PGP/GnuPG im Bundestag durch http://t.co/Qwda8tlS",
    "id" : 148734950332579840,
    "created_at" : "Mon Dec 19 12:02:30 +0000 2011",
    "user" : {
      "name" : "JoernPL",
      "screen_name" : "JoernPL",
      "protected" : false,
      "id_str" : "17388789",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/2169501334/mit_ACT_ON_normal.jpg",
      "id" : 17388789,
      "verified" : false
    }
  },
  "id" : 148770222235582464,
  "created_at" : "Mon Dec 19 14:22:39 +0000 2011",
  "user" : {
    "name" : "Felix",
    "screen_name" : "nicidienase",
    "protected" : false,
    "id_str" : "22396883",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3125784966/8223a4c5c9535be22d15c82ec829c2df_normal.jpeg",
    "id" : 22396883,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://getspaz.com\" rel=\"nofollow\">Spaz</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "HAL 9000",
      "screen_name" : "HAL9000_",
      "indices" : [ 3, 12 ],
      "id_str" : "29038088",
      "id" : 29038088
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 102, 122 ],
      "url" : "http://t.co/nm8KFtpv",
      "expanded_url" : "http://twitter.com/HAL9000_/status/148546886708637696/photo/1",
      "display_url" : "pic.twitter.com/nm8KFtpv"
    } ]
  },
  "geo" : {
  },
  "id_str" : "148769643044151297",
  "text" : "RT @HAL9000_: I don't know why people think the iPad is better than the Galaxy, so I made this chart: http://t.co/nm8KFtpv",
  "retweeted_status" : {
    "source" : "web",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "http://twitter.com/HAL9000_/status/148546886708637696/photo/1",
        "indices" : [ 88, 108 ],
        "url" : "http://t.co/nm8KFtpv",
        "media_url" : "http://pbs.twimg.com/media/Ag--mz8CMAAOVDV.png",
        "id_str" : "148546886712832000",
        "id" : 148546886712832000,
        "media_url_https" : "https://pbs.twimg.com/media/Ag--mz8CMAAOVDV.png",
        "sizes" : [ {
          "h" : 567,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 1000,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 1600,
          "resize" : "fit",
          "w" : 960
        }, {
          "h" : 1600,
          "resize" : "fit",
          "w" : 960
        } ],
        "display_url" : "pic.twitter.com/nm8KFtpv"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : {
    },
    "id_str" : "148546886708637696",
    "text" : "I don't know why people think the iPad is better than the Galaxy, so I made this chart: http://t.co/nm8KFtpv",
    "id" : 148546886708637696,
    "created_at" : "Sun Dec 18 23:35:13 +0000 2011",
    "user" : {
      "name" : "HAL 9000",
      "screen_name" : "HAL9000_",
      "protected" : false,
      "id_str" : "29038088",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/1788506913/HAL-MC2_normal.png",
      "id" : 29038088,
      "verified" : false
    }
  },
  "id" : 148769643044151297,
  "created_at" : "Mon Dec 19 14:20:21 +0000 2011",
  "user" : {
    "name" : "Felix",
    "screen_name" : "nicidienase",
    "protected" : false,
    "id_str" : "22396883",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3125784966/8223a4c5c9535be22d15c82ec829c2df_normal.jpeg",
    "id" : 22396883,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://getspaz.com\" rel=\"nofollow\">Spaz</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "psy",
      "screen_name" : "psycon",
      "indices" : [ 0, 7 ],
      "id_str" : "87286054",
      "id" : 87286054
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "146852981470527488",
  "geo" : {
  },
  "id_str" : "146905587895115777",
  "in_reply_to_user_id" : 87286054,
  "text" : "@psycon Seit \"Durlacher Tor\" direkt vorm Uni-Haupteingang is!",
  "id" : 146905587895115777,
  "in_reply_to_status_id" : 146852981470527488,
  "created_at" : "Wed Dec 14 10:53:16 +0000 2011",
  "in_reply_to_screen_name" : "psycon",
  "in_reply_to_user_id_str" : "87286054",
  "user" : {
    "name" : "Felix",
    "screen_name" : "nicidienase",
    "protected" : false,
    "id_str" : "22396883",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3125784966/8223a4c5c9535be22d15c82ec829c2df_normal.jpeg",
    "id" : 22396883,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://getspaz.com\" rel=\"nofollow\">Spaz</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "146888286139465728",
  "text" : "Auf dem Weg zum ersten Bewerbungsgespr\u00E4ch meines Lebens. Dr\u00FCckt mit die Daumen!",
  "id" : 146888286139465728,
  "created_at" : "Wed Dec 14 09:44:31 +0000 2011",
  "user" : {
    "name" : "Felix",
    "screen_name" : "nicidienase",
    "protected" : false,
    "id_str" : "22396883",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3125784966/8223a4c5c9535be22d15c82ec829c2df_normal.jpeg",
    "id" : 22396883,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://getspaz.com\" rel=\"nofollow\">Spaz</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Finn Heemeyer",
      "screen_name" : "fheemeyer",
      "indices" : [ 3, 13 ],
      "id_str" : "347127410",
      "id" : 347127410
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "146246322985504768",
  "text" : "RT @fheemeyer: \u200EDie FDP hat ein Waisenhaus in Japan besucht. \"Es ist traurig in die hoffnungslosen und leeren Augen zu gucken\", sagte di ...",
  "retweeted_status" : {
    "source" : "web",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : {
    },
    "id_str" : "116892352173457408",
    "text" : "\u200EDie FDP hat ein Waisenhaus in Japan besucht. \"Es ist traurig in die hoffnungslosen und leeren Augen zu gucken\", sagte die 8j\u00E4hrige MaiLing.",
    "id" : 116892352173457408,
    "created_at" : "Thu Sep 22 15:11:23 +0000 2011",
    "user" : {
      "name" : "Finn Heemeyer",
      "screen_name" : "fheemeyer",
      "protected" : false,
      "id_str" : "347127410",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/1474065356/_________________________________normal.jpg",
      "id" : 347127410,
      "verified" : false
    }
  },
  "id" : 146246322985504768,
  "created_at" : "Mon Dec 12 15:13:35 +0000 2011",
  "user" : {
    "name" : "Felix",
    "screen_name" : "nicidienase",
    "protected" : false,
    "id_str" : "22396883",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3125784966/8223a4c5c9535be22d15c82ec829c2df_normal.jpeg",
    "id" : 22396883,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://getspaz.com\" rel=\"nofollow\">Spaz</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Not Safe For Work",
      "screen_name" : "me_nsfw",
      "indices" : [ 17, 25 ],
      "id_str" : "198895800",
      "id" : 198895800
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "145214445138886656",
  "text" : "Yeay, neue Folge @ME_NSFW :D",
  "id" : 145214445138886656,
  "created_at" : "Fri Dec 09 18:53:16 +0000 2011",
  "user" : {
    "name" : "Felix",
    "screen_name" : "nicidienase",
    "protected" : false,
    "id_str" : "22396883",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3125784966/8223a4c5c9535be22d15c82ec829c2df_normal.jpeg",
    "id" : 22396883,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://getspaz.com\" rel=\"nofollow\">Spaz</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lila Lola",
      "screen_name" : "lilaLakritz",
      "indices" : [ 3, 15 ],
      "id_str" : "233561699",
      "id" : 233561699
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "143994839636246528",
  "text" : "RT @lilaLakritz: Osterhasi!",
  "retweeted_status" : {
    "source" : "web",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : {
    },
    "id_str" : "143948722013876224",
    "text" : "Osterhasi!",
    "id" : 143948722013876224,
    "created_at" : "Tue Dec 06 07:03:44 +0000 2011",
    "user" : {
      "name" : "Lila Lola",
      "screen_name" : "lilaLakritz",
      "protected" : false,
      "id_str" : "233561699",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/1205713416/Photo_2_normal.jpg",
      "id" : 233561699,
      "verified" : false
    }
  },
  "id" : 143994839636246528,
  "created_at" : "Tue Dec 06 10:06:59 +0000 2011",
  "user" : {
    "name" : "Felix",
    "screen_name" : "nicidienase",
    "protected" : false,
    "id_str" : "22396883",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3125784966/8223a4c5c9535be22d15c82ec829c2df_normal.jpeg",
    "id" : 22396883,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://getspaz.com\" rel=\"nofollow\">Spaz HD for webOS</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Foxy",
      "screen_name" : "FxyMxy",
      "indices" : [ 3, 10 ],
      "id_str" : "165645655",
      "id" : 165645655
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "143873897916407808",
  "text" : "RT @FxyMxy: Roses are red, Violets are blue. I suck at poems. Nice tits.",
  "retweeted_status" : {
    "source" : "<a href=\"http://seesmic.com/\" rel=\"nofollow\">Seesmic</a>",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : {
    },
    "id_str" : "143805442517250048",
    "text" : "Roses are red, Violets are blue. I suck at poems. Nice tits.",
    "id" : 143805442517250048,
    "created_at" : "Mon Dec 05 21:34:23 +0000 2011",
    "user" : {
      "name" : "Foxy",
      "screen_name" : "FxyMxy",
      "protected" : false,
      "id_str" : "165645655",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/3499800884/235115ae9871816089636279559b9023_normal.jpeg",
      "id" : 165645655,
      "verified" : false
    }
  },
  "id" : 143873897916407808,
  "created_at" : "Tue Dec 06 02:06:24 +0000 2011",
  "user" : {
    "name" : "Felix",
    "screen_name" : "nicidienase",
    "protected" : false,
    "id_str" : "22396883",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3125784966/8223a4c5c9535be22d15c82ec829c2df_normal.jpeg",
    "id" : 22396883,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://getspaz.com\" rel=\"nofollow\">Spaz</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "142384596770750465",
  "text" : "Erstes Info1-Tutoren-Gehalt is angekommen. Erst mal neue Hardware (SSD und mehr RAM) gekauft.",
  "id" : 142384596770750465,
  "created_at" : "Thu Dec 01 23:28:27 +0000 2011",
  "user" : {
    "name" : "Felix",
    "screen_name" : "nicidienase",
    "protected" : false,
    "id_str" : "22396883",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3125784966/8223a4c5c9535be22d15c82ec829c2df_normal.jpeg",
    "id" : 22396883,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://getspaz.com\" rel=\"nofollow\">Spaz</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "142252425938604032",
  "text" : "Bedienungsanleitung.rtfm",
  "id" : 142252425938604032,
  "created_at" : "Thu Dec 01 14:43:15 +0000 2011",
  "user" : {
    "name" : "Felix",
    "screen_name" : "nicidienase",
    "protected" : false,
    "id_str" : "22396883",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3125784966/8223a4c5c9535be22d15c82ec829c2df_normal.jpeg",
    "id" : 22396883,
    "verified" : false
  }
} ]