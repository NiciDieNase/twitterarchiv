Grailbird.data.tweets_2009_09 = 
 [ {
  "source" : "<a href=\"https://launchpad.net/gwibber/\" rel=\"nofollow\">Gwibber</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "piraten",
      "indices" : [ 129, 137 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "4455119816",
  "text" : "Bild.de fragt ob man Piraten erst nehmen muss: http://is.gd/3Li8a Was soll da bei einer Onlineumfrage anderes rauskommen als JA! #piraten",
  "id" : 4455119816,
  "created_at" : "Mon Sep 28 22:57:14 +0000 2009",
  "user" : {
    "name" : "Felix",
    "screen_name" : "nicidienase",
    "protected" : false,
    "id_str" : "22396883",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3125784966/8223a4c5c9535be22d15c82ec829c2df_normal.jpeg",
    "id" : 22396883,
    "verified" : false
  }
}, {
  "source" : "<a href=\"https://launchpad.net/gwibber/\" rel=\"nofollow\">Gwibber</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "robinro",
      "screen_name" : "robinro",
      "indices" : [ 0, 8 ],
      "id_str" : "14897479",
      "id" : 14897479
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "4423994892",
  "in_reply_to_user_id" : 14897479,
  "text" : "@robinro schade das nicht mehr Bezirke so gew\u00E4hlt haben. In PF fallen die Piraten noch unter Sonst. Hab leider nur Zahlen von meinem Bezirk",
  "id" : 4423994892,
  "created_at" : "Sun Sep 27 19:44:53 +0000 2009",
  "in_reply_to_screen_name" : "robinro",
  "in_reply_to_user_id_str" : "14897479",
  "user" : {
    "name" : "Felix",
    "screen_name" : "nicidienase",
    "protected" : false,
    "id_str" : "22396883",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3125784966/8223a4c5c9535be22d15c82ec829c2df_normal.jpeg",
    "id" : 22396883,
    "verified" : false
  }
}, {
  "source" : "<a href=\"https://launchpad.net/gwibber/\" rel=\"nofollow\">Gwibber</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "robinro",
      "screen_name" : "robinro",
      "indices" : [ 0, 8 ],
      "id_str" : "14897479",
      "id" : 14897479
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "btw09",
      "indices" : [ 89, 95 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "4422945398",
  "in_reply_to_user_id" : 14897479,
  "text" : "@robinro die 3,2% entsprechen 16 Stimmen, damit waren die Piraten sechst st\u00E4rkste Kraft. #btw09",
  "id" : 4422945398,
  "created_at" : "Sun Sep 27 18:55:15 +0000 2009",
  "in_reply_to_screen_name" : "robinro",
  "in_reply_to_user_id_str" : "14897479",
  "user" : {
    "name" : "Felix",
    "screen_name" : "nicidienase",
    "protected" : false,
    "id_str" : "22396883",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3125784966/8223a4c5c9535be22d15c82ec829c2df_normal.jpeg",
    "id" : 22396883,
    "verified" : false
  }
}, {
  "source" : "<a href=\"https://launchpad.net/gwibber/\" rel=\"nofollow\">Gwibber</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "wahlhelfer",
      "indices" : [ 72, 83 ]
    }, {
      "text" : "btw09",
      "indices" : [ 84, 90 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "4422812105",
  "text" : "Der interessanteste Stimmzettel war einer mit Stimmen f\u00FCr Linke und NPD #wahlhelfer #btw09",
  "id" : 4422812105,
  "created_at" : "Sun Sep 27 18:48:50 +0000 2009",
  "user" : {
    "name" : "Felix",
    "screen_name" : "nicidienase",
    "protected" : false,
    "id_str" : "22396883",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3125784966/8223a4c5c9535be22d15c82ec829c2df_normal.jpeg",
    "id" : 22396883,
    "verified" : false
  }
}, {
  "source" : "<a href=\"https://launchpad.net/gwibber/\" rel=\"nofollow\">Gwibber</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "piraten",
      "indices" : [ 33, 41 ]
    }, {
      "text" : "wahlhelfer",
      "indices" : [ 111, 122 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "4422749761",
  "text" : "Bei uns im Wahlbezirk hatten die #piraten 3,2 Prozent, schade das es bundesweit net ganz so viel geworden ist. #wahlhelfer",
  "id" : 4422749761,
  "created_at" : "Sun Sep 27 18:45:52 +0000 2009",
  "user" : {
    "name" : "Felix",
    "screen_name" : "nicidienase",
    "protected" : false,
    "id_str" : "22396883",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3125784966/8223a4c5c9535be22d15c82ec829c2df_normal.jpeg",
    "id" : 22396883,
    "verified" : false
  }
}, {
  "source" : "<a href=\"https://launchpad.net/gwibber/\" rel=\"nofollow\">Gwibber</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "btw09",
      "indices" : [ 118, 124 ]
    }, {
      "text" : "wahlhelfer",
      "indices" : [ 125, 136 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "4418923358",
  "text" : "Gleich geht zur\u00FCck ins Wahllokal zum Ausz\u00E4hlen. Bin gespannt auf Wahlbeteiligung und am meisten auf Piratenergebniss. #btw09 #wahlhelfer",
  "id" : 4418923358,
  "created_at" : "Sun Sep 27 15:42:59 +0000 2009",
  "user" : {
    "name" : "Felix",
    "screen_name" : "nicidienase",
    "protected" : false,
    "id_str" : "22396883",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3125784966/8223a4c5c9535be22d15c82ec829c2df_normal.jpeg",
    "id" : 22396883,
    "verified" : false
  }
}, {
  "source" : "<a href=\"https://launchpad.net/gwibber/\" rel=\"nofollow\">Gwibber</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "votelikeapiratday",
      "indices" : [ 96, 114 ]
    }, {
      "text" : "btw09",
      "indices" : [ 115, 121 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "4415368161",
  "text" : "Wahldienst zur H\u00E4lfte rum, um 18Uhr gehts weiter mit Ausz\u00E4hlen. Hoffe auf viele Piratenstimmen. #votelikeapiratday #btw09",
  "id" : 4415368161,
  "created_at" : "Sun Sep 27 11:48:53 +0000 2009",
  "user" : {
    "name" : "Felix",
    "screen_name" : "nicidienase",
    "protected" : false,
    "id_str" : "22396883",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3125784966/8223a4c5c9535be22d15c82ec829c2df_normal.jpeg",
    "id" : 22396883,
    "verified" : false
  }
}, {
  "source" : "<a href=\"https://launchpad.net/gwibber/\" rel=\"nofollow\">Gwibber</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Moritz U.",
      "screen_name" : "the_kenny",
      "indices" : [ 0, 10 ],
      "id_str" : "26379802",
      "id" : 26379802
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "4402794317",
  "in_reply_to_user_id" : 26379802,
  "text" : "@The_Kenny du bist eindeutig ein Pirat der Pi nicht raten muss",
  "id" : 4402794317,
  "created_at" : "Sat Sep 26 21:52:19 +0000 2009",
  "in_reply_to_screen_name" : "the_kenny",
  "in_reply_to_user_id_str" : "26379802",
  "user" : {
    "name" : "Felix",
    "screen_name" : "nicidienase",
    "protected" : false,
    "id_str" : "22396883",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3125784966/8223a4c5c9535be22d15c82ec829c2df_normal.jpeg",
    "id" : 22396883,
    "verified" : false
  }
}, {
  "source" : "<a href=\"https://launchpad.net/gwibber/\" rel=\"nofollow\">Gwibber</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "piratenbtw09",
      "indices" : [ 0, 13 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "4402518738",
  "text" : "#piratenbtw09 5%+ w\u00E4ren genial realistisch sind 3-4% auf jeden Fall drin",
  "id" : 4402518738,
  "created_at" : "Sat Sep 26 21:37:08 +0000 2009",
  "user" : {
    "name" : "Felix",
    "screen_name" : "nicidienase",
    "protected" : false,
    "id_str" : "22396883",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3125784966/8223a4c5c9535be22d15c82ec829c2df_normal.jpeg",
    "id" : 22396883,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "btw09",
      "indices" : [ 80, 86 ]
    }, {
      "text" : "raab",
      "indices" : [ 87, 92 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "4401947430",
  "text" : "Wie schlimm muss es bei PRO7 stehn wenn Sido Fachmann Nr.2 in sachen Wahl ist?? #btw09 #raab",
  "id" : 4401947430,
  "created_at" : "Sat Sep 26 21:05:33 +0000 2009",
  "user" : {
    "name" : "Felix",
    "screen_name" : "nicidienase",
    "protected" : false,
    "id_str" : "22396883",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3125784966/8223a4c5c9535be22d15c82ec829c2df_normal.jpeg",
    "id" : 22396883,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Arbeitskreis Zensur",
      "screen_name" : "akzensur",
      "indices" : [ 95, 104 ],
      "id_str" : "34256245",
      "id" : 34256245
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "4380454263",
  "text" : "vdL will niemanden an den Pranger stellen, wie peinlich ist das denn? http://bit.ly/7BRoo (via @akzensur)",
  "id" : 4380454263,
  "created_at" : "Fri Sep 25 23:02:36 +0000 2009",
  "user" : {
    "name" : "Felix",
    "screen_name" : "nicidienase",
    "protected" : false,
    "id_str" : "22396883",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3125784966/8223a4c5c9535be22d15c82ec829c2df_normal.jpeg",
    "id" : 22396883,
    "verified" : false
  }
}, {
  "source" : "<a href=\"https://launchpad.net/gwibber/\" rel=\"nofollow\">Gwibber</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "4371998198",
  "text" : "So, Koffer ist gepackt. In 20min f\u00E4hrt die S-Bahn. Bin am Wahlwochenende daheim in Pforzheim.",
  "id" : 4371998198,
  "created_at" : "Fri Sep 25 16:26:34 +0000 2009",
  "user" : {
    "name" : "Felix",
    "screen_name" : "nicidienase",
    "protected" : false,
    "id_str" : "22396883",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3125784966/8223a4c5c9535be22d15c82ec829c2df_normal.jpeg",
    "id" : 22396883,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.piratenvogel.de/\" rel=\"nofollow\">Piratenvogel</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Piratenpartei",
      "screen_name" : "Piratenpartei",
      "indices" : [ 16, 30 ],
      "id_str" : "14341194",
      "id" : 14341194
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Piraten",
      "indices" : [ 77, 85 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "4370054281",
  "text" : "Unterst\u00FCtze die @Piratenpartei und zeige Flagge! http://www.piratenvogel.de/ #Piraten+",
  "id" : 4370054281,
  "created_at" : "Fri Sep 25 15:02:03 +0000 2009",
  "user" : {
    "name" : "Felix",
    "screen_name" : "nicidienase",
    "protected" : false,
    "id_str" : "22396883",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3125784966/8223a4c5c9535be22d15c82ec829c2df_normal.jpeg",
    "id" : 22396883,
    "verified" : false
  }
}, {
  "source" : "<a href=\"https://launchpad.net/gwibber/\" rel=\"nofollow\">Gwibber</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "4369977569",
  "text" : "Das nenn ich mal kreative Wahlwerbung http://piraten.in/3y3",
  "id" : 4369977569,
  "created_at" : "Fri Sep 25 14:58:41 +0000 2009",
  "user" : {
    "name" : "Felix",
    "screen_name" : "nicidienase",
    "protected" : false,
    "id_str" : "22396883",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3125784966/8223a4c5c9535be22d15c82ec829c2df_normal.jpeg",
    "id" : 22396883,
    "verified" : false
  }
}, {
  "source" : "<a href=\"https://launchpad.net/gwibber/\" rel=\"nofollow\">Gwibber</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "4369890963",
  "text" : "Familienstreit bei Skywalkers http://is.gd/3Ffet",
  "id" : 4369890963,
  "created_at" : "Fri Sep 25 14:54:35 +0000 2009",
  "user" : {
    "name" : "Felix",
    "screen_name" : "nicidienase",
    "protected" : false,
    "id_str" : "22396883",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3125784966/8223a4c5c9535be22d15c82ec829c2df_normal.jpeg",
    "id" : 22396883,
    "verified" : false
  }
}, {
  "source" : "<a href=\"https://launchpad.net/gwibber/\" rel=\"nofollow\">Gwibber</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Felicia Day",
      "screen_name" : "feliciaday",
      "indices" : [ 3, 14 ],
      "id_str" : "7861312",
      "id" : 7861312
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "4356025318",
  "text" : "RT @feliciaday: Well, this is cool: http://bit.ly/2JLIAe",
  "id" : 4356025318,
  "created_at" : "Fri Sep 25 00:39:05 +0000 2009",
  "user" : {
    "name" : "Felix",
    "screen_name" : "nicidienase",
    "protected" : false,
    "id_str" : "22396883",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3125784966/8223a4c5c9535be22d15c82ec829c2df_normal.jpeg",
    "id" : 22396883,
    "verified" : false
  }
}, {
  "source" : "<a href=\"https://launchpad.net/gwibber/\" rel=\"nofollow\">Gwibber</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "4351543420",
  "text" : "Oh Gott, es gibt doch echt wichtigere Sachen als die Unterw\u00E4sche der Bundeswehr. http://is.gd/3DI9b",
  "id" : 4351543420,
  "created_at" : "Thu Sep 24 21:12:05 +0000 2009",
  "user" : {
    "name" : "Felix",
    "screen_name" : "nicidienase",
    "protected" : false,
    "id_str" : "22396883",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3125784966/8223a4c5c9535be22d15c82ec829c2df_normal.jpeg",
    "id" : 22396883,
    "verified" : false
  }
}, {
  "source" : "<a href=\"https://launchpad.net/gwibber/\" rel=\"nofollow\">Gwibber</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Maurissa Tancharoen",
      "screen_name" : "MoTancharoen",
      "indices" : [ 3, 16 ],
      "id_str" : "22643137",
      "id" : 22643137
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "4317629790",
  "geo" : {
  },
  "id_str" : "4317788809",
  "in_reply_to_user_id" : 22643137,
  "text" : "RT @MoTancharoen: Lego Dr. Horrible! http://bit.ly/l147R",
  "id" : 4317788809,
  "in_reply_to_status_id" : 4317629790,
  "created_at" : "Wed Sep 23 15:32:34 +0000 2009",
  "in_reply_to_screen_name" : "MoTancharoen",
  "in_reply_to_user_id_str" : "22643137",
  "user" : {
    "name" : "Felix",
    "screen_name" : "nicidienase",
    "protected" : false,
    "id_str" : "22396883",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3125784966/8223a4c5c9535be22d15c82ec829c2df_normal.jpeg",
    "id" : 22396883,
    "verified" : false
  }
}, {
  "source" : "<a href=\"https://launchpad.net/gwibber/\" rel=\"nofollow\">Gwibber</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "4310904110",
  "text" : "EU-weite Petition f\u00FCr Netzneutralit\u00E4t: http://is.gd/3ADMz",
  "id" : 4310904110,
  "created_at" : "Wed Sep 23 07:52:12 +0000 2009",
  "user" : {
    "name" : "Felix",
    "screen_name" : "nicidienase",
    "protected" : false,
    "id_str" : "22396883",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3125784966/8223a4c5c9535be22d15c82ec829c2df_normal.jpeg",
    "id" : 22396883,
    "verified" : false
  }
}, {
  "source" : "<a href=\"https://launchpad.net/gwibber/\" rel=\"nofollow\">Gwibber</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "piraten",
      "indices" : [ 0, 8 ]
    }, {
      "text" : "btw09",
      "indices" : [ 53, 59 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "4156945603",
  "text" : "#piraten+ song zur Bundestagswahl http://is.gd/3xxha #btw09",
  "id" : 4156945603,
  "created_at" : "Mon Sep 21 22:14:13 +0000 2009",
  "user" : {
    "name" : "Felix",
    "screen_name" : "nicidienase",
    "protected" : false,
    "id_str" : "22396883",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3125784966/8223a4c5c9535be22d15c82ec829c2df_normal.jpeg",
    "id" : 22396883,
    "verified" : false
  }
}, {
  "source" : "<a href=\"https://launchpad.net/gwibber/\" rel=\"nofollow\">Gwibber</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dr. Horrible",
      "screen_name" : "drhorrible",
      "indices" : [ 4, 15 ],
      "id_str" : "15249156",
      "id" : 15249156
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Emmys09",
      "indices" : [ 24, 32 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "4144035285",
  "text" : "LOL @drhorrible hijacks #Emmys09 http://is.gd/3wkfX",
  "id" : 4144035285,
  "created_at" : "Mon Sep 21 10:56:33 +0000 2009",
  "user" : {
    "name" : "Felix",
    "screen_name" : "nicidienase",
    "protected" : false,
    "id_str" : "22396883",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3125784966/8223a4c5c9535be22d15c82ec829c2df_normal.jpeg",
    "id" : 22396883,
    "verified" : false
  }
}, {
  "source" : "<a href=\"https://launchpad.net/gwibber/\" rel=\"nofollow\">Gwibber</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Gerd Eist",
      "screen_name" : "erdgeist",
      "indices" : [ 3, 12 ],
      "id_str" : "16701619",
      "id" : 16701619
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "4143583089",
  "text" : "RT @erdgeist: Wer sich schon immer gefragt hat, woher ih* die Pose auf den Angie-Plakaten bekannt vorkommt\u2026 http://is.gd/3uSrb",
  "id" : 4143583089,
  "created_at" : "Mon Sep 21 10:10:58 +0000 2009",
  "user" : {
    "name" : "Felix",
    "screen_name" : "nicidienase",
    "protected" : false,
    "id_str" : "22396883",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3125784966/8223a4c5c9535be22d15c82ec829c2df_normal.jpeg",
    "id" : 22396883,
    "verified" : false
  }
}, {
  "source" : "<a href=\"https://launchpad.net/gwibber/\" rel=\"nofollow\">Gwibber</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Piratenpartei NRW",
      "screen_name" : "PiratenNRW",
      "indices" : [ 3, 14 ],
      "id_str" : "36646869",
      "id" : 36646869
    }, {
      "name" : "Oliver Bienkowski ",
      "screen_name" : "Lightartist",
      "indices" : [ 33, 45 ],
      "id_str" : "17731295",
      "id" : 17731295
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Piraten",
      "indices" : [ 19, 27 ]
    }, {
      "text" : "Vodafail",
      "indices" : [ 72, 81 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "4121264858",
  "text" : "RT @PiratenNRW Die #Piraten+ und @lightartist entern den Zensurprovider #Vodafail- http://twitpic.com/if7k7",
  "id" : 4121264858,
  "created_at" : "Sun Sep 20 09:45:53 +0000 2009",
  "user" : {
    "name" : "Felix",
    "screen_name" : "nicidienase",
    "protected" : false,
    "id_str" : "22396883",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3125784966/8223a4c5c9535be22d15c82ec829c2df_normal.jpeg",
    "id" : 22396883,
    "verified" : false
  }
}, {
  "source" : "<a href=\"https://launchpad.net/gwibber/\" rel=\"nofollow\">Gwibber</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Thistell",
      "screen_name" : "thistell",
      "indices" : [ 3, 12 ],
      "id_str" : "66698647",
      "id" : 66698647
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "EnterDenRaab",
      "indices" : [ 22, 35 ]
    }, {
      "text" : "Piraten",
      "indices" : [ 108, 116 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "4036924087",
  "text" : "RT @thistell: \"Aktion #EnterDenRaab -Kritische Masse erreicht - Aufruf zum Mitmachen\" - http://bit.ly/GQxjD #Piraten+",
  "id" : 4036924087,
  "created_at" : "Wed Sep 16 20:01:29 +0000 2009",
  "user" : {
    "name" : "Felix",
    "screen_name" : "nicidienase",
    "protected" : false,
    "id_str" : "22396883",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3125784966/8223a4c5c9535be22d15c82ec829c2df_normal.jpeg",
    "id" : 22396883,
    "verified" : false
  }
}, {
  "source" : "<a href=\"https://launchpad.net/gwibber/\" rel=\"nofollow\">Gwibber</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Piratenpartei",
      "indices" : [ 22, 36 ]
    }, {
      "text" : "Piraten",
      "indices" : [ 69, 77 ]
    }, {
      "text" : "StudiVZ",
      "indices" : [ 78, 86 ]
    }, {
      "text" : "Merkel",
      "indices" : [ 87, 94 ]
    }, {
      "text" : "btw09",
      "indices" : [ 95, 101 ]
    }, {
      "text" : "Bundestagswahl",
      "indices" : [ 102, 117 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "4025946970",
  "text" : "Rasantes Wachstum der #Piratenpartei http://wp.me/pBJT0-94 Please RT #Piraten #StudiVZ #Merkel #btw09 #Bundestagswahl",
  "id" : 4025946970,
  "created_at" : "Wed Sep 16 09:26:36 +0000 2009",
  "user" : {
    "name" : "Felix",
    "screen_name" : "nicidienase",
    "protected" : false,
    "id_str" : "22396883",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3125784966/8223a4c5c9535be22d15c82ec829c2df_normal.jpeg",
    "id" : 22396883,
    "verified" : false
  }
}, {
  "source" : "<a href=\"https://launchpad.net/gwibber/\" rel=\"nofollow\">Gwibber</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Focker100",
      "indices" : [ 62, 72 ]
    }, {
      "text" : "stuttgart",
      "indices" : [ 96, 106 ]
    }, {
      "text" : "flughafen",
      "indices" : [ 107, 117 ]
    }, {
      "text" : "unfall",
      "indices" : [ 118, 125 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "3977145820",
  "text" : "Grad gewaltig erschrocken, gestern sind meine Eltern mit eine #Focker100 in den Urlaub geflogen #stuttgart #flughafen #unfall",
  "id" : 3977145820,
  "created_at" : "Mon Sep 14 09:38:10 +0000 2009",
  "user" : {
    "name" : "Felix",
    "screen_name" : "nicidienase",
    "protected" : false,
    "id_str" : "22396883",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3125784966/8223a4c5c9535be22d15c82ec829c2df_normal.jpeg",
    "id" : 22396883,
    "verified" : false
  }
}, {
  "source" : "<a href=\"https://launchpad.net/gwibber/\" rel=\"nofollow\">Gwibber</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Throki",
      "screen_name" : "Throki",
      "indices" : [ 3, 10 ],
      "id_str" : "49052536",
      "id" : 49052536
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Datenschutz",
      "indices" : [ 30, 42 ]
    }, {
      "text" : "Internet",
      "indices" : [ 44, 53 ]
    }, {
      "text" : "Co",
      "indices" : [ 56, 59 ]
    }, {
      "text" : "tvduell",
      "indices" : [ 70, 78 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "3960765479",
  "text" : "RT @Throki: Bisher nichts zum #Datenschutz, #Internet & #Co - schade! #tvduell",
  "id" : 3960765479,
  "created_at" : "Sun Sep 13 19:56:48 +0000 2009",
  "user" : {
    "name" : "Felix",
    "screen_name" : "nicidienase",
    "protected" : false,
    "id_str" : "22396883",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3125784966/8223a4c5c9535be22d15c82ec829c2df_normal.jpeg",
    "id" : 22396883,
    "verified" : false
  }
}, {
  "source" : "<a href=\"https://launchpad.net/gwibber/\" rel=\"nofollow\">Gwibber</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Piraten",
      "indices" : [ 81, 89 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "3960695572",
  "text" : "Wenn keiner \u00FCber 50% kommt wo gehn dann die ganzen restliche Prozent hin? Zu den #Piraten+ ? ;)",
  "id" : 3960695572,
  "created_at" : "Sun Sep 13 19:52:55 +0000 2009",
  "user" : {
    "name" : "Felix",
    "screen_name" : "nicidienase",
    "protected" : false,
    "id_str" : "22396883",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3125784966/8223a4c5c9535be22d15c82ec829c2df_normal.jpeg",
    "id" : 22396883,
    "verified" : false
  }
}, {
  "source" : "<a href=\"https://launchpad.net/gwibber/\" rel=\"nofollow\">Gwibber</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "tvduell",
      "indices" : [ 86, 94 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "3960663393",
  "text" : "Uii, Steinmeier hat grad die erste Frage direkt an Merkel gerichtet, kurz vor Schluss #tvduell",
  "id" : 3960663393,
  "created_at" : "Sun Sep 13 19:51:07 +0000 2009",
  "user" : {
    "name" : "Felix",
    "screen_name" : "nicidienase",
    "protected" : false,
    "id_str" : "22396883",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3125784966/8223a4c5c9535be22d15c82ec829c2df_normal.jpeg",
    "id" : 22396883,
    "verified" : false
  }
}, {
  "source" : "<a href=\"https://launchpad.net/gwibber/\" rel=\"nofollow\">Gwibber</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "3949203829",
  "text" : "*g\u00E4hn* Eigentlich viel zu fr\u00FCh um schon wach zu sein. Muss meine Eltern nach Stuttgart aufn Flughafen fahren.",
  "id" : 3949203829,
  "created_at" : "Sun Sep 13 04:52:40 +0000 2009",
  "user" : {
    "name" : "Felix",
    "screen_name" : "nicidienase",
    "protected" : false,
    "id_str" : "22396883",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3125784966/8223a4c5c9535be22d15c82ec829c2df_normal.jpeg",
    "id" : 22396883,
    "verified" : false
  }
}, {
  "source" : "<a href=\"https://launchpad.net/gwibber/\" rel=\"nofollow\">Gwibber</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "3919932443",
  "text" : "The needs of the few do not outweigh the needs of the many: http://is.gd/3a2eR",
  "id" : 3919932443,
  "created_at" : "Fri Sep 11 21:21:07 +0000 2009",
  "user" : {
    "name" : "Felix",
    "screen_name" : "nicidienase",
    "protected" : false,
    "id_str" : "22396883",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3125784966/8223a4c5c9535be22d15c82ec829c2df_normal.jpeg",
    "id" : 22396883,
    "verified" : false
  }
}, {
  "source" : "<a href=\"https://launchpad.net/gwibber/\" rel=\"nofollow\">Gwibber</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "3916133774",
  "text" : "lol: Nerd Love Solve for \"i\": http://is.gd/39FRE",
  "id" : 3916133774,
  "created_at" : "Fri Sep 11 18:02:43 +0000 2009",
  "user" : {
    "name" : "Felix",
    "screen_name" : "nicidienase",
    "protected" : false,
    "id_str" : "22396883",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3125784966/8223a4c5c9535be22d15c82ec829c2df_normal.jpeg",
    "id" : 22396883,
    "verified" : false
  }
}, {
  "source" : "<a href=\"https://launchpad.net/gwibber/\" rel=\"nofollow\">Gwibber</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "serienjunkies",
      "screen_name" : "serienjunkies",
      "indices" : [ 87, 101 ],
      "id_str" : "15597707",
      "id" : 15597707
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "firefly",
      "indices" : [ 73, 81 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "3911128313",
  "text" : "Play by Day: Joss Whedons \u00ABFirefly\u00BB in Deutschland http://trim.li/nk/fGv #firefly (via @serienjunkies) Wurde aber auch Zeit!",
  "id" : 3911128313,
  "created_at" : "Fri Sep 11 13:44:20 +0000 2009",
  "user" : {
    "name" : "Felix",
    "screen_name" : "nicidienase",
    "protected" : false,
    "id_str" : "22396883",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3125784966/8223a4c5c9535be22d15c82ec829c2df_normal.jpeg",
    "id" : 22396883,
    "verified" : false
  }
}, {
  "source" : "<a href=\"https://launchpad.net/gwibber/\" rel=\"nofollow\">Gwibber</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Max Winde",
      "screen_name" : "343max",
      "indices" : [ 3, 10 ],
      "id_str" : "2284151",
      "id" : 2284151
    }, {
      "name" : "bosch",
      "screen_name" : "bosch",
      "indices" : [ 15, 21 ],
      "id_str" : "2836581",
      "id" : 2836581
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "3908354034",
  "text" : "RT @343max: RT @bosch: Endlich, Politiker verstehen das Internet: http://bit.ly/3Qg03y",
  "id" : 3908354034,
  "created_at" : "Fri Sep 11 09:58:22 +0000 2009",
  "user" : {
    "name" : "Felix",
    "screen_name" : "nicidienase",
    "protected" : false,
    "id_str" : "22396883",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3125784966/8223a4c5c9535be22d15c82ec829c2df_normal.jpeg",
    "id" : 22396883,
    "verified" : false
  }
}, {
  "source" : "<a href=\"https://launchpad.net/gwibber/\" rel=\"nofollow\">Gwibber</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Max Winde",
      "screen_name" : "343max",
      "indices" : [ 8, 15 ],
      "id_str" : "2284151",
      "id" : 2284151
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "3896949300",
  "geo" : {
  },
  "id_str" : "3897286254",
  "in_reply_to_user_id" : 2284151,
  "text" : "LOL RT: @343max: Abst\u00FCrzende Telefonzellen. http://twitpic.com/h8jde",
  "id" : 3897286254,
  "in_reply_to_status_id" : 3896949300,
  "created_at" : "Thu Sep 10 22:06:18 +0000 2009",
  "in_reply_to_screen_name" : "343max",
  "in_reply_to_user_id_str" : "2284151",
  "user" : {
    "name" : "Felix",
    "screen_name" : "nicidienase",
    "protected" : false,
    "id_str" : "22396883",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3125784966/8223a4c5c9535be22d15c82ec829c2df_normal.jpeg",
    "id" : 22396883,
    "verified" : false
  }
}, {
  "source" : "<a href=\"https://launchpad.net/gwibber/\" rel=\"nofollow\">Gwibber</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "3896680852",
  "text" : "Excellent: http://is.gd/37F5f",
  "id" : 3896680852,
  "created_at" : "Thu Sep 10 21:36:05 +0000 2009",
  "user" : {
    "name" : "Felix",
    "screen_name" : "nicidienase",
    "protected" : false,
    "id_str" : "22396883",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3125784966/8223a4c5c9535be22d15c82ec829c2df_normal.jpeg",
    "id" : 22396883,
    "verified" : false
  }
}, {
  "source" : "<a href=\"https://launchpad.net/gwibber/\" rel=\"nofollow\">Gwibber</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "3848421769",
  "text" : "Jaaa, wieder online. Internetausfall im Wohnheim vorbei. Zum Gl\u00FCck wars nur ne gute Stunde.",
  "id" : 3848421769,
  "created_at" : "Tue Sep 08 21:07:16 +0000 2009",
  "user" : {
    "name" : "Felix",
    "screen_name" : "nicidienase",
    "protected" : false,
    "id_str" : "22396883",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3125784966/8223a4c5c9535be22d15c82ec829c2df_normal.jpeg",
    "id" : 22396883,
    "verified" : false
  }
}, {
  "source" : "<a href=\"https://launchpad.net/gwibber/\" rel=\"nofollow\">Gwibber</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "piraten",
      "indices" : [ 55, 63 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "3838597996",
  "text" : "Gerade Briefwahlunterlagen aus dem Briefkasten geholt. #piraten+ stehn ganz unten auf dem Stimmzettel. Is das gut oder schlecht?",
  "id" : 3838597996,
  "created_at" : "Tue Sep 08 11:46:29 +0000 2009",
  "user" : {
    "name" : "Felix",
    "screen_name" : "nicidienase",
    "protected" : false,
    "id_str" : "22396883",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3125784966/8223a4c5c9535be22d15c82ec829c2df_normal.jpeg",
    "id" : 22396883,
    "verified" : false
  }
}, {
  "source" : "<a href=\"https://launchpad.net/gwibber/\" rel=\"nofollow\">Gwibber</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "3824813832",
  "text" : "Anti-Linux Kampagne von Microsoft: http://is.gd/30jhm Die m\u00FCssen ja wahnsinnige Angst haben.",
  "id" : 3824813832,
  "created_at" : "Mon Sep 07 19:59:39 +0000 2009",
  "user" : {
    "name" : "Felix",
    "screen_name" : "nicidienase",
    "protected" : false,
    "id_str" : "22396883",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3125784966/8223a4c5c9535be22d15c82ec829c2df_normal.jpeg",
    "id" : 22396883,
    "verified" : false
  }
}, {
  "source" : "<a href=\"https://launchpad.net/gwibber/\" rel=\"nofollow\">Gwibber</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Falk Steiner",
      "screen_name" : "flueke",
      "indices" : [ 3, 10 ],
      "id_str" : "5732872",
      "id" : 5732872
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "3764725570",
  "text" : "RT @flueke: http://twitpic.com/ggtvt - In Kreuzberger Kneipen findet man immer wieder Erstaunliches",
  "id" : 3764725570,
  "created_at" : "Fri Sep 04 20:32:15 +0000 2009",
  "user" : {
    "name" : "Felix",
    "screen_name" : "nicidienase",
    "protected" : false,
    "id_str" : "22396883",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3125784966/8223a4c5c9535be22d15c82ec829c2df_normal.jpeg",
    "id" : 22396883,
    "verified" : false
  }
}, {
  "source" : "<a href=\"https://launchpad.net/gwibber/\" rel=\"nofollow\">Gwibber</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "thebigbangtheory",
      "indices" : [ 0, 17 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "3759410642",
  "text" : "#thebigbangtheory Season 3 Promo: http://is.gd/2SJ72",
  "id" : 3759410642,
  "created_at" : "Fri Sep 04 15:57:28 +0000 2009",
  "user" : {
    "name" : "Felix",
    "screen_name" : "nicidienase",
    "protected" : false,
    "id_str" : "22396883",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3125784966/8223a4c5c9535be22d15c82ec829c2df_normal.jpeg",
    "id" : 22396883,
    "verified" : false
  }
}, {
  "source" : "<a href=\"https://launchpad.net/gwibber/\" rel=\"nofollow\">Gwibber</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "metronaut",
      "screen_name" : "metronaut",
      "indices" : [ 3, 13 ],
      "id_str" : "13688272",
      "id" : 13688272
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "CDURemix09",
      "indices" : [ 31, 42 ]
    }, {
      "text" : "BTW09",
      "indices" : [ 43, 49 ]
    }, {
      "text" : "Berlin",
      "indices" : [ 93, 100 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "3689476852",
  "text" : "RT @metronaut Lustiger Offline #CDURemix09 #BTW09 am Weinbergspark: http://twitpic.com/g2vw4 #Berlin",
  "id" : 3689476852,
  "created_at" : "Tue Sep 01 14:45:55 +0000 2009",
  "user" : {
    "name" : "Felix",
    "screen_name" : "nicidienase",
    "protected" : false,
    "id_str" : "22396883",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3125784966/8223a4c5c9535be22d15c82ec829c2df_normal.jpeg",
    "id" : 22396883,
    "verified" : false
  }
}, {
  "source" : "<a href=\"https://launchpad.net/gwibber/\" rel=\"nofollow\">Gwibber</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Piraten",
      "indices" : [ 65, 73 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "3686663318",
  "text" : "Warum gibts im StudiVZ als politische Richtung nicht \"Pirat\" ?!? #Piraten+",
  "id" : 3686663318,
  "created_at" : "Tue Sep 01 11:43:14 +0000 2009",
  "user" : {
    "name" : "Felix",
    "screen_name" : "nicidienase",
    "protected" : false,
    "id_str" : "22396883",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3125784966/8223a4c5c9535be22d15c82ec829c2df_normal.jpeg",
    "id" : 22396883,
    "verified" : false
  }
} ]