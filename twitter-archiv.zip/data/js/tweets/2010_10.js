Grailbird.data.tweets_2010_10 = 
 [ {
  "source" : "<a href=\"http://tweed.pivotallabs.com\" rel=\"nofollow\">Tweed webOS</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "webosblog",
      "screen_name" : "webos_blog",
      "indices" : [ 3, 14 ],
      "id_str" : "36693294",
      "id" : 36693294
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "28963680361",
  "text" : "RT @webos_blog: Alle mit einem Palm Pre bitte retweeten ;)",
  "retweeted_status" : {
    "source" : "<a href=\"http://seesmic.com/app\" rel=\"nofollow\">Seesmic Web</a>",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : {
    },
    "id_str" : "28922064916",
    "text" : "Alle mit einem Palm Pre bitte retweeten ;)",
    "id" : 28922064916,
    "created_at" : "Wed Oct 27 20:31:52 +0000 2010",
    "user" : {
      "name" : "webosblog",
      "screen_name" : "webos_blog",
      "protected" : false,
      "id_str" : "36693294",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/193412894/logo_normal.png",
      "id" : 36693294,
      "verified" : false
    }
  },
  "id" : 28963680361,
  "created_at" : "Thu Oct 28 06:12:03 +0000 2010",
  "user" : {
    "name" : "Felix",
    "screen_name" : "nicidienase",
    "protected" : false,
    "id_str" : "22396883",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3125784966/8223a4c5c9535be22d15c82ec829c2df_normal.jpeg",
    "id" : 22396883,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.bravenewcode.com/products/wordtwit\" rel=\"nofollow\">WordTwit Plugin</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "27678138034",
  "text" : "Neuer Blog-Beitrag, Serverstatistik - http://tinyurl.com/25rul8s",
  "id" : 27678138034,
  "created_at" : "Sun Oct 17 22:35:20 +0000 2010",
  "user" : {
    "name" : "Felix",
    "screen_name" : "nicidienase",
    "protected" : false,
    "id_str" : "22396883",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3125784966/8223a4c5c9535be22d15c82ec829c2df_normal.jpeg",
    "id" : 22396883,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://tweed.pivotallabs.com\" rel=\"nofollow\">Tweed webOS</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Eve",
      "screen_name" : "ChiisanaIchigo",
      "indices" : [ 0, 15 ],
      "id_str" : "187553346",
      "id" : 187553346
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "27477144088",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 48.899633, 8.685044 ]
  },
  "id_str" : "27529366334",
  "in_reply_to_user_id" : 187553346,
  "text" : "@ChiisanaIchigo Ja, da verpasst man zu Bsp. so sachen wie das O-Phasen-Eulenfest. Hab dich da nicht gesehn.",
  "id" : 27529366334,
  "in_reply_to_status_id" : 27477144088,
  "created_at" : "Sat Oct 16 10:25:00 +0000 2010",
  "in_reply_to_screen_name" : "ChiisanaIchigo",
  "in_reply_to_user_id_str" : "187553346",
  "user" : {
    "name" : "Felix",
    "screen_name" : "nicidienase",
    "protected" : false,
    "id_str" : "22396883",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3125784966/8223a4c5c9535be22d15c82ec829c2df_normal.jpeg",
    "id" : 22396883,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://tweed.pivotallabs.com\" rel=\"nofollow\">Tweed webOS</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u056Aungi\uE051",
      "screen_name" : "dungiBear",
      "indices" : [ 0, 10 ],
      "id_str" : "25672255",
      "id" : 25672255
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "27485352144",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 48.899633, 8.685044 ]
  },
  "id_str" : "27529164837",
  "in_reply_to_user_id" : 25672255,
  "text" : "@dungiBear Nein, Prof. Dr. Pape. Der sieht aus wie Steve Jobs, es fehlt nur der Rollkragen.",
  "id" : 27529164837,
  "in_reply_to_status_id" : 27485352144,
  "created_at" : "Sat Oct 16 10:20:49 +0000 2010",
  "in_reply_to_screen_name" : "dungiBear",
  "in_reply_to_user_id_str" : "25672255",
  "user" : {
    "name" : "Felix",
    "screen_name" : "nicidienase",
    "protected" : false,
    "id_str" : "22396883",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3125784966/8223a4c5c9535be22d15c82ec829c2df_normal.jpeg",
    "id" : 22396883,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://tweed.pivotallabs.com\" rel=\"nofollow\">Tweed webOS</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 49.008344, 8.417075 ]
  },
  "id_str" : "27449132090",
  "text" : "Schei\u00DF Fahrkartenautomaten. Da kommt man grade von der Bank mit sch\u00F6nem frischem Geld und dann will das Mistding keine Scheine fressen.",
  "id" : 27449132090,
  "created_at" : "Fri Oct 15 14:59:24 +0000 2010",
  "user" : {
    "name" : "Felix",
    "screen_name" : "nicidienase",
    "protected" : false,
    "id_str" : "22396883",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3125784966/8223a4c5c9535be22d15c82ec829c2df_normal.jpeg",
    "id" : 22396883,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://tweed.pivotallabs.com\" rel=\"nofollow\">Tweed webOS</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 49.01509, 8.392694 ]
  },
  "id_str" : "27417836055",
  "text" : "Irgendwie erinnert mich unser Info1-Prof. immer ein bisschen an Steve Jobs.",
  "id" : 27417836055,
  "created_at" : "Fri Oct 15 06:44:09 +0000 2010",
  "user" : {
    "name" : "Felix",
    "screen_name" : "nicidienase",
    "protected" : false,
    "id_str" : "22396883",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3125784966/8223a4c5c9535be22d15c82ec829c2df_normal.jpeg",
    "id" : 22396883,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://tweed.pivotallabs.com\" rel=\"nofollow\">Tweed webOS</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Max Winde",
      "screen_name" : "343max",
      "indices" : [ 3, 10 ],
      "id_str" : "2284151",
      "id" : 2284151
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "27367548379",
  "text" : "RT @343max: Wenn Guttenberg Kanzler wird, wird Harz IV vermutlich um 20\u20AC pro Monat f\u00FCr Haargel aufgestockt.",
  "retweeted_status" : {
    "source" : "<a href=\"http://www.echofon.com/\" rel=\"nofollow\">Echofon</a>",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : {
    },
    "id_str" : "27342163601",
    "text" : "Wenn Guttenberg Kanzler wird, wird Harz IV vermutlich um 20\u20AC pro Monat f\u00FCr Haargel aufgestockt.",
    "id" : 27342163601,
    "created_at" : "Thu Oct 14 13:49:34 +0000 2010",
    "user" : {
      "name" : "Max Winde",
      "screen_name" : "343max",
      "protected" : false,
      "id_str" : "2284151",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/1573654380/edween_normal.png",
      "id" : 2284151,
      "verified" : false
    }
  },
  "id" : 27367548379,
  "created_at" : "Thu Oct 14 18:57:37 +0000 2010",
  "user" : {
    "name" : "Felix",
    "screen_name" : "nicidienase",
    "protected" : false,
    "id_str" : "22396883",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3125784966/8223a4c5c9535be22d15c82ec829c2df_normal.jpeg",
    "id" : 22396883,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://tweed.pivotallabs.com\" rel=\"nofollow\">Tweed webOS</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Udo Vetter",
      "screen_name" : "udovetter",
      "indices" : [ 3, 13 ],
      "id_str" : "15998669",
      "id" : 15998669
    }, {
      "name" : "Jens Ferner",
      "screen_name" : "jensferner",
      "indices" : [ 18, 29 ],
      "id_str" : "18864811",
      "id" : 18864811
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "27286521146",
  "text" : "RT @udovetter: RT @jensferner: \"Fr. Guttenberg sind Sie das ... ?\": http://www.twitpic.com/2x7sf7/full",
  "retweeted_status" : {
    "source" : "<a href=\"http://www.tweetdeck.com\" rel=\"nofollow\">TweetDeck</a>",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Jens Ferner",
        "screen_name" : "jensferner",
        "indices" : [ 3, 14 ],
        "id_str" : "18864811",
        "id" : 18864811
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : {
    },
    "id_str" : "27262046657",
    "text" : "RT @jensferner: \"Fr. Guttenberg sind Sie das ... ?\": http://www.twitpic.com/2x7sf7/full",
    "id" : 27262046657,
    "created_at" : "Wed Oct 13 17:35:40 +0000 2010",
    "user" : {
      "name" : "Udo Vetter",
      "screen_name" : "udovetter",
      "protected" : false,
      "id_str" : "15998669",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/809406216/Cartoon_normal.jpg",
      "id" : 15998669,
      "verified" : true
    }
  },
  "id" : 27286521146,
  "created_at" : "Wed Oct 13 23:25:21 +0000 2010",
  "user" : {
    "name" : "Felix",
    "screen_name" : "nicidienase",
    "protected" : false,
    "id_str" : "22396883",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3125784966/8223a4c5c9535be22d15c82ec829c2df_normal.jpeg",
    "id" : 22396883,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://tweed.pivotallabs.com\" rel=\"nofollow\">Tweed webOS</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 49.015276, 8.390067 ]
  },
  "id_str" : "27217517701",
  "text" : "Theoretische Informatik, morgends um 8. \nLaptops und Kaffee, dann sind die Nerds gl\u00FCcklich. http://twitpic.com/2x7169",
  "id" : 27217517701,
  "created_at" : "Wed Oct 13 06:26:13 +0000 2010",
  "user" : {
    "name" : "Felix",
    "screen_name" : "nicidienase",
    "protected" : false,
    "id_str" : "22396883",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3125784966/8223a4c5c9535be22d15c82ec829c2df_normal.jpeg",
    "id" : 22396883,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://tweed.pivotallabs.com\" rel=\"nofollow\">Tweed webOS</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Grant Imahara",
      "screen_name" : "grantimahara",
      "indices" : [ 3, 16 ],
      "id_str" : "28521141",
      "id" : 28521141
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "geekpickuplines",
      "indices" : [ 43, 59 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "27114268771",
  "text" : "RT @grantimahara: Your IP address or mine? #geekpickuplines",
  "retweeted_status" : {
    "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "geekpickuplines",
        "indices" : [ 25, 41 ]
      } ],
      "urls" : [ ]
    },
    "geo" : {
    },
    "id_str" : "27104564025",
    "text" : "Your IP address or mine? #geekpickuplines",
    "id" : 27104564025,
    "created_at" : "Tue Oct 12 03:38:50 +0000 2010",
    "user" : {
      "name" : "Grant Imahara",
      "screen_name" : "grantimahara",
      "protected" : false,
      "id_str" : "28521141",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/3003132229/53338ad2b848f7f59261f53901a391a6_normal.jpeg",
      "id" : 28521141,
      "verified" : true
    }
  },
  "id" : 27114268771,
  "created_at" : "Tue Oct 12 06:14:42 +0000 2010",
  "user" : {
    "name" : "Felix",
    "screen_name" : "nicidienase",
    "protected" : false,
    "id_str" : "22396883",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3125784966/8223a4c5c9535be22d15c82ec829c2df_normal.jpeg",
    "id" : 22396883,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://tweed.pivotallabs.com\" rel=\"nofollow\">Tweed webOS</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Eve",
      "screen_name" : "ChiisanaIchigo",
      "indices" : [ 0, 15 ],
      "id_str" : "187553346",
      "id" : 187553346
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "26436073807",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 49.014342, 8.390358 ]
  },
  "id_str" : "26441289657",
  "in_reply_to_user_id" : 187553346,
  "text" : "@ChiisanaIchigo Happy Birthday!! Bei mir kommt die 23 auch bald.",
  "id" : 26441289657,
  "in_reply_to_status_id" : 26436073807,
  "created_at" : "Tue Oct 05 09:21:09 +0000 2010",
  "in_reply_to_screen_name" : "ChiisanaIchigo",
  "in_reply_to_user_id_str" : "187553346",
  "user" : {
    "name" : "Felix",
    "screen_name" : "nicidienase",
    "protected" : false,
    "id_str" : "22396883",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3125784966/8223a4c5c9535be22d15c82ec829c2df_normal.jpeg",
    "id" : 22396883,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "herr stoltenberg",
      "screen_name" : "stoltenberg",
      "indices" : [ 3, 15 ],
      "id_str" : "20439636",
      "id" : 20439636
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "s21",
      "indices" : [ 111, 115 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "26303821809",
  "text" : "RT @stoltenberg: mappus bekommt von mercedes-benz einen neuen \u00BBmapbus 2\u00AB f\u00FCr seine abschiedstournee geschenkt. #s21 http://twitpic.com/2 ...",
  "retweeted_status" : {
    "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Tweetie for Mac</a>",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "s21",
        "indices" : [ 94, 98 ]
      } ],
      "urls" : [ ]
    },
    "geo" : {
    },
    "id_str" : "26288371493",
    "text" : "mappus bekommt von mercedes-benz einen neuen \u00BBmapbus 2\u00AB f\u00FCr seine abschiedstournee geschenkt. #s21 http://twitpic.com/2ue2bz",
    "id" : 26288371493,
    "created_at" : "Sun Oct 03 18:08:14 +0000 2010",
    "user" : {
      "name" : "herr stoltenberg",
      "screen_name" : "stoltenberg",
      "protected" : false,
      "id_str" : "20439636",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/1496214845/3467832779_normal.png",
      "id" : 20439636,
      "verified" : false
    }
  },
  "id" : 26303821809,
  "created_at" : "Sun Oct 03 21:50:03 +0000 2010",
  "user" : {
    "name" : "Felix",
    "screen_name" : "nicidienase",
    "protected" : false,
    "id_str" : "22396883",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3125784966/8223a4c5c9535be22d15c82ec829c2df_normal.jpeg",
    "id" : 22396883,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://tweed.pivotallabs.com\" rel=\"nofollow\">Tweed webOS</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "KA",
      "indices" : [ 88, 91 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 48.899632, 8.685044 ]
  },
  "id_str" : "26268532948",
  "text" : "Geniese grade das sch\u00F6ne Wetter daheim in Pforzheim im Garten bevors wieder zur\u00FCck nach #KA geht. http://twitpic.com/2ubvbl",
  "id" : 26268532948,
  "created_at" : "Sun Oct 03 14:00:36 +0000 2010",
  "user" : {
    "name" : "Felix",
    "screen_name" : "nicidienase",
    "protected" : false,
    "id_str" : "22396883",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3125784966/8223a4c5c9535be22d15c82ec829c2df_normal.jpeg",
    "id" : 22396883,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://tweed.pivotallabs.com\" rel=\"nofollow\">Tweed webOS</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 48.930407, 8.639286 ]
  },
  "id_str" : "26163798496",
  "text" : "Dem Ger\u00E4usch und Alkoholpegel nach zu urteilen is die Mehrheit wohl auf dem Weg zum Wasen.",
  "id" : 26163798496,
  "created_at" : "Sat Oct 02 10:29:17 +0000 2010",
  "user" : {
    "name" : "Felix",
    "screen_name" : "nicidienase",
    "protected" : false,
    "id_str" : "22396883",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3125784966/8223a4c5c9535be22d15c82ec829c2df_normal.jpeg",
    "id" : 22396883,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://tweed.pivotallabs.com\" rel=\"nofollow\">Tweed webOS</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "S21",
      "indices" : [ 48, 52 ]
    }, {
      "text" : "Wasen",
      "indices" : [ 80, 86 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 49.001928, 8.458809 ]
  },
  "id_str" : "26163300295",
  "text" : "IRE KA-&gt;S extrem voll. Wollen die alle gegen #S21 demonstrieren oder auf den #Wasen?",
  "id" : 26163300295,
  "created_at" : "Sat Oct 02 10:18:12 +0000 2010",
  "user" : {
    "name" : "Felix",
    "screen_name" : "nicidienase",
    "protected" : false,
    "id_str" : "22396883",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3125784966/8223a4c5c9535be22d15c82ec829c2df_normal.jpeg",
    "id" : 22396883,
    "verified" : false
  }
} ]