Grailbird.data.tweets_2011_05 = 
 [ {
  "source" : "<a href=\"http://twitpic.com\" rel=\"nofollow\">Twitpic</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "75190390449377280",
  "text" : "Mein Bestand an nerdigen Textilien w\u00E4chst!! http://twitpic.com/54lxeg",
  "id" : 75190390449377280,
  "created_at" : "Mon May 30 13:22:40 +0000 2011",
  "user" : {
    "name" : "Felix",
    "screen_name" : "nicidienase",
    "protected" : false,
    "id_str" : "22396883",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3125784966/8223a4c5c9535be22d15c82ec829c2df_normal.jpeg",
    "id" : 22396883,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "73723655271628800",
  "text" : "Hilfe, mein Leben RickRollt mich, an meinem Geburtstag war \"Never gonna give you up\" Nr.1 in den Deutschen Charts. http://www.nr1finder.de",
  "id" : 73723655271628800,
  "created_at" : "Thu May 26 12:14:23 +0000 2011",
  "user" : {
    "name" : "Felix",
    "screen_name" : "nicidienase",
    "protected" : false,
    "id_str" : "22396883",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3125784966/8223a4c5c9535be22d15c82ec829c2df_normal.jpeg",
    "id" : 22396883,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://tweed.pivotallabs.com\" rel=\"nofollow\">Tweed webOS</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Moss E. Cobblestone",
      "screen_name" : "Graupause",
      "indices" : [ 3, 13 ],
      "id_str" : "159923693",
      "id" : 159923693
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "72562940137586689",
  "text" : "RT @Graupause: \"Ey, ich hab dasselbe T-Shirt!\"\n\"Es hei\u00DFt 'das gleiche'.\"\n\"Grammatiknazi!\"\n\"Nein, 'Semantiknazi'.\"",
  "retweeted_status" : {
    "source" : "web",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : {
    },
    "id_str" : "27965040905",
    "text" : "\"Ey, ich hab dasselbe T-Shirt!\"\n\"Es hei\u00DFt 'das gleiche'.\"\n\"Grammatiknazi!\"\n\"Nein, 'Semantiknazi'.\"",
    "id" : 27965040905,
    "created_at" : "Wed Oct 20 21:16:54 +0000 2010",
    "user" : {
      "name" : "Moss E. Cobblestone",
      "screen_name" : "Graupause",
      "protected" : false,
      "id_str" : "159923693",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/3506698733/01be12b9778a68eb15140616e19a54dd_normal.jpeg",
      "id" : 159923693,
      "verified" : false
    }
  },
  "id" : 72562940137586689,
  "created_at" : "Mon May 23 07:22:07 +0000 2011",
  "user" : {
    "name" : "Felix",
    "screen_name" : "nicidienase",
    "protected" : false,
    "id_str" : "22396883",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3125784966/8223a4c5c9535be22d15c82ec829c2df_normal.jpeg",
    "id" : 22396883,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.bravenewcode.com/products/wordtwit\" rel=\"nofollow\">WordTwit Plugin</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "70587823526387713",
  "text" : "Neuer Blog Beitrag, Clifford Stoll on ... everything - http://tinyurl.com/678dyzh",
  "id" : 70587823526387713,
  "created_at" : "Tue May 17 20:33:43 +0000 2011",
  "user" : {
    "name" : "Felix",
    "screen_name" : "nicidienase",
    "protected" : false,
    "id_str" : "22396883",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3125784966/8223a4c5c9535be22d15c82ec829c2df_normal.jpeg",
    "id" : 22396883,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.bravenewcode.com/products/wordtwit\" rel=\"nofollow\">WordTwit Plugin</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "69043922839670784",
  "text" : "New blog posting, Serverumzug abgeschlossen - http://tinyurl.com/69b7rph",
  "id" : 69043922839670784,
  "created_at" : "Fri May 13 14:18:48 +0000 2011",
  "user" : {
    "name" : "Felix",
    "screen_name" : "nicidienase",
    "protected" : false,
    "id_str" : "22396883",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3125784966/8223a4c5c9535be22d15c82ec829c2df_normal.jpeg",
    "id" : 22396883,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://tweed.pivotallabs.com\" rel=\"nofollow\">Tweed webOS</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Eve",
      "screen_name" : "ChiisanaIchigo",
      "indices" : [ 0, 15 ],
      "id_str" : "187553346",
      "id" : 187553346
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "66487575778557952",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 48.899633, 8.685045 ]
  },
  "id_str" : "66881599622483968",
  "in_reply_to_user_id" : 187553346,
  "text" : "@ChiisanaIchigo Wenn die Au\u00DFentemperatur gegen 40\u00B0C konvergiert wirst du dich sicher net mehr beschweren.",
  "id" : 66881599622483968,
  "in_reply_to_status_id" : 66487575778557952,
  "created_at" : "Sat May 07 15:06:30 +0000 2011",
  "in_reply_to_screen_name" : "ChiisanaIchigo",
  "in_reply_to_user_id_str" : "187553346",
  "user" : {
    "name" : "Felix",
    "screen_name" : "nicidienase",
    "protected" : false,
    "id_str" : "22396883",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3125784966/8223a4c5c9535be22d15c82ec829c2df_normal.jpeg",
    "id" : 22396883,
    "verified" : false
  }
} ]