Grailbird.data.tweets_2012_05 = 
 [ {
  "source" : "<a href=\"http://getspaz.com\" rel=\"nofollow\">Spaz HD for webOS</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Eva ",
      "screen_name" : "SchokoPralini",
      "indices" : [ 0, 14 ],
      "id_str" : "575695094",
      "id" : 575695094
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "207959467604717568",
  "geo" : {
  },
  "id_str" : "207971515424194560",
  "in_reply_to_user_id" : 575695094,
  "text" : "@SchokoPralini War alles noch trocken. Hab nochmal Gl\u00FCck gehabt.",
  "id" : 207971515424194560,
  "in_reply_to_status_id" : 207959467604717568,
  "created_at" : "Wed May 30 23:07:27 +0000 2012",
  "in_reply_to_screen_name" : "SchokoPralini",
  "in_reply_to_user_id_str" : "575695094",
  "user" : {
    "name" : "Felix",
    "screen_name" : "nicidienase",
    "protected" : false,
    "id_str" : "22396883",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3125784966/8223a4c5c9535be22d15c82ec829c2df_normal.jpeg",
    "id" : 22396883,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.echofon.com/\" rel=\"nofollow\">Echofon</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Eva ",
      "screen_name" : "SchokoPralini",
      "indices" : [ 0, 14 ],
      "id_str" : "575695094",
      "id" : 575695094
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "207859331968933888",
  "geo" : {
  },
  "id_str" : "207864027018305537",
  "in_reply_to_user_id" : 575695094,
  "text" : "@SchokoPralini Wenn ich Pech hab steht mein Zimmer unter Wasser wenn ich heim komm.",
  "id" : 207864027018305537,
  "in_reply_to_status_id" : 207859331968933888,
  "created_at" : "Wed May 30 16:00:20 +0000 2012",
  "in_reply_to_screen_name" : "SchokoPralini",
  "in_reply_to_user_id_str" : "575695094",
  "user" : {
    "name" : "Felix",
    "screen_name" : "nicidienase",
    "protected" : false,
    "id_str" : "22396883",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3125784966/8223a4c5c9535be22d15c82ec829c2df_normal.jpeg",
    "id" : 22396883,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.echofon.com/\" rel=\"nofollow\">Echofon</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tim Weber",
      "screen_name" : "Scytale",
      "indices" : [ 0, 8 ],
      "id_str" : "594921016",
      "id" : 594921016
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "207843322071482368",
  "geo" : {
  },
  "id_str" : "207844060831039489",
  "in_reply_to_user_id" : 8308632,
  "text" : "@Scytale You accidentaly in her base.",
  "id" : 207844060831039489,
  "in_reply_to_status_id" : 207843322071482368,
  "created_at" : "Wed May 30 14:41:00 +0000 2012",
  "in_reply_to_screen_name" : "scy",
  "in_reply_to_user_id_str" : "8308632",
  "user" : {
    "name" : "Felix",
    "screen_name" : "nicidienase",
    "protected" : false,
    "id_str" : "22396883",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3125784966/8223a4c5c9535be22d15c82ec829c2df_normal.jpeg",
    "id" : 22396883,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.echofon.com/\" rel=\"nofollow\">Echofon</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "neingeist",
      "screen_name" : "neingeist",
      "indices" : [ 14, 24 ],
      "id_str" : "11193712",
      "id" : 11193712
    }, {
      "name" : "Eva Eichhorn",
      "screen_name" : "MamsellChaos",
      "indices" : [ 26, 39 ],
      "id_str" : "140774041",
      "id" : 140774041
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "207807567353753600",
  "text" : "Ich auch! RT: @neingeist: @MamsellChaos Shorts Baumwolle mit beiden, also zwei :-)",
  "id" : 207807567353753600,
  "created_at" : "Wed May 30 12:15:59 +0000 2012",
  "user" : {
    "name" : "Felix",
    "screen_name" : "nicidienase",
    "protected" : false,
    "id_str" : "22396883",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3125784966/8223a4c5c9535be22d15c82ec829c2df_normal.jpeg",
    "id" : 22396883,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.echofon.com/\" rel=\"nofollow\">Echofon</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "neingeist",
      "screen_name" : "neingeist",
      "indices" : [ 0, 10 ],
      "id_str" : "11193712",
      "id" : 11193712
    }, {
      "name" : "Eva Eichhorn",
      "screen_name" : "MamsellChaos",
      "indices" : [ 11, 24 ],
      "id_str" : "140774041",
      "id" : 140774041
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "207803635286024193",
  "geo" : {
  },
  "id_str" : "207804177227841536",
  "in_reply_to_user_id" : 11193712,
  "text" : "@neingeist @MamsellChaos +1 Nyancat-Shorts f\u00FCr alle!!",
  "id" : 207804177227841536,
  "in_reply_to_status_id" : 207803635286024193,
  "created_at" : "Wed May 30 12:02:31 +0000 2012",
  "in_reply_to_screen_name" : "neingeist",
  "in_reply_to_user_id_str" : "11193712",
  "user" : {
    "name" : "Felix",
    "screen_name" : "nicidienase",
    "protected" : false,
    "id_str" : "22396883",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3125784966/8223a4c5c9535be22d15c82ec829c2df_normal.jpeg",
    "id" : 22396883,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.echofon.com/\" rel=\"nofollow\">Echofon</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Eva Eichhorn",
      "screen_name" : "MamsellChaos",
      "indices" : [ 0, 13 ],
      "id_str" : "140774041",
      "id" : 140774041
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "207786473615925248",
  "geo" : {
  },
  "id_str" : "207789383217197056",
  "in_reply_to_user_id" : 140774041,
  "text" : "@MamsellChaos Ich w\u00FCrde sofort ein Paar Nyancat-Shorts nehmen.",
  "id" : 207789383217197056,
  "in_reply_to_status_id" : 207786473615925248,
  "created_at" : "Wed May 30 11:03:44 +0000 2012",
  "in_reply_to_screen_name" : "MamsellChaos",
  "in_reply_to_user_id_str" : "140774041",
  "user" : {
    "name" : "Felix",
    "screen_name" : "nicidienase",
    "protected" : false,
    "id_str" : "22396883",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3125784966/8223a4c5c9535be22d15c82ec829c2df_normal.jpeg",
    "id" : 22396883,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.echofon.com/\" rel=\"nofollow\">Echofon</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Michael Seemann",
      "screen_name" : "mspro",
      "indices" : [ 3, 9 ],
      "id_str" : "5751892",
      "id" : 5751892
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "207748312915382272",
  "text" : "RT @mspro: obwohl es noch fr\u00FCh am morgen ist, halte ich es f\u00FCr dringend geboten auf folgenden mi\u00DFstand aufmerksam zu machen: http://t.co ...",
  "retweeted_status" : {
    "source" : "<a href=\"http://itunes.apple.com/us/app/twitter/id409789998?mt=12\" rel=\"nofollow\">Twitter for Mac</a>",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 114, 134 ],
        "url" : "http://t.co/A0nvbCPT",
        "expanded_url" : "http://www.buzzfeed.com/paws/awkward-cat-sleeping-positions",
        "display_url" : "buzzfeed.com/paws/awkward-c\u2026"
      } ]
    },
    "geo" : {
    },
    "id_str" : "207724015752724481",
    "text" : "obwohl es noch fr\u00FCh am morgen ist, halte ich es f\u00FCr dringend geboten auf folgenden mi\u00DFstand aufmerksam zu machen: http://t.co/A0nvbCPT",
    "id" : 207724015752724481,
    "created_at" : "Wed May 30 06:43:59 +0000 2012",
    "user" : {
      "name" : "Michael Seemann",
      "screen_name" : "mspro",
      "protected" : false,
      "id_str" : "5751892",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/3408641243/2edf38d3c995612edf5b3d2e20d74861_normal.jpeg",
      "id" : 5751892,
      "verified" : false
    }
  },
  "id" : 207748312915382272,
  "created_at" : "Wed May 30 08:20:32 +0000 2012",
  "user" : {
    "name" : "Felix",
    "screen_name" : "nicidienase",
    "protected" : false,
    "id_str" : "22396883",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3125784966/8223a4c5c9535be22d15c82ec829c2df_normal.jpeg",
    "id" : 22396883,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://getspaz.com\" rel=\"nofollow\">Spaz HD for webOS</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "CCC Updates",
      "screen_name" : "chaosupdates",
      "indices" : [ 3, 16 ],
      "id_str" : "31812497",
      "id" : 31812497
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "GPN12",
      "indices" : [ 42, 48 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "207620009256693760",
  "text" : "RT @chaosupdates: Gulaschprogrammiernacht #GPN12 \u2013 Bald geht's los! Von Donnerstag, den 7. Juni, bis Sonntag, den 10. Juni in Karlsruhe  ...",
  "retweeted_status" : {
    "source" : "web",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "GPN12",
        "indices" : [ 24, 30 ]
      } ],
      "urls" : [ {
        "indices" : [ 118, 138 ],
        "url" : "http://t.co/lZNdLPEV",
        "expanded_url" : "http://grin.to/BXBqQ",
        "display_url" : "grin.to/BXBqQ"
      } ]
    },
    "geo" : {
    },
    "id_str" : "207614351962685440",
    "text" : "Gulaschprogrammiernacht #GPN12 \u2013 Bald geht's los! Von Donnerstag, den 7. Juni, bis Sonntag, den 10. Juni in Karlsruhe http://t.co/lZNdLPEV",
    "id" : 207614351962685440,
    "created_at" : "Tue May 29 23:28:13 +0000 2012",
    "user" : {
      "name" : "CCC Updates",
      "screen_name" : "chaosupdates",
      "protected" : false,
      "id_str" : "31812497",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/140824344/Chaosknoten-gelbes-quadrat_normal.png",
      "id" : 31812497,
      "verified" : false
    }
  },
  "id" : 207620009256693760,
  "created_at" : "Tue May 29 23:50:42 +0000 2012",
  "user" : {
    "name" : "Felix",
    "screen_name" : "nicidienase",
    "protected" : false,
    "id_str" : "22396883",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3125784966/8223a4c5c9535be22d15c82ec829c2df_normal.jpeg",
    "id" : 22396883,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.echofon.com/\" rel=\"nofollow\">Echofon</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "s'Flusinsche",
      "screen_name" : "silbermund",
      "indices" : [ 3, 14 ],
      "id_str" : "22347158",
      "id" : 22347158
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "206042503214923777",
  "text" : "RT @silbermund: +++ Breaking +++ \nTeenager geschockt: Justin hat geheiratet und hei\u00DFt jetzt Bieber-Butzemann. \n+++ Breaking +++",
  "retweeted_status" : {
    "source" : "web",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : {
    },
    "id_str" : "19809377662",
    "text" : "+++ Breaking +++ \nTeenager geschockt: Justin hat geheiratet und hei\u00DFt jetzt Bieber-Butzemann. \n+++ Breaking +++",
    "id" : 19809377662,
    "created_at" : "Thu Jul 29 08:00:43 +0000 2010",
    "user" : {
      "name" : "s'Flusinsche",
      "screen_name" : "silbermund",
      "protected" : false,
      "id_str" : "22347158",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/3142051551/520e6e744dc9312dd0f26809f0e2a88c_normal.jpeg",
      "id" : 22347158,
      "verified" : false
    }
  },
  "id" : 206042503214923777,
  "created_at" : "Fri May 25 15:22:15 +0000 2012",
  "user" : {
    "name" : "Felix",
    "screen_name" : "nicidienase",
    "protected" : false,
    "id_str" : "22396883",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3125784966/8223a4c5c9535be22d15c82ec829c2df_normal.jpeg",
    "id" : 22396883,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.echofon.com/\" rel=\"nofollow\">Echofon</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Alexander Richter",
      "screen_name" : "Hybr1s",
      "indices" : [ 3, 10 ],
      "id_str" : "21610187",
      "id" : 21610187
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "206032024593637378",
  "text" : "RT @Hybr1s: Oh zerfrettelter Grunzwanzling\ndein Harngedr\u00E4nge ist f\u00FCr mich\nWie Schnatterfleck auf Bienenstich.",
  "retweeted_status" : {
    "source" : "<a href=\"http://www.osfoora.com/mac\" rel=\"nofollow\">Osfoora for Mac</a>",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : {
    },
    "id_str" : "206000464741924864",
    "text" : "Oh zerfrettelter Grunzwanzling\ndein Harngedr\u00E4nge ist f\u00FCr mich\nWie Schnatterfleck auf Bienenstich.",
    "id" : 206000464741924864,
    "created_at" : "Fri May 25 12:35:12 +0000 2012",
    "user" : {
      "name" : "Alexander Richter",
      "screen_name" : "Hybr1s",
      "protected" : false,
      "id_str" : "21610187",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/3051350900/05fe2f7043ae4474a8caa37a80a415a9_normal.jpeg",
      "id" : 21610187,
      "verified" : false
    }
  },
  "id" : 206032024593637378,
  "created_at" : "Fri May 25 14:40:37 +0000 2012",
  "user" : {
    "name" : "Felix",
    "screen_name" : "nicidienase",
    "protected" : false,
    "id_str" : "22396883",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3125784966/8223a4c5c9535be22d15c82ec829c2df_normal.jpeg",
    "id" : 22396883,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.echofon.com/\" rel=\"nofollow\">Echofon</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Corinna Milborn",
      "screen_name" : "corinnamilborn",
      "indices" : [ 3, 18 ],
      "id_str" : "28251658",
      "id" : 28251658
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "towelday",
      "indices" : [ 63, 72 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "205957082489434112",
  "text" : "RT @corinnamilborn: habt ihr alle euer handtuch mit? 25.5. ist #towelday - und heute ist der SUPER-towelday: 25+5+12=42!",
  "retweeted_status" : {
    "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "towelday",
        "indices" : [ 43, 52 ]
      } ],
      "urls" : [ ]
    },
    "geo" : {
    },
    "id_str" : "205922553183748096",
    "text" : "habt ihr alle euer handtuch mit? 25.5. ist #towelday - und heute ist der SUPER-towelday: 25+5+12=42!",
    "id" : 205922553183748096,
    "created_at" : "Fri May 25 07:25:37 +0000 2012",
    "user" : {
      "name" : "Corinna Milborn",
      "screen_name" : "corinnamilborn",
      "protected" : false,
      "id_str" : "28251658",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/422957799/cm3_normal.jpg",
      "id" : 28251658,
      "verified" : false
    }
  },
  "id" : 205957082489434112,
  "created_at" : "Fri May 25 09:42:49 +0000 2012",
  "user" : {
    "name" : "Felix",
    "screen_name" : "nicidienase",
    "protected" : false,
    "id_str" : "22396883",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3125784966/8223a4c5c9535be22d15c82ec829c2df_normal.jpeg",
    "id" : 22396883,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.echofon.com/\" rel=\"nofollow\">Echofon</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "monoxyd",
      "screen_name" : "monoxyd",
      "indices" : [ 3, 11 ],
      "id_str" : "14085052",
      "id" : 14085052
    }, {
      "name" : "\u269B Leon Weidauer",
      "screen_name" : "lnwdr",
      "indices" : [ 103, 109 ],
      "id_str" : "17742694",
      "id" : 17742694
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 77, 97 ],
      "url" : "http://t.co/oZjh5MOp",
      "expanded_url" : "http://arstechnica.com/information-technology/2012/05/no-cost-desktop-software-development-is-dead-on-windows-8/",
      "display_url" : "arstechnica.com/information-te\u2026"
    } ]
  },
  "geo" : {
  },
  "id_str" : "205950146305986560",
  "text" : "RT @monoxyd: And here you can watch Microsoft digging it's own grave. Again. http://t.co/oZjh5MOp /via @lnwdr",
  "retweeted_status" : {
    "source" : "<a href=\"http://tapbots.com/tweetbot\" rel=\"nofollow\">Tweetbot for iOS</a>",
    "entities" : {
      "user_mentions" : [ {
        "name" : "\u269B Leon Weidauer",
        "screen_name" : "lnwdr",
        "indices" : [ 90, 96 ],
        "id_str" : "17742694",
        "id" : 17742694
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 64, 84 ],
        "url" : "http://t.co/oZjh5MOp",
        "expanded_url" : "http://arstechnica.com/information-technology/2012/05/no-cost-desktop-software-development-is-dead-on-windows-8/",
        "display_url" : "arstechnica.com/information-te\u2026"
      } ]
    },
    "geo" : {
    },
    "id_str" : "205945834079141888",
    "text" : "And here you can watch Microsoft digging it's own grave. Again. http://t.co/oZjh5MOp /via @lnwdr",
    "id" : 205945834079141888,
    "created_at" : "Fri May 25 08:58:07 +0000 2012",
    "user" : {
      "name" : "monoxyd",
      "screen_name" : "monoxyd",
      "protected" : false,
      "id_str" : "14085052",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/1422306657/lampe_normal.jpg",
      "id" : 14085052,
      "verified" : false
    }
  },
  "id" : 205950146305986560,
  "created_at" : "Fri May 25 09:15:15 +0000 2012",
  "user" : {
    "name" : "Felix",
    "screen_name" : "nicidienase",
    "protected" : false,
    "id_str" : "22396883",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3125784966/8223a4c5c9535be22d15c82ec829c2df_normal.jpeg",
    "id" : 22396883,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.echofon.com/\" rel=\"nofollow\">Echofon</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "ratschlagpony",
      "screen_name" : "ratschlagpony",
      "indices" : [ 3, 17 ],
      "id_str" : "588158396",
      "id" : 588158396
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "205941376427376643",
  "text" : "RT @ratschlagpony: Auch ihr Ponys solltet heute ein Handtuch mitnehmen!",
  "retweeted_status" : {
    "source" : "<a href=\"http://tapbots.com/tweetbot\" rel=\"nofollow\">Tweetbot for iOS</a>",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : {
    },
    "id_str" : "205930861978324992",
    "text" : "Auch ihr Ponys solltet heute ein Handtuch mitnehmen!",
    "id" : 205930861978324992,
    "created_at" : "Fri May 25 07:58:38 +0000 2012",
    "user" : {
      "name" : "ratschlagpony",
      "screen_name" : "ratschlagpony",
      "protected" : false,
      "id_str" : "588158396",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/2243175539/AdvicePony_normal.png",
      "id" : 588158396,
      "verified" : false
    }
  },
  "id" : 205941376427376643,
  "created_at" : "Fri May 25 08:40:25 +0000 2012",
  "user" : {
    "name" : "Felix",
    "screen_name" : "nicidienase",
    "protected" : false,
    "id_str" : "22396883",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3125784966/8223a4c5c9535be22d15c82ec829c2df_normal.jpeg",
    "id" : 22396883,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Beate",
      "screen_name" : "beate",
      "indices" : [ 3, 9 ],
      "id_str" : "5378432",
      "id" : 5378432
    }, {
      "name" : "Hochschule Karlsruhe",
      "screen_name" : "HsKANews",
      "indices" : [ 11, 20 ],
      "id_str" : "70745834",
      "id" : 70745834
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "205934467548856321",
  "text" : "RT @beate: @HsKANews twittert ihr den Speiseplan jetzt jeden Tag? Dann muss ich euch mal schnell unfollwen...",
  "retweeted_status" : {
    "source" : "<a href=\"http://www.echofon.com/\" rel=\"nofollow\">Echofon</a>",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Hochschule Karlsruhe",
        "screen_name" : "HsKANews",
        "indices" : [ 0, 9 ],
        "id_str" : "70745834",
        "id" : 70745834
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : {
    },
    "id_str" : "205933421426515968",
    "in_reply_to_user_id" : 70745834,
    "text" : "@HsKANews twittert ihr den Speiseplan jetzt jeden Tag? Dann muss ich euch mal schnell unfollwen...",
    "id" : 205933421426515968,
    "created_at" : "Fri May 25 08:08:48 +0000 2012",
    "in_reply_to_screen_name" : "HsKANews",
    "in_reply_to_user_id_str" : "70745834",
    "user" : {
      "name" : "Beate",
      "screen_name" : "beate",
      "protected" : false,
      "id_str" : "5378432",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/1113869738/beate-avatar_normal.jpg",
      "id" : 5378432,
      "verified" : false
    }
  },
  "id" : 205934467548856321,
  "created_at" : "Fri May 25 08:12:57 +0000 2012",
  "user" : {
    "name" : "Felix",
    "screen_name" : "nicidienase",
    "protected" : false,
    "id_str" : "22396883",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3125784966/8223a4c5c9535be22d15c82ec829c2df_normal.jpeg",
    "id" : 22396883,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://getspaz.com\" rel=\"nofollow\">Spaz HD for webOS</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Angie",
      "screen_name" : "AngieTragedy",
      "indices" : [ 0, 13 ],
      "id_str" : "117178429",
      "id" : 117178429
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "205767327373991936",
  "in_reply_to_user_id" : 117178429,
  "text" : "@AngieTragedy Die meisten anderen Lebewesen machen ja auch nix anderes au\u00DFer Fressen, Ficken und Chillen. \u00C4\u00E4h. Okay, ich hab nix gesagt.",
  "id" : 205767327373991936,
  "created_at" : "Thu May 24 21:08:48 +0000 2012",
  "in_reply_to_screen_name" : "AngieTragedy",
  "in_reply_to_user_id_str" : "117178429",
  "user" : {
    "name" : "Felix",
    "screen_name" : "nicidienase",
    "protected" : false,
    "id_str" : "22396883",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3125784966/8223a4c5c9535be22d15c82ec829c2df_normal.jpeg",
    "id" : 22396883,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://getspaz.com\" rel=\"nofollow\">Spaz HD for webOS</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "GPN12",
      "indices" : [ 24, 30 ]
    }, {
      "text" : "Vorfreude",
      "indices" : [ 31, 41 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "205765527333904385",
  "text" : "Jetzt in zwei Wochen is #GPN12 #Vorfreude",
  "id" : 205765527333904385,
  "created_at" : "Thu May 24 21:01:39 +0000 2012",
  "user" : {
    "name" : "Felix",
    "screen_name" : "nicidienase",
    "protected" : false,
    "id_str" : "22396883",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3125784966/8223a4c5c9535be22d15c82ec829c2df_normal.jpeg",
    "id" : 22396883,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://getspaz.com\" rel=\"nofollow\">Spaz HD for webOS</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Michael Seemann",
      "screen_name" : "mspro",
      "indices" : [ 3, 9 ],
      "id_str" : "5751892",
      "id" : 5751892
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "205762724498653184",
  "text" : "RT @mspro: einerseits halte ich die pareto optimale distribution sexueller ressourcen f\u00FCr erstrebenswert, andererseits bin ich romantiker.",
  "retweeted_status" : {
    "source" : "<a href=\"http://tapbots.com/tweetbot\" rel=\"nofollow\">Tweetbot for iOS</a>",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : {
    },
    "id_str" : "205759552254251010",
    "text" : "einerseits halte ich die pareto optimale distribution sexueller ressourcen f\u00FCr erstrebenswert, andererseits bin ich romantiker.",
    "id" : 205759552254251010,
    "created_at" : "Thu May 24 20:37:54 +0000 2012",
    "user" : {
      "name" : "Michael Seemann",
      "screen_name" : "mspro",
      "protected" : false,
      "id_str" : "5751892",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/3408641243/2edf38d3c995612edf5b3d2e20d74861_normal.jpeg",
      "id" : 5751892,
      "verified" : false
    }
  },
  "id" : 205762724498653184,
  "created_at" : "Thu May 24 20:50:31 +0000 2012",
  "user" : {
    "name" : "Felix",
    "screen_name" : "nicidienase",
    "protected" : false,
    "id_str" : "22396883",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3125784966/8223a4c5c9535be22d15c82ec829c2df_normal.jpeg",
    "id" : 22396883,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://getspaz.com\" rel=\"nofollow\">Spaz HD for webOS</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 0, 20 ],
      "url" : "http://t.co/8yv3zClk",
      "expanded_url" : "http://www.youtube.com/watch?v=vsvlsuLau5c",
      "display_url" : "youtube.com/watch?v=vsvlsu\u2026"
    } ]
  },
  "geo" : {
  },
  "id_str" : "205737816079073280",
  "text" : "http://t.co/8yv3zClk Besser als das Original",
  "id" : 205737816079073280,
  "created_at" : "Thu May 24 19:11:32 +0000 2012",
  "user" : {
    "name" : "Felix",
    "screen_name" : "nicidienase",
    "protected" : false,
    "id_str" : "22396883",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3125784966/8223a4c5c9535be22d15c82ec829c2df_normal.jpeg",
    "id" : 22396883,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://getspaz.com\" rel=\"nofollow\">Spaz HD for webOS</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Michael Merk",
      "screen_name" : "DerMorb",
      "indices" : [ 3, 11 ],
      "id_str" : "95022235",
      "id" : 95022235
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 32, 52 ],
      "url" : "http://t.co/FPRM9JK4",
      "expanded_url" : "http://youtu.be/jjZYoKYM_8Q",
      "display_url" : "youtu.be/jjZYoKYM_8Q"
    } ]
  },
  "geo" : {
  },
  "id_str" : "205730512910827521",
  "text" : "RT @DerMorb: needs more cowbell http://t.co/FPRM9JK4",
  "retweeted_status" : {
    "source" : "web",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 19, 39 ],
        "url" : "http://t.co/FPRM9JK4",
        "expanded_url" : "http://youtu.be/jjZYoKYM_8Q",
        "display_url" : "youtu.be/jjZYoKYM_8Q"
      } ]
    },
    "geo" : {
    },
    "id_str" : "205716888687353857",
    "text" : "needs more cowbell http://t.co/FPRM9JK4",
    "id" : 205716888687353857,
    "created_at" : "Thu May 24 17:48:22 +0000 2012",
    "user" : {
      "name" : "Michael Merk",
      "screen_name" : "DerMorb",
      "protected" : false,
      "id_str" : "95022235",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/561722284/36527823_normal.jpg",
      "id" : 95022235,
      "verified" : false
    }
  },
  "id" : 205730512910827521,
  "created_at" : "Thu May 24 18:42:31 +0000 2012",
  "user" : {
    "name" : "Felix",
    "screen_name" : "nicidienase",
    "protected" : false,
    "id_str" : "22396883",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3125784966/8223a4c5c9535be22d15c82ec829c2df_normal.jpeg",
    "id" : 22396883,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://getspaz.com\" rel=\"nofollow\">Spaz HD for webOS</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Adam Savage",
      "screen_name" : "donttrythis",
      "indices" : [ 3, 15 ],
      "id_str" : "15661871",
      "id" : 15661871
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 64, 84 ],
      "url" : "http://t.co/NRdeBTxX",
      "expanded_url" : "http://www.youtube.com/watch?&v=drzq1x0mqjo",
      "display_url" : "youtube.com/watch?&v=drzq1\u2026"
    } ]
  },
  "geo" : {
  },
  "id_str" : "205725995360206850",
  "text" : "RT @donttrythis: You want the CUTE? You can't HANDLE the cute!! http://t.co/NRdeBTxX",
  "retweeted_status" : {
    "source" : "web",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 47, 67 ],
        "url" : "http://t.co/NRdeBTxX",
        "expanded_url" : "http://www.youtube.com/watch?&v=drzq1x0mqjo",
        "display_url" : "youtube.com/watch?&v=drzq1\u2026"
      } ]
    },
    "geo" : {
    },
    "id_str" : "205673030209372162",
    "text" : "You want the CUTE? You can't HANDLE the cute!! http://t.co/NRdeBTxX",
    "id" : 205673030209372162,
    "created_at" : "Thu May 24 14:54:06 +0000 2012",
    "user" : {
      "name" : "Adam Savage",
      "screen_name" : "donttrythis",
      "protected" : false,
      "id_str" : "15661871",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/1925644866/FotoFlexer_Photo_normal.jpg",
      "id" : 15661871,
      "verified" : true
    }
  },
  "id" : 205725995360206850,
  "created_at" : "Thu May 24 18:24:34 +0000 2012",
  "user" : {
    "name" : "Felix",
    "screen_name" : "nicidienase",
    "protected" : false,
    "id_str" : "22396883",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3125784966/8223a4c5c9535be22d15c82ec829c2df_normal.jpeg",
    "id" : 22396883,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.echofon.com/\" rel=\"nofollow\">Echofon</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Fiona",
      "screen_name" : "Fotografiona",
      "indices" : [ 3, 16 ],
      "id_str" : "59090320",
      "id" : 59090320
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 68, 88 ],
      "url" : "http://t.co/5duMxLot",
      "expanded_url" : "http://twitpic.com/9oo03v",
      "display_url" : "twitpic.com/9oo03v"
    } ]
  },
  "geo" : {
  },
  "id_str" : "205632685933211650",
  "text" : "RT @Fotografiona: wollte in ruhe programmieren drau\u00DFen und dann das http://t.co/5duMxLot",
  "retweeted_status" : {
    "source" : "<a href=\"http://twidroyd.com\" rel=\"nofollow\">Twidroyd for Android</a>",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 50, 70 ],
        "url" : "http://t.co/5duMxLot",
        "expanded_url" : "http://twitpic.com/9oo03v",
        "display_url" : "twitpic.com/9oo03v"
      } ]
    },
    "geo" : {
    },
    "id_str" : "205631564376317953",
    "text" : "wollte in ruhe programmieren drau\u00DFen und dann das http://t.co/5duMxLot",
    "id" : 205631564376317953,
    "created_at" : "Thu May 24 12:09:20 +0000 2012",
    "user" : {
      "name" : "Fiona",
      "screen_name" : "Fotografiona",
      "protected" : false,
      "id_str" : "59090320",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/2546078946/lfyc2rzsxw67cbv89x37_normal.jpeg",
      "id" : 59090320,
      "verified" : false
    }
  },
  "id" : 205632685933211650,
  "created_at" : "Thu May 24 12:13:47 +0000 2012",
  "user" : {
    "name" : "Felix",
    "screen_name" : "nicidienase",
    "protected" : false,
    "id_str" : "22396883",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3125784966/8223a4c5c9535be22d15c82ec829c2df_normal.jpeg",
    "id" : 22396883,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.echofon.com/\" rel=\"nofollow\">Echofon</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "SpaceX",
      "screen_name" : "SpaceX",
      "indices" : [ 3, 10 ],
      "id_str" : "34743251",
      "id" : 34743251
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Dragon",
      "indices" : [ 12, 19 ]
    } ],
    "urls" : [ {
      "indices" : [ 85, 105 ],
      "url" : "http://t.co/i31FIQrL",
      "expanded_url" : "http://twitter.com/SpaceX/status/205614555018178560/photo/1",
      "display_url" : "pic.twitter.com/i31FIQrL"
    } ]
  },
  "geo" : {
  },
  "id_str" : "205626304366772225",
  "text" : "RT @SpaceX: #Dragon spacecraft is now visible from the space station as a small dot. http://t.co/i31FIQrL",
  "retweeted_status" : {
    "source" : "web",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "http://twitter.com/SpaceX/status/205614555018178560/photo/1",
        "indices" : [ 73, 93 ],
        "url" : "http://t.co/i31FIQrL",
        "media_url" : "http://pbs.twimg.com/media/Atp9WTDCMAEnot9.png",
        "id_str" : "205614555022372865",
        "id" : 205614555022372865,
        "media_url_https" : "https://pbs.twimg.com/media/Atp9WTDCMAEnot9.png",
        "sizes" : [ {
          "h" : 454,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 495,
          "resize" : "fit",
          "w" : 654
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 257,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 495,
          "resize" : "fit",
          "w" : 654
        } ],
        "display_url" : "pic.twitter.com/i31FIQrL"
      } ],
      "hashtags" : [ {
        "text" : "Dragon",
        "indices" : [ 0, 7 ]
      } ],
      "urls" : [ ]
    },
    "geo" : {
    },
    "id_str" : "205614555018178560",
    "text" : "#Dragon spacecraft is now visible from the space station as a small dot. http://t.co/i31FIQrL",
    "id" : 205614555018178560,
    "created_at" : "Thu May 24 11:01:45 +0000 2012",
    "user" : {
      "name" : "SpaceX",
      "screen_name" : "SpaceX",
      "protected" : false,
      "id_str" : "34743251",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/2341252179/4zbhy2jm5xiflnqvy8bw_normal.jpeg",
      "id" : 34743251,
      "verified" : true
    }
  },
  "id" : 205626304366772225,
  "created_at" : "Thu May 24 11:48:25 +0000 2012",
  "user" : {
    "name" : "Felix",
    "screen_name" : "nicidienase",
    "protected" : false,
    "id_str" : "22396883",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3125784966/8223a4c5c9535be22d15c82ec829c2df_normal.jpeg",
    "id" : 22396883,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.echofon.com/\" rel=\"nofollow\">Echofon</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "cupe",
      "screen_name" : "cupe_cupe",
      "indices" : [ 3, 13 ],
      "id_str" : "143922800",
      "id" : 143922800
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "205565307962662913",
  "text" : "RT @cupe_cupe: OH: \u201Cdas htc desir\u00E9e\u201C",
  "retweeted_status" : {
    "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : {
    },
    "id_str" : "205411498208673792",
    "text" : "OH: \u201Cdas htc desir\u00E9e\u201C",
    "id" : 205411498208673792,
    "created_at" : "Wed May 23 21:34:52 +0000 2012",
    "user" : {
      "name" : "cupe",
      "screen_name" : "cupe_cupe",
      "protected" : false,
      "id_str" : "143922800",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/929551965/fern-avatar_normal.png",
      "id" : 143922800,
      "verified" : false
    }
  },
  "id" : 205565307962662913,
  "created_at" : "Thu May 24 07:46:03 +0000 2012",
  "user" : {
    "name" : "Felix",
    "screen_name" : "nicidienase",
    "protected" : false,
    "id_str" : "22396883",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3125784966/8223a4c5c9535be22d15c82ec829c2df_normal.jpeg",
    "id" : 22396883,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.echofon.com/\" rel=\"nofollow\">Echofon</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Stefan Zimmermann",
      "screen_name" : "_codepoet_",
      "indices" : [ 3, 14 ],
      "id_str" : "15557627",
      "id" : 15557627
    }, {
      "name" : "Max Winde",
      "screen_name" : "343max",
      "indices" : [ 16, 23 ],
      "id_str" : "2284151",
      "id" : 2284151
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 46, 66 ],
      "url" : "http://t.co/jnGfrwce",
      "expanded_url" : "http://on.mash.to/JGgUy0",
      "display_url" : "on.mash.to/JGgUy0"
    } ]
  },
  "geo" : {
  },
  "id_str" : "205210448784658433",
  "text" : "RT @_codepoet_: @343max dazu vielleicht noch: http://t.co/jnGfrwce",
  "retweeted_status" : {
    "source" : "<a href=\"http://www.echofon.com/\" rel=\"nofollow\">Echofon</a>",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Max Winde",
        "screen_name" : "343max",
        "indices" : [ 0, 7 ],
        "id_str" : "2284151",
        "id" : 2284151
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 30, 50 ],
        "url" : "http://t.co/jnGfrwce",
        "expanded_url" : "http://on.mash.to/JGgUy0",
        "display_url" : "on.mash.to/JGgUy0"
      } ]
    },
    "in_reply_to_status_id_str" : "205208667455356928",
    "geo" : {
    },
    "id_str" : "205209594576900096",
    "in_reply_to_user_id" : 2284151,
    "text" : "@343max dazu vielleicht noch: http://t.co/jnGfrwce",
    "id" : 205209594576900096,
    "in_reply_to_status_id" : 205208667455356928,
    "created_at" : "Wed May 23 08:12:34 +0000 2012",
    "in_reply_to_screen_name" : "343max",
    "in_reply_to_user_id_str" : "2284151",
    "user" : {
      "name" : "Stefan Zimmermann",
      "screen_name" : "_codepoet_",
      "protected" : false,
      "id_str" : "15557627",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/1361908387/gravatar_normal.jpg",
      "id" : 15557627,
      "verified" : false
    }
  },
  "id" : 205210448784658433,
  "created_at" : "Wed May 23 08:15:58 +0000 2012",
  "user" : {
    "name" : "Felix",
    "screen_name" : "nicidienase",
    "protected" : false,
    "id_str" : "22396883",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3125784966/8223a4c5c9535be22d15c82ec829c2df_normal.jpeg",
    "id" : 22396883,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.echofon.com/\" rel=\"nofollow\">Echofon</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "cupe",
      "screen_name" : "cupe_cupe",
      "indices" : [ 0, 10 ],
      "id_str" : "143922800",
      "id" : 143922800
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "204528478761132032",
  "geo" : {
  },
  "id_str" : "204529083525238784",
  "in_reply_to_user_id" : 143922800,
  "text" : "@cupe_cupe Was spricht gegen dedizierte Weck-Hardware?",
  "id" : 204529083525238784,
  "in_reply_to_status_id" : 204528478761132032,
  "created_at" : "Mon May 21 11:08:28 +0000 2012",
  "in_reply_to_screen_name" : "cupe_cupe",
  "in_reply_to_user_id_str" : "143922800",
  "user" : {
    "name" : "Felix",
    "screen_name" : "nicidienase",
    "protected" : false,
    "id_str" : "22396883",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3125784966/8223a4c5c9535be22d15c82ec829c2df_normal.jpeg",
    "id" : 22396883,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.echofon.com/\" rel=\"nofollow\">Echofon</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Colin Barrett",
      "screen_name" : "cbarrett",
      "indices" : [ 3, 12 ],
      "id_str" : "3562421",
      "id" : 3562421
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 46, 66 ],
      "url" : "http://t.co/wYfcEIZU",
      "expanded_url" : "http://twitpic.com/9nild1",
      "display_url" : "twitpic.com/9nild1"
    } ]
  },
  "geo" : {
  },
  "id_str" : "204507435820531712",
  "text" : "RT @cbarrett: Guess God really does use Lisp. http://t.co/wYfcEIZU",
  "retweeted_status" : {
    "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 32, 52 ],
        "url" : "http://t.co/wYfcEIZU",
        "expanded_url" : "http://twitpic.com/9nild1",
        "display_url" : "twitpic.com/9nild1"
      } ]
    },
    "geo" : {
    },
    "id_str" : "204425890132787200",
    "text" : "Guess God really does use Lisp. http://t.co/wYfcEIZU",
    "id" : 204425890132787200,
    "created_at" : "Mon May 21 04:18:24 +0000 2012",
    "user" : {
      "name" : "Colin Barrett",
      "screen_name" : "cbarrett",
      "protected" : false,
      "id_str" : "3562421",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/2872419083/1bae5475bae6c9c5e5a37c252a9f68cd_normal.png",
      "id" : 3562421,
      "verified" : false
    }
  },
  "id" : 204507435820531712,
  "created_at" : "Mon May 21 09:42:26 +0000 2012",
  "user" : {
    "name" : "Felix",
    "screen_name" : "nicidienase",
    "protected" : false,
    "id_str" : "22396883",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3125784966/8223a4c5c9535be22d15c82ec829c2df_normal.jpeg",
    "id" : 22396883,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.echofon.com/\" rel=\"nofollow\">Echofon</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Nienor86",
      "screen_name" : "Nienor86",
      "indices" : [ 3, 12 ],
      "id_str" : "1014883652",
      "id" : 1014883652
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "204489071907713024",
  "text" : "RT @Nienor86: Freitag ist ja Towel Day \\o/ wehe, ich erwische einen von euch ohne Handtuch!",
  "retweeted_status" : {
    "source" : "<a href=\"http://itunes.apple.com/us/app/twitter/id409789998?mt=12\" rel=\"nofollow\">Twitter for Mac</a>",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : {
    },
    "id_str" : "204487787368562689",
    "text" : "Freitag ist ja Towel Day \\o/ wehe, ich erwische einen von euch ohne Handtuch!",
    "id" : 204487787368562689,
    "created_at" : "Mon May 21 08:24:22 +0000 2012",
    "user" : {
      "name" : "Jella",
      "screen_name" : "Nienor_",
      "protected" : false,
      "id_str" : "17461946",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/1831476140/ponyhipster_normal.jpg",
      "id" : 17461946,
      "verified" : false
    }
  },
  "id" : 204489071907713024,
  "created_at" : "Mon May 21 08:29:28 +0000 2012",
  "user" : {
    "name" : "Felix",
    "screen_name" : "nicidienase",
    "protected" : false,
    "id_str" : "22396883",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3125784966/8223a4c5c9535be22d15c82ec829c2df_normal.jpeg",
    "id" : 22396883,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://getspaz.com\" rel=\"nofollow\">Spaz HD for webOS</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "getDigital Team",
      "screen_name" : "getDigital_de",
      "indices" : [ 3, 17 ],
      "id_str" : "45354877",
      "id" : 45354877
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 80, 100 ],
      "url" : "http://t.co/bLFItSb8",
      "expanded_url" : "http://tinyurl.com/7jrybab",
      "display_url" : "tinyurl.com/7jrybab"
    } ]
  },
  "geo" : {
  },
  "id_str" : "204183537186902017",
  "text" : "RT @getDigital_de: Wenn Diablo kein D\u00E4mon, sondern Deine (Ex-)Freundin w\u00E4re...: http://t.co/bLFItSb8",
  "retweeted_status" : {
    "source" : "web",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 61, 81 ],
        "url" : "http://t.co/bLFItSb8",
        "expanded_url" : "http://tinyurl.com/7jrybab",
        "display_url" : "tinyurl.com/7jrybab"
      } ]
    },
    "geo" : {
    },
    "id_str" : "204182380980875264",
    "text" : "Wenn Diablo kein D\u00E4mon, sondern Deine (Ex-)Freundin w\u00E4re...: http://t.co/bLFItSb8",
    "id" : 204182380980875264,
    "created_at" : "Sun May 20 12:10:47 +0000 2012",
    "user" : {
      "name" : "getDigital Team",
      "screen_name" : "getDigital_de",
      "protected" : false,
      "id_str" : "45354877",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/253278066/logo2_normal.png",
      "id" : 45354877,
      "verified" : false
    }
  },
  "id" : 204183537186902017,
  "created_at" : "Sun May 20 12:15:23 +0000 2012",
  "user" : {
    "name" : "Felix",
    "screen_name" : "nicidienase",
    "protected" : false,
    "id_str" : "22396883",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3125784966/8223a4c5c9535be22d15c82ec829c2df_normal.jpeg",
    "id" : 22396883,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://getspaz.com\" rel=\"nofollow\">Spaz HD for webOS</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Command Line Magic",
      "screen_name" : "climagic",
      "indices" : [ 3, 12 ],
      "id_str" : "91333167",
      "id" : 91333167
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "203815277119537152",
  "text" : "RT @climagic: How many Linux users does it take to change a lightbulb? 20. 1 to change it and 19 others to install new sockets do it the ...",
  "retweeted_status" : {
    "source" : "<a href=\"http://suso.suso.org/xulu/Command_Line_Magic\" rel=\"nofollow\">CLI Magic poster</a>",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : {
    },
    "id_str" : "203655027536035840",
    "text" : "How many Linux users does it take to change a lightbulb? 20. 1 to change it and 19 others to install new sockets do it their own way.",
    "id" : 203655027536035840,
    "created_at" : "Sat May 19 01:15:16 +0000 2012",
    "user" : {
      "name" : "Command Line Magic",
      "screen_name" : "climagic",
      "protected" : false,
      "id_str" : "91333167",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/535876218/climagic-icon_normal.png",
      "id" : 91333167,
      "verified" : false
    }
  },
  "id" : 203815277119537152,
  "created_at" : "Sat May 19 11:52:03 +0000 2012",
  "user" : {
    "name" : "Felix",
    "screen_name" : "nicidienase",
    "protected" : false,
    "id_str" : "22396883",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3125784966/8223a4c5c9535be22d15c82ec829c2df_normal.jpeg",
    "id" : 22396883,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://getspaz.com\" rel=\"nofollow\">Spaz HD for webOS</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Randulf Stiglitz",
      "screen_name" : "RNDLFSTGLTZ",
      "indices" : [ 3, 15 ],
      "id_str" : "16238940",
      "id" : 16238940
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "blockupy",
      "indices" : [ 94, 103 ]
    } ],
    "urls" : [ {
      "indices" : [ 104, 124 ],
      "url" : "http://t.co/qMzWhfOE",
      "expanded_url" : "http://twitter.com/RNDLFSTGLTZ/status/203403223174889473/photo/1",
      "display_url" : "pic.twitter.com/qMzWhfOE"
    } ]
  },
  "geo" : {
  },
  "id_str" : "203612383174856706",
  "text" : "RT @RNDLFSTGLTZ: Der Zorn auf die Banken nimmt drastisch zu- jetzt trifft es auch unschuldige #blockupy http://t.co/qMzWhfOE",
  "retweeted_status" : {
    "source" : "web",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "http://twitter.com/RNDLFSTGLTZ/status/203403223174889473/photo/1",
        "indices" : [ 87, 107 ],
        "url" : "http://t.co/qMzWhfOE",
        "media_url" : "http://pbs.twimg.com/media/AtKiJ1_CQAANsRK.jpg",
        "id_str" : "203403223179083776",
        "id" : 203403223179083776,
        "media_url_https" : "https://pbs.twimg.com/media/AtKiJ1_CQAANsRK.jpg",
        "sizes" : [ {
          "h" : 475,
          "resize" : "fit",
          "w" : 671
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 241,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 425,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 475,
          "resize" : "fit",
          "w" : 671
        } ],
        "display_url" : "pic.twitter.com/qMzWhfOE"
      } ],
      "hashtags" : [ {
        "text" : "blockupy",
        "indices" : [ 77, 86 ]
      } ],
      "urls" : [ ]
    },
    "geo" : {
    },
    "id_str" : "203403223174889473",
    "text" : "Der Zorn auf die Banken nimmt drastisch zu- jetzt trifft es auch unschuldige #blockupy http://t.co/qMzWhfOE",
    "id" : 203403223174889473,
    "created_at" : "Fri May 18 08:34:43 +0000 2012",
    "user" : {
      "name" : "Randulf Stiglitz",
      "screen_name" : "RNDLFSTGLTZ",
      "protected" : false,
      "id_str" : "16238940",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/2286108105/9bfzi4kr1ofivbtyctsd_normal.jpeg",
      "id" : 16238940,
      "verified" : false
    }
  },
  "id" : 203612383174856706,
  "created_at" : "Fri May 18 22:25:49 +0000 2012",
  "user" : {
    "name" : "Felix",
    "screen_name" : "nicidienase",
    "protected" : false,
    "id_str" : "22396883",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3125784966/8223a4c5c9535be22d15c82ec829c2df_normal.jpeg",
    "id" : 22396883,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://getspaz.com\" rel=\"nofollow\">Spaz HD for webOS</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 34, 54 ],
      "url" : "http://t.co/cyRboRcJ",
      "expanded_url" : "http://ragefac.es/54",
      "display_url" : "ragefac.es/54"
    } ]
  },
  "geo" : {
  },
  "id_str" : "203188067480252417",
  "text" : "Pfaster am Daumen + Touchscreen =\u00A0http://t.co/cyRboRcJ",
  "id" : 203188067480252417,
  "created_at" : "Thu May 17 18:19:44 +0000 2012",
  "user" : {
    "name" : "Felix",
    "screen_name" : "nicidienase",
    "protected" : false,
    "id_str" : "22396883",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3125784966/8223a4c5c9535be22d15c82ec829c2df_normal.jpeg",
    "id" : 22396883,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.echofon.com/\" rel=\"nofollow\">Echofon</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "news.yc Popular",
      "screen_name" : "newsycombinator",
      "indices" : [ 3, 19 ],
      "id_str" : "14335498",
      "id" : 14335498
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 81, 101 ],
      "url" : "http://t.co/fvIWWskk",
      "expanded_url" : "http://j.mp/JuQP5s",
      "display_url" : "j.mp/JuQP5s"
    } ]
  },
  "geo" : {
  },
  "id_str" : "202735809865072644",
  "text" : "RT @newsycombinator: How the Professor Who Fooled Wikipedia Got Caught by Reddit http://t.co/fvIWWskk",
  "retweeted_status" : {
    "source" : "<a href=\"http://www.steer.me\" rel=\"nofollow\">newsycombinator</a>",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 60, 80 ],
        "url" : "http://t.co/fvIWWskk",
        "expanded_url" : "http://j.mp/JuQP5s",
        "display_url" : "j.mp/JuQP5s"
      } ]
    },
    "geo" : {
    },
    "id_str" : "202716288072695810",
    "text" : "How the Professor Who Fooled Wikipedia Got Caught by Reddit http://t.co/fvIWWskk",
    "id" : 202716288072695810,
    "created_at" : "Wed May 16 11:05:04 +0000 2012",
    "user" : {
      "name" : "news.yc Popular",
      "screen_name" : "newsycombinator",
      "protected" : false,
      "id_str" : "14335498",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/52589204/y_normal.png",
      "id" : 14335498,
      "verified" : false
    }
  },
  "id" : 202735809865072644,
  "created_at" : "Wed May 16 12:22:38 +0000 2012",
  "user" : {
    "name" : "Felix",
    "screen_name" : "nicidienase",
    "protected" : false,
    "id_str" : "22396883",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3125784966/8223a4c5c9535be22d15c82ec829c2df_normal.jpeg",
    "id" : 22396883,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.echofon.com/\" rel=\"nofollow\">Echofon</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ratschlagfiona",
      "screen_name" : "ratschlagfiona",
      "indices" : [ 3, 18 ],
      "id_str" : "579868097",
      "id" : 579868097
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "tesla",
      "indices" : [ 77, 83 ]
    } ],
    "urls" : [ {
      "indices" : [ 56, 76 ],
      "url" : "http://t.co/BQyYWde5",
      "expanded_url" : "http://theoatmeal.com/comics/tesla",
      "display_url" : "theoatmeal.com/comics/tesla"
    } ]
  },
  "geo" : {
  },
  "id_str" : "202400142333194240",
  "text" : "RT @ratschlagfiona: Share this and ALL your inventions: http://t.co/BQyYWde5 #tesla",
  "retweeted_status" : {
    "source" : "web",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "tesla",
        "indices" : [ 57, 63 ]
      } ],
      "urls" : [ {
        "indices" : [ 36, 56 ],
        "url" : "http://t.co/BQyYWde5",
        "expanded_url" : "http://theoatmeal.com/comics/tesla",
        "display_url" : "theoatmeal.com/comics/tesla"
      } ]
    },
    "geo" : {
    },
    "id_str" : "202389759061004288",
    "text" : "Share this and ALL your inventions: http://t.co/BQyYWde5 #tesla",
    "id" : 202389759061004288,
    "created_at" : "Tue May 15 13:27:33 +0000 2012",
    "user" : {
      "name" : "Ratschlagfiona",
      "screen_name" : "ratschlagfiona",
      "protected" : false,
      "id_str" : "579868097",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/2217756149/ratschlagfiona-salz_normal.png",
      "id" : 579868097,
      "verified" : false
    }
  },
  "id" : 202400142333194240,
  "created_at" : "Tue May 15 14:08:49 +0000 2012",
  "user" : {
    "name" : "Felix",
    "screen_name" : "nicidienase",
    "protected" : false,
    "id_str" : "22396883",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3125784966/8223a4c5c9535be22d15c82ec829c2df_normal.jpeg",
    "id" : 22396883,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.echofon.com/\" rel=\"nofollow\">Echofon</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Marco ",
      "screen_name" : "Fadenaffe",
      "indices" : [ 3, 13 ],
      "id_str" : "54425158",
      "id" : 54425158
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "202382150539030529",
  "text" : "RT @Fadenaffe: In K\u00F6ln regnets... passt auf, gleich verkaufen die das als Bier.",
  "retweeted_status" : {
    "source" : "<a href=\"http://www.echofon.com/\" rel=\"nofollow\">Echofon</a>",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : {
    },
    "id_str" : "202381232045166592",
    "text" : "In K\u00F6ln regnets... passt auf, gleich verkaufen die das als Bier.",
    "id" : 202381232045166592,
    "created_at" : "Tue May 15 12:53:40 +0000 2012",
    "user" : {
      "name" : "Marco ",
      "screen_name" : "Fadenaffe",
      "protected" : false,
      "id_str" : "54425158",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/3074128805/f60a441649ee5640b42071b0f16ce6da_normal.jpeg",
      "id" : 54425158,
      "verified" : false
    }
  },
  "id" : 202382150539030529,
  "created_at" : "Tue May 15 12:57:19 +0000 2012",
  "user" : {
    "name" : "Felix",
    "screen_name" : "nicidienase",
    "protected" : false,
    "id_str" : "22396883",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3125784966/8223a4c5c9535be22d15c82ec829c2df_normal.jpeg",
    "id" : 22396883,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.echofon.com/\" rel=\"nofollow\">Echofon</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jemus",
      "screen_name" : "Jemus42",
      "indices" : [ 3, 11 ],
      "id_str" : "50339766",
      "id" : 50339766
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "202019621958713344",
  "text" : "RT @Jemus42: Der UNIX-Timestamp ist 1337000000 \\o/",
  "retweeted_status" : {
    "source" : "<a href=\"http://itunes.apple.com/us/app/twitter/id409789998?mt=12\" rel=\"nofollow\">Twitter for Mac</a>",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : {
    },
    "id_str" : "202018767448981505",
    "text" : "Der UNIX-Timestamp ist 1337000000 \\o/",
    "id" : 202018767448981505,
    "created_at" : "Mon May 14 12:53:22 +0000 2012",
    "user" : {
      "name" : "Jemus",
      "screen_name" : "Jemus42",
      "protected" : false,
      "id_str" : "50339766",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/2442155420/13fr1e3on4dzb9fn7i48_normal.jpeg",
      "id" : 50339766,
      "verified" : false
    }
  },
  "id" : 202019621958713344,
  "created_at" : "Mon May 14 12:56:45 +0000 2012",
  "user" : {
    "name" : "Felix",
    "screen_name" : "nicidienase",
    "protected" : false,
    "id_str" : "22396883",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3125784966/8223a4c5c9535be22d15c82ec829c2df_normal.jpeg",
    "id" : 22396883,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.echofon.com/\" rel=\"nofollow\">Echofon</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tim Pritlove",
      "screen_name" : "timpritlove",
      "indices" : [ 3, 15 ],
      "id_str" : "11268812",
      "id" : 11268812
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 53, 73 ],
      "url" : "http://t.co/cdU2K6lH",
      "expanded_url" : "http://www.ikeahackers.net/2012/05/sunday-comics-may-ikea-be-with-you.html",
      "display_url" : "ikeahackers.net/2012/05/sunday\u2026"
    } ]
  },
  "geo" : {
  },
  "id_str" : "201953089182384128",
  "text" : "RT @timpritlove: Neu! Jedibedarf bei IKEA: LITSABBUR http://t.co/cdU2K6lH",
  "retweeted_status" : {
    "source" : "<a href=\"http://www.echofon.com/\" rel=\"nofollow\">Echofon</a>",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 36, 56 ],
        "url" : "http://t.co/cdU2K6lH",
        "expanded_url" : "http://www.ikeahackers.net/2012/05/sunday-comics-may-ikea-be-with-you.html",
        "display_url" : "ikeahackers.net/2012/05/sunday\u2026"
      } ]
    },
    "geo" : {
    },
    "id_str" : "201929028200972288",
    "text" : "Neu! Jedibedarf bei IKEA: LITSABBUR http://t.co/cdU2K6lH",
    "id" : 201929028200972288,
    "created_at" : "Mon May 14 06:56:46 +0000 2012",
    "user" : {
      "name" : "Tim Pritlove",
      "screen_name" : "timpritlove",
      "protected" : false,
      "id_str" : "11268812",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/2332275606/Tim_Pritlove_2009_Avatar_512x512_normal.jpg",
      "id" : 11268812,
      "verified" : true
    }
  },
  "id" : 201953089182384128,
  "created_at" : "Mon May 14 08:32:23 +0000 2012",
  "user" : {
    "name" : "Felix",
    "screen_name" : "nicidienase",
    "protected" : false,
    "id_str" : "22396883",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3125784966/8223a4c5c9535be22d15c82ec829c2df_normal.jpeg",
    "id" : 22396883,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://getspaz.com\" rel=\"nofollow\">Spaz HD for webOS</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Zach Braff",
      "screen_name" : "zachbraff",
      "indices" : [ 3, 13 ],
      "id_str" : "76997832",
      "id" : 76997832
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 119, 139 ],
      "url" : "http://t.co/PYRN2oW4",
      "expanded_url" : "http://campl.us/jswA",
      "display_url" : "campl.us/jswA"
    } ]
  },
  "geo" : {
  },
  "id_str" : "201798588479713281",
  "text" : "RT @zachbraff: Last night I heard a sentence I never thought I'd hear: \"Hey, Zach. I played you in the Scrubs porno.\"  http://t.co/PYRN2oW4",
  "retweeted_status" : {
    "source" : "<a href=\"http://itunes.apple.com/us/app/id329670577?mt=8&uo=4\" rel=\"nofollow\">Camera+\u200B on iOS</a>",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 104, 124 ],
        "url" : "http://t.co/PYRN2oW4",
        "expanded_url" : "http://campl.us/jswA",
        "display_url" : "campl.us/jswA"
      } ]
    },
    "geo" : {
    },
    "id_str" : "201747203998482432",
    "text" : "Last night I heard a sentence I never thought I'd hear: \"Hey, Zach. I played you in the Scrubs porno.\"  http://t.co/PYRN2oW4",
    "id" : 201747203998482432,
    "created_at" : "Sun May 13 18:54:16 +0000 2012",
    "user" : {
      "name" : "Zach Braff",
      "screen_name" : "zachbraff",
      "protected" : false,
      "id_str" : "76997832",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/3376133649/37b45b0faa23a4cde798521fd069dc1e_normal.jpeg",
      "id" : 76997832,
      "verified" : true
    }
  },
  "id" : 201798588479713281,
  "created_at" : "Sun May 13 22:18:27 +0000 2012",
  "user" : {
    "name" : "Felix",
    "screen_name" : "nicidienase",
    "protected" : false,
    "id_str" : "22396883",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3125784966/8223a4c5c9535be22d15c82ec829c2df_normal.jpeg",
    "id" : 22396883,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://getspaz.com\" rel=\"nofollow\">Spaz HD for webOS</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Christoph Kappes",
      "screen_name" : "ChristophKappes",
      "indices" : [ 3, 19 ],
      "id_str" : "19961453",
      "id" : 19961453
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "201623224247779328",
  "text" : "RT @ChristophKappes: Deine Mudda ist geistiges Eigentum von Deiner Grossmudda.",
  "retweeted_status" : {
    "source" : "<a href=\"http://tapbots.com/tweetbot\" rel=\"nofollow\">Tweetbot for iOS</a>",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : {
    },
    "id_str" : "201601197516390400",
    "text" : "Deine Mudda ist geistiges Eigentum von Deiner Grossmudda.",
    "id" : 201601197516390400,
    "created_at" : "Sun May 13 09:14:05 +0000 2012",
    "user" : {
      "name" : "Christoph Kappes",
      "screen_name" : "ChristophKappes",
      "protected" : false,
      "id_str" : "19961453",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/3496224972/0692d207d3603281389a2c92b5df06a2_normal.jpeg",
      "id" : 19961453,
      "verified" : false
    }
  },
  "id" : 201623224247779328,
  "created_at" : "Sun May 13 10:41:37 +0000 2012",
  "user" : {
    "name" : "Felix",
    "screen_name" : "nicidienase",
    "protected" : false,
    "id_str" : "22396883",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3125784966/8223a4c5c9535be22d15c82ec829c2df_normal.jpeg",
    "id" : 22396883,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://getspaz.com\" rel=\"nofollow\">Spaz HD for webOS</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Herman Radtke",
      "screen_name" : "hermanradtke",
      "indices" : [ 3, 16 ],
      "id_str" : "59876870",
      "id" : 59876870
    }, {
      "name" : "Michael Maclean",
      "screen_name" : "mgdm",
      "indices" : [ 44, 49 ],
      "id_str" : "5244631",
      "id" : 5244631
    }, {
      "name" : "Major Hayden",
      "screen_name" : "rackerhacker",
      "indices" : [ 52, 65 ],
      "id_str" : "14453057",
      "id" : 14453057
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "201235966764134401",
  "text" : "RT @hermanradtke: This has to be a level RT @mgdm: \u201C@rackerhacker: This is the best thing ever sent to the Linux Kernel Mailing List: ht ...",
  "retweeted_status" : {
    "source" : "<a href=\"http://www.tweetcaster.com\" rel=\"nofollow\">TweetCaster for Android</a>",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Michael Maclean",
        "screen_name" : "mgdm",
        "indices" : [ 26, 31 ],
        "id_str" : "5244631",
        "id" : 5244631
      }, {
        "name" : "Major Hayden",
        "screen_name" : "rackerhacker",
        "indices" : [ 34, 47 ],
        "id_str" : "14453057",
        "id" : 14453057
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 116, 136 ],
        "url" : "http://t.co/5pbeToQn",
        "expanded_url" : "http://rkrh.kr/np",
        "display_url" : "rkrh.kr/np"
      } ]
    },
    "geo" : {
      "type" : "Point",
      "coordinates" : [ 34.0263224, -118.2766143 ]
    },
    "id_str" : "200011444530593792",
    "text" : "This has to be a level RT @mgdm: \u201C@rackerhacker: This is the best thing ever sent to the Linux Kernel Mailing List: http://t.co/5pbeToQn",
    "id" : 200011444530593792,
    "created_at" : "Tue May 08 23:56:59 +0000 2012",
    "user" : {
      "name" : "Herman Radtke",
      "screen_name" : "hermanradtke",
      "protected" : false,
      "id_str" : "59876870",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/2886523854/712a911f05a448d239d9e0b8372f36c7_normal.jpeg",
      "id" : 59876870,
      "verified" : false
    }
  },
  "id" : 201235966764134401,
  "created_at" : "Sat May 12 09:02:47 +0000 2012",
  "user" : {
    "name" : "Felix",
    "screen_name" : "nicidienase",
    "protected" : false,
    "id_str" : "22396883",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3125784966/8223a4c5c9535be22d15c82ec829c2df_normal.jpeg",
    "id" : 22396883,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://getspaz.com\" rel=\"nofollow\">Spaz</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "201094877717594112",
  "text" : "Romantische Comedies alleine zu schaun is ne bl\u00F6de Idee.",
  "id" : 201094877717594112,
  "created_at" : "Fri May 11 23:42:09 +0000 2012",
  "user" : {
    "name" : "Felix",
    "screen_name" : "nicidienase",
    "protected" : false,
    "id_str" : "22396883",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3125784966/8223a4c5c9535be22d15c82ec829c2df_normal.jpeg",
    "id" : 22396883,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.echofon.com/\" rel=\"nofollow\">Echofon</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "pbnoxious",
      "screen_name" : "pbnoxious",
      "indices" : [ 3, 13 ],
      "id_str" : "206164785",
      "id" : 206164785
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 37, 57 ],
      "url" : "http://t.co/cuE1guPf",
      "expanded_url" : "http://wannstirbtstudivz.com/",
      "display_url" : "wannstirbtstudivz.com"
    } ]
  },
  "geo" : {
  },
  "id_str" : "200896541018427392",
  "text" : "RT @pbnoxious: Heute stirbt StudiVZ! http://t.co/cuE1guPf",
  "retweeted_status" : {
    "source" : "web",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 22, 42 ],
        "url" : "http://t.co/cuE1guPf",
        "expanded_url" : "http://wannstirbtstudivz.com/",
        "display_url" : "wannstirbtstudivz.com"
      } ]
    },
    "geo" : {
    },
    "id_str" : "200888051705192448",
    "text" : "Heute stirbt StudiVZ! http://t.co/cuE1guPf",
    "id" : 200888051705192448,
    "created_at" : "Fri May 11 10:00:18 +0000 2012",
    "user" : {
      "name" : "pbnoxious",
      "screen_name" : "pbnoxious",
      "protected" : false,
      "id_str" : "206164785",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/1896834857/406602_141819292597545_100003084259010_176983_1980311609_n_normal.jpg",
      "id" : 206164785,
      "verified" : false
    }
  },
  "id" : 200896541018427392,
  "created_at" : "Fri May 11 10:34:02 +0000 2012",
  "user" : {
    "name" : "Felix",
    "screen_name" : "nicidienase",
    "protected" : false,
    "id_str" : "22396883",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3125784966/8223a4c5c9535be22d15c82ec829c2df_normal.jpeg",
    "id" : 22396883,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.echofon.com/\" rel=\"nofollow\">Echofon</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "ankegroener",
      "screen_name" : "ankegroener",
      "indices" : [ 3, 15 ],
      "id_str" : "9585092",
      "id" : 9585092
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 54, 74 ],
      "url" : "http://t.co/FcycQiqv",
      "expanded_url" : "http://www.everywhereist.com/7-badass-bavarian-foods-you-must-try/",
      "display_url" : "everywhereist.com/7-badass-bavar\u2026"
    } ]
  },
  "geo" : {
  },
  "id_str" : "200568912612573184",
  "text" : "RT @ankegroener: \"Bavarian food doesn\u2019t f#ck around.\" http://t.co/FcycQiqv",
  "retweeted_status" : {
    "source" : "<a href=\"http://www.echofon.com/\" rel=\"nofollow\">Echofon</a>",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 37, 57 ],
        "url" : "http://t.co/FcycQiqv",
        "expanded_url" : "http://www.everywhereist.com/7-badass-bavarian-foods-you-must-try/",
        "display_url" : "everywhereist.com/7-badass-bavar\u2026"
      } ]
    },
    "geo" : {
    },
    "id_str" : "200545922885754880",
    "text" : "\"Bavarian food doesn\u2019t f#ck around.\" http://t.co/FcycQiqv",
    "id" : 200545922885754880,
    "created_at" : "Thu May 10 11:20:48 +0000 2012",
    "user" : {
      "name" : "ankegroener",
      "screen_name" : "ankegroener",
      "protected" : false,
      "id_str" : "9585092",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/2255387015/Anke_Gr_ner2012_normal.jpg",
      "id" : 9585092,
      "verified" : false
    }
  },
  "id" : 200568912612573184,
  "created_at" : "Thu May 10 12:52:09 +0000 2012",
  "user" : {
    "name" : "Felix",
    "screen_name" : "nicidienase",
    "protected" : false,
    "id_str" : "22396883",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3125784966/8223a4c5c9535be22d15c82ec829c2df_normal.jpeg",
    "id" : 22396883,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.echofon.com/\" rel=\"nofollow\">Echofon</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Peter Glaser",
      "screen_name" : "peterglaser",
      "indices" : [ 3, 15 ],
      "id_str" : "67278209",
      "id" : 67278209
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "200503492538933248",
  "text" : "RT @peterglaser: Rating-Agentur Moodys stuft USA auf USB herab.",
  "retweeted_status" : {
    "source" : "<a href=\"http://www.hootsuite.com\" rel=\"nofollow\">HootSuite</a>",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : {
    },
    "id_str" : "200502974542381057",
    "text" : "Rating-Agentur Moodys stuft USA auf USB herab.",
    "id" : 200502974542381057,
    "created_at" : "Thu May 10 08:30:08 +0000 2012",
    "user" : {
      "name" : "Peter Glaser",
      "screen_name" : "peterglaser",
      "protected" : false,
      "id_str" : "67278209",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/372004147/peterglaser_normal.jpg",
      "id" : 67278209,
      "verified" : false
    }
  },
  "id" : 200503492538933248,
  "created_at" : "Thu May 10 08:32:12 +0000 2012",
  "user" : {
    "name" : "Felix",
    "screen_name" : "nicidienase",
    "protected" : false,
    "id_str" : "22396883",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3125784966/8223a4c5c9535be22d15c82ec829c2df_normal.jpeg",
    "id" : 22396883,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.echofon.com/\" rel=\"nofollow\">Echofon</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Holger Klein",
      "screen_name" : "holgi",
      "indices" : [ 3, 9 ],
      "id_str" : "3068271",
      "id" : 3068271
    }, {
      "name" : "Marcel B\u00F6ttcher",
      "screen_name" : "73inches",
      "indices" : [ 49, 58 ],
      "id_str" : "6917602",
      "id" : 6917602
    }, {
      "name" : "Das Salzprojekt",
      "screen_name" : "salzprojekt",
      "indices" : [ 76, 88 ],
      "id_str" : "146754311",
      "id" : 146754311
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "200498909850775555",
  "text" : "RT @holgi: *ROFL* Kannte ich noch gar nicht! RT: @73inches: Das sch\u00F6nste am @salzprojekt sind doch die unerw\u00E4hnt gebliebenen AGB: http:/ ...",
  "retweeted_status" : {
    "source" : "<a href=\"http://www.echofon.com/\" rel=\"nofollow\">Echofon</a>",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Marcel B\u00F6ttcher",
        "screen_name" : "73inches",
        "indices" : [ 38, 47 ],
        "id_str" : "6917602",
        "id" : 6917602
      }, {
        "name" : "Das Salzprojekt",
        "screen_name" : "salzprojekt",
        "indices" : [ 65, 77 ],
        "id_str" : "146754311",
        "id" : 146754311
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 119, 139 ],
        "url" : "http://t.co/m1bZUkxK",
        "expanded_url" : "http://salzprojekt.de/impressum-kontakt/",
        "display_url" : "salzprojekt.de/impressum-kont\u2026"
      } ]
    },
    "geo" : {
    },
    "id_str" : "200498091693056000",
    "text" : "*ROFL* Kannte ich noch gar nicht! RT: @73inches: Das sch\u00F6nste am @salzprojekt sind doch die unerw\u00E4hnt gebliebenen AGB: http://t.co/m1bZUkxK",
    "id" : 200498091693056000,
    "created_at" : "Thu May 10 08:10:44 +0000 2012",
    "user" : {
      "name" : "Holger Klein",
      "screen_name" : "holgi",
      "protected" : false,
      "id_str" : "3068271",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/14606372/ich1_normal.jpg",
      "id" : 3068271,
      "verified" : false
    }
  },
  "id" : 200498909850775555,
  "created_at" : "Thu May 10 08:13:59 +0000 2012",
  "user" : {
    "name" : "Felix",
    "screen_name" : "nicidienase",
    "protected" : false,
    "id_str" : "22396883",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3125784966/8223a4c5c9535be22d15c82ec829c2df_normal.jpeg",
    "id" : 22396883,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.echofon.com/\" rel=\"nofollow\">Echofon</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Markus Angermeier",
      "screen_name" : "kosmar",
      "indices" : [ 3, 10 ],
      "id_str" : "1487011",
      "id" : 1487011
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "tagesthemen",
      "indices" : [ 30, 42 ]
    }, {
      "text" : "scnr",
      "indices" : [ 43, 48 ]
    } ],
    "urls" : [ {
      "indices" : [ 49, 69 ],
      "url" : "http://t.co/aqh6daS6",
      "expanded_url" : "http://instagr.am/p/Ka2KQeTPtU/",
      "display_url" : "instagr.am/p/Ka2KQeTPtU/"
    } ]
  },
  "geo" : {
  },
  "id_str" : "200488708137431041",
  "text" : "RT @kosmar: Oh, Mars Attacks? #tagesthemen #scnr http://t.co/aqh6daS6",
  "retweeted_status" : {
    "source" : "<a href=\"http://instagram.com\" rel=\"nofollow\">Instagram</a>",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "tagesthemen",
        "indices" : [ 18, 30 ]
      }, {
        "text" : "scnr",
        "indices" : [ 31, 36 ]
      } ],
      "urls" : [ {
        "indices" : [ 37, 57 ],
        "url" : "http://t.co/aqh6daS6",
        "expanded_url" : "http://instagr.am/p/Ka2KQeTPtU/",
        "display_url" : "instagr.am/p/Ka2KQeTPtU/"
      } ]
    },
    "geo" : {
    },
    "id_str" : "200323085067501570",
    "text" : "Oh, Mars Attacks? #tagesthemen #scnr http://t.co/aqh6daS6",
    "id" : 200323085067501570,
    "created_at" : "Wed May 09 20:35:19 +0000 2012",
    "user" : {
      "name" : "Markus Angermeier",
      "screen_name" : "kosmar",
      "protected" : false,
      "id_str" : "1487011",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/2228570189/kosmar_150_normal.jpg",
      "id" : 1487011,
      "verified" : false
    }
  },
  "id" : 200488708137431041,
  "created_at" : "Thu May 10 07:33:27 +0000 2012",
  "user" : {
    "name" : "Felix",
    "screen_name" : "nicidienase",
    "protected" : false,
    "id_str" : "22396883",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3125784966/8223a4c5c9535be22d15c82ec829c2df_normal.jpeg",
    "id" : 22396883,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.echofon.com/\" rel=\"nofollow\">Echofon</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "ellinem",
      "screen_name" : "ellinem",
      "indices" : [ 3, 11 ],
      "id_str" : "29514392",
      "id" : 29514392
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 41, 61 ],
      "url" : "http://t.co/Z5qimTl0",
      "expanded_url" : "http://www.27bslash6.com/halogen.html",
      "display_url" : "27bslash6.com/halogen.html"
    } ]
  },
  "geo" : {
  },
  "id_str" : "200246881979346945",
  "text" : "RT @ellinem: \"Fuck off back to Austria.\" http://t.co/Z5qimTl0",
  "retweeted_status" : {
    "source" : "web",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 28, 48 ],
        "url" : "http://t.co/Z5qimTl0",
        "expanded_url" : "http://www.27bslash6.com/halogen.html",
        "display_url" : "27bslash6.com/halogen.html"
      } ]
    },
    "geo" : {
    },
    "id_str" : "200240463544979456",
    "text" : "\"Fuck off back to Austria.\" http://t.co/Z5qimTl0",
    "id" : 200240463544979456,
    "created_at" : "Wed May 09 15:07:01 +0000 2012",
    "user" : {
      "name" : "ellinem",
      "screen_name" : "ellinem",
      "protected" : false,
      "id_str" : "29514392",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/1141372905/me_normal.jpg",
      "id" : 29514392,
      "verified" : false
    }
  },
  "id" : 200246881979346945,
  "created_at" : "Wed May 09 15:32:31 +0000 2012",
  "user" : {
    "name" : "Felix",
    "screen_name" : "nicidienase",
    "protected" : false,
    "id_str" : "22396883",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3125784966/8223a4c5c9535be22d15c82ec829c2df_normal.jpeg",
    "id" : 22396883,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.echofon.com/\" rel=\"nofollow\">Echofon</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Max Winde",
      "screen_name" : "343max",
      "indices" : [ 3, 10 ],
      "id_str" : "2284151",
      "id" : 2284151
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 113, 133 ],
      "url" : "http://t.co/tbX7vB2N",
      "expanded_url" : "http://new.livestream.com/FosterKittenCam/MirandasKittens",
      "display_url" : "new.livestream.com/FosterKittenCa\u2026"
    } ]
  },
  "geo" : {
  },
  "id_str" : "200226597104660482",
  "text" : "RT @343max: Schaue mir das ab jetzt jeden Tag im B\u00FCro an und werde die Katzen zu hause nachher gleich wegwerfen. http://t.co/tbX7vB2N vi ...",
  "retweeted_status" : {
    "source" : "<a href=\"http://itunes.apple.com/us/app/twitter/id409789998?mt=12\" rel=\"nofollow\">Twitter for Mac</a>",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Gernot",
        "screen_name" : "Gernot",
        "indices" : [ 126, 133 ],
        "id_str" : "710613",
        "id" : 710613
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 101, 121 ],
        "url" : "http://t.co/tbX7vB2N",
        "expanded_url" : "http://new.livestream.com/FosterKittenCam/MirandasKittens",
        "display_url" : "new.livestream.com/FosterKittenCa\u2026"
      } ]
    },
    "geo" : {
    },
    "id_str" : "200226022619234304",
    "text" : "Schaue mir das ab jetzt jeden Tag im B\u00FCro an und werde die Katzen zu hause nachher gleich wegwerfen. http://t.co/tbX7vB2N via @Gernot",
    "id" : 200226022619234304,
    "created_at" : "Wed May 09 14:09:38 +0000 2012",
    "user" : {
      "name" : "Max Winde",
      "screen_name" : "343max",
      "protected" : false,
      "id_str" : "2284151",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/1573654380/edween_normal.png",
      "id" : 2284151,
      "verified" : false
    }
  },
  "id" : 200226597104660482,
  "created_at" : "Wed May 09 14:11:55 +0000 2012",
  "user" : {
    "name" : "Felix",
    "screen_name" : "nicidienase",
    "protected" : false,
    "id_str" : "22396883",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3125784966/8223a4c5c9535be22d15c82ec829c2df_normal.jpeg",
    "id" : 22396883,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.echofon.com/\" rel=\"nofollow\">Echofon</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tim Weber",
      "screen_name" : "Scytale",
      "indices" : [ 0, 8 ],
      "id_str" : "594921016",
      "id" : 594921016
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "200139423902470144",
  "geo" : {
  },
  "id_str" : "200139568404627456",
  "in_reply_to_user_id" : 8308632,
  "text" : "@Scytale \u00C4rger mit Fefe?",
  "id" : 200139568404627456,
  "in_reply_to_status_id" : 200139423902470144,
  "created_at" : "Wed May 09 08:26:06 +0000 2012",
  "in_reply_to_screen_name" : "scy",
  "in_reply_to_user_id_str" : "8308632",
  "user" : {
    "name" : "Felix",
    "screen_name" : "nicidienase",
    "protected" : false,
    "id_str" : "22396883",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3125784966/8223a4c5c9535be22d15c82ec829c2df_normal.jpeg",
    "id" : 22396883,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.echofon.com/\" rel=\"nofollow\">Echofon</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Das F\u00FChl.",
      "screen_name" : "Das_Fuehl",
      "indices" : [ 3, 13 ],
      "id_str" : "256165184",
      "id" : 256165184
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "root",
      "indices" : [ 78, 83 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "200131202571710465",
  "text" : "RT @Das_Fuehl: Das F\u00FChl, wenn du das Haus verl\u00E4sst und dich fragst, ob du die #root-Konsole offen gelassen hast.",
  "retweeted_status" : {
    "source" : "web",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "root",
        "indices" : [ 63, 68 ]
      } ],
      "urls" : [ ]
    },
    "geo" : {
    },
    "id_str" : "71060753750310913",
    "text" : "Das F\u00FChl, wenn du das Haus verl\u00E4sst und dich fragst, ob du die #root-Konsole offen gelassen hast.",
    "id" : 71060753750310913,
    "created_at" : "Thu May 19 03:52:58 +0000 2011",
    "user" : {
      "name" : "Das F\u00FChl.",
      "screen_name" : "Das_Fuehl",
      "protected" : false,
      "id_str" : "256165184",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/1251581735/1292724191001_normal.jpg",
      "id" : 256165184,
      "verified" : false
    }
  },
  "id" : 200131202571710465,
  "created_at" : "Wed May 09 07:52:51 +0000 2012",
  "user" : {
    "name" : "Felix",
    "screen_name" : "nicidienase",
    "protected" : false,
    "id_str" : "22396883",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3125784966/8223a4c5c9535be22d15c82ec829c2df_normal.jpeg",
    "id" : 22396883,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.echofon.com/\" rel=\"nofollow\">Echofon</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tim Weber",
      "screen_name" : "Scytale",
      "indices" : [ 3, 11 ],
      "id_str" : "594921016",
      "id" : 594921016
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 80, 100 ],
      "url" : "http://t.co/7Baexu5w",
      "expanded_url" : "http://shapecatcher.com/",
      "display_url" : "shapecatcher.com"
    } ]
  },
  "geo" : {
  },
  "id_str" : "200130247969079296",
  "text" : "RT @Scytale: Ihr sucht ein Zeichen in Unicode? Malt es einfach in Shapecatcher. http://t.co/7Baexu5w &lt;3",
  "retweeted_status" : {
    "source" : "<a href=\"http://www.tweetdeck.com\" rel=\"nofollow\">TweetDeck</a>",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 67, 87 ],
        "url" : "http://t.co/7Baexu5w",
        "expanded_url" : "http://shapecatcher.com/",
        "display_url" : "shapecatcher.com"
      } ]
    },
    "geo" : {
      "type" : "Point",
      "coordinates" : [ 49.4955473928, 8.4576165676 ]
    },
    "id_str" : "200129314216349696",
    "text" : "Ihr sucht ein Zeichen in Unicode? Malt es einfach in Shapecatcher. http://t.co/7Baexu5w &lt;3",
    "id" : 200129314216349696,
    "created_at" : "Wed May 09 07:45:21 +0000 2012",
    "user" : {
      "name" : "Tim Weber",
      "screen_name" : "scy",
      "protected" : false,
      "id_str" : "8308632",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/424137519/avatar184_normal.jpg",
      "id" : 8308632,
      "verified" : false
    }
  },
  "id" : 200130247969079296,
  "created_at" : "Wed May 09 07:49:04 +0000 2012",
  "user" : {
    "name" : "Felix",
    "screen_name" : "nicidienase",
    "protected" : false,
    "id_str" : "22396883",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3125784966/8223a4c5c9535be22d15c82ec829c2df_normal.jpeg",
    "id" : 22396883,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.echofon.com/\" rel=\"nofollow\">Echofon</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "m.",
      "screen_name" : "ohaimareiki",
      "indices" : [ 0, 12 ],
      "id_str" : "14732096",
      "id" : 14732096
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "199892800249151488",
  "geo" : {
  },
  "id_str" : "199893100376768513",
  "in_reply_to_user_id" : 14732096,
  "text" : "@ohaimareiki Frankfurt-R\u00F6delheim",
  "id" : 199893100376768513,
  "in_reply_to_status_id" : 199892800249151488,
  "created_at" : "Tue May 08 16:06:43 +0000 2012",
  "in_reply_to_screen_name" : "ohaimareiki",
  "in_reply_to_user_id_str" : "14732096",
  "user" : {
    "name" : "Felix",
    "screen_name" : "nicidienase",
    "protected" : false,
    "id_str" : "22396883",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3125784966/8223a4c5c9535be22d15c82ec829c2df_normal.jpeg",
    "id" : 22396883,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.echofon.com/\" rel=\"nofollow\">Echofon</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "monoxyd",
      "screen_name" : "monoxyd",
      "indices" : [ 3, 11 ],
      "id_str" : "14085052",
      "id" : 14085052
    }, {
      "name" : "@zeitweise",
      "screen_name" : "zeitweise",
      "indices" : [ 18, 28 ],
      "id_str" : "15494684",
      "id" : 15494684
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 106, 126 ],
      "url" : "http://t.co/rpoBFQ2x",
      "expanded_url" : "http://www.137b.org/?p=2445",
      "display_url" : "137b.org/?p=2445"
    } ]
  },
  "geo" : {
  },
  "id_str" : "199816067361685504",
  "text" : "RT @monoxyd: Herr @zeitweise schrob einen sch\u00F6nen Text \u00FCber Siegfried Kauders geistiges Eigentumsfahrrad: http://t.co/rpoBFQ2x",
  "retweeted_status" : {
    "source" : "<a href=\"http://itunes.apple.com/us/app/twitter/id409789998?mt=12\" rel=\"nofollow\">Twitter for Mac</a>",
    "entities" : {
      "user_mentions" : [ {
        "name" : "@zeitweise",
        "screen_name" : "zeitweise",
        "indices" : [ 5, 15 ],
        "id_str" : "15494684",
        "id" : 15494684
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 93, 113 ],
        "url" : "http://t.co/rpoBFQ2x",
        "expanded_url" : "http://www.137b.org/?p=2445",
        "display_url" : "137b.org/?p=2445"
      } ]
    },
    "geo" : {
    },
    "id_str" : "199815357022732288",
    "text" : "Herr @zeitweise schrob einen sch\u00F6nen Text \u00FCber Siegfried Kauders geistiges Eigentumsfahrrad: http://t.co/rpoBFQ2x",
    "id" : 199815357022732288,
    "created_at" : "Tue May 08 10:57:48 +0000 2012",
    "user" : {
      "name" : "monoxyd",
      "screen_name" : "monoxyd",
      "protected" : false,
      "id_str" : "14085052",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/1422306657/lampe_normal.jpg",
      "id" : 14085052,
      "verified" : false
    }
  },
  "id" : 199816067361685504,
  "created_at" : "Tue May 08 11:00:37 +0000 2012",
  "user" : {
    "name" : "Felix",
    "screen_name" : "nicidienase",
    "protected" : false,
    "id_str" : "22396883",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3125784966/8223a4c5c9535be22d15c82ec829c2df_normal.jpeg",
    "id" : 22396883,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.echofon.com/\" rel=\"nofollow\">Echofon</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "pfleidi",
      "screen_name" : "pfleidi",
      "indices" : [ 3, 11 ],
      "id_str" : "15647796",
      "id" : 15647796
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 73, 93 ],
      "url" : "http://t.co/iEApxPzn",
      "expanded_url" : "http://www.infoworld.com/d/application-development/hello-world-programming-languages-quiz-188874",
      "display_url" : "infoworld.com/d/application-\u2026"
    } ]
  },
  "geo" : {
  },
  "id_str" : "199772903338807296",
  "text" : "RT @pfleidi: Ok, ok ... I don't know what Logo and Fortran look like ... http://t.co/iEApxPzn",
  "retweeted_status" : {
    "source" : "<a href=\"http://www.echofon.com/\" rel=\"nofollow\">Echofon</a>",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 60, 80 ],
        "url" : "http://t.co/iEApxPzn",
        "expanded_url" : "http://www.infoworld.com/d/application-development/hello-world-programming-languages-quiz-188874",
        "display_url" : "infoworld.com/d/application-\u2026"
      } ]
    },
    "geo" : {
    },
    "id_str" : "199618482940280833",
    "text" : "Ok, ok ... I don't know what Logo and Fortran look like ... http://t.co/iEApxPzn",
    "id" : 199618482940280833,
    "created_at" : "Mon May 07 21:55:29 +0000 2012",
    "user" : {
      "name" : "pfleidi",
      "screen_name" : "pfleidi",
      "protected" : false,
      "id_str" : "15647796",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/2992339395/7f60afee5ffff6e961831ba8d07d0850_normal.png",
      "id" : 15647796,
      "verified" : false
    }
  },
  "id" : 199772903338807296,
  "created_at" : "Tue May 08 08:09:06 +0000 2012",
  "user" : {
    "name" : "Felix",
    "screen_name" : "nicidienase",
    "protected" : false,
    "id_str" : "22396883",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3125784966/8223a4c5c9535be22d15c82ec829c2df_normal.jpeg",
    "id" : 22396883,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://getspaz.com\" rel=\"nofollow\">Spaz HD for webOS</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Grazia Schonkost",
      "screen_name" : "Steaklight",
      "indices" : [ 3, 14 ],
      "id_str" : "287302033",
      "id" : 287302033
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "199609794460532736",
  "text" : "RT @Steaklight: Mama: \"Ich w\u00E4hle auch die Piraten. Wenn ich mich schon verarschen lasse, dann wenigstens von welchen, die rumlaufen, wie ...",
  "retweeted_status" : {
    "source" : "web",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : {
    },
    "id_str" : "199565319616987136",
    "text" : "Mama: \"Ich w\u00E4hle auch die Piraten. Wenn ich mich schon verarschen lasse, dann wenigstens von welchen, die rumlaufen, wie Dein Bruder.\" &lt;3",
    "id" : 199565319616987136,
    "created_at" : "Mon May 07 18:24:14 +0000 2012",
    "user" : {
      "name" : "Grazia Schonkost",
      "screen_name" : "Steaklight",
      "protected" : false,
      "id_str" : "287302033",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/1324128053/DSC05458_normal.JPG",
      "id" : 287302033,
      "verified" : false
    }
  },
  "id" : 199609794460532736,
  "created_at" : "Mon May 07 21:20:58 +0000 2012",
  "user" : {
    "name" : "Felix",
    "screen_name" : "nicidienase",
    "protected" : false,
    "id_str" : "22396883",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3125784966/8223a4c5c9535be22d15c82ec829c2df_normal.jpeg",
    "id" : 22396883,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://getspaz.com\" rel=\"nofollow\">Spaz HD for webOS</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Christian Zaschke",
      "screen_name" : "ChZaschke",
      "indices" : [ 3, 13 ],
      "id_str" : "395319523",
      "id" : 395319523
    }, {
      "name" : "The subeditor",
      "screen_name" : "subedited",
      "indices" : [ 29, 39 ],
      "id_str" : "32983189",
      "id" : 32983189
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 114, 134 ],
      "url" : "http://t.co/aK1Vbt1Y",
      "expanded_url" : "http://imgur.com/OaJyK",
      "display_url" : "imgur.com/OaJyK"
    } ]
  },
  "geo" : {
  },
  "id_str" : "198804212140883968",
  "text" : "RT @ChZaschke: Brillant!! RT @subedited: One of the worst typography decisions I've EVER seen. Do WHAT yourself?! http://t.co/aK1Vbt1Y",
  "retweeted_status" : {
    "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
    "entities" : {
      "user_mentions" : [ {
        "name" : "The subeditor",
        "screen_name" : "subedited",
        "indices" : [ 14, 24 ],
        "id_str" : "32983189",
        "id" : 32983189
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 99, 119 ],
        "url" : "http://t.co/aK1Vbt1Y",
        "expanded_url" : "http://imgur.com/OaJyK",
        "display_url" : "imgur.com/OaJyK"
      } ]
    },
    "geo" : {
    },
    "id_str" : "198720504088104960",
    "text" : "Brillant!! RT @subedited: One of the worst typography decisions I've EVER seen. Do WHAT yourself?! http://t.co/aK1Vbt1Y",
    "id" : 198720504088104960,
    "created_at" : "Sat May 05 10:27:14 +0000 2012",
    "user" : {
      "name" : "Christian Zaschke",
      "screen_name" : "ChZaschke",
      "protected" : false,
      "id_str" : "395319523",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/1731822727/Christian_Zaschke__Sueddeutsche_Zeitung_normal.JPG",
      "id" : 395319523,
      "verified" : false
    }
  },
  "id" : 198804212140883968,
  "created_at" : "Sat May 05 15:59:52 +0000 2012",
  "user" : {
    "name" : "Felix",
    "screen_name" : "nicidienase",
    "protected" : false,
    "id_str" : "22396883",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3125784966/8223a4c5c9535be22d15c82ec829c2df_normal.jpeg",
    "id" : 22396883,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.echofon.com/\" rel=\"nofollow\">Echofon</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Der Postillon",
      "screen_name" : "Der_Postillon",
      "indices" : [ 3, 17 ],
      "id_str" : "105554801",
      "id" : 105554801
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "facebook",
      "indices" : [ 115, 124 ]
    }, {
      "text" : "studivz",
      "indices" : [ 125, 133 ]
    } ],
    "urls" : [ {
      "indices" : [ 94, 114 ],
      "url" : "http://t.co/dp5wkSSo",
      "expanded_url" : "http://bit.ly/IAgW8F",
      "display_url" : "bit.ly/IAgW8F"
    } ]
  },
  "geo" : {
  },
  "id_str" : "198396092973457408",
  "text" : "RT @Der_Postillon: StudiVZ baut Firewall, um verbleibende Nutzer an der Flucht zu hindern ... http://t.co/dp5wkSSo #facebook #studivz",
  "retweeted_status" : {
    "source" : "web",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "facebook",
        "indices" : [ 96, 105 ]
      }, {
        "text" : "studivz",
        "indices" : [ 106, 114 ]
      } ],
      "urls" : [ {
        "indices" : [ 75, 95 ],
        "url" : "http://t.co/dp5wkSSo",
        "expanded_url" : "http://bit.ly/IAgW8F",
        "display_url" : "bit.ly/IAgW8F"
      } ]
    },
    "geo" : {
    },
    "id_str" : "198388693713686528",
    "text" : "StudiVZ baut Firewall, um verbleibende Nutzer an der Flucht zu hindern ... http://t.co/dp5wkSSo #facebook #studivz",
    "id" : 198388693713686528,
    "created_at" : "Fri May 04 12:28:45 +0000 2012",
    "user" : {
      "name" : "Der Postillon",
      "screen_name" : "Der_Postillon",
      "protected" : false,
      "id_str" : "105554801",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/1274516114/Twitterpferd_normal.jpg",
      "id" : 105554801,
      "verified" : false
    }
  },
  "id" : 198396092973457408,
  "created_at" : "Fri May 04 12:58:09 +0000 2012",
  "user" : {
    "name" : "Felix",
    "screen_name" : "nicidienase",
    "protected" : false,
    "id_str" : "22396883",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3125784966/8223a4c5c9535be22d15c82ec829c2df_normal.jpeg",
    "id" : 22396883,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.echofon.com/\" rel=\"nofollow\">Echofon</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 0, 20 ],
      "url" : "http://t.co/dKo9PSaF",
      "expanded_url" : "http://en.wikipedia.org/wiki/Timeline_of_the_near_future",
      "display_url" : "en.wikipedia.org/wiki/Timeline_\u2026"
    } ]
  },
  "geo" : {
  },
  "id_str" : "198313936016257024",
  "text" : "http://t.co/dKo9PSaF",
  "id" : 198313936016257024,
  "created_at" : "Fri May 04 07:31:41 +0000 2012",
  "user" : {
    "name" : "Felix",
    "screen_name" : "nicidienase",
    "protected" : false,
    "id_str" : "22396883",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3125784966/8223a4c5c9535be22d15c82ec829c2df_normal.jpeg",
    "id" : 22396883,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://getspaz.com\" rel=\"nofollow\">Spaz HD for webOS</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Graham Lee",
      "screen_name" : "secboffin",
      "indices" : [ 3, 13 ],
      "id_str" : "15537466",
      "id" : 15537466
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "198193761929531394",
  "text" : "RT @secboffin: \"I can cast out either one of your demons, but not both of them.\" \u2014 the XORcist.",
  "retweeted_status" : {
    "source" : "<a href=\"http://tapbots.com/tweetbot\" rel=\"nofollow\">Tweetbot for iOS</a>",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : {
    },
    "id_str" : "197932270286417920",
    "text" : "\"I can cast out either one of your demons, but not both of them.\" \u2014 the XORcist.",
    "id" : 197932270286417920,
    "created_at" : "Thu May 03 06:15:05 +0000 2012",
    "user" : {
      "name" : "Graham Lee",
      "screen_name" : "secboffin",
      "protected" : false,
      "id_str" : "15537466",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/2728789195/7a9b59c46d83e9648e002dce52f192cd_normal.jpeg",
      "id" : 15537466,
      "verified" : false
    }
  },
  "id" : 198193761929531394,
  "created_at" : "Thu May 03 23:34:09 +0000 2012",
  "user" : {
    "name" : "Felix",
    "screen_name" : "nicidienase",
    "protected" : false,
    "id_str" : "22396883",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3125784966/8223a4c5c9535be22d15c82ec829c2df_normal.jpeg",
    "id" : 22396883,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.echofon.com/\" rel=\"nofollow\">Echofon</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jessie De Weyrd",
      "screen_name" : "StrassenKatze",
      "indices" : [ 3, 17 ],
      "id_str" : "21585225",
      "id" : 21585225
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "198009459941978112",
  "text" : "RT @StrassenKatze: &lt;Zoidberg&gt;Whoopwhoopwhoopwhoop!!!&lt;/Zoidberg&gt;",
  "retweeted_status" : {
    "source" : "<a href=\"http://blackberry.com/twitter\" rel=\"nofollow\">Twitter for BlackBerry\u00AE</a>",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : {
    },
    "id_str" : "197989107266355200",
    "text" : "&lt;Zoidberg&gt;Whoopwhoopwhoopwhoop!!!&lt;/Zoidberg&gt;",
    "id" : 197989107266355200,
    "created_at" : "Thu May 03 10:00:56 +0000 2012",
    "user" : {
      "name" : "Jessie De Weyrd",
      "screen_name" : "StrassenKatze",
      "protected" : false,
      "id_str" : "21585225",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/3329453866/88ade5439ab6da12fac309a457eb07b3_normal.jpeg",
      "id" : 21585225,
      "verified" : false
    }
  },
  "id" : 198009459941978112,
  "created_at" : "Thu May 03 11:21:48 +0000 2012",
  "user" : {
    "name" : "Felix",
    "screen_name" : "nicidienase",
    "protected" : false,
    "id_str" : "22396883",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3125784966/8223a4c5c9535be22d15c82ec829c2df_normal.jpeg",
    "id" : 22396883,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.echofon.com/\" rel=\"nofollow\">Echofon</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 4, 25 ],
      "url" : "https://t.co/ZvsDht63",
      "expanded_url" : "https://fbcdn-sphotos-a.akamaihd.net/hphotos-ak-prn1/549310_425109057517256_100000544959373_1493543_1280001535_n.jpg",
      "display_url" : "fbcdn-sphotos-a.akamaihd.net/hphotos-ak-prn\u2026"
    } ]
  },
  "geo" : {
  },
  "id_str" : "198008783346221056",
  "text" : "LOL https://t.co/ZvsDht63",
  "id" : 198008783346221056,
  "created_at" : "Thu May 03 11:19:07 +0000 2012",
  "user" : {
    "name" : "Felix",
    "screen_name" : "nicidienase",
    "protected" : false,
    "id_str" : "22396883",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3125784966/8223a4c5c9535be22d15c82ec829c2df_normal.jpeg",
    "id" : 22396883,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.echofon.com/\" rel=\"nofollow\">Echofon</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Quinn Norton",
      "screen_name" : "quinnnorton",
      "indices" : [ 3, 15 ],
      "id_str" : "38975663",
      "id" : 38975663
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "197959986054303744",
  "text" : "RT @quinnnorton: The way the kids speak in memes these days, it's totally Darmok and Jalad at Tanagra.",
  "retweeted_status" : {
    "source" : "web",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : {
    },
    "id_str" : "192219459723870208",
    "text" : "The way the kids speak in memes these days, it's totally Darmok and Jalad at Tanagra.",
    "id" : 192219459723870208,
    "created_at" : "Tue Apr 17 11:54:25 +0000 2012",
    "user" : {
      "name" : "Quinn Norton",
      "screen_name" : "quinnnorton",
      "protected" : false,
      "id_str" : "38975663",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/3409984165/89adcc0cc358970902b2deaef17c6fd0_normal.jpeg",
      "id" : 38975663,
      "verified" : false
    }
  },
  "id" : 197959986054303744,
  "created_at" : "Thu May 03 08:05:13 +0000 2012",
  "user" : {
    "name" : "Felix",
    "screen_name" : "nicidienase",
    "protected" : false,
    "id_str" : "22396883",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3125784966/8223a4c5c9535be22d15c82ec829c2df_normal.jpeg",
    "id" : 22396883,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "197779854328995840",
  "geo" : {
  },
  "id_str" : "197781265359978496",
  "in_reply_to_user_id" : 20689932,
  "text" : "@Geruhn Hast dus zur\u00FCckgehn lassen?",
  "id" : 197781265359978496,
  "in_reply_to_status_id" : 197779854328995840,
  "created_at" : "Wed May 02 20:15:02 +0000 2012",
  "in_reply_to_screen_name" : "keinGeruhn",
  "in_reply_to_user_id_str" : "20689932",
  "user" : {
    "name" : "Felix",
    "screen_name" : "nicidienase",
    "protected" : false,
    "id_str" : "22396883",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3125784966/8223a4c5c9535be22d15c82ec829c2df_normal.jpeg",
    "id" : 22396883,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.echofon.com/\" rel=\"nofollow\">Echofon</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "197720854669426688",
  "geo" : {
  },
  "id_str" : "197724295399616515",
  "in_reply_to_user_id" : 20689932,
  "text" : "@Geruhn Schaut nach Wohnheim aus. Wo ist den deine neue Residenz?",
  "id" : 197724295399616515,
  "in_reply_to_status_id" : 197720854669426688,
  "created_at" : "Wed May 02 16:28:40 +0000 2012",
  "in_reply_to_screen_name" : "keinGeruhn",
  "in_reply_to_user_id_str" : "20689932",
  "user" : {
    "name" : "Felix",
    "screen_name" : "nicidienase",
    "protected" : false,
    "id_str" : "22396883",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3125784966/8223a4c5c9535be22d15c82ec829c2df_normal.jpeg",
    "id" : 22396883,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.echofon.com/\" rel=\"nofollow\">Echofon</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mikko Hypponen \u2718",
      "screen_name" : "mikko",
      "indices" : [ 3, 9 ],
      "id_str" : "23566038",
      "id" : 23566038
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 40, 60 ],
      "url" : "http://t.co/DRGqRvpR",
      "expanded_url" : "http://pinterest.com/pin/11610911509612074/",
      "display_url" : "pinterest.com/pin/1161091150\u2026"
    } ]
  },
  "geo" : {
  },
  "id_str" : "197657031971323906",
  "text" : "RT @mikko: The server did a DROP TABLE. http://t.co/DRGqRvpR",
  "retweeted_status" : {
    "source" : "<a href=\"http://twitter.com/tweetbutton\" rel=\"nofollow\">Tweet Button</a>",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 29, 49 ],
        "url" : "http://t.co/DRGqRvpR",
        "expanded_url" : "http://pinterest.com/pin/11610911509612074/",
        "display_url" : "pinterest.com/pin/1161091150\u2026"
      } ]
    },
    "geo" : {
    },
    "id_str" : "197646606911279104",
    "text" : "The server did a DROP TABLE. http://t.co/DRGqRvpR",
    "id" : 197646606911279104,
    "created_at" : "Wed May 02 11:19:57 +0000 2012",
    "user" : {
      "name" : "Mikko Hypponen \u2718",
      "screen_name" : "mikko",
      "protected" : false,
      "id_str" : "23566038",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/3428497729/8a03810d1c84ab31c512fb6660e85477_normal.jpeg",
      "id" : 23566038,
      "verified" : false
    }
  },
  "id" : 197657031971323906,
  "created_at" : "Wed May 02 12:01:23 +0000 2012",
  "user" : {
    "name" : "Felix",
    "screen_name" : "nicidienase",
    "protected" : false,
    "id_str" : "22396883",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3125784966/8223a4c5c9535be22d15c82ec829c2df_normal.jpeg",
    "id" : 22396883,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.echofon.com/\" rel=\"nofollow\">Echofon</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Piratenpartei",
      "screen_name" : "Piratenpartei",
      "indices" : [ 3, 17 ],
      "id_str" : "14341194",
      "id" : 14341194
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Piraten",
      "indices" : [ 41, 49 ]
    }, {
      "text" : "WegDerS",
      "indices" : [ 128, 136 ]
    } ],
    "urls" : [ {
      "indices" : [ 107, 127 ],
      "url" : "http://t.co/7PwJapAS",
      "expanded_url" : "http://youtu.be/PeMILrlF55Q",
      "display_url" : "youtu.be/PeMILrlF55Q"
    } ]
  },
  "geo" : {
  },
  "id_str" : "197652592736731136",
  "text" : "RT @Piratenpartei: Gro\u00DFartige Aktion der #Piraten gestern in Neum\u00FCnster: Geschichtsunterricht f\u00FCr Neonazis http://t.co/7PwJapAS #WegDerS ...",
  "retweeted_status" : {
    "source" : "<a href=\"http://www.tweetdeck.com\" rel=\"nofollow\">TweetDeck</a>",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "Piraten",
        "indices" : [ 22, 30 ]
      }, {
        "text" : "WegDerSchande",
        "indices" : [ 109, 123 ]
      } ],
      "urls" : [ {
        "indices" : [ 88, 108 ],
        "url" : "http://t.co/7PwJapAS",
        "expanded_url" : "http://youtu.be/PeMILrlF55Q",
        "display_url" : "youtu.be/PeMILrlF55Q"
      } ]
    },
    "geo" : {
    },
    "id_str" : "197650462428766209",
    "text" : "Gro\u00DFartige Aktion der #Piraten gestern in Neum\u00FCnster: Geschichtsunterricht f\u00FCr Neonazis http://t.co/7PwJapAS #WegDerSchande",
    "id" : 197650462428766209,
    "created_at" : "Wed May 02 11:35:17 +0000 2012",
    "user" : {
      "name" : "Piratenpartei",
      "screen_name" : "Piratenpartei",
      "protected" : false,
      "id_str" : "14341194",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/3477535621/635250d0522a675f3e0344d44310cbcc_normal.jpeg",
      "id" : 14341194,
      "verified" : false
    }
  },
  "id" : 197652592736731136,
  "created_at" : "Wed May 02 11:43:44 +0000 2012",
  "user" : {
    "name" : "Felix",
    "screen_name" : "nicidienase",
    "protected" : false,
    "id_str" : "22396883",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3125784966/8223a4c5c9535be22d15c82ec829c2df_normal.jpeg",
    "id" : 22396883,
    "verified" : false
  }
} ]