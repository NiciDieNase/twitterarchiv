Grailbird.data.tweets_2012_06 = 
 [ {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "219174661848694784",
  "text" : "Eigentlich wollt ich noch zum Unifest, aber da drau\u00DFen findet grade die Sintflut statt.",
  "id" : 219174661848694784,
  "created_at" : "Sat Jun 30 21:04:46 +0000 2012",
  "user" : {
    "name" : "Felix",
    "screen_name" : "nicidienase",
    "protected" : false,
    "id_str" : "22396883",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3125784966/8223a4c5c9535be22d15c82ec829c2df_normal.jpeg",
    "id" : 22396883,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "memo",
      "screen_name" : "memo42",
      "indices" : [ 3, 10 ],
      "id_str" : "55311456",
      "id" : 55311456
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "218826233285328896",
  "text" : "RT @memo42: bzw. Maegermeister! still try it!",
  "retweeted_status" : {
    "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : {
    },
    "id_str" : "218826146274484224",
    "text" : "bzw. Maegermeister! still try it!",
    "id" : 218826146274484224,
    "created_at" : "Fri Jun 29 21:59:53 +0000 2012",
    "user" : {
      "name" : "memo",
      "screen_name" : "memo42",
      "protected" : false,
      "id_str" : "55311456",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/2873023937/3ae32f81f1fe847dc5c5820e297028ad_normal.jpeg",
      "id" : 55311456,
      "verified" : false
    }
  },
  "id" : 218826233285328896,
  "created_at" : "Fri Jun 29 22:00:14 +0000 2012",
  "user" : {
    "name" : "Felix",
    "screen_name" : "nicidienase",
    "protected" : false,
    "id_str" : "22396883",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3125784966/8223a4c5c9535be22d15c82ec829c2df_normal.jpeg",
    "id" : 22396883,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "218826190662803457",
  "text" : "Maegermeister FTW!!!",
  "id" : 218826190662803457,
  "created_at" : "Fri Jun 29 22:00:04 +0000 2012",
  "user" : {
    "name" : "Felix",
    "screen_name" : "nicidienase",
    "protected" : false,
    "id_str" : "22396883",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3125784966/8223a4c5c9535be22d15c82ec829c2df_normal.jpeg",
    "id" : 22396883,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "memo",
      "screen_name" : "memo42",
      "indices" : [ 3, 10 ],
      "id_str" : "55311456",
      "id" : 55311456
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "218825745500340225",
  "text" : "RT @memo42: Megameister!!! try it",
  "retweeted_status" : {
    "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : {
    },
    "id_str" : "218825672628502530",
    "text" : "Megameister!!! try it",
    "id" : 218825672628502530,
    "created_at" : "Fri Jun 29 21:58:00 +0000 2012",
    "user" : {
      "name" : "memo",
      "screen_name" : "memo42",
      "protected" : false,
      "id_str" : "55311456",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/2873023937/3ae32f81f1fe847dc5c5820e297028ad_normal.jpeg",
      "id" : 55311456,
      "verified" : false
    }
  },
  "id" : 218825745500340225,
  "created_at" : "Fri Jun 29 21:58:17 +0000 2012",
  "user" : {
    "name" : "Felix",
    "screen_name" : "nicidienase",
    "protected" : false,
    "id_str" : "22396883",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3125784966/8223a4c5c9535be22d15c82ec829c2df_normal.jpeg",
    "id" : 22396883,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http://twitter.com/nicidienase/status/218815631024324610/photo/1",
      "indices" : [ 14, 34 ],
      "url" : "http://t.co/Z3DseVjH",
      "media_url" : "http://pbs.twimg.com/media/AwljqDbCAAA0sZG.jpg",
      "id_str" : "218815631028518912",
      "id" : 218815631028518912,
      "media_url_https" : "https://pbs.twimg.com/media/AwljqDbCAAA0sZG.jpg",
      "sizes" : [ {
        "h" : 71,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 214,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 125,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 448,
        "resize" : "fit",
        "w" : 2146
      } ],
      "display_url" : "pic.twitter.com/Z3DseVjH"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "218815631024324610",
  "text" : "Parkplatzfest http://t.co/Z3DseVjH",
  "id" : 218815631024324610,
  "created_at" : "Fri Jun 29 21:18:07 +0000 2012",
  "user" : {
    "name" : "Felix",
    "screen_name" : "nicidienase",
    "protected" : false,
    "id_str" : "22396883",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3125784966/8223a4c5c9535be22d15c82ec829c2df_normal.jpeg",
    "id" : 22396883,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "218424674294562816",
  "text" : "Da schaut man einmal Fu\u00DFball und dann liegt Deutschland 0:2 hinten.",
  "id" : 218424674294562816,
  "created_at" : "Thu Jun 28 19:24:35 +0000 2012",
  "user" : {
    "name" : "Felix",
    "screen_name" : "nicidienase",
    "protected" : false,
    "id_str" : "22396883",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3125784966/8223a4c5c9535be22d15c82ec829c2df_normal.jpeg",
    "id" : 22396883,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sturzelchen.",
      "screen_name" : "randsturz",
      "indices" : [ 0, 10 ],
      "id_str" : "73659102",
      "id" : 73659102
    }, {
      "name" : "Eva Eichhorn",
      "screen_name" : "MamsellChaos",
      "indices" : [ 11, 24 ],
      "id_str" : "140774041",
      "id" : 140774041
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "218422325815685124",
  "text" : "@randsturz @MamsellChaos Yeah, lange Nyan-Unterhosen!",
  "id" : 218422325815685124,
  "created_at" : "Thu Jun 28 19:15:15 +0000 2012",
  "user" : {
    "name" : "Felix",
    "screen_name" : "nicidienase",
    "protected" : false,
    "id_str" : "22396883",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3125784966/8223a4c5c9535be22d15c82ec829c2df_normal.jpeg",
    "id" : 22396883,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "218418992115752960",
  "text" : "Ich schau mir heute auch mal dieses \"Fu\u00DFball\" an vom dem in letzter Zeit alle reden.",
  "id" : 218418992115752960,
  "created_at" : "Thu Jun 28 19:02:00 +0000 2012",
  "user" : {
    "name" : "Felix",
    "screen_name" : "nicidienase",
    "protected" : false,
    "id_str" : "22396883",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3125784966/8223a4c5c9535be22d15c82ec829c2df_normal.jpeg",
    "id" : 22396883,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.echofon.com/\" rel=\"nofollow\">Echofon</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "psy",
      "screen_name" : "psycon",
      "indices" : [ 0, 7 ],
      "id_str" : "87286054",
      "id" : 87286054
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "218292399296888832",
  "geo" : {
  },
  "id_str" : "218306514128093186",
  "in_reply_to_user_id" : 87286054,
  "text" : "@psycon Wie liefs?",
  "id" : 218306514128093186,
  "in_reply_to_status_id" : 218292399296888832,
  "created_at" : "Thu Jun 28 11:35:03 +0000 2012",
  "in_reply_to_screen_name" : "psycon",
  "in_reply_to_user_id_str" : "87286054",
  "user" : {
    "name" : "Felix",
    "screen_name" : "nicidienase",
    "protected" : false,
    "id_str" : "22396883",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3125784966/8223a4c5c9535be22d15c82ec829c2df_normal.jpeg",
    "id" : 22396883,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.echofon.com/\" rel=\"nofollow\">Echofon</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "psy",
      "screen_name" : "psycon",
      "indices" : [ 0, 7 ],
      "id_str" : "87286054",
      "id" : 87286054
    }, {
      "name" : "neingeist",
      "screen_name" : "neingeist",
      "indices" : [ 8, 18 ],
      "id_str" : "11193712",
      "id" : 11193712
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "217731873814745088",
  "geo" : {
  },
  "id_str" : "217896572065824768",
  "in_reply_to_user_id" : 87286054,
  "text" : "@psycon @neingeist Toast, Ananas, K\u00E4se, fertig!",
  "id" : 217896572065824768,
  "in_reply_to_status_id" : 217731873814745088,
  "created_at" : "Wed Jun 27 08:26:05 +0000 2012",
  "in_reply_to_screen_name" : "psycon",
  "in_reply_to_user_id_str" : "87286054",
  "user" : {
    "name" : "Felix",
    "screen_name" : "nicidienase",
    "protected" : false,
    "id_str" : "22396883",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3125784966/8223a4c5c9535be22d15c82ec829c2df_normal.jpeg",
    "id" : 22396883,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "@sumosu",
      "screen_name" : "sumosu",
      "indices" : [ 3, 10 ],
      "id_str" : "50801129",
      "id" : 50801129
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "217766829186228224",
  "text" : "RT @sumosu: Lassen sie mich durch, ich bin operierender GEMA Thetan Stufe 5",
  "retweeted_status" : {
    "source" : "<a href=\"http://www.tweetdeck.com\" rel=\"nofollow\">TweetDeck</a>",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : {
    },
    "id_str" : "217740433072209920",
    "text" : "Lassen sie mich durch, ich bin operierender GEMA Thetan Stufe 5",
    "id" : 217740433072209920,
    "created_at" : "Tue Jun 26 22:05:39 +0000 2012",
    "user" : {
      "name" : "@sumosu",
      "screen_name" : "sumosu",
      "protected" : false,
      "id_str" : "50801129",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/2352355857/ijhxrdjk64jmytiqp36w_normal.jpeg",
      "id" : 50801129,
      "verified" : false
    }
  },
  "id" : 217766829186228224,
  "created_at" : "Tue Jun 26 23:50:32 +0000 2012",
  "user" : {
    "name" : "Felix",
    "screen_name" : "nicidienase",
    "protected" : false,
    "id_str" : "22396883",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3125784966/8223a4c5c9535be22d15c82ec829c2df_normal.jpeg",
    "id" : 22396883,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.echofon.com/\" rel=\"nofollow\">Echofon</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "psy",
      "screen_name" : "psycon",
      "indices" : [ 0, 7 ],
      "id_str" : "87286054",
      "id" : 87286054
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 76, 96 ],
      "url" : "http://t.co/gnSp6FR7",
      "expanded_url" : "http://www.clker.com/cliparts/9/6/0/5/1194983927973663421io_anthony_liekens_01.svg.med.png",
      "display_url" : "clker.com/cliparts/9/6/0\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "217603320116805633",
  "geo" : {
  },
  "id_str" : "217609842037227520",
  "in_reply_to_user_id" : 87286054,
  "text" : "@psycon ich finde wir k\u00F6nnen das lassen, es weis auch keine wo das herkommt http://t.co/gnSp6FR7 aber alles wissen es ist ein Power-Knopf",
  "id" : 217609842037227520,
  "in_reply_to_status_id" : 217603320116805633,
  "created_at" : "Tue Jun 26 13:26:43 +0000 2012",
  "in_reply_to_screen_name" : "psycon",
  "in_reply_to_user_id_str" : "87286054",
  "user" : {
    "name" : "Felix",
    "screen_name" : "nicidienase",
    "protected" : false,
    "id_str" : "22396883",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3125784966/8223a4c5c9535be22d15c82ec829c2df_normal.jpeg",
    "id" : 22396883,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.echofon.com/\" rel=\"nofollow\">Echofon</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "psy",
      "screen_name" : "psycon",
      "indices" : [ 0, 7 ],
      "id_str" : "87286054",
      "id" : 87286054
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "217602736504582144",
  "geo" : {
  },
  "id_str" : "217602851625648131",
  "in_reply_to_user_id" : 87286054,
  "text" : "@psycon hast du ne sch\u00F6ne Alternative?",
  "id" : 217602851625648131,
  "in_reply_to_status_id" : 217602736504582144,
  "created_at" : "Tue Jun 26 12:58:57 +0000 2012",
  "in_reply_to_screen_name" : "psycon",
  "in_reply_to_user_id_str" : "87286054",
  "user" : {
    "name" : "Felix",
    "screen_name" : "nicidienase",
    "protected" : false,
    "id_str" : "22396883",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3125784966/8223a4c5c9535be22d15c82ec829c2df_normal.jpeg",
    "id" : 22396883,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.echofon.com/\" rel=\"nofollow\">Echofon</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Christopher Lauer",
      "screen_name" : "Schmidtlepp",
      "indices" : [ 3, 15 ],
      "id_str" : "59085146",
      "id" : 59085146
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "217602635719647233",
  "text" : "RT @Schmidtlepp: Deine Mutter betreibt einen legalen Streamingdienst f\u00FCr Kinofilme.",
  "retweeted_status" : {
    "source" : "<a href=\"http://tapbots.com/tweetbot\" rel=\"nofollow\">Tweetbot for iOS</a>",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : {
    },
    "id_str" : "217601968003231745",
    "text" : "Deine Mutter betreibt einen legalen Streamingdienst f\u00FCr Kinofilme.",
    "id" : 217601968003231745,
    "created_at" : "Tue Jun 26 12:55:26 +0000 2012",
    "user" : {
      "name" : "Christopher Lauer",
      "screen_name" : "Schmidtlepp",
      "protected" : false,
      "id_str" : "59085146",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/2102411967/TwitterAvatar3_normal.jpg",
      "id" : 59085146,
      "verified" : true
    }
  },
  "id" : 217602635719647233,
  "created_at" : "Tue Jun 26 12:58:05 +0000 2012",
  "user" : {
    "name" : "Felix",
    "screen_name" : "nicidienase",
    "protected" : false,
    "id_str" : "22396883",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3125784966/8223a4c5c9535be22d15c82ec829c2df_normal.jpeg",
    "id" : 22396883,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http://twitter.com/nicidienase/status/217377872560660480/photo/1",
      "indices" : [ 7, 27 ],
      "url" : "http://t.co/txMb0d1K",
      "media_url" : "http://pbs.twimg.com/media/AwRIBfxCIAAIEFg.jpg",
      "id_str" : "217377872564854784",
      "id" : 217377872564854784,
      "media_url_https" : "https://pbs.twimg.com/media/AwRIBfxCIAAIEFg.jpg",
      "sizes" : [ {
        "h" : 1365,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 453,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 800,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 2048,
        "resize" : "fit",
        "w" : 1536
      } ],
      "display_url" : "pic.twitter.com/txMb0d1K"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 49.0120166, 8.4449281 ]
  },
  "id_str" : "217377872560660480",
  "text" : "Prost! http://t.co/txMb0d1K",
  "id" : 217377872560660480,
  "created_at" : "Mon Jun 25 22:04:59 +0000 2012",
  "user" : {
    "name" : "Felix",
    "screen_name" : "nicidienase",
    "protected" : false,
    "id_str" : "22396883",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3125784966/8223a4c5c9535be22d15c82ec829c2df_normal.jpeg",
    "id" : 22396883,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Andy",
      "screen_name" : "Phrewfuf",
      "indices" : [ 3, 12 ],
      "id_str" : "412582922",
      "id" : 412582922
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "godblessamerica",
      "indices" : [ 53, 69 ]
    } ],
    "urls" : [ {
      "indices" : [ 32, 52 ],
      "url" : "http://t.co/O5KfnmqK",
      "expanded_url" : "http://www.youtube.com/watch?v=ul4CZrnEFxU&feature=player_embedded",
      "display_url" : "youtube.com/watch?v=ul4CZr\u2026"
    } ]
  },
  "geo" : {
  },
  "id_str" : "217363086699528192",
  "text" : "RT @Phrewfuf: My kind of movie: http://t.co/O5KfnmqK #godblessamerica",
  "retweeted_status" : {
    "source" : "web",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "godblessamerica",
        "indices" : [ 39, 55 ]
      } ],
      "urls" : [ {
        "indices" : [ 18, 38 ],
        "url" : "http://t.co/O5KfnmqK",
        "expanded_url" : "http://www.youtube.com/watch?v=ul4CZrnEFxU&feature=player_embedded",
        "display_url" : "youtube.com/watch?v=ul4CZr\u2026"
      } ]
    },
    "geo" : {
    },
    "id_str" : "217175228479053825",
    "text" : "My kind of movie: http://t.co/O5KfnmqK #godblessamerica",
    "id" : 217175228479053825,
    "created_at" : "Mon Jun 25 08:39:44 +0000 2012",
    "user" : {
      "name" : "Andy",
      "screen_name" : "Phrewfuf",
      "protected" : false,
      "id_str" : "412582922",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/1639315193/me_normal.jpg",
      "id" : 412582922,
      "verified" : false
    }
  },
  "id" : 217363086699528192,
  "created_at" : "Mon Jun 25 21:06:12 +0000 2012",
  "user" : {
    "name" : "Felix",
    "screen_name" : "nicidienase",
    "protected" : false,
    "id_str" : "22396883",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3125784966/8223a4c5c9535be22d15c82ec829c2df_normal.jpeg",
    "id" : 22396883,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.echofon.com/\" rel=\"nofollow\">Echofon</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lore Frost",
      "screen_name" : "Lobot",
      "indices" : [ 3, 9 ],
      "id_str" : "1492631",
      "id" : 1492631
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 56, 76 ],
      "url" : "http://t.co/0bPIujyw",
      "expanded_url" : "http://bit.ly/OklAfE",
      "display_url" : "bit.ly/OklAfE"
    } ]
  },
  "geo" : {
  },
  "id_str" : "217277908237033472",
  "text" : "RT @Lobot: And this is why Twitter goes down sometimes. http://t.co/0bPIujyw",
  "retweeted_status" : {
    "source" : "<a href=\"http://www.tweetdeck.com\" rel=\"nofollow\">TweetDeck</a>",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 45, 65 ],
        "url" : "http://t.co/0bPIujyw",
        "expanded_url" : "http://bit.ly/OklAfE",
        "display_url" : "bit.ly/OklAfE"
      } ]
    },
    "geo" : {
    },
    "id_str" : "217274016715640833",
    "text" : "And this is why Twitter goes down sometimes. http://t.co/0bPIujyw",
    "id" : 217274016715640833,
    "created_at" : "Mon Jun 25 15:12:17 +0000 2012",
    "user" : {
      "name" : "Lore Frost",
      "screen_name" : "Lobot",
      "protected" : false,
      "id_str" : "1492631",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/1846171052/user_manual_330x330_sw_normal.jpg",
      "id" : 1492631,
      "verified" : false
    }
  },
  "id" : 217277908237033472,
  "created_at" : "Mon Jun 25 15:27:44 +0000 2012",
  "user" : {
    "name" : "Felix",
    "screen_name" : "nicidienase",
    "protected" : false,
    "id_str" : "22396883",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3125784966/8223a4c5c9535be22d15c82ec829c2df_normal.jpeg",
    "id" : 22396883,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.echofon.com/\" rel=\"nofollow\">Echofon</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "psy",
      "screen_name" : "psycon",
      "indices" : [ 0, 7 ],
      "id_str" : "87286054",
      "id" : 87286054
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "217257857215770624",
  "geo" : {
  },
  "id_str" : "217265972363538432",
  "in_reply_to_user_id" : 87286054,
  "text" : "@psycon Niemand hat so Spezialisten wie wir!",
  "id" : 217265972363538432,
  "in_reply_to_status_id" : 217257857215770624,
  "created_at" : "Mon Jun 25 14:40:19 +0000 2012",
  "in_reply_to_screen_name" : "psycon",
  "in_reply_to_user_id_str" : "87286054",
  "user" : {
    "name" : "Felix",
    "screen_name" : "nicidienase",
    "protected" : false,
    "id_str" : "22396883",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3125784966/8223a4c5c9535be22d15c82ec829c2df_normal.jpeg",
    "id" : 22396883,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.echofon.com/\" rel=\"nofollow\">Echofon</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tim Pritlove",
      "screen_name" : "timpritlove",
      "indices" : [ 3, 15 ],
      "id_str" : "11268812",
      "id" : 11268812
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 30, 50 ],
      "url" : "http://t.co/art1XgDO",
      "expanded_url" : "http://wronghands1.wordpress.com/2012/03/01/the-outernet/",
      "display_url" : "wronghands1.wordpress.com/2012/03/01/the\u2026"
    } ]
  },
  "geo" : {
  },
  "id_str" : "217179637363646466",
  "text" : "RT @timpritlove: The Outernet http://t.co/art1XgDO",
  "retweeted_status" : {
    "source" : "<a href=\"http://www.echofon.com/\" rel=\"nofollow\">Echofon</a>",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 13, 33 ],
        "url" : "http://t.co/art1XgDO",
        "expanded_url" : "http://wronghands1.wordpress.com/2012/03/01/the-outernet/",
        "display_url" : "wronghands1.wordpress.com/2012/03/01/the\u2026"
      } ]
    },
    "geo" : {
    },
    "id_str" : "217178679007125504",
    "text" : "The Outernet http://t.co/art1XgDO",
    "id" : 217178679007125504,
    "created_at" : "Mon Jun 25 08:53:26 +0000 2012",
    "user" : {
      "name" : "Tim Pritlove",
      "screen_name" : "timpritlove",
      "protected" : false,
      "id_str" : "11268812",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/2332275606/Tim_Pritlove_2009_Avatar_512x512_normal.jpg",
      "id" : 11268812,
      "verified" : true
    }
  },
  "id" : 217179637363646466,
  "created_at" : "Mon Jun 25 08:57:15 +0000 2012",
  "user" : {
    "name" : "Felix",
    "screen_name" : "nicidienase",
    "protected" : false,
    "id_str" : "22396883",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3125784966/8223a4c5c9535be22d15c82ec829c2df_normal.jpeg",
    "id" : 22396883,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "216671985911078912",
  "geo" : {
  },
  "id_str" : "216828386876727297",
  "in_reply_to_user_id" : 20689932,
  "text" : "@Geruhn Die geh\u00F6ren auf den Bildschirm hintendrauf. An der Handablage sind die ziemlich schnell abgenutzt.",
  "id" : 216828386876727297,
  "in_reply_to_status_id" : 216671985911078912,
  "created_at" : "Sun Jun 24 09:41:30 +0000 2012",
  "in_reply_to_screen_name" : "keinGeruhn",
  "in_reply_to_user_id_str" : "20689932",
  "user" : {
    "name" : "Felix",
    "screen_name" : "nicidienase",
    "protected" : false,
    "id_str" : "22396883",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3125784966/8223a4c5c9535be22d15c82ec829c2df_normal.jpeg",
    "id" : 22396883,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "eFrane",
      "screen_name" : "eFrane",
      "indices" : [ 3, 10 ],
      "id_str" : "18114946",
      "id" : 18114946
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 70, 90 ],
      "url" : "http://t.co/Ax2PCD49",
      "expanded_url" : "http://twitter.com/eFrane/status/216572529433772032/photo/1",
      "display_url" : "pic.twitter.com/Ax2PCD49"
    } ]
  },
  "geo" : {
  },
  "id_str" : "216637659039285248",
  "text" : "RT @eFrane: Sehr viel Liebe f\u00FCr das Urban Dictionary Word of the Day. http://t.co/Ax2PCD49",
  "retweeted_status" : {
    "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "http://twitter.com/eFrane/status/216572529433772032/photo/1",
        "indices" : [ 58, 78 ],
        "url" : "http://t.co/Ax2PCD49",
        "media_url" : "http://pbs.twimg.com/media/AwFrkW1CAAI-YGE.jpg",
        "id_str" : "216572529437966338",
        "id" : 216572529437966338,
        "media_url_https" : "https://pbs.twimg.com/media/AwFrkW1CAAI-YGE.jpg",
        "sizes" : [ {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 900,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 510,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 960,
          "resize" : "fit",
          "w" : 640
        }, {
          "h" : 960,
          "resize" : "fit",
          "w" : 640
        } ],
        "display_url" : "pic.twitter.com/Ax2PCD49"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : {
    },
    "id_str" : "216572529433772032",
    "text" : "Sehr viel Liebe f\u00FCr das Urban Dictionary Word of the Day. http://t.co/Ax2PCD49",
    "id" : 216572529433772032,
    "created_at" : "Sat Jun 23 16:44:50 +0000 2012",
    "user" : {
      "name" : "eFrane",
      "screen_name" : "eFrane",
      "protected" : false,
      "id_str" : "18114946",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/2220045505/avatar_normal.png",
      "id" : 18114946,
      "verified" : false
    }
  },
  "id" : 216637659039285248,
  "created_at" : "Sat Jun 23 21:03:37 +0000 2012",
  "user" : {
    "name" : "Felix",
    "screen_name" : "nicidienase",
    "protected" : false,
    "id_str" : "22396883",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3125784966/8223a4c5c9535be22d15c82ec829c2df_normal.jpeg",
    "id" : 22396883,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Bildverbrennung",
      "indices" : [ 0, 16 ]
    }, {
      "text" : "Karlsruhe",
      "indices" : [ 20, 30 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "216486328475467777",
  "text" : "#Bildverbrennung in #Karlsruhe anyone??",
  "id" : 216486328475467777,
  "created_at" : "Sat Jun 23 11:02:17 +0000 2012",
  "user" : {
    "name" : "Felix",
    "screen_name" : "nicidienase",
    "protected" : false,
    "id_str" : "22396883",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3125784966/8223a4c5c9535be22d15c82ec829c2df_normal.jpeg",
    "id" : 22396883,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ninette Cumberbatch",
      "screen_name" : "halbbluthobbit",
      "indices" : [ 3, 18 ],
      "id_str" : "21881850",
      "id" : 21881850
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "216320170774364161",
  "text" : "RT @halbbluthobbit: MORGEN IST ERST WENN ICH GESCHLAFEN HABE.",
  "retweeted_status" : {
    "source" : "<a href=\"http://www.tweetdeck.com\" rel=\"nofollow\">TweetDeck</a>",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : {
    },
    "id_str" : "216305396711829504",
    "text" : "MORGEN IST ERST WENN ICH GESCHLAFEN HABE.",
    "id" : 216305396711829504,
    "created_at" : "Fri Jun 22 23:03:19 +0000 2012",
    "user" : {
      "name" : "Ninette Cumberbatch",
      "screen_name" : "halbbluthobbit",
      "protected" : false,
      "id_str" : "21881850",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/3479752892/4903bf91e5b6b08234ec158ef9c77b68_normal.jpeg",
      "id" : 21881850,
      "verified" : false
    }
  },
  "id" : 216320170774364161,
  "created_at" : "Sat Jun 23 00:02:02 +0000 2012",
  "user" : {
    "name" : "Felix",
    "screen_name" : "nicidienase",
    "protected" : false,
    "id_str" : "22396883",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3125784966/8223a4c5c9535be22d15c82ec829c2df_normal.jpeg",
    "id" : 22396883,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.echofon.com/\" rel=\"nofollow\">Echofon</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tim Weber",
      "screen_name" : "scy",
      "indices" : [ 3, 7 ],
      "id_str" : "8308632",
      "id" : 8308632
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "216118636182638593",
  "text" : "RT @scy: OR: \u00BBMillionen Menschen machen keine Commits!\u00AB Schreib dich nicht ab. Lern coden und Git. ;)",
  "retweeted_status" : {
    "source" : "<a href=\"http://www.tweetdeck.com\" rel=\"nofollow\">TweetDeck</a>",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : {
    },
    "id_str" : "216111276588408832",
    "text" : "OR: \u00BBMillionen Menschen machen keine Commits!\u00AB Schreib dich nicht ab. Lern coden und Git. ;)",
    "id" : 216111276588408832,
    "created_at" : "Fri Jun 22 10:11:58 +0000 2012",
    "user" : {
      "name" : "Tim Weber",
      "screen_name" : "scy",
      "protected" : false,
      "id_str" : "8308632",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/424137519/avatar184_normal.jpg",
      "id" : 8308632,
      "verified" : false
    }
  },
  "id" : 216118636182638593,
  "created_at" : "Fri Jun 22 10:41:12 +0000 2012",
  "user" : {
    "name" : "Felix",
    "screen_name" : "nicidienase",
    "protected" : false,
    "id_str" : "22396883",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3125784966/8223a4c5c9535be22d15c82ec829c2df_normal.jpeg",
    "id" : 22396883,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.echofon.com/\" rel=\"nofollow\">Echofon</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tim Weber",
      "screen_name" : "scy",
      "indices" : [ 3, 7 ],
      "id_str" : "8308632",
      "id" : 8308632
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "216101660353773568",
  "text" : "RT @scy: Zu den grundlegenden Verantwortungen des Lebens geh\u00F6rt, f\u00FCr seine Commits Rede und Antwort zu stehen.",
  "retweeted_status" : {
    "source" : "<a href=\"http://www.tweetdeck.com\" rel=\"nofollow\">TweetDeck</a>",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : {
    },
    "id_str" : "216101412810137600",
    "text" : "Zu den grundlegenden Verantwortungen des Lebens geh\u00F6rt, f\u00FCr seine Commits Rede und Antwort zu stehen.",
    "id" : 216101412810137600,
    "created_at" : "Fri Jun 22 09:32:46 +0000 2012",
    "user" : {
      "name" : "Tim Weber",
      "screen_name" : "scy",
      "protected" : false,
      "id_str" : "8308632",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/424137519/avatar184_normal.jpg",
      "id" : 8308632,
      "verified" : false
    }
  },
  "id" : 216101660353773568,
  "created_at" : "Fri Jun 22 09:33:45 +0000 2012",
  "user" : {
    "name" : "Felix",
    "screen_name" : "nicidienase",
    "protected" : false,
    "id_str" : "22396883",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3125784966/8223a4c5c9535be22d15c82ec829c2df_normal.jpeg",
    "id" : 22396883,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.echofon.com/\" rel=\"nofollow\">Echofon</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Vlic",
      "screen_name" : "Vliconaleash",
      "indices" : [ 3, 16 ],
      "id_str" : "189078088",
      "id" : 189078088
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "twistori",
      "indices" : [ 18, 27 ]
    }, {
      "text" : "arse",
      "indices" : [ 28, 33 ]
    } ],
    "urls" : [ {
      "indices" : [ 34, 54 ],
      "url" : "http://t.co/exEzvC56",
      "expanded_url" : "http://twitter.com/Vliconaleash/status/216099814335713280/photo/1",
      "display_url" : "pic.twitter.com/exEzvC56"
    } ]
  },
  "geo" : {
  },
  "id_str" : "216101286381240321",
  "text" : "RT @Vliconaleash: #twistori #arse http://t.co/exEzvC56",
  "retweeted_status" : {
    "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "http://twitter.com/Vliconaleash/status/216099814335713280/photo/1",
        "indices" : [ 16, 36 ],
        "url" : "http://t.co/exEzvC56",
        "media_url" : "http://pbs.twimg.com/media/Av-9ot3CEAAWqR8.jpg",
        "id_str" : "216099814339907584",
        "id" : 216099814339907584,
        "media_url_https" : "https://pbs.twimg.com/media/Av-9ot3CEAAWqR8.jpg",
        "sizes" : [ {
          "h" : 605,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 1823,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 1068,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 2592,
          "resize" : "fit",
          "w" : 1456
        } ],
        "display_url" : "pic.twitter.com/exEzvC56"
      } ],
      "hashtags" : [ {
        "text" : "twistori",
        "indices" : [ 0, 9 ]
      }, {
        "text" : "arse",
        "indices" : [ 10, 15 ]
      } ],
      "urls" : [ ]
    },
    "geo" : {
    },
    "id_str" : "216099814335713280",
    "text" : "#twistori #arse http://t.co/exEzvC56",
    "id" : 216099814335713280,
    "created_at" : "Fri Jun 22 09:26:26 +0000 2012",
    "user" : {
      "name" : "Vlic",
      "screen_name" : "Vliconaleash",
      "protected" : false,
      "id_str" : "189078088",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/3247473459/0fdc40c4eadec3ef25a5718adcc1c924_normal.jpeg",
      "id" : 189078088,
      "verified" : false
    }
  },
  "id" : 216101286381240321,
  "created_at" : "Fri Jun 22 09:32:16 +0000 2012",
  "user" : {
    "name" : "Felix",
    "screen_name" : "nicidienase",
    "protected" : false,
    "id_str" : "22396883",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3125784966/8223a4c5c9535be22d15c82ec829c2df_normal.jpeg",
    "id" : 22396883,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "WarFrog",
      "screen_name" : "WarFrog123",
      "indices" : [ 0, 11 ],
      "id_str" : "604042793",
      "id" : 604042793
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "215180845374382080",
  "geo" : {
  },
  "id_str" : "215181167895388161",
  "in_reply_to_user_id" : 604042793,
  "text" : "@WarFrog123 Da regnets aber.",
  "id" : 215181167895388161,
  "in_reply_to_status_id" : 215180845374382080,
  "created_at" : "Tue Jun 19 20:36:02 +0000 2012",
  "in_reply_to_screen_name" : "WarFrog123",
  "in_reply_to_user_id_str" : "604042793",
  "user" : {
    "name" : "Felix",
    "screen_name" : "nicidienase",
    "protected" : false,
    "id_str" : "22396883",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3125784966/8223a4c5c9535be22d15c82ec829c2df_normal.jpeg",
    "id" : 22396883,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "psy",
      "screen_name" : "psycon",
      "indices" : [ 0, 7 ],
      "id_str" : "87286054",
      "id" : 87286054
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "215165273181925376",
  "geo" : {
  },
  "id_str" : "215168016244150272",
  "in_reply_to_user_id" : 87286054,
  "text" : "@psycon Da reicht der Platz bei uns in der Wohnung nicht.Der braucht leider schon ein bissl mehr Platz als ein Zimmer um gescheit zu fliegen",
  "id" : 215168016244150272,
  "in_reply_to_status_id" : 215165273181925376,
  "created_at" : "Tue Jun 19 19:43:47 +0000 2012",
  "in_reply_to_screen_name" : "psycon",
  "in_reply_to_user_id_str" : "87286054",
  "user" : {
    "name" : "Felix",
    "screen_name" : "nicidienase",
    "protected" : false,
    "id_str" : "22396883",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3125784966/8223a4c5c9535be22d15c82ec829c2df_normal.jpeg",
    "id" : 22396883,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http://twitter.com/nicidienase/status/215164615728967680/photo/1",
      "indices" : [ 58, 78 ],
      "url" : "http://t.co/qGp5pqsG",
      "media_url" : "http://pbs.twimg.com/media/AvxrE_kCMAAG9Iz.jpg",
      "id_str" : "215164615733161984",
      "id" : 215164615733161984,
      "media_url_https" : "https://pbs.twimg.com/media/AvxrE_kCMAAG9Iz.jpg",
      "sizes" : [ {
        "h" : 1365,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 453,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 800,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 2048,
        "resize" : "fit",
        "w" : 1536
      } ],
      "display_url" : "pic.twitter.com/qGp5pqsG"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "215164615728967680",
  "text" : "Arg, neues Spielzeug ist da und das Wetter spielt net mit http://t.co/qGp5pqsG",
  "id" : 215164615728967680,
  "created_at" : "Tue Jun 19 19:30:18 +0000 2012",
  "user" : {
    "name" : "Felix",
    "screen_name" : "nicidienase",
    "protected" : false,
    "id_str" : "22396883",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3125784966/8223a4c5c9535be22d15c82ec829c2df_normal.jpeg",
    "id" : 22396883,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://instagram.com\" rel=\"nofollow\">Instagram</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 22, 42 ],
      "url" : "http://t.co/45IdwXCy",
      "expanded_url" : "http://instagr.am/p/L8xpUxl0e6/",
      "display_url" : "instagr.am/p/L8xpUxl0e6/"
    } ]
  },
  "geo" : {
  },
  "id_str" : "214105425082195970",
  "text" : "Brownies sind im Ofen http://t.co/45IdwXCy",
  "id" : 214105425082195970,
  "created_at" : "Sat Jun 16 21:21:25 +0000 2012",
  "user" : {
    "name" : "Felix",
    "screen_name" : "nicidienase",
    "protected" : false,
    "id_str" : "22396883",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3125784966/8223a4c5c9535be22d15c82ec829c2df_normal.jpeg",
    "id" : 22396883,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://instagram.com\" rel=\"nofollow\">Instagram</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 28, 48 ],
      "url" : "http://t.co/kNAGo1v1",
      "expanded_url" : "http://instagr.am/p/L7zvl0l0Z3/",
      "display_url" : "instagr.am/p/L7zvl0l0Z3/"
    } ]
  },
  "geo" : {
  },
  "id_str" : "213969315886678017",
  "text" : "Gerade ein Foto hochgeladen http://t.co/kNAGo1v1",
  "id" : 213969315886678017,
  "created_at" : "Sat Jun 16 12:20:34 +0000 2012",
  "user" : {
    "name" : "Felix",
    "screen_name" : "nicidienase",
    "protected" : false,
    "id_str" : "22396883",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3125784966/8223a4c5c9535be22d15c82ec829c2df_normal.jpeg",
    "id" : 22396883,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Timo A. Hummel",
      "screen_name" : "_felicitus",
      "indices" : [ 3, 14 ],
      "id_str" : "107309554",
      "id" : 107309554
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "213962557273292801",
  "text" : "RT @_felicitus: \"RZL ist die neue Ma\u00DFeinheit f\u00FCr Trollierung.\" - \"Wieviel ist ein RZL?\" - \"50 Shackspaces\"",
  "retweeted_status" : {
    "source" : "<a href=\"http://www.bitlbee.org/\" rel=\"nofollow\">BitlBee</a>",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : {
    },
    "id_str" : "213669645859815424",
    "text" : "\"RZL ist die neue Ma\u00DFeinheit f\u00FCr Trollierung.\" - \"Wieviel ist ein RZL?\" - \"50 Shackspaces\"",
    "id" : 213669645859815424,
    "created_at" : "Fri Jun 15 16:29:48 +0000 2012",
    "user" : {
      "name" : "Timo A. Hummel",
      "screen_name" : "_felicitus",
      "protected" : false,
      "id_str" : "107309554",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/1785069176/test2_normal.jpeg",
      "id" : 107309554,
      "verified" : false
    }
  },
  "id" : 213962557273292801,
  "created_at" : "Sat Jun 16 11:53:43 +0000 2012",
  "user" : {
    "name" : "Felix",
    "screen_name" : "nicidienase",
    "protected" : false,
    "id_str" : "22396883",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3125784966/8223a4c5c9535be22d15c82ec829c2df_normal.jpeg",
    "id" : 22396883,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://getspaz.com\" rel=\"nofollow\">Spaz HD for webOS</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "medienmagazin",
      "screen_name" : "medienmagazin",
      "indices" : [ 3, 17 ],
      "id_str" : "14408711",
      "id" : 14408711
    }, {
      "name" : "ZDF",
      "screen_name" : "ZDF",
      "indices" : [ 32, 36 ],
      "id_str" : "57350105",
      "id" : 57350105
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "b",
      "indices" : [ 134, 136 ]
    } ],
    "urls" : [ {
      "indices" : [ 113, 133 ],
      "url" : "http://t.co/AggAMkxW",
      "expanded_url" : "http://youtu.be/1pvPHdQK4Mw",
      "display_url" : "youtu.be/1pvPHdQK4Mw"
    } ]
  },
  "geo" : {
  },
  "id_str" : "213747148615979008",
  "text" : "RT @medienmagazin: Einmalig! RT @ZDF \"Aus der Serie Historische Momente, die man nicht so oft zu sehen bekommt.\" http://t.co/AggAMkxW #b ...",
  "retweeted_status" : {
    "source" : "<a href=\"http://itunes.apple.com/us/app/twitter/id409789998?mt=12\" rel=\"nofollow\">Twitter for Mac</a>",
    "entities" : {
      "user_mentions" : [ {
        "name" : "ZDF",
        "screen_name" : "ZDF",
        "indices" : [ 13, 17 ],
        "id_str" : "57350105",
        "id" : 57350105
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "betreuungsgeld",
        "indices" : [ 115, 130 ]
      } ],
      "urls" : [ {
        "indices" : [ 94, 114 ],
        "url" : "http://t.co/AggAMkxW",
        "expanded_url" : "http://youtu.be/1pvPHdQK4Mw",
        "display_url" : "youtu.be/1pvPHdQK4Mw"
      } ]
    },
    "geo" : {
    },
    "id_str" : "213739142062936064",
    "text" : "Einmalig! RT @ZDF \"Aus der Serie Historische Momente, die man nicht so oft zu sehen bekommt.\" http://t.co/AggAMkxW #betreuungsgeld",
    "id" : 213739142062936064,
    "created_at" : "Fri Jun 15 21:05:57 +0000 2012",
    "user" : {
      "name" : "medienmagazin",
      "screen_name" : "medienmagazin",
      "protected" : false,
      "id_str" : "14408711",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/52872044/MM_normal.jpg",
      "id" : 14408711,
      "verified" : false
    }
  },
  "id" : 213747148615979008,
  "created_at" : "Fri Jun 15 21:37:46 +0000 2012",
  "user" : {
    "name" : "Felix",
    "screen_name" : "nicidienase",
    "protected" : false,
    "id_str" : "22396883",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3125784966/8223a4c5c9535be22d15c82ec829c2df_normal.jpeg",
    "id" : 22396883,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://getspaz.com\" rel=\"nofollow\">Spaz HD for webOS</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "RaumZeitLudwigshafen",
      "screen_name" : "RZLudwigshafen",
      "indices" : [ 3, 18 ],
      "id_str" : "605828591",
      "id" : 605828591
    }, {
      "name" : "RZLFlagge",
      "screen_name" : "RZLFlagge",
      "indices" : [ 27, 37 ],
      "id_str" : "606214353",
      "id" : 606214353
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 54, 74 ],
      "url" : "http://t.co/a3aywKkP",
      "expanded_url" : "http://twitter.com/RZLudwigshafen/status/213686139486343170/photo/1",
      "display_url" : "pic.twitter.com/a3aywKkP"
    } ]
  },
  "geo" : {
  },
  "id_str" : "213732061847109633",
  "text" : "RT @RZLudwigshafen: Unsere @RZLFlagge wird bedroht!!! http://t.co/a3aywKkP",
  "retweeted_status" : {
    "source" : "web",
    "entities" : {
      "user_mentions" : [ {
        "name" : "RZLFlagge",
        "screen_name" : "RZLFlagge",
        "indices" : [ 7, 17 ],
        "id_str" : "606214353",
        "id" : 606214353
      } ],
      "media" : [ {
        "expanded_url" : "http://twitter.com/RZLudwigshafen/status/213686139486343170/photo/1",
        "indices" : [ 34, 54 ],
        "url" : "http://t.co/a3aywKkP",
        "media_url" : "http://pbs.twimg.com/media/AvcqaWXCEAAOI6x.jpg",
        "id_str" : "213686139490537472",
        "id" : 213686139490537472,
        "media_url_https" : "https://pbs.twimg.com/media/AvcqaWXCEAAOI6x.jpg",
        "sizes" : [ {
          "h" : 1059,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 2048,
          "resize" : "fit",
          "w" : 1980
        }, {
          "h" : 621,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 352,
          "resize" : "fit",
          "w" : 340
        } ],
        "display_url" : "pic.twitter.com/a3aywKkP"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : {
    },
    "id_str" : "213686139486343170",
    "text" : "Unsere @RZLFlagge wird bedroht!!! http://t.co/a3aywKkP",
    "id" : 213686139486343170,
    "created_at" : "Fri Jun 15 17:35:21 +0000 2012",
    "user" : {
      "name" : "RaumZeitLudwigshafen",
      "screen_name" : "RZLudwigshafen",
      "protected" : false,
      "id_str" : "605828591",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/2300140968/z65fu2metgm1jl2rrutq_normal.png",
      "id" : 605828591,
      "verified" : false
    }
  },
  "id" : 213732061847109633,
  "created_at" : "Fri Jun 15 20:37:49 +0000 2012",
  "user" : {
    "name" : "Felix",
    "screen_name" : "nicidienase",
    "protected" : false,
    "id_str" : "22396883",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3125784966/8223a4c5c9535be22d15c82ec829c2df_normal.jpeg",
    "id" : 22396883,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.echofon.com/\" rel=\"nofollow\">Echofon</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "vertipperdestages",
      "indices" : [ 0, 18 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "213555556655448064",
  "text" : "#vertipperdestages \"git stash poop\"",
  "id" : 213555556655448064,
  "created_at" : "Fri Jun 15 08:56:27 +0000 2012",
  "user" : {
    "name" : "Felix",
    "screen_name" : "nicidienase",
    "protected" : false,
    "id_str" : "22396883",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3125784966/8223a4c5c9535be22d15c82ec829c2df_normal.jpeg",
    "id" : 22396883,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.echofon.com/\" rel=\"nofollow\">Echofon</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tobias Kral",
      "screen_name" : "Inte",
      "indices" : [ 3, 8 ],
      "id_str" : "7606562",
      "id" : 7606562
    }, {
      "name" : "RZLFlagge",
      "screen_name" : "RZLFlagge",
      "indices" : [ 102, 112 ],
      "id_str" : "606214353",
      "id" : 606214353
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "GPN12",
      "indices" : [ 122, 128 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "213551934718754816",
  "text" : "RT @Inte: H\u00E4tte erwartet, dass die @RZLKueche oder der @RZLKuehlschrank anf\u00E4ngt zu twittern; aber die @RZLFlagge? Geheime #GPN12-Experim ...",
  "retweeted_status" : {
    "source" : "<a href=\"http://twicca.r246.jp/\" rel=\"nofollow\">twicca</a>",
    "entities" : {
      "user_mentions" : [ {
        "name" : "RZLFlagge",
        "screen_name" : "RZLFlagge",
        "indices" : [ 92, 102 ],
        "id_str" : "606214353",
        "id" : 606214353
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "GPN12",
        "indices" : [ 112, 118 ]
      } ],
      "urls" : [ ]
    },
    "geo" : {
    },
    "id_str" : "213547444464652288",
    "text" : "H\u00E4tte erwartet, dass die @RZLKueche oder der @RZLKuehlschrank anf\u00E4ngt zu twittern; aber die @RZLFlagge? Geheime #GPN12-Experimente?",
    "id" : 213547444464652288,
    "created_at" : "Fri Jun 15 08:24:12 +0000 2012",
    "user" : {
      "name" : "Tobias Kral",
      "screen_name" : "Inte",
      "protected" : false,
      "id_str" : "7606562",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/283332186/gillian_anderson-_rolling_stone_1997-avatar-2_normal.png",
      "id" : 7606562,
      "verified" : false
    }
  },
  "id" : 213551934718754816,
  "created_at" : "Fri Jun 15 08:42:03 +0000 2012",
  "user" : {
    "name" : "Felix",
    "screen_name" : "nicidienase",
    "protected" : false,
    "id_str" : "22396883",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3125784966/8223a4c5c9535be22d15c82ec829c2df_normal.jpeg",
    "id" : 22396883,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.echofon.com/\" rel=\"nofollow\">Echofon</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "$(RandomName)",
      "screen_name" : "Ik4ru5",
      "indices" : [ 0, 7 ],
      "id_str" : "48294441",
      "id" : 48294441
    }, {
      "name" : "psy",
      "screen_name" : "psycon",
      "indices" : [ 8, 15 ],
      "id_str" : "87286054",
      "id" : 87286054
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "213521528267087872",
  "geo" : {
  },
  "id_str" : "213539807224279041",
  "in_reply_to_user_id" : 48294441,
  "text" : "@Ik4ru5 @psycon Hackercamp klingt immer gut!",
  "id" : 213539807224279041,
  "in_reply_to_status_id" : 213521528267087872,
  "created_at" : "Fri Jun 15 07:53:52 +0000 2012",
  "in_reply_to_screen_name" : "Ik4ru5",
  "in_reply_to_user_id_str" : "48294441",
  "user" : {
    "name" : "Felix",
    "screen_name" : "nicidienase",
    "protected" : false,
    "id_str" : "22396883",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3125784966/8223a4c5c9535be22d15c82ec829c2df_normal.jpeg",
    "id" : 22396883,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.echofon.com/\" rel=\"nofollow\">Echofon</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "astrodicticum",
      "screen_name" : "astrodicticum",
      "indices" : [ 3, 17 ],
      "id_str" : "15318271",
      "id" : 15318271
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "213538984914194433",
  "text" : "RT @astrodicticum: 9j\u00E4hrige schreibt Blog \u00FCber Essen in der Schule. Politiker sorgen daf\u00FCr, dass es eingestellt werden muss: http://t.co ...",
  "retweeted_status" : {
    "source" : "<a href=\"http://www.tweetdeck.com\" rel=\"nofollow\">TweetDeck</a>",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 106, 126 ],
        "url" : "http://t.co/ZXqh1khE",
        "expanded_url" : "http://is.gd/KcMM7v",
        "display_url" : "is.gd/KcMM7v"
      } ]
    },
    "geo" : {
    },
    "id_str" : "213511238142013440",
    "text" : "9j\u00E4hrige schreibt Blog \u00FCber Essen in der Schule. Politiker sorgen daf\u00FCr, dass es eingestellt werden muss: http://t.co/ZXqh1khE",
    "id" : 213511238142013440,
    "created_at" : "Fri Jun 15 06:00:20 +0000 2012",
    "user" : {
      "name" : "astrodicticum",
      "screen_name" : "astrodicticum",
      "protected" : false,
      "id_str" : "15318271",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/2690897782/419cc0193b5bdc2b6abc6b374a2ce383_normal.jpeg",
      "id" : 15318271,
      "verified" : false
    }
  },
  "id" : 213538984914194433,
  "created_at" : "Fri Jun 15 07:50:36 +0000 2012",
  "user" : {
    "name" : "Felix",
    "screen_name" : "nicidienase",
    "protected" : false,
    "id_str" : "22396883",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3125784966/8223a4c5c9535be22d15c82ec829c2df_normal.jpeg",
    "id" : 22396883,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.echofon.com/\" rel=\"nofollow\">Echofon</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "psy",
      "screen_name" : "psycon",
      "indices" : [ 0, 7 ],
      "id_str" : "87286054",
      "id" : 87286054
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "213267289619959808",
  "geo" : {
  },
  "id_str" : "213269462932135939",
  "in_reply_to_user_id" : 87286054,
  "text" : "@psycon Ich glaub das was wir brauchen nennt sich in der Textilfachsprache Faden, nicht Schnur.",
  "id" : 213269462932135939,
  "in_reply_to_status_id" : 213267289619959808,
  "created_at" : "Thu Jun 14 13:59:36 +0000 2012",
  "in_reply_to_screen_name" : "psycon",
  "in_reply_to_user_id_str" : "87286054",
  "user" : {
    "name" : "Felix",
    "screen_name" : "nicidienase",
    "protected" : false,
    "id_str" : "22396883",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3125784966/8223a4c5c9535be22d15c82ec829c2df_normal.jpeg",
    "id" : 22396883,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://getspaz.com\" rel=\"nofollow\">Spaz HD for webOS</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "P.J.",
      "screen_name" : "BubuHose",
      "indices" : [ 3, 12 ],
      "id_str" : "393469193",
      "id" : 393469193
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "212976988800024577",
  "text" : "RT @BubuHose: \"Eis.de? Bestellst Du Dein Eis jetzt echt auch noch im Internet?!\" - \"Ja, Mama.\"",
  "retweeted_status" : {
    "source" : "web",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : {
    },
    "id_str" : "212635684828217345",
    "text" : "\"Eis.de? Bestellst Du Dein Eis jetzt echt auch noch im Internet?!\" - \"Ja, Mama.\"",
    "id" : 212635684828217345,
    "created_at" : "Tue Jun 12 20:01:12 +0000 2012",
    "user" : {
      "name" : "P.J.",
      "screen_name" : "BubuHose",
      "protected" : false,
      "id_str" : "393469193",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/3400856978/b2d4e68b0f55bf4a1a85fea71dbaa232_normal.jpeg",
      "id" : 393469193,
      "verified" : false
    }
  },
  "id" : 212976988800024577,
  "created_at" : "Wed Jun 13 18:37:25 +0000 2012",
  "user" : {
    "name" : "Felix",
    "screen_name" : "nicidienase",
    "protected" : false,
    "id_str" : "22396883",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3125784966/8223a4c5c9535be22d15c82ec829c2df_normal.jpeg",
    "id" : 22396883,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.echofon.com/\" rel=\"nofollow\">Echofon</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Various Artist",
      "screen_name" : "kaiNpardon",
      "indices" : [ 3, 14 ],
      "id_str" : "148475466",
      "id" : 148475466
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "212940184772296704",
  "text" : "RT @kaiNpardon: \"Quelle: Internet.\" (Quelle: Fernsehen)",
  "retweeted_status" : {
    "source" : "<a href=\"http://www.hootsuite.com\" rel=\"nofollow\">HootSuite</a>",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : {
    },
    "id_str" : "212933557641945089",
    "text" : "\"Quelle: Internet.\" (Quelle: Fernsehen)",
    "id" : 212933557641945089,
    "created_at" : "Wed Jun 13 15:44:50 +0000 2012",
    "user" : {
      "name" : "Various Artist",
      "screen_name" : "kaiNpardon",
      "protected" : false,
      "id_str" : "148475466",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/2349512638/ctry1td59mwf75autq76_normal.jpeg",
      "id" : 148475466,
      "verified" : false
    }
  },
  "id" : 212940184772296704,
  "created_at" : "Wed Jun 13 16:11:10 +0000 2012",
  "user" : {
    "name" : "Felix",
    "screen_name" : "nicidienase",
    "protected" : false,
    "id_str" : "22396883",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3125784966/8223a4c5c9535be22d15c82ec829c2df_normal.jpeg",
    "id" : 22396883,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.echofon.com/\" rel=\"nofollow\">Echofon</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tim Weber",
      "screen_name" : "scy",
      "indices" : [ 3, 7 ],
      "id_str" : "8308632",
      "id" : 8308632
    }, {
      "name" : "*m",
      "screen_name" : "lumibots",
      "indices" : [ 51, 60 ],
      "id_str" : "284042510",
      "id" : 284042510
    }, {
      "name" : "Niklas Roy",
      "screen_name" : "royrobotiks",
      "indices" : [ 61, 73 ],
      "id_str" : "323185275",
      "id" : 323185275
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 25, 45 ],
      "url" : "http://t.co/nsPyGEfn",
      "expanded_url" : "http://www.pointerpointer.com/",
      "display_url" : "pointerpointer.com"
    } ]
  },
  "geo" : {
  },
  "id_str" : "212903950037417984",
  "text" : "RT @scy: Ist. Das. Geil. http://t.co/nsPyGEfn (via @lumibots @royrobotiks)",
  "retweeted_status" : {
    "source" : "<a href=\"http://www.tweetdeck.com\" rel=\"nofollow\">TweetDeck</a>",
    "entities" : {
      "user_mentions" : [ {
        "name" : "*m",
        "screen_name" : "lumibots",
        "indices" : [ 42, 51 ],
        "id_str" : "284042510",
        "id" : 284042510
      }, {
        "name" : "Niklas Roy",
        "screen_name" : "royrobotiks",
        "indices" : [ 52, 64 ],
        "id_str" : "323185275",
        "id" : 323185275
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 16, 36 ],
        "url" : "http://t.co/nsPyGEfn",
        "expanded_url" : "http://www.pointerpointer.com/",
        "display_url" : "pointerpointer.com"
      } ]
    },
    "geo" : {
    },
    "id_str" : "212892432923238401",
    "text" : "Ist. Das. Geil. http://t.co/nsPyGEfn (via @lumibots @royrobotiks)",
    "id" : 212892432923238401,
    "created_at" : "Wed Jun 13 13:01:26 +0000 2012",
    "user" : {
      "name" : "Tim Weber",
      "screen_name" : "scy",
      "protected" : false,
      "id_str" : "8308632",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/424137519/avatar184_normal.jpg",
      "id" : 8308632,
      "verified" : false
    }
  },
  "id" : 212903950037417984,
  "created_at" : "Wed Jun 13 13:47:11 +0000 2012",
  "user" : {
    "name" : "Felix",
    "screen_name" : "nicidienase",
    "protected" : false,
    "id_str" : "22396883",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3125784966/8223a4c5c9535be22d15c82ec829c2df_normal.jpeg",
    "id" : 22396883,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.echofon.com/\" rel=\"nofollow\">Echofon</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Charles",
      "screen_name" : "Hirnschnipsel",
      "indices" : [ 3, 17 ],
      "id_str" : "226782876",
      "id" : 226782876
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "212892188529541121",
  "text" : "RT @Hirnschnipsel: Woran Du merkst, dass die Frau Humor hat? Wenn Sie  nach dem Sex sagt \"Ded\u00FCmm, Hardware kann jetzt sicher entfernt we ...",
  "retweeted_status" : {
    "source" : "<a href=\"http://www.tweetdeck.com\" rel=\"nofollow\">TweetDeck</a>",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : {
    },
    "id_str" : "41895656662642688",
    "text" : "Woran Du merkst, dass die Frau Humor hat? Wenn Sie  nach dem Sex sagt \"Ded\u00FCmm, Hardware kann jetzt sicher entfernt werden\"",
    "id" : 41895656662642688,
    "created_at" : "Sun Feb 27 16:21:17 +0000 2011",
    "user" : {
      "name" : "Charles",
      "screen_name" : "Hirnschnipsel",
      "protected" : false,
      "id_str" : "226782876",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/2729664478/58f07035a6ba84b78de571678c1f9ec4_normal.jpeg",
      "id" : 226782876,
      "verified" : false
    }
  },
  "id" : 212892188529541121,
  "created_at" : "Wed Jun 13 13:00:27 +0000 2012",
  "user" : {
    "name" : "Felix",
    "screen_name" : "nicidienase",
    "protected" : false,
    "id_str" : "22396883",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3125784966/8223a4c5c9535be22d15c82ec829c2df_normal.jpeg",
    "id" : 22396883,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://getspaz.com\" rel=\"nofollow\">Spaz HD for webOS</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "pfleidi",
      "screen_name" : "pfleidi",
      "indices" : [ 3, 11 ],
      "id_str" : "15647796",
      "id" : 15647796
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "lol",
      "indices" : [ 44, 48 ]
    } ],
    "urls" : [ {
      "indices" : [ 22, 42 ],
      "url" : "http://t.co/QTMR6Bzj",
      "expanded_url" : "http://maps.apple.com",
      "display_url" : "maps.apple.com"
    } ]
  },
  "geo" : {
  },
  "id_str" : "212685483384373249",
  "text" : "RT @pfleidi: `curl -I http://t.co/QTMR6Bzj` #lol",
  "retweeted_status" : {
    "source" : "<a href=\"http://www.echofon.com/\" rel=\"nofollow\">Echofon</a>",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "lol",
        "indices" : [ 31, 35 ]
      } ],
      "urls" : [ {
        "indices" : [ 9, 29 ],
        "url" : "http://t.co/QTMR6Bzj",
        "expanded_url" : "http://maps.apple.com",
        "display_url" : "maps.apple.com"
      } ]
    },
    "geo" : {
    },
    "id_str" : "212644721451991040",
    "text" : "`curl -I http://t.co/QTMR6Bzj` #lol",
    "id" : 212644721451991040,
    "created_at" : "Tue Jun 12 20:37:07 +0000 2012",
    "user" : {
      "name" : "pfleidi",
      "screen_name" : "pfleidi",
      "protected" : false,
      "id_str" : "15647796",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/2992339395/7f60afee5ffff6e961831ba8d07d0850_normal.png",
      "id" : 15647796,
      "verified" : false
    }
  },
  "id" : 212685483384373249,
  "created_at" : "Tue Jun 12 23:19:05 +0000 2012",
  "user" : {
    "name" : "Felix",
    "screen_name" : "nicidienase",
    "protected" : false,
    "id_str" : "22396883",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3125784966/8223a4c5c9535be22d15c82ec829c2df_normal.jpeg",
    "id" : 22396883,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.echofon.com/\" rel=\"nofollow\">Echofon</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "cupe",
      "screen_name" : "cupe_cupe",
      "indices" : [ 0, 10 ],
      "id_str" : "143922800",
      "id" : 143922800
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "beiwasauchimmer",
      "indices" : [ 24, 40 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "212528479407845376",
  "geo" : {
  },
  "id_str" : "212528703241060353",
  "in_reply_to_user_id" : 143922800,
  "text" : "@cupe_cupe Viel Erfolg! #beiwasauchimmer",
  "id" : 212528703241060353,
  "in_reply_to_status_id" : 212528479407845376,
  "created_at" : "Tue Jun 12 12:56:06 +0000 2012",
  "in_reply_to_screen_name" : "cupe_cupe",
  "in_reply_to_user_id_str" : "143922800",
  "user" : {
    "name" : "Felix",
    "screen_name" : "nicidienase",
    "protected" : false,
    "id_str" : "22396883",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3125784966/8223a4c5c9535be22d15c82ec829c2df_normal.jpeg",
    "id" : 22396883,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://getspaz.com\" rel=\"nofollow\">Spaz HD for webOS</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "mmmmh",
      "indices" : [ 68, 74 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "212271145737650176",
  "text" : "Brownies aus dem Ofen geholt, ganze Wohnung riecht nach Schokolade. #mmmmh",
  "id" : 212271145737650176,
  "created_at" : "Mon Jun 11 19:52:39 +0000 2012",
  "user" : {
    "name" : "Felix",
    "screen_name" : "nicidienase",
    "protected" : false,
    "id_str" : "22396883",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3125784966/8223a4c5c9535be22d15c82ec829c2df_normal.jpeg",
    "id" : 22396883,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://getspaz.com\" rel=\"nofollow\">Spaz HD for webOS</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Not Safe For Work",
      "screen_name" : "me_nsfw",
      "indices" : [ 34, 42 ],
      "id_str" : "198895800",
      "id" : 198895800
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "212255938479013888",
  "text" : "Gerade die Brownies nach original @me_nsfw -Rezept in den Ofen geschoben. Bin gespannt auf das Ergebniss.",
  "id" : 212255938479013888,
  "created_at" : "Mon Jun 11 18:52:13 +0000 2012",
  "user" : {
    "name" : "Felix",
    "screen_name" : "nicidienase",
    "protected" : false,
    "id_str" : "22396883",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3125784966/8223a4c5c9535be22d15c82ec829c2df_normal.jpeg",
    "id" : 22396883,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://getspaz.com\" rel=\"nofollow\">Spaz HD for webOS</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Eva Eichhorn",
      "screen_name" : "MamsellChaos",
      "indices" : [ 0, 13 ],
      "id_str" : "140774041",
      "id" : 140774041
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "211742930904420352",
  "geo" : {
  },
  "id_str" : "211744923689549824",
  "in_reply_to_user_id" : 140774041,
  "text" : "@MamsellChaos twitter doch einfach, das verstehn wahrscheinlich mehr Leute.",
  "id" : 211744923689549824,
  "in_reply_to_status_id" : 211742930904420352,
  "created_at" : "Sun Jun 10 09:01:38 +0000 2012",
  "in_reply_to_screen_name" : "MamsellChaos",
  "in_reply_to_user_id_str" : "140774041",
  "user" : {
    "name" : "Felix",
    "screen_name" : "nicidienase",
    "protected" : false,
    "id_str" : "22396883",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3125784966/8223a4c5c9535be22d15c82ec829c2df_normal.jpeg",
    "id" : 22396883,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://getspaz.com\" rel=\"nofollow\">Spaz HD for webOS</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "fengor",
      "screen_name" : "fengor",
      "indices" : [ 3, 10 ],
      "id_str" : "14121643",
      "id" : 14121643
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "gpn12",
      "indices" : [ 12, 18 ]
    }, {
      "text" : "em2012",
      "indices" : [ 24, 31 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "211709023467216896",
  "text" : "RT @fengor: #gpn12 &gt; #em2012",
  "retweeted_status" : {
    "source" : "web",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "gpn12",
        "indices" : [ 0, 6 ]
      }, {
        "text" : "em2012",
        "indices" : [ 12, 19 ]
      } ],
      "urls" : [ ]
    },
    "geo" : {
    },
    "id_str" : "211552176487661569",
    "text" : "#gpn12 &gt; #em2012",
    "id" : 211552176487661569,
    "created_at" : "Sat Jun 09 20:15:43 +0000 2012",
    "user" : {
      "name" : "fengor",
      "screen_name" : "fengor",
      "protected" : false,
      "id_str" : "14121643",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/1137897799/fengor_small_normal.png",
      "id" : 14121643,
      "verified" : false
    }
  },
  "id" : 211709023467216896,
  "created_at" : "Sun Jun 10 06:38:59 +0000 2012",
  "user" : {
    "name" : "Felix",
    "screen_name" : "nicidienase",
    "protected" : false,
    "id_str" : "22396883",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3125784966/8223a4c5c9535be22d15c82ec829c2df_normal.jpeg",
    "id" : 22396883,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://getspaz.com\" rel=\"nofollow\">Spaz HD for webOS</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "h0uz3",
      "screen_name" : "h0uz3",
      "indices" : [ 3, 9 ],
      "id_str" : "15730216",
      "id" : 15730216
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "gpn12",
      "indices" : [ 47, 53 ]
    } ],
    "urls" : [ {
      "indices" : [ 56, 77 ],
      "url" : "https://t.co/OFnZFstG",
      "expanded_url" : "https://vimeo.com/43741601",
      "display_url" : "vimeo.com/43741601"
    } ]
  },
  "geo" : {
  },
  "id_str" : "211705147531862016",
  "text" : "RT @h0uz3: Search &amp; Rescue Mission auf der #gpn12 : https://t.co/OFnZFstG",
  "retweeted_status" : {
    "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Tweetie for Mac</a>",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "gpn12",
        "indices" : [ 36, 42 ]
      } ],
      "urls" : [ {
        "indices" : [ 45, 66 ],
        "url" : "https://t.co/OFnZFstG",
        "expanded_url" : "https://vimeo.com/43741601",
        "display_url" : "vimeo.com/43741601"
      } ]
    },
    "geo" : {
    },
    "id_str" : "211627380698132480",
    "text" : "Search &amp; Rescue Mission auf der #gpn12 : https://t.co/OFnZFstG",
    "id" : 211627380698132480,
    "created_at" : "Sun Jun 10 01:14:34 +0000 2012",
    "user" : {
      "name" : "h0uz3",
      "screen_name" : "h0uz3",
      "protected" : false,
      "id_str" : "15730216",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/1511702544/myPony_normal.png",
      "id" : 15730216,
      "verified" : false
    }
  },
  "id" : 211705147531862016,
  "created_at" : "Sun Jun 10 06:23:35 +0000 2012",
  "user" : {
    "name" : "Felix",
    "screen_name" : "nicidienase",
    "protected" : false,
    "id_str" : "22396883",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3125784966/8223a4c5c9535be22d15c82ec829c2df_normal.jpeg",
    "id" : 22396883,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://getspaz.com\" rel=\"nofollow\">Spaz</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "GPN12",
      "indices" : [ 36, 42 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "211644791975448576",
  "text" : "Awesome, Doctor Who Dubstep auf der #GPN12",
  "id" : 211644791975448576,
  "created_at" : "Sun Jun 10 02:23:45 +0000 2012",
  "user" : {
    "name" : "Felix",
    "screen_name" : "nicidienase",
    "protected" : false,
    "id_str" : "22396883",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3125784966/8223a4c5c9535be22d15c82ec829c2df_normal.jpeg",
    "id" : 22396883,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://getspaz.com\" rel=\"nofollow\">Spaz HD for webOS</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "cr",
      "screen_name" : "p4ula",
      "indices" : [ 3, 9 ],
      "id_str" : "18506162",
      "id" : 18506162
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "GPN12",
      "indices" : [ 98, 104 ]
    } ],
    "urls" : [ {
      "indices" : [ 77, 97 ],
      "url" : "http://t.co/HnVZfWPJ",
      "expanded_url" : "http://youtu.be/aA9lc_7_tww",
      "display_url" : "youtu.be/aA9lc_7_tww"
    } ]
  },
  "geo" : {
  },
  "id_str" : "211272661265952770",
  "text" : "RT @p4ula: Non-Newtonian fluid made from starch and water, filmed at 320fps: http://t.co/HnVZfWPJ #GPN12",
  "retweeted_status" : {
    "source" : "<a href=\"http://www.tweetdeck.com\" rel=\"nofollow\">TweetDeck</a>",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "GPN12",
        "indices" : [ 87, 93 ]
      } ],
      "urls" : [ {
        "indices" : [ 66, 86 ],
        "url" : "http://t.co/HnVZfWPJ",
        "expanded_url" : "http://youtu.be/aA9lc_7_tww",
        "display_url" : "youtu.be/aA9lc_7_tww"
      } ]
    },
    "geo" : {
    },
    "id_str" : "211101682870927361",
    "text" : "Non-Newtonian fluid made from starch and water, filmed at 320fps: http://t.co/HnVZfWPJ #GPN12",
    "id" : 211101682870927361,
    "created_at" : "Fri Jun 08 14:25:37 +0000 2012",
    "user" : {
      "name" : "cr",
      "screen_name" : "p4ula",
      "protected" : false,
      "id_str" : "18506162",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/1763694644/f-pentomino-titanium_normal.png",
      "id" : 18506162,
      "verified" : false
    }
  },
  "id" : 211272661265952770,
  "created_at" : "Sat Jun 09 01:45:02 +0000 2012",
  "user" : {
    "name" : "Felix",
    "screen_name" : "nicidienase",
    "protected" : false,
    "id_str" : "22396883",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3125784966/8223a4c5c9535be22d15c82ec829c2df_normal.jpeg",
    "id" : 22396883,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://getspaz.com\" rel=\"nofollow\">Spaz HD for webOS</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Golem.de",
      "screen_name" : "GolemRedaktion",
      "indices" : [ 3, 18 ],
      "id_str" : "19454998",
      "id" : 19454998
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "gpn12",
      "indices" : [ 60, 66 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "211026230521249792",
  "text" : "RT @GolemRedaktion: Aus Solidarit\u00E4t mit den Teilnehmern der #gpn12 gibt es bei uns heute Gulasch! Linux-Kollege J\u00F6rg Thoma kocht. http:/ ...",
  "retweeted_status" : {
    "source" : "<a href=\"http://www.hootsuite.com\" rel=\"nofollow\">HootSuite</a>",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "gpn12",
        "indices" : [ 40, 46 ]
      } ],
      "urls" : [ {
        "indices" : [ 110, 130 ],
        "url" : "http://t.co/3lFr5ZJ7",
        "expanded_url" : "http://ow.ly/i/GkZt",
        "display_url" : "ow.ly/i/GkZt"
      } ]
    },
    "geo" : {
    },
    "id_str" : "211024690993577984",
    "text" : "Aus Solidarit\u00E4t mit den Teilnehmern der #gpn12 gibt es bei uns heute Gulasch! Linux-Kollege J\u00F6rg Thoma kocht. http://t.co/3lFr5ZJ7 (sha)",
    "id" : 211024690993577984,
    "created_at" : "Fri Jun 08 09:19:41 +0000 2012",
    "user" : {
      "name" : "Golem.de",
      "screen_name" : "GolemRedaktion",
      "protected" : false,
      "id_str" : "19454998",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/1341239197/golem-twitter-q_normal.png",
      "id" : 19454998,
      "verified" : true
    }
  },
  "id" : 211026230521249792,
  "created_at" : "Fri Jun 08 09:25:48 +0000 2012",
  "user" : {
    "name" : "Felix",
    "screen_name" : "nicidienase",
    "protected" : false,
    "id_str" : "22396883",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3125784966/8223a4c5c9535be22d15c82ec829c2df_normal.jpeg",
    "id" : 22396883,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://getspaz.com\" rel=\"nofollow\">Spaz</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "GPN12",
      "indices" : [ 8, 14 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "210687030198403073",
  "text" : "Auf zur #GPN12 !!!",
  "id" : 210687030198403073,
  "created_at" : "Thu Jun 07 10:57:57 +0000 2012",
  "user" : {
    "name" : "Felix",
    "screen_name" : "nicidienase",
    "protected" : false,
    "id_str" : "22396883",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3125784966/8223a4c5c9535be22d15c82ec829c2df_normal.jpeg",
    "id" : 22396883,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://getspaz.com\" rel=\"nofollow\">Spaz HD for webOS</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "i3 wm",
      "screen_name" : "i3wm",
      "indices" : [ 3, 8 ],
      "id_str" : "203048497",
      "id" : 203048497
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "i3wm",
      "indices" : [ 125, 130 ]
    }, {
      "text" : "gpn",
      "indices" : [ 131, 135 ]
    } ],
    "urls" : [ {
      "indices" : [ 43, 63 ],
      "url" : "http://t.co/K4iEk8F8",
      "expanded_url" : "http://gulas.ch/",
      "display_url" : "gulas.ch"
    } ]
  },
  "geo" : {
  },
  "id_str" : "210506049231396866",
  "text" : "RT @i3wm: i3 devs will be at the excellent http://t.co/K4iEk8F8 in Karlsruhe starting from tomorrow. Ask us for i3 stickers! #i3wm #gpn",
  "retweeted_status" : {
    "source" : "web",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "i3wm",
        "indices" : [ 115, 120 ]
      }, {
        "text" : "gpn",
        "indices" : [ 121, 125 ]
      } ],
      "urls" : [ {
        "indices" : [ 33, 53 ],
        "url" : "http://t.co/K4iEk8F8",
        "expanded_url" : "http://gulas.ch/",
        "display_url" : "gulas.ch"
      } ]
    },
    "geo" : {
    },
    "id_str" : "210472916301791232",
    "text" : "i3 devs will be at the excellent http://t.co/K4iEk8F8 in Karlsruhe starting from tomorrow. Ask us for i3 stickers! #i3wm #gpn",
    "id" : 210472916301791232,
    "created_at" : "Wed Jun 06 20:47:08 +0000 2012",
    "user" : {
      "name" : "i3 wm",
      "screen_name" : "i3wm",
      "protected" : false,
      "id_str" : "203048497",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/1145449163/logo_normal.png",
      "id" : 203048497,
      "verified" : false
    }
  },
  "id" : 210506049231396866,
  "created_at" : "Wed Jun 06 22:58:47 +0000 2012",
  "user" : {
    "name" : "Felix",
    "screen_name" : "nicidienase",
    "protected" : false,
    "id_str" : "22396883",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3125784966/8223a4c5c9535be22d15c82ec829c2df_normal.jpeg",
    "id" : 22396883,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://getspaz.com\" rel=\"nofollow\">Spaz</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "210448520078049280",
  "text" : "Grade auf Firefox13 geupdated. Wie lange haben die jetzt f\u00FCr 10 Versionsnummern gebraucht? Das war doch grade n Jahr oder so.",
  "id" : 210448520078049280,
  "created_at" : "Wed Jun 06 19:10:11 +0000 2012",
  "user" : {
    "name" : "Felix",
    "screen_name" : "nicidienase",
    "protected" : false,
    "id_str" : "22396883",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3125784966/8223a4c5c9535be22d15c82ec829c2df_normal.jpeg",
    "id" : 22396883,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.echofon.com/\" rel=\"nofollow\">Echofon</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ribo",
      "screen_name" : "Hoerns",
      "indices" : [ 0, 7 ],
      "id_str" : "271594126",
      "id" : 271594126
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "210390422760079362",
  "geo" : {
  },
  "id_str" : "210391792556851200",
  "in_reply_to_user_id" : 271594126,
  "text" : "@Hoerns Switche stehn an den Tischen normalerweise genug rum, nur keine Kabel zum einstecken und da reicht im normalfall schon 1m",
  "id" : 210391792556851200,
  "in_reply_to_status_id" : 210390422760079362,
  "created_at" : "Wed Jun 06 15:24:46 +0000 2012",
  "in_reply_to_screen_name" : "Hoerns",
  "in_reply_to_user_id_str" : "271594126",
  "user" : {
    "name" : "Felix",
    "screen_name" : "nicidienase",
    "protected" : false,
    "id_str" : "22396883",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3125784966/8223a4c5c9535be22d15c82ec829c2df_normal.jpeg",
    "id" : 22396883,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.echofon.com/\" rel=\"nofollow\">Echofon</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ribo",
      "screen_name" : "Hoerns",
      "indices" : [ 0, 7 ],
      "id_str" : "271594126",
      "id" : 271594126
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "210387859016908800",
  "geo" : {
  },
  "id_str" : "210389930596237314",
  "in_reply_to_user_id" : 271594126,
  "text" : "@Hoerns Also LAN-Kabel brauchst du sicher und ein eigener Mehrfachstecker schadet nie.",
  "id" : 210389930596237314,
  "in_reply_to_status_id" : 210387859016908800,
  "created_at" : "Wed Jun 06 15:17:22 +0000 2012",
  "in_reply_to_screen_name" : "Hoerns",
  "in_reply_to_user_id_str" : "271594126",
  "user" : {
    "name" : "Felix",
    "screen_name" : "nicidienase",
    "protected" : false,
    "id_str" : "22396883",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3125784966/8223a4c5c9535be22d15c82ec829c2df_normal.jpeg",
    "id" : 22396883,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://getspaz.com\" rel=\"nofollow\">Spaz</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "210134528109449217",
  "text" : "\"Wir leben heute schon im morgen von gestern\"",
  "id" : 210134528109449217,
  "created_at" : "Tue Jun 05 22:22:30 +0000 2012",
  "user" : {
    "name" : "Felix",
    "screen_name" : "nicidienase",
    "protected" : false,
    "id_str" : "22396883",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3125784966/8223a4c5c9535be22d15c82ec829c2df_normal.jpeg",
    "id" : 22396883,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://getspaz.com\" rel=\"nofollow\">Spaz HD for webOS</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Holger Klein",
      "screen_name" : "holgi",
      "indices" : [ 5, 11 ],
      "id_str" : "3068271",
      "id" : 3068271
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "210131863765925888",
  "text" : "Wenn @holgi nen Bier&amp;Burger-Replikator neben dem Bett hat wird er doch zu Jabba the Hutt.",
  "id" : 210131863765925888,
  "created_at" : "Tue Jun 05 22:11:55 +0000 2012",
  "user" : {
    "name" : "Felix",
    "screen_name" : "nicidienase",
    "protected" : false,
    "id_str" : "22396883",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3125784966/8223a4c5c9535be22d15c82ec829c2df_normal.jpeg",
    "id" : 22396883,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://getspaz.com\" rel=\"nofollow\">Spaz HD for webOS</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Hilgi",
      "screen_name" : "hilgi",
      "indices" : [ 1, 7 ],
      "id_str" : "19795507",
      "id" : 19795507
    }, {
      "name" : "Not Safe For Work",
      "screen_name" : "me_nsfw",
      "indices" : [ 42, 50 ],
      "id_str" : "198895800",
      "id" : 198895800
    }, {
      "name" : "Holger Klein",
      "screen_name" : "holgi",
      "indices" : [ 74, 80 ],
      "id_str" : "3068271",
      "id" : 3068271
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "210118694163058688",
  "text" : ".@hilgi im Radio in der K\u00FCche und ich hab @me_nsfw auf den Ohren, zweimal @holgi iritiert.",
  "id" : 210118694163058688,
  "created_at" : "Tue Jun 05 21:19:35 +0000 2012",
  "user" : {
    "name" : "Felix",
    "screen_name" : "nicidienase",
    "protected" : false,
    "id_str" : "22396883",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3125784966/8223a4c5c9535be22d15c82ec829c2df_normal.jpeg",
    "id" : 22396883,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.echofon.com/\" rel=\"nofollow\">Echofon</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Scientific Python",
      "screen_name" : "SciPyTip",
      "indices" : [ 3, 12 ],
      "id_str" : "254791849",
      "id" : 254791849
    }, {
      "name" : "Tim Hopper",
      "screen_name" : "tdhopper",
      "indices" : [ 58, 67 ],
      "id_str" : "89249164",
      "id" : 89249164
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 33, 53 ],
      "url" : "http://t.co/HC1YPHqW",
      "expanded_url" : "http://ow.ly/bmrKf",
      "display_url" : "ow.ly/bmrKf"
    } ]
  },
  "geo" : {
  },
  "id_str" : "209956493280280577",
  "text" : "RT @SciPyTip: Cool Python tricks http://t.co/HC1YPHqW via @tdhopper",
  "retweeted_status" : {
    "source" : "<a href=\"http://www.hootsuite.com\" rel=\"nofollow\">HootSuite</a>",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Tim Hopper",
        "screen_name" : "tdhopper",
        "indices" : [ 44, 53 ],
        "id_str" : "89249164",
        "id" : 89249164
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 19, 39 ],
        "url" : "http://t.co/HC1YPHqW",
        "expanded_url" : "http://ow.ly/bmrKf",
        "display_url" : "ow.ly/bmrKf"
      } ]
    },
    "geo" : {
    },
    "id_str" : "209837442155548672",
    "text" : "Cool Python tricks http://t.co/HC1YPHqW via @tdhopper",
    "id" : 209837442155548672,
    "created_at" : "Tue Jun 05 02:41:59 +0000 2012",
    "user" : {
      "name" : "Scientific Python",
      "screen_name" : "SciPyTip",
      "protected" : false,
      "id_str" : "254791849",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/1249386397/sp_white_on_blue_normal.png",
      "id" : 254791849,
      "verified" : false
    }
  },
  "id" : 209956493280280577,
  "created_at" : "Tue Jun 05 10:35:03 +0000 2012",
  "user" : {
    "name" : "Felix",
    "screen_name" : "nicidienase",
    "protected" : false,
    "id_str" : "22396883",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3125784966/8223a4c5c9535be22d15c82ec829c2df_normal.jpeg",
    "id" : 22396883,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://getspaz.com\" rel=\"nofollow\">Spaz HD for webOS</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "GPN12",
      "indices" : [ 78, 84 ]
    } ],
    "urls" : [ {
      "indices" : [ 91, 111 ],
      "url" : "http://t.co/Ub9yi6ST",
      "expanded_url" : "http://j.mp/NdowZB",
      "display_url" : "j.mp/NdowZB"
    } ]
  },
  "geo" : {
  },
  "id_str" : "209809715142725632",
  "text" : "Bei uns is noch ein bisschen Platz falls jemand noch ne Schlafm\u00F6glichkeit zur #GPN12 sucht http://t.co/Ub9yi6ST",
  "id" : 209809715142725632,
  "created_at" : "Tue Jun 05 00:51:48 +0000 2012",
  "user" : {
    "name" : "Felix",
    "screen_name" : "nicidienase",
    "protected" : false,
    "id_str" : "22396883",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3125784966/8223a4c5c9535be22d15c82ec829c2df_normal.jpeg",
    "id" : 22396883,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://getspaz.com\" rel=\"nofollow\">Spaz</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Alice",
      "screen_name" : "AliceVanWunder",
      "indices" : [ 3, 18 ],
      "id_str" : "93172226",
      "id" : 93172226
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "209767641232064512",
  "text" : "RT @AliceVanWunder: Sex ist besser, wenn man ihn nicht allein hat.",
  "retweeted_status" : {
    "source" : "<a href=\"http://www.tweetdeck.com\" rel=\"nofollow\">TweetDeck</a>",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : {
    },
    "id_str" : "209760367843348481",
    "text" : "Sex ist besser, wenn man ihn nicht allein hat.",
    "id" : 209760367843348481,
    "created_at" : "Mon Jun 04 21:35:43 +0000 2012",
    "user" : {
      "name" : "Alice",
      "screen_name" : "AliceVanWunder",
      "protected" : false,
      "id_str" : "93172226",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/3298783441/9a0e4f0328a4efd6b5d89a03c67f7b54_normal.jpeg",
      "id" : 93172226,
      "verified" : false
    }
  },
  "id" : 209767641232064512,
  "created_at" : "Mon Jun 04 22:04:37 +0000 2012",
  "user" : {
    "name" : "Felix",
    "screen_name" : "nicidienase",
    "protected" : false,
    "id_str" : "22396883",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3125784966/8223a4c5c9535be22d15c82ec829c2df_normal.jpeg",
    "id" : 22396883,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.echofon.com/\" rel=\"nofollow\">Echofon</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "209657524939534336",
  "geo" : {
  },
  "id_str" : "209669763469811713",
  "in_reply_to_user_id" : 237439292,
  "text" : "@Fluoreszent_Rot Die sind da alle ganz nett und bei\u00DFen auch net. Brauchst keine Angst haben.",
  "id" : 209669763469811713,
  "in_reply_to_status_id" : 209657524939534336,
  "created_at" : "Mon Jun 04 15:35:41 +0000 2012",
  "in_reply_to_screen_name" : "_fluoreszent",
  "in_reply_to_user_id_str" : "237439292",
  "user" : {
    "name" : "Felix",
    "screen_name" : "nicidienase",
    "protected" : false,
    "id_str" : "22396883",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3125784966/8223a4c5c9535be22d15c82ec829c2df_normal.jpeg",
    "id" : 22396883,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.echofon.com/\" rel=\"nofollow\">Echofon</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "psy",
      "screen_name" : "psycon",
      "indices" : [ 45, 52 ],
      "id_str" : "87286054",
      "id" : 87286054
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "GPN12",
      "indices" : [ 79, 85 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "209668297166290946",
  "text" : "Und dann vier Tage lang (fast) gar nicht RT: @psycon: Nur noch 3 Mal schlafen! #GPN12",
  "id" : 209668297166290946,
  "created_at" : "Mon Jun 04 15:29:52 +0000 2012",
  "user" : {
    "name" : "Felix",
    "screen_name" : "nicidienase",
    "protected" : false,
    "id_str" : "22396883",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3125784966/8223a4c5c9535be22d15c82ec829c2df_normal.jpeg",
    "id" : 22396883,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.echofon.com/\" rel=\"nofollow\">Echofon</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "neingeist",
      "screen_name" : "neingeist",
      "indices" : [ 0, 10 ],
      "id_str" : "11193712",
      "id" : 11193712
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Viruszombieapokalypse",
      "indices" : [ 25, 47 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "209638508158132224",
  "geo" : {
  },
  "id_str" : "209639674271109120",
  "in_reply_to_user_id" : 11193712,
  "text" : "@neingeist Hei\u00DFt das die #Viruszombieapokalypse zur GPN f\u00E4llt aus?",
  "id" : 209639674271109120,
  "in_reply_to_status_id" : 209638508158132224,
  "created_at" : "Mon Jun 04 13:36:07 +0000 2012",
  "in_reply_to_screen_name" : "neingeist",
  "in_reply_to_user_id_str" : "11193712",
  "user" : {
    "name" : "Felix",
    "screen_name" : "nicidienase",
    "protected" : false,
    "id_str" : "22396883",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3125784966/8223a4c5c9535be22d15c82ec829c2df_normal.jpeg",
    "id" : 22396883,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.echofon.com/\" rel=\"nofollow\">Echofon</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Timo Hetzel",
      "screen_name" : "timohetzel",
      "indices" : [ 3, 14 ],
      "id_str" : "777070",
      "id" : 777070
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "209594021390192641",
  "text" : "RT @timohetzel: Was lebt im Zoo und hat viele Festplatten? Das NAShorn.",
  "retweeted_status" : {
    "source" : "<a href=\"http://itunes.apple.com/us/app/twitter/id409789998?mt=12\" rel=\"nofollow\">Twitter for Mac</a>",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : {
    },
    "id_str" : "208300784989900802",
    "text" : "Was lebt im Zoo und hat viele Festplatten? Das NAShorn.",
    "id" : 208300784989900802,
    "created_at" : "Thu May 31 20:55:51 +0000 2012",
    "user" : {
      "name" : "Timo Hetzel",
      "screen_name" : "timohetzel",
      "protected" : false,
      "id_str" : "777070",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/1800930947/threepwood-transparent_normal.png",
      "id" : 777070,
      "verified" : false
    }
  },
  "id" : 209594021390192641,
  "created_at" : "Mon Jun 04 10:34:43 +0000 2012",
  "user" : {
    "name" : "Felix",
    "screen_name" : "nicidienase",
    "protected" : false,
    "id_str" : "22396883",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3125784966/8223a4c5c9535be22d15c82ec829c2df_normal.jpeg",
    "id" : 22396883,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://getspaz.com\" rel=\"nofollow\">Spaz HD for webOS</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Julian Finn",
      "screen_name" : "hdsjulian",
      "indices" : [ 52, 62 ],
      "id_str" : "12192142",
      "id" : 12192142
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "209118913382973440",
  "text" : "Du nimmst mir den Tweet aus dem Mund/den Fingern RT @hdsjulian Wenn einen die V\u00F6gel mit ihrem gezwitscher vom schlafen abhalten. Orr!",
  "id" : 209118913382973440,
  "created_at" : "Sun Jun 03 03:06:48 +0000 2012",
  "user" : {
    "name" : "Felix",
    "screen_name" : "nicidienase",
    "protected" : false,
    "id_str" : "22396883",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3125784966/8223a4c5c9535be22d15c82ec829c2df_normal.jpeg",
    "id" : 22396883,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://getspaz.com\" rel=\"nofollow\">Spaz HD for webOS</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "betrunkeneerkenntnis",
      "indices" : [ 58, 79 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "209113430014173185",
  "text" : "Das Leben is sch\u00F6ner wenn man jemanden zum kuscheln hat!! #betrunkeneerkenntnis",
  "id" : 209113430014173185,
  "created_at" : "Sun Jun 03 02:45:01 +0000 2012",
  "user" : {
    "name" : "Felix",
    "screen_name" : "nicidienase",
    "protected" : false,
    "id_str" : "22396883",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3125784966/8223a4c5c9535be22d15c82ec829c2df_normal.jpeg",
    "id" : 22396883,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://getspaz.com\" rel=\"nofollow\">Spaz HD for webOS</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "neingeist",
      "screen_name" : "neingeist",
      "indices" : [ 0, 10 ],
      "id_str" : "11193712",
      "id" : 11193712
    }, {
      "name" : "Jack McCrack",
      "screen_name" : "JackMcCrack",
      "indices" : [ 11, 23 ],
      "id_str" : "21289833",
      "id" : 21289833
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "viruszombieapokalypse",
      "indices" : [ 48, 70 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "208618049731960832",
  "geo" : {
  },
  "id_str" : "208633735359377408",
  "in_reply_to_user_id" : 11193712,
  "text" : "@neingeist @jackmccrack Und ins Gulasch husten! #viruszombieapokalypse",
  "id" : 208633735359377408,
  "in_reply_to_status_id" : 208618049731960832,
  "created_at" : "Fri Jun 01 18:58:53 +0000 2012",
  "in_reply_to_screen_name" : "neingeist",
  "in_reply_to_user_id_str" : "11193712",
  "user" : {
    "name" : "Felix",
    "screen_name" : "nicidienase",
    "protected" : false,
    "id_str" : "22396883",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3125784966/8223a4c5c9535be22d15c82ec829c2df_normal.jpeg",
    "id" : 22396883,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://getspaz.com\" rel=\"nofollow\">Spaz HD for webOS</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 0, 20 ],
      "url" : "http://t.co/06zVhEQA",
      "expanded_url" : "http://on3.de",
      "display_url" : "on3.de"
    } ]
  },
  "geo" : {
  },
  "id_str" : "208591692415238145",
  "text" : "http://t.co/06zVhEQA Tenacious D Live!!!",
  "id" : 208591692415238145,
  "created_at" : "Fri Jun 01 16:11:49 +0000 2012",
  "user" : {
    "name" : "Felix",
    "screen_name" : "nicidienase",
    "protected" : false,
    "id_str" : "22396883",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3125784966/8223a4c5c9535be22d15c82ec829c2df_normal.jpeg",
    "id" : 22396883,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://getspaz.com\" rel=\"nofollow\">Spaz</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "208580242376364033",
  "text" : "47 Seiten Kontoausz\u00FCge!! Ich sollte mir angew\u00F6hnen die regelma\u00DFiger abzuholen.",
  "id" : 208580242376364033,
  "created_at" : "Fri Jun 01 15:26:19 +0000 2012",
  "user" : {
    "name" : "Felix",
    "screen_name" : "nicidienase",
    "protected" : false,
    "id_str" : "22396883",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3125784966/8223a4c5c9535be22d15c82ec829c2df_normal.jpeg",
    "id" : 22396883,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.echofon.com/\" rel=\"nofollow\">Echofon</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Eva ",
      "screen_name" : "SchokoPralini",
      "indices" : [ 0, 14 ],
      "id_str" : "575695094",
      "id" : 575695094
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "208571109061296128",
  "geo" : {
  },
  "id_str" : "208571285830254592",
  "in_reply_to_user_id" : 575695094,
  "text" : "@SchokoPralini Ne, morgen is Sommerfest im Hadiko und ich muss mich langsam mal mit meinem Praxissemesterbericht befassen.",
  "id" : 208571285830254592,
  "in_reply_to_status_id" : 208571109061296128,
  "created_at" : "Fri Jun 01 14:50:44 +0000 2012",
  "in_reply_to_screen_name" : "SchokoPralini",
  "in_reply_to_user_id_str" : "575695094",
  "user" : {
    "name" : "Felix",
    "screen_name" : "nicidienase",
    "protected" : false,
    "id_str" : "22396883",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3125784966/8223a4c5c9535be22d15c82ec829c2df_normal.jpeg",
    "id" : 22396883,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.echofon.com/\" rel=\"nofollow\">Echofon</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "208569628786556929",
  "text" : "Sitzen mit Nerf-Gun im B\u00FCro, nebenan patrouillieren Kinder mit gr\u00F6\u00DFeren Nerf-Guns durch die Schreberg\u00E4rten.",
  "id" : 208569628786556929,
  "created_at" : "Fri Jun 01 14:44:09 +0000 2012",
  "user" : {
    "name" : "Felix",
    "screen_name" : "nicidienase",
    "protected" : false,
    "id_str" : "22396883",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3125784966/8223a4c5c9535be22d15c82ec829c2df_normal.jpeg",
    "id" : 22396883,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.echofon.com/\" rel=\"nofollow\">Echofon</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "psy",
      "screen_name" : "psycon",
      "indices" : [ 0, 7 ],
      "id_str" : "87286054",
      "id" : 87286054
    }, {
      "name" : "neingeist",
      "screen_name" : "neingeist",
      "indices" : [ 8, 18 ],
      "id_str" : "11193712",
      "id" : 11193712
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 37, 57 ],
      "url" : "http://t.co/zkkiolcY",
      "expanded_url" : "http://www.der-postillon.com/2009/10/studie-indianer-kennen-doch-schmerz.html",
      "display_url" : "der-postillon.com/2009/10/studie\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "208558555970805762",
  "geo" : {
  },
  "id_str" : "208560300784488449",
  "in_reply_to_user_id" : 87286054,
  "text" : "@psycon @neingeist Stimmt gar nicht! http://t.co/zkkiolcY",
  "id" : 208560300784488449,
  "in_reply_to_status_id" : 208558555970805762,
  "created_at" : "Fri Jun 01 14:07:05 +0000 2012",
  "in_reply_to_screen_name" : "psycon",
  "in_reply_to_user_id_str" : "87286054",
  "user" : {
    "name" : "Felix",
    "screen_name" : "nicidienase",
    "protected" : false,
    "id_str" : "22396883",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3125784966/8223a4c5c9535be22d15c82ec829c2df_normal.jpeg",
    "id" : 22396883,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.echofon.com/\" rel=\"nofollow\">Echofon</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "psy",
      "screen_name" : "psycon",
      "indices" : [ 3, 10 ],
      "id_str" : "87286054",
      "id" : 87286054
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 40, 60 ],
      "url" : "http://t.co/CZOSUUc2",
      "expanded_url" : "http://www.der-postillon.com/2012/06/exklusiv-im-postillon-megan-fox-zeigt.html",
      "display_url" : "der-postillon.com/2012/06/exklus\u2026"
    } ]
  },
  "geo" : {
  },
  "id_str" : "208559899892920320",
  "text" : "RT @psycon: Megan Fox zeigt ihre B\u00FCrste http://t.co/CZOSUUc2",
  "retweeted_status" : {
    "source" : "web",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 28, 48 ],
        "url" : "http://t.co/CZOSUUc2",
        "expanded_url" : "http://www.der-postillon.com/2012/06/exklusiv-im-postillon-megan-fox-zeigt.html",
        "display_url" : "der-postillon.com/2012/06/exklus\u2026"
      } ]
    },
    "geo" : {
    },
    "id_str" : "208559726458445824",
    "text" : "Megan Fox zeigt ihre B\u00FCrste http://t.co/CZOSUUc2",
    "id" : 208559726458445824,
    "created_at" : "Fri Jun 01 14:04:48 +0000 2012",
    "user" : {
      "name" : "psy",
      "screen_name" : "psycon",
      "protected" : false,
      "id_str" : "87286054",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/2620981046/xkjfqh2iy0xp1lxx6cl1_normal.jpeg",
      "id" : 87286054,
      "verified" : false
    }
  },
  "id" : 208559899892920320,
  "created_at" : "Fri Jun 01 14:05:29 +0000 2012",
  "user" : {
    "name" : "Felix",
    "screen_name" : "nicidienase",
    "protected" : false,
    "id_str" : "22396883",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3125784966/8223a4c5c9535be22d15c82ec829c2df_normal.jpeg",
    "id" : 22396883,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.echofon.com/\" rel=\"nofollow\">Echofon</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "neingeist",
      "screen_name" : "neingeist",
      "indices" : [ 0, 10 ],
      "id_str" : "11193712",
      "id" : 11193712
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "GPN12",
      "indices" : [ 87, 93 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "208515299249631232",
  "geo" : {
  },
  "id_str" : "208519486771433472",
  "in_reply_to_user_id" : 11193712,
  "text" : "@neingeist Gute Besserung!! Hoffentlich werdens nicht mehr und du bist rechtzeitig zur #GPN12 wieder drau\u00DFen.",
  "id" : 208519486771433472,
  "in_reply_to_status_id" : 208515299249631232,
  "created_at" : "Fri Jun 01 11:24:54 +0000 2012",
  "in_reply_to_screen_name" : "neingeist",
  "in_reply_to_user_id_str" : "11193712",
  "user" : {
    "name" : "Felix",
    "screen_name" : "nicidienase",
    "protected" : false,
    "id_str" : "22396883",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3125784966/8223a4c5c9535be22d15c82ec829c2df_normal.jpeg",
    "id" : 22396883,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "GPN13 @ HfG",
      "screen_name" : "entropiagpn",
      "indices" : [ 0, 12 ],
      "id_str" : "27639193",
      "id" : 27639193
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "208302651857846272",
  "geo" : {
  },
  "id_str" : "208317271913926658",
  "in_reply_to_user_id" : 27639193,
  "text" : "@entropiagpn Gibts nen Aktuellen Graph?",
  "id" : 208317271913926658,
  "in_reply_to_status_id" : 208302651857846272,
  "created_at" : "Thu May 31 22:01:22 +0000 2012",
  "in_reply_to_screen_name" : "entropiagpn",
  "in_reply_to_user_id_str" : "27639193",
  "user" : {
    "name" : "Felix",
    "screen_name" : "nicidienase",
    "protected" : false,
    "id_str" : "22396883",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3125784966/8223a4c5c9535be22d15c82ec829c2df_normal.jpeg",
    "id" : 22396883,
    "verified" : false
  }
} ]