Grailbird.data.tweets_2012_02 = 
 [ {
  "source" : "<a href=\"http://getspaz.com\" rel=\"nofollow\">Spaz HD for webOS</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "nutellagangbang",
      "screen_name" : "nutellagangbang",
      "indices" : [ 3, 19 ],
      "id_str" : "113119960",
      "id" : 113119960
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 44, 64 ],
      "url" : "http://t.co/jje2Buxj",
      "expanded_url" : "http://twitpic.com/8oz85y",
      "display_url" : "twitpic.com/8oz85y"
    } ]
  },
  "geo" : {
  },
  "id_str" : "173792945403731968",
  "text" : "RT @nutellagangbang: Welcher Vogel ist das? http://t.co/jje2Buxj",
  "retweeted_status" : {
    "source" : "<a href=\"http://twitpic.com\" rel=\"nofollow\">Twitpic</a>",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 23, 43 ],
        "url" : "http://t.co/jje2Buxj",
        "expanded_url" : "http://twitpic.com/8oz85y",
        "display_url" : "twitpic.com/8oz85y"
      } ]
    },
    "geo" : {
    },
    "id_str" : "173770281964404736",
    "text" : "Welcher Vogel ist das? http://t.co/jje2Buxj",
    "id" : 173770281964404736,
    "created_at" : "Sun Feb 26 14:03:58 +0000 2012",
    "user" : {
      "name" : "nutellagangbang",
      "screen_name" : "nutellagangbang",
      "protected" : false,
      "id_str" : "113119960",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/2579893238/bgblzhmwz2eqx2ibytla_normal.jpeg",
      "id" : 113119960,
      "verified" : false
    }
  },
  "id" : 173792945403731968,
  "created_at" : "Sun Feb 26 15:34:01 +0000 2012",
  "user" : {
    "name" : "Felix",
    "screen_name" : "nicidienase",
    "protected" : false,
    "id_str" : "22396883",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3125784966/8223a4c5c9535be22d15c82ec829c2df_normal.jpeg",
    "id" : 22396883,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://getspaz.com\" rel=\"nofollow\">Spaz HD for webOS</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kate H.",
      "screen_name" : "elaoe7",
      "indices" : [ 0, 7 ],
      "id_str" : "149650777",
      "id" : 149650777
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "173393754256982016",
  "geo" : {
  },
  "id_str" : "173412899895775232",
  "in_reply_to_user_id" : 149650777,
  "text" : "@elaoe7 Herzlichen Gl\u00FCckwunsch!!11!!",
  "id" : 173412899895775232,
  "in_reply_to_status_id" : 173393754256982016,
  "created_at" : "Sat Feb 25 14:23:51 +0000 2012",
  "in_reply_to_screen_name" : "elaoe7",
  "in_reply_to_user_id_str" : "149650777",
  "user" : {
    "name" : "Felix",
    "screen_name" : "nicidienase",
    "protected" : false,
    "id_str" : "22396883",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3125784966/8223a4c5c9535be22d15c82ec829c2df_normal.jpeg",
    "id" : 22396883,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://getspaz.com\" rel=\"nofollow\">Spaz HD for webOS</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tim Weber",
      "screen_name" : "Scytale",
      "indices" : [ 3, 11 ],
      "id_str" : "594921016",
      "id" : 594921016
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "173087736939556866",
  "text" : "RT @Scytale: Dieses delikat ausbalancierte Gef\u00FChl zwischen Amoklauf und wiederholtem Kopf-an-die-Wand-schlagen-Wollen kriegt man auch nu ...",
  "retweeted_status" : {
    "source" : "<a href=\"http://www.tweetdeck.com\" rel=\"nofollow\">TweetDeck</a>",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : {
    },
    "id_str" : "173019816523866112",
    "text" : "Dieses delikat ausbalancierte Gef\u00FChl zwischen Amoklauf und wiederholtem Kopf-an-die-Wand-schlagen-Wollen kriegt man auch nur in der IT.",
    "id" : 173019816523866112,
    "created_at" : "Fri Feb 24 12:21:53 +0000 2012",
    "user" : {
      "name" : "Tim Weber",
      "screen_name" : "scy",
      "protected" : false,
      "id_str" : "8308632",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/424137519/avatar184_normal.jpg",
      "id" : 8308632,
      "verified" : false
    }
  },
  "id" : 173087736939556866,
  "created_at" : "Fri Feb 24 16:51:46 +0000 2012",
  "user" : {
    "name" : "Felix",
    "screen_name" : "nicidienase",
    "protected" : false,
    "id_str" : "22396883",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3125784966/8223a4c5c9535be22d15c82ec829c2df_normal.jpeg",
    "id" : 22396883,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://getspaz.com\" rel=\"nofollow\">Spaz HD for webOS</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Carlo Zottmann",
      "screen_name" : "municode",
      "indices" : [ 3, 12 ],
      "id_str" : "63893",
      "id" : 63893
    }, {
      "name" : "Lilly W.",
      "screen_name" : "dielilly",
      "indices" : [ 14, 23 ],
      "id_str" : "19603003",
      "id" : 19603003
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "172815482158710784",
  "text" : "RT @municode: @dielilly \"Wer zuletzt lacht\u2026 hat den Witz bei Facebook gelesen.\"",
  "retweeted_status" : {
    "source" : "<a href=\"http://www.echofon.com/\" rel=\"nofollow\">Echofon</a>",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Lilly W.",
        "screen_name" : "dielilly",
        "indices" : [ 0, 9 ],
        "id_str" : "19603003",
        "id" : 19603003
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "in_reply_to_status_id_str" : "172796028637032448",
    "geo" : {
    },
    "id_str" : "172797007860211712",
    "in_reply_to_user_id" : 19603003,
    "text" : "@dielilly \"Wer zuletzt lacht\u2026 hat den Witz bei Facebook gelesen.\"",
    "id" : 172797007860211712,
    "in_reply_to_status_id" : 172796028637032448,
    "created_at" : "Thu Feb 23 21:36:31 +0000 2012",
    "in_reply_to_screen_name" : "dielilly",
    "in_reply_to_user_id_str" : "19603003",
    "user" : {
      "name" : "Carlo Zottmann",
      "screen_name" : "municode",
      "protected" : false,
      "id_str" : "63893",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/2939498690/dda7d075c81dbb5f943853d5b8cab292_normal.png",
      "id" : 63893,
      "verified" : false
    }
  },
  "id" : 172815482158710784,
  "created_at" : "Thu Feb 23 22:49:56 +0000 2012",
  "user" : {
    "name" : "Felix",
    "screen_name" : "nicidienase",
    "protected" : false,
    "id_str" : "22396883",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3125784966/8223a4c5c9535be22d15c82ec829c2df_normal.jpeg",
    "id" : 22396883,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://getspaz.com\" rel=\"nofollow\">Spaz HD for webOS</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 98, 118 ],
      "url" : "http://t.co/qhCivLFG",
      "expanded_url" : "http://me.lt/6JNcq",
      "display_url" : "me.lt/6JNcq"
    } ]
  },
  "geo" : {
  },
  "id_str" : "172797767507378176",
  "text" : "RT @Geruhn: \"\u201ESexist? Aber du bist doch weiblich? Dann wohl eher SexistIN?\u201C - unterambitioniert - http://t.co/qhCivLFG",
  "retweeted_status" : {
    "source" : "<a href=\"http://rockmelt.com\" rel=\"nofollow\">Rockmelt</a>",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 86, 106 ],
        "url" : "http://t.co/qhCivLFG",
        "expanded_url" : "http://me.lt/6JNcq",
        "display_url" : "me.lt/6JNcq"
      } ]
    },
    "geo" : {
    },
    "id_str" : "172774443171590144",
    "text" : "\"\u201ESexist? Aber du bist doch weiblich? Dann wohl eher SexistIN?\u201C - unterambitioniert - http://t.co/qhCivLFG",
    "id" : 172774443171590144,
    "created_at" : "Thu Feb 23 20:06:51 +0000 2012",
    "user" : {
      "name" : "Andy P.",
      "screen_name" : "keinGeruhn",
      "protected" : false,
      "id_str" : "20689932",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/2532717078/sqf75a6eqiayl7c6idu7_normal.jpeg",
      "id" : 20689932,
      "verified" : false
    }
  },
  "id" : 172797767507378176,
  "created_at" : "Thu Feb 23 21:39:32 +0000 2012",
  "user" : {
    "name" : "Felix",
    "screen_name" : "nicidienase",
    "protected" : false,
    "id_str" : "22396883",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3125784966/8223a4c5c9535be22d15c82ec829c2df_normal.jpeg",
    "id" : 22396883,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://getspaz.com\" rel=\"nofollow\">Spaz HD for webOS</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "yetzt",
      "screen_name" : "yetzt",
      "indices" : [ 3, 9 ],
      "id_str" : "2902401",
      "id" : 2902401
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "172742581640372224",
  "text" : "RT @yetzt: lieber buffer overflausch als kuschel underrun.",
  "retweeted_status" : {
    "source" : "<a href=\"http://www.echofon.com/\" rel=\"nofollow\">Echofon</a>",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : {
    },
    "id_str" : "172425637380882433",
    "text" : "lieber buffer overflausch als kuschel underrun.",
    "id" : 172425637380882433,
    "created_at" : "Wed Feb 22 21:00:50 +0000 2012",
    "user" : {
      "name" : "yetzt",
      "screen_name" : "yetzt",
      "protected" : false,
      "id_str" : "2902401",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/2541812133/qp1r3ec2njl54p8lcsp3_normal.png",
      "id" : 2902401,
      "verified" : false
    }
  },
  "id" : 172742581640372224,
  "created_at" : "Thu Feb 23 18:00:15 +0000 2012",
  "user" : {
    "name" : "Felix",
    "screen_name" : "nicidienase",
    "protected" : false,
    "id_str" : "22396883",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3125784966/8223a4c5c9535be22d15c82ec829c2df_normal.jpeg",
    "id" : 22396883,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://getspaz.com\" rel=\"nofollow\">Spaz HD for webOS</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Gerd Eist",
      "screen_name" : "erdgeist",
      "indices" : [ 3, 12 ],
      "id_str" : "16701619",
      "id" : 16701619
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 23, 43 ],
      "url" : "http://t.co/rQEvQMAq",
      "expanded_url" : "http://blog.fefe.de",
      "display_url" : "blog.fefe.de"
    } ]
  },
  "geo" : {
  },
  "id_str" : "172742168539168768",
  "text" : "RT @erdgeist: Wenn man http://t.co/rQEvQMAq und youporn aufhat, hat man eigentlich schon 'ne digitale Nerd-BILD.",
  "retweeted_status" : {
    "source" : "web",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 9, 29 ],
        "url" : "http://t.co/rQEvQMAq",
        "expanded_url" : "http://blog.fefe.de",
        "display_url" : "blog.fefe.de"
      } ]
    },
    "geo" : {
    },
    "id_str" : "172421986063101953",
    "text" : "Wenn man http://t.co/rQEvQMAq und youporn aufhat, hat man eigentlich schon 'ne digitale Nerd-BILD.",
    "id" : 172421986063101953,
    "created_at" : "Wed Feb 22 20:46:19 +0000 2012",
    "user" : {
      "name" : "Gerd Eist",
      "screen_name" : "erdgeist",
      "protected" : false,
      "id_str" : "16701619",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/61748149/ta_normal.jpg",
      "id" : 16701619,
      "verified" : false
    }
  },
  "id" : 172742168539168768,
  "created_at" : "Thu Feb 23 17:58:37 +0000 2012",
  "user" : {
    "name" : "Felix",
    "screen_name" : "nicidienase",
    "protected" : false,
    "id_str" : "22396883",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3125784966/8223a4c5c9535be22d15c82ec829c2df_normal.jpeg",
    "id" : 22396883,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://getspaz.com\" rel=\"nofollow\">Spaz</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Raumzeit",
      "screen_name" : "raumzeit",
      "indices" : [ 0, 9 ],
      "id_str" : "84790809",
      "id" : 84790809
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "172655168633044993",
  "in_reply_to_user_id" : 84790809,
  "text" : "@raumzeit Mein mp3-Player frisst kein m4a. Gibts in Zukunft zwei Feeds oder muss ich mir die mp3s manuel runterladen?",
  "id" : 172655168633044993,
  "created_at" : "Thu Feb 23 12:12:54 +0000 2012",
  "in_reply_to_screen_name" : "raumzeit",
  "in_reply_to_user_id_str" : "84790809",
  "user" : {
    "name" : "Felix",
    "screen_name" : "nicidienase",
    "protected" : false,
    "id_str" : "22396883",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3125784966/8223a4c5c9535be22d15c82ec829c2df_normal.jpeg",
    "id" : 22396883,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://getspaz.com\" rel=\"nofollow\">Spaz</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 33, 53 ],
      "url" : "http://t.co/PGVS3CEH",
      "expanded_url" : "http://twitpic.com/8nkvgd",
      "display_url" : "twitpic.com/8nkvgd"
    } ]
  },
  "geo" : {
  },
  "id_str" : "172645761237000193",
  "text" : "Neuzug\u00E4nge in meinem B\u00FCcherregal http://t.co/PGVS3CEH",
  "id" : 172645761237000193,
  "created_at" : "Thu Feb 23 11:35:31 +0000 2012",
  "user" : {
    "name" : "Felix",
    "screen_name" : "nicidienase",
    "protected" : false,
    "id_str" : "22396883",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3125784966/8223a4c5c9535be22d15c82ec829c2df_normal.jpeg",
    "id" : 22396883,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://getspaz.com\" rel=\"nofollow\">Spaz HD for webOS</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Eva Eichhorn",
      "screen_name" : "MamsellChaos",
      "indices" : [ 3, 16 ],
      "id_str" : "140774041",
      "id" : 140774041
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 23, 43 ],
      "url" : "http://t.co/vYUcn5wF",
      "expanded_url" : "http://theoatmeal.com/comics/game_of_thrones",
      "display_url" : "theoatmeal.com/comics/game_of\u2026"
    } ]
  },
  "geo" : {
  },
  "id_str" : "171927981676175360",
  "text" : "RT @MamsellChaos: Yes. http://t.co/vYUcn5wF",
  "retweeted_status" : {
    "source" : "<a href=\"http://itunes.apple.com/us/app/twitter/id409789998?mt=12\" rel=\"nofollow\">Twitter for Mac</a>",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 5, 25 ],
        "url" : "http://t.co/vYUcn5wF",
        "expanded_url" : "http://theoatmeal.com/comics/game_of_thrones",
        "display_url" : "theoatmeal.com/comics/game_of\u2026"
      } ]
    },
    "geo" : {
    },
    "id_str" : "171924108894937088",
    "text" : "Yes. http://t.co/vYUcn5wF",
    "id" : 171924108894937088,
    "created_at" : "Tue Feb 21 11:47:56 +0000 2012",
    "user" : {
      "name" : "Eva Eichhorn",
      "screen_name" : "MamsellChaos",
      "protected" : false,
      "id_str" : "140774041",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/3231510280/b59cd7b5771078fb646882e5e5882940_normal.jpeg",
      "id" : 140774041,
      "verified" : false
    }
  },
  "id" : 171927981676175360,
  "created_at" : "Tue Feb 21 12:03:19 +0000 2012",
  "user" : {
    "name" : "Felix",
    "screen_name" : "nicidienase",
    "protected" : false,
    "id_str" : "22396883",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3125784966/8223a4c5c9535be22d15c82ec829c2df_normal.jpeg",
    "id" : 22396883,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://getspaz.com\" rel=\"nofollow\">Spaz</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Christian Reinboth",
      "screen_name" : "reinboth",
      "indices" : [ 3, 12 ],
      "id_str" : "17187345",
      "id" : 17187345
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "171222307723939840",
  "text" : "RT @reinboth: Wie w\u00E4re es eigentlich mit Harald Lesch als Kandidat? Das w\u00E4re mal ein Pr\u00E4sident!",
  "retweeted_status" : {
    "source" : "<a href=\"http://mobile.twitter.com\" rel=\"nofollow\">Mobile Web</a>",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : {
    },
    "id_str" : "171203821295517698",
    "text" : "Wie w\u00E4re es eigentlich mit Harald Lesch als Kandidat? Das w\u00E4re mal ein Pr\u00E4sident!",
    "id" : 171203821295517698,
    "created_at" : "Sun Feb 19 12:05:46 +0000 2012",
    "user" : {
      "name" : "Christian Reinboth",
      "screen_name" : "reinboth",
      "protected" : false,
      "id_str" : "17187345",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/63738891/2576239650_68e4f5f7fe_normal.jpg",
      "id" : 17187345,
      "verified" : false
    }
  },
  "id" : 171222307723939840,
  "created_at" : "Sun Feb 19 13:19:13 +0000 2012",
  "user" : {
    "name" : "Felix",
    "screen_name" : "nicidienase",
    "protected" : false,
    "id_str" : "22396883",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3125784966/8223a4c5c9535be22d15c82ec829c2df_normal.jpeg",
    "id" : 22396883,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://getspaz.com\" rel=\"nofollow\">Spaz</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Katze",
      "indices" : [ 0, 6 ]
    } ],
    "urls" : [ {
      "indices" : [ 51, 71 ],
      "url" : "http://t.co/baRBRZ9y",
      "expanded_url" : "http://twitpic.com/8llnk9",
      "display_url" : "twitpic.com/8llnk9"
    } ]
  },
  "geo" : {
  },
  "id_str" : "170921154587017216",
  "text" : "#Katze mit Schleifchen, nur irgendwie aufm Kopf .. http://t.co/baRBRZ9y",
  "id" : 170921154587017216,
  "created_at" : "Sat Feb 18 17:22:33 +0000 2012",
  "user" : {
    "name" : "Felix",
    "screen_name" : "nicidienase",
    "protected" : false,
    "id_str" : "22396883",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3125784966/8223a4c5c9535be22d15c82ec829c2df_normal.jpeg",
    "id" : 22396883,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://getspaz.com\" rel=\"nofollow\">Spaz HD for webOS</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "forschungstorte",
      "screen_name" : "forschungstorte",
      "indices" : [ 3, 19 ],
      "id_str" : "19395255",
      "id" : 19395255
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 91, 111 ],
      "url" : "http://t.co/FlPlobq9",
      "expanded_url" : "http://antiprodukt.soup.io/post/232483650/a-story-about-stars-and-white-knights",
      "display_url" : "antiprodukt.soup.io/post/232483650\u2026"
    } ]
  },
  "geo" : {
  },
  "id_str" : "170919264939814912",
  "text" : "RT @forschungstorte: Noch ein sehr sch\u00F6ner comic \u00FCber hoffnung wenn das leben garstig ist. http://t.co/FlPlobq9",
  "retweeted_status" : {
    "source" : "<a href=\"http://hotot.org\" rel=\"nofollow\">Hotot for Chrome</a>",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 70, 90 ],
        "url" : "http://t.co/FlPlobq9",
        "expanded_url" : "http://antiprodukt.soup.io/post/232483650/a-story-about-stars-and-white-knights",
        "display_url" : "antiprodukt.soup.io/post/232483650\u2026"
      } ]
    },
    "geo" : {
    },
    "id_str" : "170916093794336769",
    "text" : "Noch ein sehr sch\u00F6ner comic \u00FCber hoffnung wenn das leben garstig ist. http://t.co/FlPlobq9",
    "id" : 170916093794336769,
    "created_at" : "Sat Feb 18 17:02:26 +0000 2012",
    "user" : {
      "name" : "forschungstorte",
      "screen_name" : "forschungstorte",
      "protected" : false,
      "id_str" : "19395255",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/3466440021/d2a554a96194ac1475759d22e1804d31_normal.png",
      "id" : 19395255,
      "verified" : false
    }
  },
  "id" : 170919264939814912,
  "created_at" : "Sat Feb 18 17:15:02 +0000 2012",
  "user" : {
    "name" : "Felix",
    "screen_name" : "nicidienase",
    "protected" : false,
    "id_str" : "22396883",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3125784966/8223a4c5c9535be22d15c82ec829c2df_normal.jpeg",
    "id" : 22396883,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://getspaz.com\" rel=\"nofollow\">Spaz HD for webOS</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Eva Eichhorn",
      "screen_name" : "MamsellChaos",
      "indices" : [ 0, 13 ],
      "id_str" : "140774041",
      "id" : 140774041
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "170842063242407937",
  "geo" : {
  },
  "id_str" : "170843667173605376",
  "in_reply_to_user_id" : 140774041,
  "text" : "@MamsellChaos Bei den aktuellen Festplattenpreisen taugen immerhin noch was als Backup-Medium.",
  "id" : 170843667173605376,
  "in_reply_to_status_id" : 170842063242407937,
  "created_at" : "Sat Feb 18 12:14:39 +0000 2012",
  "in_reply_to_screen_name" : "MamsellChaos",
  "in_reply_to_user_id_str" : "140774041",
  "user" : {
    "name" : "Felix",
    "screen_name" : "nicidienase",
    "protected" : false,
    "id_str" : "22396883",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3125784966/8223a4c5c9535be22d15c82ec829c2df_normal.jpeg",
    "id" : 22396883,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://getspaz.com\" rel=\"nofollow\">Spaz HD for webOS</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "170620351447957504",
  "text" : "Internetblogger, sagt der Fernehtagesschausprecher ...",
  "id" : 170620351447957504,
  "created_at" : "Fri Feb 17 21:27:16 +0000 2012",
  "user" : {
    "name" : "Felix",
    "screen_name" : "nicidienase",
    "protected" : false,
    "id_str" : "22396883",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3125784966/8223a4c5c9535be22d15c82ec829c2df_normal.jpeg",
    "id" : 22396883,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://getspaz.com\" rel=\"nofollow\">Spaz HD for webOS</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "jauch",
      "indices" : [ 13, 19 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "170612079185768449",
  "text" : "Aber G\u00FCnter! #jauch",
  "id" : 170612079185768449,
  "created_at" : "Fri Feb 17 20:54:24 +0000 2012",
  "user" : {
    "name" : "Felix",
    "screen_name" : "nicidienase",
    "protected" : false,
    "id_str" : "22396883",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3125784966/8223a4c5c9535be22d15c82ec829c2df_normal.jpeg",
    "id" : 22396883,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://getspaz.com\" rel=\"nofollow\">Spaz HD for webOS</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Gerd Eist",
      "screen_name" : "erdgeist",
      "indices" : [ 3, 12 ],
      "id_str" : "16701619",
      "id" : 16701619
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 57, 77 ],
      "url" : "http://t.co/mnTtziJx",
      "expanded_url" : "http://www.istgeorgschrammschonimamt.de/",
      "display_url" : "istgeorgschrammschonimamt.de"
    } ]
  },
  "geo" : {
  },
  "id_str" : "170610919880130560",
  "text" : "RT @erdgeist: Ist eigentlich Georg Schramm schon im Amt? http://t.co/mnTtziJx",
  "retweeted_status" : {
    "source" : "web",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 43, 63 ],
        "url" : "http://t.co/mnTtziJx",
        "expanded_url" : "http://www.istgeorgschrammschonimamt.de/",
        "display_url" : "istgeorgschrammschonimamt.de"
      } ]
    },
    "geo" : {
    },
    "id_str" : "170594437666316289",
    "text" : "Ist eigentlich Georg Schramm schon im Amt? http://t.co/mnTtziJx",
    "id" : 170594437666316289,
    "created_at" : "Fri Feb 17 19:44:18 +0000 2012",
    "user" : {
      "name" : "Gerd Eist",
      "screen_name" : "erdgeist",
      "protected" : false,
      "id_str" : "16701619",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/61748149/ta_normal.jpg",
      "id" : 16701619,
      "verified" : false
    }
  },
  "id" : 170610919880130560,
  "created_at" : "Fri Feb 17 20:49:47 +0000 2012",
  "user" : {
    "name" : "Felix",
    "screen_name" : "nicidienase",
    "protected" : false,
    "id_str" : "22396883",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3125784966/8223a4c5c9535be22d15c82ec829c2df_normal.jpeg",
    "id" : 22396883,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://getspaz.com\" rel=\"nofollow\">Spaz HD for webOS</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Michael Merk",
      "screen_name" : "DerMorb",
      "indices" : [ 3, 11 ],
      "id_str" : "95022235",
      "id" : 95022235
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "wulff",
      "indices" : [ 47, 53 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "170512711992614912",
  "text" : "RT @DerMorb: Breaking News: Ron Paul steht f\u00FCr #wulff Nachfolge bereit!",
  "retweeted_status" : {
    "source" : "web",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "wulff",
        "indices" : [ 34, 40 ]
      } ],
      "urls" : [ ]
    },
    "geo" : {
    },
    "id_str" : "170506684870033410",
    "text" : "Breaking News: Ron Paul steht f\u00FCr #wulff Nachfolge bereit!",
    "id" : 170506684870033410,
    "created_at" : "Fri Feb 17 13:55:36 +0000 2012",
    "user" : {
      "name" : "Michael Merk",
      "screen_name" : "DerMorb",
      "protected" : false,
      "id_str" : "95022235",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/561722284/36527823_normal.jpg",
      "id" : 95022235,
      "verified" : false
    }
  },
  "id" : 170512711992614912,
  "created_at" : "Fri Feb 17 14:19:33 +0000 2012",
  "user" : {
    "name" : "Felix",
    "screen_name" : "nicidienase",
    "protected" : false,
    "id_str" : "22396883",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3125784966/8223a4c5c9535be22d15c82ec829c2df_normal.jpeg",
    "id" : 22396883,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/tweetbutton\" rel=\"nofollow\">Tweet Button</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Schrammforpresident",
      "indices" : [ 0, 20 ]
    } ],
    "urls" : [ {
      "indices" : [ 21, 41 ],
      "url" : "http://t.co/A5exPz35",
      "expanded_url" : "http://youtu.be/qtFJfOTAfOM",
      "display_url" : "youtu.be/qtFJfOTAfOM"
    } ]
  },
  "geo" : {
  },
  "id_str" : "170314597029523456",
  "text" : "#Schrammforpresident http://t.co/A5exPz35",
  "id" : 170314597029523456,
  "created_at" : "Fri Feb 17 01:12:18 +0000 2012",
  "user" : {
    "name" : "Felix",
    "screen_name" : "nicidienase",
    "protected" : false,
    "id_str" : "22396883",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3125784966/8223a4c5c9535be22d15c82ec829c2df_normal.jpeg",
    "id" : 22396883,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Schramm",
      "indices" : [ 4, 12 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "170301472624488448",
  "text" : "\\o/ #Schramm for president! \\o/",
  "id" : 170301472624488448,
  "created_at" : "Fri Feb 17 00:20:09 +0000 2012",
  "user" : {
    "name" : "Felix",
    "screen_name" : "nicidienase",
    "protected" : false,
    "id_str" : "22396883",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3125784966/8223a4c5c9535be22d15c82ec829c2df_normal.jpeg",
    "id" : 22396883,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://getspaz.com\" rel=\"nofollow\">Spaz</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "dani",
      "screen_name" : "danintown",
      "indices" : [ 0, 10 ],
      "id_str" : "352607567",
      "id" : 352607567
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "170185912830009344",
  "geo" : {
  },
  "id_str" : "170196322689888256",
  "in_reply_to_user_id" : 352607567,
  "text" : "@danintown Danke, hab mich schnell in meinen Anschlusszug verzogen, da is warm und weniger Polizeistaatlich.",
  "id" : 170196322689888256,
  "in_reply_to_status_id" : 170185912830009344,
  "created_at" : "Thu Feb 16 17:22:20 +0000 2012",
  "in_reply_to_screen_name" : "danintown",
  "in_reply_to_user_id_str" : "352607567",
  "user" : {
    "name" : "Felix",
    "screen_name" : "nicidienase",
    "protected" : false,
    "id_str" : "22396883",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3125784966/8223a4c5c9535be22d15c82ec829c2df_normal.jpeg",
    "id" : 22396883,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://getspaz.com\" rel=\"nofollow\">Spaz</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "S21",
      "indices" : [ 85, 89 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "170185108698038272",
  "text" : "Am Stuttgarter HBF kommt man sich ja vor wie in nem Polizeistaat, is das alles wegen #S21 oder is heute Fussball oder so was??",
  "id" : 170185108698038272,
  "created_at" : "Thu Feb 16 16:37:46 +0000 2012",
  "user" : {
    "name" : "Felix",
    "screen_name" : "nicidienase",
    "protected" : false,
    "id_str" : "22396883",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3125784966/8223a4c5c9535be22d15c82ec829c2df_normal.jpeg",
    "id" : 22396883,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://getspaz.com\" rel=\"nofollow\">Spaz HD for webOS</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "gabriel rath ",
      "screen_name" : "gabrealness",
      "indices" : [ 3, 15 ],
      "id_str" : "29413859",
      "id" : 29413859
    }, {
      "name" : "Ren\u00E9 Hesse",
      "screen_name" : "ReneHesse",
      "indices" : [ 60, 70 ],
      "id_str" : "24183052",
      "id" : 24183052
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "169981707804622848",
  "text" : "RT @gabrealness: Na wenn das keinen Retweet wert ist ;)  RT @ReneHesse: 16 Bud Spencer & Terence Hill Filme kostenlos auf YouTube http:/ ...",
  "retweeted_status" : {
    "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Ren\u00E9 Hesse",
        "screen_name" : "ReneHesse",
        "indices" : [ 43, 53 ],
        "id_str" : "24183052",
        "id" : 24183052
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 113, 133 ],
        "url" : "http://t.co/5GxTmVUy",
        "expanded_url" : "http://j.mp/wgmQkS",
        "display_url" : "j.mp/wgmQkS"
      } ]
    },
    "geo" : {
    },
    "id_str" : "169841143138369538",
    "text" : "Na wenn das keinen Retweet wert ist ;)  RT @ReneHesse: 16 Bud Spencer & Terence Hill Filme kostenlos auf YouTube http://t.co/5GxTmVUy",
    "id" : 169841143138369538,
    "created_at" : "Wed Feb 15 17:50:58 +0000 2012",
    "user" : {
      "name" : "gabriel rath ",
      "screen_name" : "gabrealness",
      "protected" : false,
      "id_str" : "29413859",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/3455627195/9bcea7bb1427b4cab786a4df2c92c8a5_normal.jpeg",
      "id" : 29413859,
      "verified" : false
    }
  },
  "id" : 169981707804622848,
  "created_at" : "Thu Feb 16 03:09:31 +0000 2012",
  "user" : {
    "name" : "Felix",
    "screen_name" : "nicidienase",
    "protected" : false,
    "id_str" : "22396883",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3125784966/8223a4c5c9535be22d15c82ec829c2df_normal.jpeg",
    "id" : 22396883,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://getspaz.com\" rel=\"nofollow\">Spaz HD for webOS</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Richard",
      "screen_name" : "_L_M_C_",
      "indices" : [ 3, 11 ],
      "id_str" : "19544379",
      "id" : 19544379
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "169426143626264577",
  "text" : "RT @_L_M_C_: I was disappointed when the book '1001 Things You Never Knew About Binary' turned out to only have nine pages.",
  "retweeted_status" : {
    "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : {
    },
    "id_str" : "169089674051198977",
    "text" : "I was disappointed when the book '1001 Things You Never Knew About Binary' turned out to only have nine pages.",
    "id" : 169089674051198977,
    "created_at" : "Mon Feb 13 16:04:54 +0000 2012",
    "user" : {
      "name" : "Richard",
      "screen_name" : "_L_M_C_",
      "protected" : false,
      "id_str" : "19544379",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/3465952841/d23a0e7ac4b8b27cb3e7eda91d3a9a30_normal.jpeg",
      "id" : 19544379,
      "verified" : false
    }
  },
  "id" : 169426143626264577,
  "created_at" : "Tue Feb 14 14:21:55 +0000 2012",
  "user" : {
    "name" : "Felix",
    "screen_name" : "nicidienase",
    "protected" : false,
    "id_str" : "22396883",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3125784966/8223a4c5c9535be22d15c82ec829c2df_normal.jpeg",
    "id" : 22396883,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://getspaz.com\" rel=\"nofollow\">Spaz HD for webOS</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Cheatha",
      "screen_name" : "Cheatha",
      "indices" : [ 3, 11 ],
      "id_str" : "6712152",
      "id" : 6712152
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 55, 75 ],
      "url" : "http://t.co/i0773xdY",
      "expanded_url" : "http://j.mp/wdyYGz",
      "display_url" : "j.mp/wdyYGz"
    } ]
  },
  "geo" : {
  },
  "id_str" : "169035598953332737",
  "text" : "RT @Cheatha: \u00BBPinguin treibt auf Eisscholle im Neckar\u00AB http://t.co/i0773xdY Trolllevel: Batman",
  "retweeted_status" : {
    "source" : "<a href=\"http://bitly.com\" rel=\"nofollow\">bitly</a>",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 42, 62 ],
        "url" : "http://t.co/i0773xdY",
        "expanded_url" : "http://j.mp/wdyYGz",
        "display_url" : "j.mp/wdyYGz"
      } ]
    },
    "geo" : {
    },
    "id_str" : "169015198110322688",
    "text" : "\u00BBPinguin treibt auf Eisscholle im Neckar\u00AB http://t.co/i0773xdY Trolllevel: Batman",
    "id" : 169015198110322688,
    "created_at" : "Mon Feb 13 11:08:58 +0000 2012",
    "user" : {
      "name" : "Cheatha",
      "screen_name" : "Cheatha",
      "protected" : false,
      "id_str" : "6712152",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/3374866766/96e7f9f0120e743ed5c2e5bd9400ee7f_normal.jpeg",
      "id" : 6712152,
      "verified" : false
    }
  },
  "id" : 169035598953332737,
  "created_at" : "Mon Feb 13 12:30:01 +0000 2012",
  "user" : {
    "name" : "Felix",
    "screen_name" : "nicidienase",
    "protected" : false,
    "id_str" : "22396883",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3125784966/8223a4c5c9535be22d15c82ec829c2df_normal.jpeg",
    "id" : 22396883,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://getspaz.com\" rel=\"nofollow\">Spaz HD for webOS</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Floyd",
      "screen_name" : "DerFloyd",
      "indices" : [ 3, 12 ],
      "id_str" : "256995048",
      "id" : 256995048
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "169033639210921984",
  "text" : "RT @DerFloyd: \"Du verstehst immer nur das, was du verstehen willst!\" \n\"Gar nicht wahr.\" \n\"Ich liebe dich.\" \n\"Bring mir eins mit.\"",
  "retweeted_status" : {
    "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : {
    },
    "id_str" : "168742512968744960",
    "text" : "\"Du verstehst immer nur das, was du verstehen willst!\" \n\"Gar nicht wahr.\" \n\"Ich liebe dich.\" \n\"Bring mir eins mit.\"",
    "id" : 168742512968744960,
    "created_at" : "Sun Feb 12 17:05:24 +0000 2012",
    "user" : {
      "name" : "Floyd",
      "screen_name" : "DerFloyd",
      "protected" : false,
      "id_str" : "256995048",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/3284311242/2895cef4273ddbafa10b2d820b19c225_normal.jpeg",
      "id" : 256995048,
      "verified" : false
    }
  },
  "id" : 169033639210921984,
  "created_at" : "Mon Feb 13 12:22:14 +0000 2012",
  "user" : {
    "name" : "Felix",
    "screen_name" : "nicidienase",
    "protected" : false,
    "id_str" : "22396883",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3125784966/8223a4c5c9535be22d15c82ec829c2df_normal.jpeg",
    "id" : 22396883,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://getspaz.com\" rel=\"nofollow\">Spaz HD for webOS</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "GPN12",
      "indices" : [ 6, 12 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "168481560788598784",
  "text" : "Yeay, #GPN12 angek\u00FCndigt, vom 7.-10. Juni. Freu mich schon drauf!",
  "id" : 168481560788598784,
  "created_at" : "Sat Feb 11 23:48:28 +0000 2012",
  "user" : {
    "name" : "Felix",
    "screen_name" : "nicidienase",
    "protected" : false,
    "id_str" : "22396883",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3125784966/8223a4c5c9535be22d15c82ec829c2df_normal.jpeg",
    "id" : 22396883,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://getspaz.com\" rel=\"nofollow\">Spaz</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "praxisvorbereitung",
      "indices" : [ 79, 98 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "168252015498117120",
  "text" : "Eine halbe Stunde rum und wir haben gelernt wie man in Excel navigiert. *g\u00E4hn* #praxisvorbereitung",
  "id" : 168252015498117120,
  "created_at" : "Sat Feb 11 08:36:21 +0000 2012",
  "user" : {
    "name" : "Felix",
    "screen_name" : "nicidienase",
    "protected" : false,
    "id_str" : "22396883",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3125784966/8223a4c5c9535be22d15c82ec829c2df_normal.jpeg",
    "id" : 22396883,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://getspaz.com\" rel=\"nofollow\">Spaz HD for webOS</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Holger Klein",
      "screen_name" : "holgi",
      "indices" : [ 16, 22 ],
      "id_str" : "3068271",
      "id" : 3068271
    }, {
      "name" : "@monkeydom",
      "screen_name" : "monkeydom",
      "indices" : [ 68, 78 ],
      "id_str" : "6259182",
      "id" : 6259182
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 80, 100 ],
      "url" : "http://t.co/L93tzS2k",
      "expanded_url" : "http://twitpic.com/8i5hbc",
      "display_url" : "twitpic.com/8i5hbc"
    } ]
  },
  "geo" : {
  },
  "id_str" : "168082138493755392",
  "text" : "Bwahahahahah RT @holgi Harhar! Ihr m\u00FCsst jetzt sehr tapfer sein! (v @monkeydom) http://t.co/L93tzS2k",
  "id" : 168082138493755392,
  "created_at" : "Fri Feb 10 21:21:19 +0000 2012",
  "user" : {
    "name" : "Felix",
    "screen_name" : "nicidienase",
    "protected" : false,
    "id_str" : "22396883",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3125784966/8223a4c5c9535be22d15c82ec829c2df_normal.jpeg",
    "id" : 22396883,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://getspaz.com\" rel=\"nofollow\">Spaz HD for webOS</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Netzverweigerer",
      "screen_name" : "netzverweigerer",
      "indices" : [ 3, 19 ],
      "id_str" : "391700353",
      "id" : 391700353
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "168076910792941568",
  "text" : "RT @netzverweigerer: \"Warum liegen hier eigentlich iptables rum?\" \"Warum hast Du eigentlich ne Netmask an?\" \"Na, dann tunnel mir doch ei ...",
  "retweeted_status" : {
    "source" : "<a href=\"http://www.bitlbee.org/\" rel=\"nofollow\">BitlBee</a>",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : {
    },
    "id_str" : "165391938084814848",
    "text" : "\"Warum liegen hier eigentlich iptables rum?\" \"Warum hast Du eigentlich ne Netmask an?\" \"Na, dann tunnel mir doch einen!\"",
    "id" : 165391938084814848,
    "created_at" : "Fri Feb 03 11:11:25 +0000 2012",
    "user" : {
      "name" : "Netzverweigerer",
      "screen_name" : "netzverweigerer",
      "protected" : false,
      "id_str" : "391700353",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/2270050487/nx09qhgwhc22x4kvel87_normal.png",
      "id" : 391700353,
      "verified" : false
    }
  },
  "id" : 168076910792941568,
  "created_at" : "Fri Feb 10 21:00:32 +0000 2012",
  "user" : {
    "name" : "Felix",
    "screen_name" : "nicidienase",
    "protected" : false,
    "id_str" : "22396883",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3125784966/8223a4c5c9535be22d15c82ec829c2df_normal.jpeg",
    "id" : 22396883,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 18, 39 ],
      "url" : "https://t.co/Kvkno49w",
      "expanded_url" : "https://www.youtube.com/watch?v=KV-qS82lXtk",
      "display_url" : "youtube.com/watch?v=KV-qS8\u2026"
    } ]
  },
  "geo" : {
  },
  "id_str" : "167661924270620673",
  "text" : "Why not Zoidberg? https://t.co/Kvkno49w",
  "id" : 167661924270620673,
  "created_at" : "Thu Feb 09 17:31:32 +0000 2012",
  "user" : {
    "name" : "Felix",
    "screen_name" : "nicidienase",
    "protected" : false,
    "id_str" : "22396883",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3125784966/8223a4c5c9535be22d15c82ec829c2df_normal.jpeg",
    "id" : 22396883,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://getspaz.com\" rel=\"nofollow\">Spaz</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "167641300491960320",
  "text" : "OH: \"Ich hab nen schwarzen G\u00FCrtel in Fujitsu.\"",
  "id" : 167641300491960320,
  "created_at" : "Thu Feb 09 16:09:35 +0000 2012",
  "user" : {
    "name" : "Felix",
    "screen_name" : "nicidienase",
    "protected" : false,
    "id_str" : "22396883",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3125784966/8223a4c5c9535be22d15c82ec829c2df_normal.jpeg",
    "id" : 22396883,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://getspaz.com\" rel=\"nofollow\">Spaz</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "167623034147057664",
  "text" : "Emaile, Hammer3+ gro\u00DFes Pils!",
  "id" : 167623034147057664,
  "created_at" : "Thu Feb 09 14:57:00 +0000 2012",
  "user" : {
    "name" : "Felix",
    "screen_name" : "nicidienase",
    "protected" : false,
    "id_str" : "22396883",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3125784966/8223a4c5c9535be22d15c82ec829c2df_normal.jpeg",
    "id" : 22396883,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://getspaz.com\" rel=\"nofollow\">Spaz</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "167611589099401217",
  "text" : "Letzte Klausur rum! Alkohol her!!",
  "id" : 167611589099401217,
  "created_at" : "Thu Feb 09 14:11:31 +0000 2012",
  "user" : {
    "name" : "Felix",
    "screen_name" : "nicidienase",
    "protected" : false,
    "id_str" : "22396883",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3125784966/8223a4c5c9535be22d15c82ec829c2df_normal.jpeg",
    "id" : 22396883,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://getspaz.com\" rel=\"nofollow\">Spaz</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "167402870591848449",
  "text" : "Hab mich grade f\u00FCrs SoSe zur\u00FCckgemeldet. Auf der Studienbescheinigung steht jetzt \"Hochschulsemester: 10\"",
  "id" : 167402870591848449,
  "created_at" : "Thu Feb 09 00:22:09 +0000 2012",
  "user" : {
    "name" : "Felix",
    "screen_name" : "nicidienase",
    "protected" : false,
    "id_str" : "22396883",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3125784966/8223a4c5c9535be22d15c82ec829c2df_normal.jpeg",
    "id" : 22396883,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://getspaz.com\" rel=\"nofollow\">Spaz</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 35, 55 ],
      "url" : "http://t.co/K8tiRry6",
      "expanded_url" : "http://twitpic.com/8hex46",
      "display_url" : "twitpic.com/8hex46"
    } ]
  },
  "geo" : {
  },
  "id_str" : "167396708731461632",
  "text" : "WRTs lassen sich sch\u00F6n stapeln :-) http://t.co/K8tiRry6",
  "id" : 167396708731461632,
  "created_at" : "Wed Feb 08 23:57:40 +0000 2012",
  "user" : {
    "name" : "Felix",
    "screen_name" : "nicidienase",
    "protected" : false,
    "id_str" : "22396883",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3125784966/8223a4c5c9535be22d15c82ec829c2df_normal.jpeg",
    "id" : 22396883,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "deimudder",
      "indices" : [ 63, 73 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "166942045544529922",
  "text" : "\"Dei Mudda ist so fat, sie unterst\u00FCtzt keine Datein \u00FCber 4GB!\" #deimudder",
  "id" : 166942045544529922,
  "created_at" : "Tue Feb 07 17:50:59 +0000 2012",
  "user" : {
    "name" : "Felix",
    "screen_name" : "nicidienase",
    "protected" : false,
    "id_str" : "22396883",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3125784966/8223a4c5c9535be22d15c82ec829c2df_normal.jpeg",
    "id" : 22396883,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://getspaz.com\" rel=\"nofollow\">Spaz HD for webOS</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lilly W.",
      "screen_name" : "dielilly",
      "indices" : [ 3, 12 ],
      "id_str" : "19603003",
      "id" : 19603003
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "166938450560430082",
  "text" : "RT @dielilly: ich wollte kein fass aufmachen, aber dann hat es der tropfen zum \u00FCberlaufen gebracht, da hab ich ihm schnell den boden aus ...",
  "retweeted_status" : {
    "source" : "<a href=\"http://itunes.apple.com/us/app/twitter/id409789998?mt=12\" rel=\"nofollow\">Twitter for Mac</a>",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : {
    },
    "id_str" : "166825595399962624",
    "text" : "ich wollte kein fass aufmachen, aber dann hat es der tropfen zum \u00FCberlaufen gebracht, da hab ich ihm schnell den boden ausgeschlagen.",
    "id" : 166825595399962624,
    "created_at" : "Tue Feb 07 10:08:16 +0000 2012",
    "user" : {
      "name" : "Lilly W.",
      "screen_name" : "dielilly",
      "protected" : false,
      "id_str" : "19603003",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/3217478653/94ba887554ffa33ae41bdc05830e05d8_normal.jpeg",
      "id" : 19603003,
      "verified" : false
    }
  },
  "id" : 166938450560430082,
  "created_at" : "Tue Feb 07 17:36:42 +0000 2012",
  "user" : {
    "name" : "Felix",
    "screen_name" : "nicidienase",
    "protected" : false,
    "id_str" : "22396883",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3125784966/8223a4c5c9535be22d15c82ec829c2df_normal.jpeg",
    "id" : 22396883,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://getspaz.com\" rel=\"nofollow\">Spaz HD for webOS</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "166622465034948608",
  "geo" : {
  },
  "id_str" : "166623385844056065",
  "in_reply_to_user_id" : 20689932,
  "text" : "@Geruhn Hat wenigstens der Geschmack \u00FCberzeugt?",
  "id" : 166623385844056065,
  "in_reply_to_status_id" : 166622465034948608,
  "created_at" : "Mon Feb 06 20:44:45 +0000 2012",
  "in_reply_to_screen_name" : "keinGeruhn",
  "in_reply_to_user_id_str" : "20689932",
  "user" : {
    "name" : "Felix",
    "screen_name" : "nicidienase",
    "protected" : false,
    "id_str" : "22396883",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3125784966/8223a4c5c9535be22d15c82ec829c2df_normal.jpeg",
    "id" : 22396883,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://getspaz.com\" rel=\"nofollow\">Spaz HD for webOS</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "166595250469601280",
  "geo" : {
  },
  "id_str" : "166622112403038208",
  "in_reply_to_user_id" : 20689932,
  "text" : "@Geruhn Das sah in der Vorlage aber irgendwie besser aus ...",
  "id" : 166622112403038208,
  "in_reply_to_status_id" : 166595250469601280,
  "created_at" : "Mon Feb 06 20:39:41 +0000 2012",
  "in_reply_to_screen_name" : "keinGeruhn",
  "in_reply_to_user_id_str" : "20689932",
  "user" : {
    "name" : "Felix",
    "screen_name" : "nicidienase",
    "protected" : false,
    "id_str" : "22396883",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3125784966/8223a4c5c9535be22d15c82ec829c2df_normal.jpeg",
    "id" : 22396883,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://formspring.me\" rel=\"nofollow\">Formspring.me</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 16, 36 ],
      "url" : "http://t.co/MNbGn1iv",
      "expanded_url" : "http://formspring.me/NiciDieNase",
      "display_url" : "formspring.me/NiciDieNase"
    } ]
  },
  "geo" : {
  },
  "id_str" : "166327080060067841",
  "text" : "Ask me anything http://t.co/MNbGn1iv",
  "id" : 166327080060067841,
  "created_at" : "Mon Feb 06 01:07:20 +0000 2012",
  "user" : {
    "name" : "Felix",
    "screen_name" : "nicidienase",
    "protected" : false,
    "id_str" : "22396883",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3125784966/8223a4c5c9535be22d15c82ec829c2df_normal.jpeg",
    "id" : 22396883,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://getspaz.com\" rel=\"nofollow\">Spaz HD for webOS</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Peter Oebel ",
      "screen_name" : "PeterOebel",
      "indices" : [ 3, 14 ],
      "id_str" : "223411010",
      "id" : 223411010
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "166319030012084225",
  "text" : "RT @PeterOebel: \"Die \u00D6ffentlich-Rechtlichen machen sich in jede Hose, die man ihnen hinh\u00E4lt, und die Privaten senden das, was darin ist. ...",
  "retweeted_status" : {
    "source" : "web",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : {
    },
    "id_str" : "166229965321404418",
    "text" : "\"Die \u00D6ffentlich-Rechtlichen machen sich in jede Hose, die man ihnen hinh\u00E4lt, und die Privaten senden das, was darin ist.\" Dieter Hildebrandt",
    "id" : 166229965321404418,
    "created_at" : "Sun Feb 05 18:41:26 +0000 2012",
    "user" : {
      "name" : "Peter Oebel ",
      "screen_name" : "PeterOebel",
      "protected" : false,
      "id_str" : "223411010",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/1421519988/IMG_0115_normal.JPG",
      "id" : 223411010,
      "verified" : false
    }
  },
  "id" : 166319030012084225,
  "created_at" : "Mon Feb 06 00:35:21 +0000 2012",
  "user" : {
    "name" : "Felix",
    "screen_name" : "nicidienase",
    "protected" : false,
    "id_str" : "22396883",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3125784966/8223a4c5c9535be22d15c82ec829c2df_normal.jpeg",
    "id" : 22396883,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://getspaz.com\" rel=\"nofollow\">Spaz HD for webOS</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tim Pritlove",
      "screen_name" : "timpritlove",
      "indices" : [ 0, 12 ],
      "id_str" : "11268812",
      "id" : 11268812
    }, {
      "name" : "Mario Sixtus",
      "screen_name" : "sixtus",
      "indices" : [ 13, 20 ],
      "id_str" : "9334352",
      "id" : 9334352
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "166174968550404096",
  "geo" : {
  },
  "id_str" : "166269452382511104",
  "in_reply_to_user_id" : 11268812,
  "text" : "@timpritlove @sixtus Stellt euch mal vor wie Bestatter-Lobby loslegt wenn die ersten Unsterblichkeitspillen auf den Markt kommen.",
  "id" : 166269452382511104,
  "in_reply_to_status_id" : 166174968550404096,
  "created_at" : "Sun Feb 05 21:18:21 +0000 2012",
  "in_reply_to_screen_name" : "timpritlove",
  "in_reply_to_user_id_str" : "11268812",
  "user" : {
    "name" : "Felix",
    "screen_name" : "nicidienase",
    "protected" : false,
    "id_str" : "22396883",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3125784966/8223a4c5c9535be22d15c82ec829c2df_normal.jpeg",
    "id" : 22396883,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://getspaz.com\" rel=\"nofollow\">Spaz</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 20, 40 ],
      "url" : "http://t.co/FvXzjijA",
      "expanded_url" : "http://twitpic.com/8fqyz1",
      "display_url" : "twitpic.com/8fqyz1"
    } ]
  },
  "geo" : {
  },
  "id_str" : "165906454975492096",
  "text" : "Die Nazis von Catan http://t.co/FvXzjijA",
  "id" : 165906454975492096,
  "created_at" : "Sat Feb 04 21:15:55 +0000 2012",
  "user" : {
    "name" : "Felix",
    "screen_name" : "nicidienase",
    "protected" : false,
    "id_str" : "22396883",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3125784966/8223a4c5c9535be22d15c82ec829c2df_normal.jpeg",
    "id" : 22396883,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://getspaz.com\" rel=\"nofollow\">Spaz</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "true",
      "indices" : [ 57, 62 ]
    } ],
    "urls" : [ {
      "indices" : [ 36, 56 ],
      "url" : "http://t.co/9Au2nHys",
      "expanded_url" : "http://me.lt/1yCA9",
      "display_url" : "me.lt/1yCA9"
    } ]
  },
  "geo" : {
  },
  "id_str" : "165555208108244993",
  "text" : "RT @Geruhn: My bed in the morning - http://t.co/9Au2nHys #true",
  "retweeted_status" : {
    "source" : "<a href=\"http://rockmelt.com\" rel=\"nofollow\">Rockmelt</a>",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "true",
        "indices" : [ 45, 50 ]
      } ],
      "urls" : [ {
        "indices" : [ 24, 44 ],
        "url" : "http://t.co/9Au2nHys",
        "expanded_url" : "http://me.lt/1yCA9",
        "display_url" : "me.lt/1yCA9"
      } ]
    },
    "geo" : {
    },
    "id_str" : "165541195722919937",
    "text" : "My bed in the morning - http://t.co/9Au2nHys #true",
    "id" : 165541195722919937,
    "created_at" : "Fri Feb 03 21:04:31 +0000 2012",
    "user" : {
      "name" : "Andy P.",
      "screen_name" : "keinGeruhn",
      "protected" : false,
      "id_str" : "20689932",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/2532717078/sqf75a6eqiayl7c6idu7_normal.jpeg",
      "id" : 20689932,
      "verified" : false
    }
  },
  "id" : 165555208108244993,
  "created_at" : "Fri Feb 03 22:00:12 +0000 2012",
  "user" : {
    "name" : "Felix",
    "screen_name" : "nicidienase",
    "protected" : false,
    "id_str" : "22396883",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3125784966/8223a4c5c9535be22d15c82ec829c2df_normal.jpeg",
    "id" : 22396883,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://getspaz.com\" rel=\"nofollow\">Spaz</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "YouPorn (Jude)",
      "screen_name" : "YouPorn",
      "indices" : [ 3, 11 ],
      "id_str" : "37060147",
      "id" : 37060147
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "165410153393430529",
  "text" : "RT @YouPorn: It's Fuck-A-Friend Friday! Share the love... with a friend.",
  "retweeted_status" : {
    "source" : "<a href=\"http://www.hootsuite.com\" rel=\"nofollow\">HootSuite</a>",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : {
    },
    "id_str" : "165384060238180352",
    "text" : "It's Fuck-A-Friend Friday! Share the love... with a friend.",
    "id" : 165384060238180352,
    "created_at" : "Fri Feb 03 10:40:07 +0000 2012",
    "user" : {
      "name" : "YouPorn (Jude)",
      "screen_name" : "YouPorn",
      "protected" : false,
      "id_str" : "37060147",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/2652879023/197b4dbe4cf438248ce92238d09a61a5_normal.png",
      "id" : 37060147,
      "verified" : false
    }
  },
  "id" : 165410153393430529,
  "created_at" : "Fri Feb 03 12:23:48 +0000 2012",
  "user" : {
    "name" : "Felix",
    "screen_name" : "nicidienase",
    "protected" : false,
    "id_str" : "22396883",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3125784966/8223a4c5c9535be22d15c82ec829c2df_normal.jpeg",
    "id" : 22396883,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 34, 54 ],
      "url" : "http://t.co/jIMSey16",
      "expanded_url" : "http://ubergeek.tv/article.php?pid=54&swfSize=1",
      "display_url" : "ubergeek.tv/article.php?pi\u2026"
    } ]
  },
  "geo" : {
  },
  "id_str" : "165176251231911936",
  "text" : "I\u2019m Steve, and I\u2019m a Supervillain http://t.co/jIMSey16",
  "id" : 165176251231911936,
  "created_at" : "Thu Feb 02 20:54:21 +0000 2012",
  "user" : {
    "name" : "Felix",
    "screen_name" : "nicidienase",
    "protected" : false,
    "id_str" : "22396883",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3125784966/8223a4c5c9535be22d15c82ec829c2df_normal.jpeg",
    "id" : 22396883,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://getspaz.com\" rel=\"nofollow\">Spaz HD for webOS</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "fail",
      "indices" : [ 110, 115 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "165154176278609922",
  "text" : "Arrg, wenn man sich wunder warum ein Cronjob nix tut sollte man erst mal nachschauen ob Cron \u00FCberhaupt l\u00E4uft. #fail",
  "id" : 165154176278609922,
  "created_at" : "Thu Feb 02 19:26:38 +0000 2012",
  "user" : {
    "name" : "Felix",
    "screen_name" : "nicidienase",
    "protected" : false,
    "id_str" : "22396883",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3125784966/8223a4c5c9535be22d15c82ec829c2df_normal.jpeg",
    "id" : 22396883,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://getspaz.com\" rel=\"nofollow\">Spaz HD for webOS</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tim Weber",
      "screen_name" : "Scytale",
      "indices" : [ 3, 11 ],
      "id_str" : "594921016",
      "id" : 594921016
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 112, 132 ],
      "url" : "http://t.co/zXiHZR79",
      "expanded_url" : "http://blog.fefe.de/?ts=b1d47cfc",
      "display_url" : "blog.fefe.de/?ts=b1d47cfc"
    } ]
  },
  "geo" : {
  },
  "id_str" : "165122969838952448",
  "text" : "RT @Scytale: Macs sind unsicher? Von wegen! Macs sch\u00FCtzen sogar vor Hausdurchsuchungen! Das gibt sogar Fefe zu! http://t.co/zXiHZR79 xD",
  "retweeted_status" : {
    "source" : "<a href=\"http://www.tweetdeck.com\" rel=\"nofollow\">TweetDeck</a>",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 99, 119 ],
        "url" : "http://t.co/zXiHZR79",
        "expanded_url" : "http://blog.fefe.de/?ts=b1d47cfc",
        "display_url" : "blog.fefe.de/?ts=b1d47cfc"
      } ]
    },
    "geo" : {
      "type" : "Point",
      "coordinates" : [ 49.4955473928, 8.4576165676 ]
    },
    "id_str" : "165121337793314816",
    "text" : "Macs sind unsicher? Von wegen! Macs sch\u00FCtzen sogar vor Hausdurchsuchungen! Das gibt sogar Fefe zu! http://t.co/zXiHZR79 xD",
    "id" : 165121337793314816,
    "created_at" : "Thu Feb 02 17:16:09 +0000 2012",
    "user" : {
      "name" : "Tim Weber",
      "screen_name" : "scy",
      "protected" : false,
      "id_str" : "8308632",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/424137519/avatar184_normal.jpg",
      "id" : 8308632,
      "verified" : false
    }
  },
  "id" : 165122969838952448,
  "created_at" : "Thu Feb 02 17:22:38 +0000 2012",
  "user" : {
    "name" : "Felix",
    "screen_name" : "nicidienase",
    "protected" : false,
    "id_str" : "22396883",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3125784966/8223a4c5c9535be22d15c82ec829c2df_normal.jpeg",
    "id" : 22396883,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://getspaz.com\" rel=\"nofollow\">Spaz HD for webOS</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "words like swords",
      "screen_name" : "Weltregierung",
      "indices" : [ 3, 17 ],
      "id_str" : "6413902",
      "id" : 6413902
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "facep",
      "indices" : [ 127, 133 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "165046285798350849",
  "text" : "RT @Weltregierung: \"Wenn Facebook meine Chronik ver\u00F6ffentlicht - k\u00F6nnen ja alle sehen, welche Pornoseiten ich besucht habe!!?\" #facep ht ...",
  "retweeted_status" : {
    "source" : "<a href=\"http://twitpic.com\" rel=\"nofollow\">Twitpic</a>",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "facep",
        "indices" : [ 108, 114 ]
      } ],
      "urls" : [ {
        "indices" : [ 115, 135 ],
        "url" : "http://t.co/rsi4m8R3",
        "expanded_url" : "http://twitpic.com/8ep1ln",
        "display_url" : "twitpic.com/8ep1ln"
      } ]
    },
    "geo" : {
    },
    "id_str" : "165030392712278016",
    "text" : "\"Wenn Facebook meine Chronik ver\u00F6ffentlicht - k\u00F6nnen ja alle sehen, welche Pornoseiten ich besucht habe!!?\" #facep http://t.co/rsi4m8R3",
    "id" : 165030392712278016,
    "created_at" : "Thu Feb 02 11:14:46 +0000 2012",
    "user" : {
      "name" : "words like swords",
      "screen_name" : "Weltregierung",
      "protected" : false,
      "id_str" : "6413902",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/3509683546/f17e80d411fe259225cdebb9ecdb45ff_normal.jpeg",
      "id" : 6413902,
      "verified" : false
    }
  },
  "id" : 165046285798350849,
  "created_at" : "Thu Feb 02 12:17:55 +0000 2012",
  "user" : {
    "name" : "Felix",
    "screen_name" : "nicidienase",
    "protected" : false,
    "id_str" : "22396883",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3125784966/8223a4c5c9535be22d15c82ec829c2df_normal.jpeg",
    "id" : 22396883,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://getspaz.com\" rel=\"nofollow\">Spaz HD for webOS</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Michael Seemann",
      "screen_name" : "mspro",
      "indices" : [ 3, 9 ],
      "id_str" : "5751892",
      "id" : 5751892
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 45, 65 ],
      "url" : "http://t.co/kIITSl04",
      "expanded_url" : "http://wirres.net/article/articleview/6140/1/6/",
      "display_url" : "wirres.net/article/articl\u2026"
    } ]
  },
  "geo" : {
  },
  "id_str" : "165028484916322304",
  "text" : "RT @mspro: geil! die telekom gibt einen aus! http://t.co/kIITSl04",
  "retweeted_status" : {
    "source" : "<a href=\"http://itunes.apple.com/us/app/twitter/id409789998?mt=12\" rel=\"nofollow\">Twitter for Mac</a>",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 34, 54 ],
        "url" : "http://t.co/kIITSl04",
        "expanded_url" : "http://wirres.net/article/articleview/6140/1/6/",
        "display_url" : "wirres.net/article/articl\u2026"
      } ]
    },
    "geo" : {
    },
    "id_str" : "165016459892883456",
    "text" : "geil! die telekom gibt einen aus! http://t.co/kIITSl04",
    "id" : 165016459892883456,
    "created_at" : "Thu Feb 02 10:19:24 +0000 2012",
    "user" : {
      "name" : "Michael Seemann",
      "screen_name" : "mspro",
      "protected" : false,
      "id_str" : "5751892",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/3408641243/2edf38d3c995612edf5b3d2e20d74861_normal.jpeg",
      "id" : 5751892,
      "verified" : false
    }
  },
  "id" : 165028484916322304,
  "created_at" : "Thu Feb 02 11:07:11 +0000 2012",
  "user" : {
    "name" : "Felix",
    "screen_name" : "nicidienase",
    "protected" : false,
    "id_str" : "22396883",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3125784966/8223a4c5c9535be22d15c82ec829c2df_normal.jpeg",
    "id" : 22396883,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://getspaz.com\" rel=\"nofollow\">Spaz</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Eva Eichhorn",
      "screen_name" : "MamsellChaos",
      "indices" : [ 13, 26 ],
      "id_str" : "140774041",
      "id" : 140774041
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 94, 114 ],
      "url" : "http://t.co/1ESks1cj",
      "expanded_url" : "http://twitpic.com/8eikhh",
      "display_url" : "twitpic.com/8eikhh"
    } ]
  },
  "in_reply_to_status_id_str" : "164365345279311872",
  "geo" : {
  },
  "id_str" : "164851984279666688",
  "in_reply_to_user_id" : 140774041,
  "text" : "Hab mich von @MamsellChaos inspirieren lassen und endlich mal meinen Rucksack mal bestickert! http://t.co/1ESks1cj",
  "id" : 164851984279666688,
  "in_reply_to_status_id" : 164365345279311872,
  "created_at" : "Wed Feb 01 23:25:50 +0000 2012",
  "in_reply_to_screen_name" : "MamsellChaos",
  "in_reply_to_user_id_str" : "140774041",
  "user" : {
    "name" : "Felix",
    "screen_name" : "nicidienase",
    "protected" : false,
    "id_str" : "22396883",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3125784966/8223a4c5c9535be22d15c82ec829c2df_normal.jpeg",
    "id" : 22396883,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://getspaz.com\" rel=\"nofollow\">Spaz</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kate H.",
      "screen_name" : "elaoe7",
      "indices" : [ 0, 7 ],
      "id_str" : "149650777",
      "id" : 149650777
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "164803224270929920",
  "geo" : {
  },
  "id_str" : "164807110134202369",
  "in_reply_to_user_id" : 149650777,
  "text" : "@elaoe7 Gar nicht, es hat einfach gepasst. \u00DCbrigends viel Erfolg bei ERP morgen.",
  "id" : 164807110134202369,
  "in_reply_to_status_id" : 164803224270929920,
  "created_at" : "Wed Feb 01 20:27:31 +0000 2012",
  "in_reply_to_screen_name" : "elaoe7",
  "in_reply_to_user_id_str" : "149650777",
  "user" : {
    "name" : "Felix",
    "screen_name" : "nicidienase",
    "protected" : false,
    "id_str" : "22396883",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3125784966/8223a4c5c9535be22d15c82ec829c2df_normal.jpeg",
    "id" : 22396883,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://getspaz.com\" rel=\"nofollow\">Spaz</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "164794168944762881",
  "text" : "Betty blinkt im Takt der Musik :-)",
  "id" : 164794168944762881,
  "created_at" : "Wed Feb 01 19:36:06 +0000 2012",
  "user" : {
    "name" : "Felix",
    "screen_name" : "nicidienase",
    "protected" : false,
    "id_str" : "22396883",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3125784966/8223a4c5c9535be22d15c82ec829c2df_normal.jpeg",
    "id" : 22396883,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://getspaz.com\" rel=\"nofollow\">Spaz</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "28c3",
      "indices" : [ 79, 84 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "164787446800846850",
  "text" : "Sitze in der Fachschaft und lerne und im Hintergrund l\u00E4uft die Pausenmusik vom #28c3",
  "id" : 164787446800846850,
  "created_at" : "Wed Feb 01 19:09:23 +0000 2012",
  "user" : {
    "name" : "Felix",
    "screen_name" : "nicidienase",
    "protected" : false,
    "id_str" : "22396883",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3125784966/8223a4c5c9535be22d15c82ec829c2df_normal.jpeg",
    "id" : 22396883,
    "verified" : false
  }
} ]