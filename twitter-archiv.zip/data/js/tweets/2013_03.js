Grailbird.data.tweets_2013_03 = 
 [ {
  "source" : "<a href=\"http://hotot.org\" rel=\"nofollow\">Hotot</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "eh13",
      "indices" : [ 133, 138 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "318318301308669952",
  "text" : "Ich hab noch eine Viererticket auf dem noch eine Fahrt drauf is, fall heute noch jemand mit dem Bus ins Nixdorf-Museum wil, oder so. #eh13",
  "id" : 318318301308669952,
  "created_at" : "Sun Mar 31 11:06:11 +0000 2013",
  "user" : {
    "name" : "Felix",
    "screen_name" : "nicidienase",
    "protected" : false,
    "id_str" : "22396883",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3125784966/8223a4c5c9535be22d15c82ec829c2df_normal.jpeg",
    "id" : 22396883,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://hotot.org\" rel=\"nofollow\">Hotot</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "m.",
      "screen_name" : "ohaimareiki",
      "indices" : [ 3, 15 ],
      "id_str" : "14732096",
      "id" : 14732096
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "318065753444208640",
  "text" : "RT @ohaimareiki: ich wei\u00DF, dass wir mit dem thema eigentlich durch sind, aber schwesterchen hat gerade \"pfertiglasagne\" gesagt.",
  "retweeted_status" : {
    "source" : "<a href=\"http://itunes.apple.com/us/app/twitter/id409789998?mt=12\" rel=\"nofollow\">Twitter for Mac</a>",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : {
    },
    "id_str" : "318057594499497984",
    "text" : "ich wei\u00DF, dass wir mit dem thema eigentlich durch sind, aber schwesterchen hat gerade \"pfertiglasagne\" gesagt.",
    "id" : 318057594499497984,
    "created_at" : "Sat Mar 30 17:50:14 +0000 2013",
    "user" : {
      "name" : "m.",
      "screen_name" : "ohaimareiki",
      "protected" : false,
      "id_str" : "14732096",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/3100722026/475d6897ce8c06c7cd73742c8fae872f_normal.jpeg",
      "id" : 14732096,
      "verified" : false
    }
  },
  "id" : 318065753444208640,
  "created_at" : "Sat Mar 30 18:22:39 +0000 2013",
  "user" : {
    "name" : "Felix",
    "screen_name" : "nicidienase",
    "protected" : false,
    "id_str" : "22396883",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3125784966/8223a4c5c9535be22d15c82ec829c2df_normal.jpeg",
    "id" : 22396883,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.tweetlanes.com\" rel=\"nofollow\">Tweet Lanes</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http://twitter.com/nicidienase/status/318047984883482626/photo/1",
      "indices" : [ 51, 73 ],
      "url" : "http://t.co/lZEfBBD2Eo",
      "media_url" : "http://pbs.twimg.com/media/BGnu9QjCQAAL_fc.jpg",
      "id_str" : "318047984887676928",
      "id" : 318047984887676928,
      "media_url_https" : "https://pbs.twimg.com/media/BGnu9QjCQAAL_fc.jpg",
      "sizes" : [ {
        "h" : 450,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 1920,
        "resize" : "fit",
        "w" : 2560
      }, {
        "h" : 768,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 255,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com/lZEfBBD2Eo"
    } ],
    "hashtags" : [ {
      "text" : "eh13",
      "indices" : [ 45, 50 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "318047984883482626",
  "text" : "Modernste Mustererkennung im Nixdorf-Museum. #eh13 http://t.co/lZEfBBD2Eo",
  "id" : 318047984883482626,
  "created_at" : "Sat Mar 30 17:12:03 +0000 2013",
  "user" : {
    "name" : "Felix",
    "screen_name" : "nicidienase",
    "protected" : false,
    "id_str" : "22396883",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3125784966/8223a4c5c9535be22d15c82ec829c2df_normal.jpeg",
    "id" : 22396883,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u02C1\u02DA\u1D25\u02DA\u02C0 ",
      "screen_name" : "nanooq_",
      "indices" : [ 0, 8 ],
      "id_str" : "589231398",
      "id" : 589231398
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "eh13",
      "indices" : [ 29, 34 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "317583316062703616",
  "in_reply_to_user_id" : 589231398,
  "text" : "@nanooq_ ETA in Siegen 12:42 #eh13",
  "id" : 317583316062703616,
  "created_at" : "Fri Mar 29 10:25:37 +0000 2013",
  "in_reply_to_screen_name" : "nanooq_",
  "in_reply_to_user_id_str" : "589231398",
  "user" : {
    "name" : "Felix",
    "screen_name" : "nicidienase",
    "protected" : false,
    "id_str" : "22396883",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3125784966/8223a4c5c9535be22d15c82ec829c2df_normal.jpeg",
    "id" : 22396883,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.tweetlanes.com\" rel=\"nofollow\">Tweet Lanes</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Stephen Fry",
      "screen_name" : "stephenfry",
      "indices" : [ 3, 14 ],
      "id_str" : "15439395",
      "id" : 15439395
    }, {
      "name" : "RHINO",
      "screen_name" : "russmilleruk",
      "indices" : [ 19, 32 ],
      "id_str" : "79114759",
      "id" : 79114759
    } ],
    "media" : [ {
      "expanded_url" : "http://twitter.com/russmilleruk/status/317080463980240897/photo/1",
      "indices" : [ 34, 56 ],
      "url" : "http://t.co/kC0RtSfdPU",
      "media_url" : "http://pbs.twimg.com/media/BGZ_AIVCIAAU7Rg.jpg",
      "id_str" : "317080463988629504",
      "id" : 317080463988629504,
      "media_url_https" : "https://pbs.twimg.com/media/BGZ_AIVCIAAU7Rg.jpg",
      "sizes" : [ {
        "h" : 436,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 480,
        "resize" : "fit",
        "w" : 374
      }, {
        "h" : 480,
        "resize" : "fit",
        "w" : 374
      }, {
        "h" : 480,
        "resize" : "fit",
        "w" : 374
      } ],
      "display_url" : "pic.twitter.com/kC0RtSfdPU"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "317269624704081920",
  "text" : "RT @stephenfry: RT @russmilleruk: http://t.co/kC0RtSfdPU",
  "retweeted_status" : {
    "source" : "<a href=\"http://tapbots.com/tweetbot\" rel=\"nofollow\">Tweetbot for iOS</a>",
    "entities" : {
      "user_mentions" : [ {
        "name" : "RHINO",
        "screen_name" : "russmilleruk",
        "indices" : [ 3, 16 ],
        "id_str" : "79114759",
        "id" : 79114759
      } ],
      "media" : [ {
        "expanded_url" : "http://twitter.com/russmilleruk/status/317080463980240897/photo/1",
        "indices" : [ 18, 40 ],
        "url" : "http://t.co/kC0RtSfdPU",
        "media_url" : "http://pbs.twimg.com/media/BGZ_AIVCIAAU7Rg.jpg",
        "id_str" : "317080463988629504",
        "id" : 317080463988629504,
        "media_url_https" : "https://pbs.twimg.com/media/BGZ_AIVCIAAU7Rg.jpg",
        "sizes" : [ {
          "h" : 436,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 480,
          "resize" : "fit",
          "w" : 374
        }, {
          "h" : 480,
          "resize" : "fit",
          "w" : 374
        }, {
          "h" : 480,
          "resize" : "fit",
          "w" : 374
        } ],
        "display_url" : "pic.twitter.com/kC0RtSfdPU"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : {
    },
    "id_str" : "317080895989370882",
    "text" : "RT @russmilleruk: http://t.co/kC0RtSfdPU",
    "id" : 317080895989370882,
    "created_at" : "Thu Mar 28 01:09:11 +0000 2013",
    "user" : {
      "name" : "Stephen Fry",
      "screen_name" : "stephenfry",
      "protected" : false,
      "id_str" : "15439395",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/3435690052/c87ea9034f1fca7ef255385dd932b716_normal.png",
      "id" : 15439395,
      "verified" : true
    }
  },
  "id" : 317269624704081920,
  "created_at" : "Thu Mar 28 13:39:07 +0000 2013",
  "user" : {
    "name" : "Felix",
    "screen_name" : "nicidienase",
    "protected" : false,
    "id_str" : "22396883",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3125784966/8223a4c5c9535be22d15c82ec829c2df_normal.jpeg",
    "id" : 22396883,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "316823911088136193",
  "text" : "Wenn man beim BDSG einen Buchstaben ver\u00E4ndert hei\u00DFt es BDSM.",
  "id" : 316823911088136193,
  "created_at" : "Wed Mar 27 08:08:01 +0000 2013",
  "user" : {
    "name" : "Felix",
    "screen_name" : "nicidienase",
    "protected" : false,
    "id_str" : "22396883",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3125784966/8223a4c5c9535be22d15c82ec829c2df_normal.jpeg",
    "id" : 22396883,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 48, 70 ],
      "url" : "http://t.co/MhwIy6cTRa",
      "expanded_url" : "http://memegenerator.net/instance/36661472",
      "display_url" : "memegenerator.net/instance/36661\u2026"
    } ]
  },
  "geo" : {
  },
  "id_str" : "316461898327552001",
  "text" : "Arrrrg. Hochschul-WLAN why u soo unusably slow? http://t.co/MhwIy6cTRa",
  "id" : 316461898327552001,
  "created_at" : "Tue Mar 26 08:09:30 +0000 2013",
  "user" : {
    "name" : "Felix",
    "screen_name" : "nicidienase",
    "protected" : false,
    "id_str" : "22396883",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3125784966/8223a4c5c9535be22d15c82ec829c2df_normal.jpeg",
    "id" : 22396883,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "*andy",
      "screen_name" : "derGeruhn",
      "indices" : [ 0, 10 ],
      "id_str" : "936437276",
      "id" : 936437276
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "316145629426491392",
  "geo" : {
  },
  "id_str" : "316166895982227456",
  "in_reply_to_user_id" : 936437276,
  "text" : "@derGeruhn jaja, OH",
  "id" : 316166895982227456,
  "in_reply_to_status_id" : 316145629426491392,
  "created_at" : "Mon Mar 25 12:37:16 +0000 2013",
  "in_reply_to_screen_name" : "derGeruhn",
  "in_reply_to_user_id_str" : "936437276",
  "user" : {
    "name" : "Felix",
    "screen_name" : "nicidienase",
    "protected" : false,
    "id_str" : "22396883",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3125784966/8223a4c5c9535be22d15c82ec829c2df_normal.jpeg",
    "id" : 22396883,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.tweetlanes.com\" rel=\"nofollow\">Tweet Lanes</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Marcel",
      "screen_name" : "xartas",
      "indices" : [ 0, 7 ],
      "id_str" : "14274086",
      "id" : 14274086
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "315960547969482753",
  "geo" : {
  },
  "id_str" : "316146789940088833",
  "in_reply_to_user_id" : 14274086,
  "text" : "@xartas I link both, but they just don't fit together.",
  "id" : 316146789940088833,
  "in_reply_to_status_id" : 315960547969482753,
  "created_at" : "Mon Mar 25 11:17:23 +0000 2013",
  "in_reply_to_screen_name" : "xartas",
  "in_reply_to_user_id_str" : "14274086",
  "user" : {
    "name" : "Felix",
    "screen_name" : "nicidienase",
    "protected" : false,
    "id_str" : "22396883",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3125784966/8223a4c5c9535be22d15c82ec829c2df_normal.jpeg",
    "id" : 22396883,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.tweetlanes.com\" rel=\"nofollow\">Tweet Lanes</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Patrick Willms",
      "screen_name" : "patsbin",
      "indices" : [ 3, 11 ],
      "id_str" : "55035973",
      "id" : 55035973
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 19, 42 ],
      "url" : "https://t.co/wtZaX9vvjM",
      "expanded_url" : "https://lh3.googleusercontent.com/-NJ2Pqxju8lM/UU5psKumIvI/AAAAAAAAWwU/pSqb75suadQ/s640/geekprod.png",
      "display_url" : "lh3.googleusercontent.com/-NJ2Pqxju8lM/U\u2026"
    } ]
  },
  "geo" : {
  },
  "id_str" : "316092865245745153",
  "text" : "RT @patsbin: True. https://t.co/wtZaX9vvjM",
  "retweeted_status" : {
    "source" : "web",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 6, 29 ],
        "url" : "https://t.co/wtZaX9vvjM",
        "expanded_url" : "https://lh3.googleusercontent.com/-NJ2Pqxju8lM/UU5psKumIvI/AAAAAAAAWwU/pSqb75suadQ/s640/geekprod.png",
        "display_url" : "lh3.googleusercontent.com/-NJ2Pqxju8lM/U\u2026"
      } ]
    },
    "geo" : {
    },
    "id_str" : "315826111751790592",
    "text" : "True. https://t.co/wtZaX9vvjM",
    "id" : 315826111751790592,
    "created_at" : "Sun Mar 24 14:03:07 +0000 2013",
    "user" : {
      "name" : "Patrick Willms",
      "screen_name" : "patsbin",
      "protected" : false,
      "id_str" : "55035973",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/1416960338/P1030417_small_normal.jpeg",
      "id" : 55035973,
      "verified" : false
    }
  },
  "id" : 316092865245745153,
  "created_at" : "Mon Mar 25 07:43:06 +0000 2013",
  "user" : {
    "name" : "Felix",
    "screen_name" : "nicidienase",
    "protected" : false,
    "id_str" : "22396883",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3125784966/8223a4c5c9535be22d15c82ec829c2df_normal.jpeg",
    "id" : 22396883,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "315957651789979648",
  "text" : "Aaaaaaah! Einmal beim Firefox \u00F6ffnen verklickt und alle Tabs sind weg!",
  "id" : 315957651789979648,
  "created_at" : "Sun Mar 24 22:45:49 +0000 2013",
  "user" : {
    "name" : "Felix",
    "screen_name" : "nicidienase",
    "protected" : false,
    "id_str" : "22396883",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3125784966/8223a4c5c9535be22d15c82ec829c2df_normal.jpeg",
    "id" : 22396883,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.tweetlanes.com\" rel=\"nofollow\">Tweet Lanes</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Die Wissensbox",
      "screen_name" : "Wissensbox",
      "indices" : [ 43, 54 ],
      "id_str" : "72870463",
      "id" : 72870463
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "313356773878812672",
  "text" : "Und der Rest hat noch nie Schnee gesehen? \"@Wissensbox: 58 % aller M\u00E4nner haben schonmal versucht, ihren Namen in den Schnee zu pinkeln.\"",
  "id" : 313356773878812672,
  "created_at" : "Sun Mar 17 18:30:51 +0000 2013",
  "user" : {
    "name" : "Felix",
    "screen_name" : "nicidienase",
    "protected" : false,
    "id_str" : "22396883",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3125784966/8223a4c5c9535be22d15c82ec829c2df_normal.jpeg",
    "id" : 22396883,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.tweetlanes.com\" rel=\"nofollow\">Tweet Lanes</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "andreasdotorg",
      "screen_name" : "andreasdotorg",
      "indices" : [ 3, 17 ],
      "id_str" : "14285735",
      "id" : 14285735
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "313356097937354752",
  "text" : "RT @andreasdotorg: Informatik-Studenten exploiten Bug in Benotungsschema: keiner schreibt Klausur, alle bekommen Bestnote. http://t.co/I ...",
  "retweeted_status" : {
    "source" : "<a href=\"http://www.tweetdeck.com\" rel=\"nofollow\">TweetDeck</a>",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 104, 126 ],
        "url" : "http://t.co/IaEZLF2QID",
        "expanded_url" : "http://boingboing.net/2013/02/19/students-get-class-wide-as-by.html",
        "display_url" : "boingboing.net/2013/02/19/stu\u2026"
      } ]
    },
    "geo" : {
    },
    "id_str" : "313234137177800704",
    "text" : "Informatik-Studenten exploiten Bug in Benotungsschema: keiner schreibt Klausur, alle bekommen Bestnote. http://t.co/IaEZLF2QID",
    "id" : 313234137177800704,
    "created_at" : "Sun Mar 17 10:23:32 +0000 2013",
    "user" : {
      "name" : "andreasdotorg",
      "screen_name" : "andreasdotorg",
      "protected" : false,
      "id_str" : "14285735",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/2857263613/87df849b9667509c53079d7bb7fd0b31_normal.jpeg",
      "id" : 14285735,
      "verified" : false
    }
  },
  "id" : 313356097937354752,
  "created_at" : "Sun Mar 17 18:28:10 +0000 2013",
  "user" : {
    "name" : "Felix",
    "screen_name" : "nicidienase",
    "protected" : false,
    "id_str" : "22396883",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3125784966/8223a4c5c9535be22d15c82ec829c2df_normal.jpeg",
    "id" : 22396883,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http://twitter.com/nicidienase/status/313006173215391744/photo/1",
      "indices" : [ 32, 54 ],
      "url" : "http://t.co/vwonHlEMxh",
      "media_url" : "http://pbs.twimg.com/media/BFgFdMdCAAES_KD.jpg",
      "id_str" : "313006173219586049",
      "id" : 313006173219586049,
      "media_url_https" : "https://pbs.twimg.com/media/BFgFdMdCAAES_KD.jpg",
      "sizes" : [ {
        "h" : 450,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 1920,
        "resize" : "fit",
        "w" : 2560
      }, {
        "h" : 768,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 255,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com/vwonHlEMxh"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "313006173215391744",
  "text" : "Mmh. Frisch gebackene Brownies. http://t.co/vwonHlEMxh",
  "id" : 313006173215391744,
  "created_at" : "Sat Mar 16 19:17:42 +0000 2013",
  "user" : {
    "name" : "Felix",
    "screen_name" : "nicidienase",
    "protected" : false,
    "id_str" : "22396883",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3125784966/8223a4c5c9535be22d15c82ec829c2df_normal.jpeg",
    "id" : 22396883,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.tweetlanes.com\" rel=\"nofollow\">Tweet Lanes</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "312939568146046977",
  "text" : "Langsam sollte ich mal fr\u00FChst\u00FCcken...",
  "id" : 312939568146046977,
  "created_at" : "Sat Mar 16 14:53:01 +0000 2013",
  "user" : {
    "name" : "Felix",
    "screen_name" : "nicidienase",
    "protected" : false,
    "id_str" : "22396883",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3125784966/8223a4c5c9535be22d15c82ec829c2df_normal.jpeg",
    "id" : 22396883,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Eva ",
      "screen_name" : "SchokoPralini",
      "indices" : [ 0, 14 ],
      "id_str" : "575695094",
      "id" : 575695094
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "309229168254672896",
  "geo" : {
  },
  "id_str" : "309245305017229312",
  "in_reply_to_user_id" : 575695094,
  "text" : "@SchokoPralini Ich huste auch noch bissl rum. Aber der Schnupfen und die Kopfschmerzen sind wieder weg.",
  "id" : 309245305017229312,
  "in_reply_to_status_id" : 309229168254672896,
  "created_at" : "Wed Mar 06 10:13:20 +0000 2013",
  "in_reply_to_screen_name" : "SchokoPralini",
  "in_reply_to_user_id_str" : "575695094",
  "user" : {
    "name" : "Felix",
    "screen_name" : "nicidienase",
    "protected" : false,
    "id_str" : "22396883",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3125784966/8223a4c5c9535be22d15c82ec829c2df_normal.jpeg",
    "id" : 22396883,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.tweetlanes.com\" rel=\"nofollow\">Tweet Lanes</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "ArnePoparne",
      "screen_name" : "ArnePoparne",
      "indices" : [ 3, 15 ],
      "id_str" : "32032195",
      "id" : 32032195
    } ],
    "media" : [ {
      "expanded_url" : "http://twitter.com/ArnePoparne/status/308911247997419521/photo/1",
      "indices" : [ 90, 112 ],
      "url" : "http://t.co/kuRJOnO3ox",
      "media_url" : "http://pbs.twimg.com/media/BEl5JLSCQAAaJdk.jpg",
      "id_str" : "308911248005808128",
      "id" : 308911248005808128,
      "media_url_https" : "https://pbs.twimg.com/media/BEl5JLSCQAAaJdk.jpg",
      "sizes" : [ {
        "h" : 191,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 314,
        "resize" : "fit",
        "w" : 559
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 314,
        "resize" : "fit",
        "w" : 559
      }, {
        "h" : 314,
        "resize" : "fit",
        "w" : 559
      } ],
      "display_url" : "pic.twitter.com/kuRJOnO3ox"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "309120197829197824",
  "text" : "RT @ArnePoparne: Die Beschriftung lautet: \u201EPommerntourist\u201C\u2026.. und dann geht die T\u00FCre auf! http://t.co/kuRJOnO3ox",
  "retweeted_status" : {
    "source" : "<a href=\"http://tapbots.com/software/tweetbot/mac\" rel=\"nofollow\">Tweetbot for Mac</a>",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "http://twitter.com/ArnePoparne/status/308911247997419521/photo/1",
        "indices" : [ 73, 95 ],
        "url" : "http://t.co/kuRJOnO3ox",
        "media_url" : "http://pbs.twimg.com/media/BEl5JLSCQAAaJdk.jpg",
        "id_str" : "308911248005808128",
        "id" : 308911248005808128,
        "media_url_https" : "https://pbs.twimg.com/media/BEl5JLSCQAAaJdk.jpg",
        "sizes" : [ {
          "h" : 191,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 314,
          "resize" : "fit",
          "w" : 559
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 314,
          "resize" : "fit",
          "w" : 559
        }, {
          "h" : 314,
          "resize" : "fit",
          "w" : 559
        } ],
        "display_url" : "pic.twitter.com/kuRJOnO3ox"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : {
    },
    "id_str" : "308911247997419521",
    "text" : "Die Beschriftung lautet: \u201EPommerntourist\u201C\u2026.. und dann geht die T\u00FCre auf! http://t.co/kuRJOnO3ox",
    "id" : 308911247997419521,
    "created_at" : "Tue Mar 05 12:05:55 +0000 2013",
    "user" : {
      "name" : "ArnePoparne",
      "screen_name" : "ArnePoparne",
      "protected" : false,
      "id_str" : "32032195",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/3064835797/5555e3b6d0fe595057b68c9c1c5d1a04_normal.jpeg",
      "id" : 32032195,
      "verified" : false
    }
  },
  "id" : 309120197829197824,
  "created_at" : "Wed Mar 06 01:56:12 +0000 2013",
  "user" : {
    "name" : "Felix",
    "screen_name" : "nicidienase",
    "protected" : false,
    "id_str" : "22396883",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3125784966/8223a4c5c9535be22d15c82ec829c2df_normal.jpeg",
    "id" : 22396883,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Eva ",
      "screen_name" : "SchokoPralini",
      "indices" : [ 0, 14 ],
      "id_str" : "575695094",
      "id" : 575695094
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "309018875515793408",
  "geo" : {
  },
  "id_str" : "309116210920968194",
  "in_reply_to_user_id" : 575695094,
  "text" : "@SchokoPralini Jo. Kurriere grade meine Erk\u00E4ltung vollendet aus und helfe beim Programmiervorkurs f\u00FCr die Verstie\u00DF.",
  "id" : 309116210920968194,
  "in_reply_to_status_id" : 309018875515793408,
  "created_at" : "Wed Mar 06 01:40:22 +0000 2013",
  "in_reply_to_screen_name" : "SchokoPralini",
  "in_reply_to_user_id_str" : "575695094",
  "user" : {
    "name" : "Felix",
    "screen_name" : "nicidienase",
    "protected" : false,
    "id_str" : "22396883",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3125784966/8223a4c5c9535be22d15c82ec829c2df_normal.jpeg",
    "id" : 22396883,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.tweetlanes.com\" rel=\"nofollow\">Tweet Lanes</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Eva ",
      "screen_name" : "SchokoPralini",
      "indices" : [ 0, 14 ],
      "id_str" : "575695094",
      "id" : 575695094
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "306896190253957120",
  "geo" : {
  },
  "id_str" : "307283115699740674",
  "in_reply_to_user_id" : 575695094,
  "text" : "@SchokoPralini Lief das Probearbeiten gut?",
  "id" : 307283115699740674,
  "in_reply_to_status_id" : 306896190253957120,
  "created_at" : "Fri Mar 01 00:16:18 +0000 2013",
  "in_reply_to_screen_name" : "SchokoPralini",
  "in_reply_to_user_id_str" : "575695094",
  "user" : {
    "name" : "Felix",
    "screen_name" : "nicidienase",
    "protected" : false,
    "id_str" : "22396883",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3125784966/8223a4c5c9535be22d15c82ec829c2df_normal.jpeg",
    "id" : 22396883,
    "verified" : false
  }
} ]