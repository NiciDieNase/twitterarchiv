Grailbird.data.tweets_2011_08 = 
 [ {
  "source" : "<a href=\"http://getspaz.com\" rel=\"nofollow\">Spaz</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "106841682204569600",
  "text" : "Grade barfu\u00DF durch den Gewitterregen heimgelaufen :)",
  "id" : 106841682204569600,
  "created_at" : "Thu Aug 25 21:33:36 +0000 2011",
  "user" : {
    "name" : "Felix",
    "screen_name" : "nicidienase",
    "protected" : false,
    "id_str" : "22396883",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3125784966/8223a4c5c9535be22d15c82ec829c2df_normal.jpeg",
    "id" : 22396883,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http://twitter.com/nicidienase/status/104719959053180929/photo/1",
      "indices" : [ 118, 137 ],
      "url" : "http://t.co/w8rRR9u",
      "media_url" : "http://pbs.twimg.com/media/AXQKP3hCIAIwoPI.png",
      "id_str" : "104719959053180930",
      "id" : 104719959053180930,
      "media_url_https" : "https://pbs.twimg.com/media/AXQKP3hCIAIwoPI.png",
      "sizes" : [ {
        "h" : 352,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 600,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 199,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 600,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      } ],
      "display_url" : "pic.twitter.com/w8rRR9u"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "104719959053180929",
  "text" : "Auf meinem Netbook l\u00E4uft jetzt Arch, und es bis auf ein paar Kleinigkeiten geht auch schon alles was ich gerne h\u00E4tte. http://t.co/w8rRR9u",
  "id" : 104719959053180929,
  "created_at" : "Sat Aug 20 01:02:40 +0000 2011",
  "user" : {
    "name" : "Felix",
    "screen_name" : "nicidienase",
    "protected" : false,
    "id_str" : "22396883",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3125784966/8223a4c5c9535be22d15c82ec829c2df_normal.jpeg",
    "id" : 22396883,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.bravenewcode.com/products/wordtwit\" rel=\"nofollow\">WordTwit Plugin</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 32, 51 ],
      "url" : "http://t.co/GpCk8XR",
      "expanded_url" : "http://tinyurl.com/3usy9uo",
      "display_url" : "tinyurl.com/3usy9uo"
    } ]
  },
  "geo" : {
  },
  "id_str" : "104692847680299008",
  "text" : "NewBlogpost: CCCamp-Ohrw\u00FCrmer - http://t.co/GpCk8XR",
  "id" : 104692847680299008,
  "created_at" : "Fri Aug 19 23:14:54 +0000 2011",
  "user" : {
    "name" : "Felix",
    "screen_name" : "nicidienase",
    "protected" : false,
    "id_str" : "22396883",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3125784966/8223a4c5c9535be22d15c82ec829c2df_normal.jpeg",
    "id" : 22396883,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.bravenewcode.com/products/wordtwit\" rel=\"nofollow\">WordTwit Plugin</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 47, 66 ],
      "url" : "http://t.co/MwvGvjq",
      "expanded_url" : "http://tinyurl.com/3ls83fv",
      "display_url" : "tinyurl.com/3ls83fv"
    } ]
  },
  "geo" : {
  },
  "id_str" : "103179170087055360",
  "text" : "Neuer Blog Beitrag, Awesome Daft Punk Mashup - http://t.co/MwvGvjq",
  "id" : 103179170087055360,
  "created_at" : "Mon Aug 15 19:00:05 +0000 2011",
  "user" : {
    "name" : "Felix",
    "screen_name" : "nicidienase",
    "protected" : false,
    "id_str" : "22396883",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3125784966/8223a4c5c9535be22d15c82ec829c2df_normal.jpeg",
    "id" : 22396883,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://getspaz.com\" rel=\"nofollow\">Spaz</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "cccamp",
      "indices" : [ 39, 46 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "100572905150234624",
  "text" : "Ausfahrt Finowfurt, gleich sind wir am #cccamp",
  "id" : 100572905150234624,
  "created_at" : "Mon Aug 08 14:23:43 +0000 2011",
  "user" : {
    "name" : "Felix",
    "screen_name" : "nicidienase",
    "protected" : false,
    "id_str" : "22396883",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3125784966/8223a4c5c9535be22d15c82ec829c2df_normal.jpeg",
    "id" : 22396883,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://getspaz.com\" rel=\"nofollow\">Spaz</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "cccamp",
      "indices" : [ 20, 27 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "100540891088957440",
  "text" : "Noch gute 200km zum #cccamp ETA kurz nach vier",
  "id" : 100540891088957440,
  "created_at" : "Mon Aug 08 12:16:31 +0000 2011",
  "user" : {
    "name" : "Felix",
    "screen_name" : "nicidienase",
    "protected" : false,
    "id_str" : "22396883",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3125784966/8223a4c5c9535be22d15c82ec829c2df_normal.jpeg",
    "id" : 22396883,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://getspaz.com\" rel=\"nofollow\">Spaz</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "cccamp",
      "indices" : [ 29, 36 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "100521915264925696",
  "text" : "Halbzeit! Noch 350km bis zum #cccamp",
  "id" : 100521915264925696,
  "created_at" : "Mon Aug 08 11:01:06 +0000 2011",
  "user" : {
    "name" : "Felix",
    "screen_name" : "nicidienase",
    "protected" : false,
    "id_str" : "22396883",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3125784966/8223a4c5c9535be22d15c82ec829c2df_normal.jpeg",
    "id" : 22396883,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://getspaz.com\" rel=\"nofollow\">Spaz</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "cccamp",
      "indices" : [ 33, 40 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "100504148969132032",
  "text" : "Kurz hinter N\u00FCrnberg, noch 500km #cccamp",
  "id" : 100504148969132032,
  "created_at" : "Mon Aug 08 09:50:31 +0000 2011",
  "user" : {
    "name" : "Felix",
    "screen_name" : "nicidienase",
    "protected" : false,
    "id_str" : "22396883",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3125784966/8223a4c5c9535be22d15c82ec829c2df_normal.jpeg",
    "id" : 22396883,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://getspaz.com\" rel=\"nofollow\">Spaz</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "cccamp",
      "indices" : [ 9, 16 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "100470647586684928",
  "text" : "Abfahrt! #cccamp here we come. ETA 7h",
  "id" : 100470647586684928,
  "created_at" : "Mon Aug 08 07:37:23 +0000 2011",
  "user" : {
    "name" : "Felix",
    "screen_name" : "nicidienase",
    "protected" : false,
    "id_str" : "22396883",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3125784966/8223a4c5c9535be22d15c82ec829c2df_normal.jpeg",
    "id" : 22396883,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://getspaz.com\" rel=\"nofollow\">Spaz</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "trouble?",
      "screen_name" : "Eemily3",
      "indices" : [ 0, 8 ],
      "id_str" : "867481477",
      "id" : 867481477
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "97828028750639105",
  "text" : "@Eemily3 In meinem auch net ...",
  "id" : 97828028750639105,
  "created_at" : "Mon Aug 01 00:36:34 +0000 2011",
  "user" : {
    "name" : "Felix",
    "screen_name" : "nicidienase",
    "protected" : false,
    "id_str" : "22396883",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3125784966/8223a4c5c9535be22d15c82ec829c2df_normal.jpeg",
    "id" : 22396883,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://getspaz.com\" rel=\"nofollow\">Spaz</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Henryk Pl\u00F6tz",
      "screen_name" : "henrykploetz",
      "indices" : [ 3, 16 ],
      "id_str" : "241125767",
      "id" : 241125767
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "97825909716955138",
  "text" : "RT @henrykploetz: +++ EILMELDUNG +++ Nationaler Notstand ausgerufen +++ Das Undenkbare geschieht +++ Fefe's Blog ist down +++",
  "retweeted_status" : {
    "source" : "web",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : {
    },
    "id_str" : "97707048845836288",
    "text" : "+++ EILMELDUNG +++ Nationaler Notstand ausgerufen +++ Das Undenkbare geschieht +++ Fefe's Blog ist down +++",
    "id" : 97707048845836288,
    "created_at" : "Sun Jul 31 16:35:50 +0000 2011",
    "user" : {
      "name" : "Henryk Pl\u00F6tz",
      "screen_name" : "henrykploetz",
      "protected" : false,
      "id_str" : "241125767",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/2161738112/henryk_2012_april_normal.jpg",
      "id" : 241125767,
      "verified" : false
    }
  },
  "id" : 97825909716955138,
  "created_at" : "Mon Aug 01 00:28:09 +0000 2011",
  "user" : {
    "name" : "Felix",
    "screen_name" : "nicidienase",
    "protected" : false,
    "id_str" : "22396883",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3125784966/8223a4c5c9535be22d15c82ec829c2df_normal.jpeg",
    "id" : 22396883,
    "verified" : false
  }
} ]