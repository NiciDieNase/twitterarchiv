Grailbird.data.tweets_2011_11 = 
 [ {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "139001835477417984",
  "text" : "Eigentlich bin ich ja ein sehr friedlicher Mensch, aber Step7 ruft in mir das starke Bed\u00FCrfniss hervor Dinge zu zerst\u00F6ren!",
  "id" : 139001835477417984,
  "created_at" : "Tue Nov 22 15:26:34 +0000 2011",
  "user" : {
    "name" : "Felix",
    "screen_name" : "nicidienase",
    "protected" : false,
    "id_str" : "22396883",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3125784966/8223a4c5c9535be22d15c82ec829c2df_normal.jpeg",
    "id" : 22396883,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://getspaz.com\" rel=\"nofollow\">Spaz</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "m.",
      "screen_name" : "ohaimareiki",
      "indices" : [ 3, 15 ],
      "id_str" : "14732096",
      "id" : 14732096
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "138272488818880512",
  "text" : "RT @ohaimareiki: liebe m\u00E4dchen. dumm ist niemals s\u00FC\u00DF. danke f\u00FCr die aufmerksamkeit.",
  "retweeted_status" : {
    "source" : "web",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : {
    },
    "id_str" : "138240866635628544",
    "text" : "liebe m\u00E4dchen. dumm ist niemals s\u00FC\u00DF. danke f\u00FCr die aufmerksamkeit.",
    "id" : 138240866635628544,
    "created_at" : "Sun Nov 20 13:02:45 +0000 2011",
    "user" : {
      "name" : "m.",
      "screen_name" : "ohaimareiki",
      "protected" : false,
      "id_str" : "14732096",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/3100722026/475d6897ce8c06c7cd73742c8fae872f_normal.jpeg",
      "id" : 14732096,
      "verified" : false
    }
  },
  "id" : 138272488818880512,
  "created_at" : "Sun Nov 20 15:08:24 +0000 2011",
  "user" : {
    "name" : "Felix",
    "screen_name" : "nicidienase",
    "protected" : false,
    "id_str" : "22396883",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3125784966/8223a4c5c9535be22d15c82ec829c2df_normal.jpeg",
    "id" : 22396883,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://getspaz.com\" rel=\"nofollow\">Spaz HD for webOS</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "AndreasMarcKlingler",
      "screen_name" : "AndreasKlingler",
      "indices" : [ 3, 19 ],
      "id_str" : "77751090",
      "id" : 77751090
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "137557280030859264",
  "text" : "RT @AndreasKlingler: \"Ihr d\u00FCrft nicht in den Konferenzr\u00E4umen schlafen\" - \"Gilt das nur nachts?\" - \"Ja. Tags\u00FCber hei\u00DFt das Vorlesung und  ...",
  "retweeted_status" : {
    "source" : "<a href=\"http://www.echofon.com/\" rel=\"nofollow\">Echofon</a>",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "kif395",
        "indices" : [ 129, 136 ]
      } ],
      "urls" : [ ]
    },
    "geo" : {
    },
    "id_str" : "136896999487307776",
    "text" : "\"Ihr d\u00FCrft nicht in den Konferenzr\u00E4umen schlafen\" - \"Gilt das nur nachts?\" - \"Ja. Tags\u00FCber hei\u00DFt das Vorlesung und ist halt so.\" #kif395",
    "id" : 136896999487307776,
    "created_at" : "Wed Nov 16 20:02:42 +0000 2011",
    "user" : {
      "name" : "AndreasMarcKlingler",
      "screen_name" : "AndreasKlingler",
      "protected" : false,
      "id_str" : "77751090",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/710261212/profilbild2_fotokopie_normal.png",
      "id" : 77751090,
      "verified" : false
    }
  },
  "id" : 137557280030859264,
  "created_at" : "Fri Nov 18 15:46:25 +0000 2011",
  "user" : {
    "name" : "Felix",
    "screen_name" : "nicidienase",
    "protected" : false,
    "id_str" : "22396883",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3125784966/8223a4c5c9535be22d15c82ec829c2df_normal.jpeg",
    "id" : 22396883,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://getspaz.com\" rel=\"nofollow\">Spaz HD for webOS</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "DHL Paket",
      "screen_name" : "DHLPaket",
      "indices" : [ 0, 9 ],
      "id_str" : "42414621",
      "id" : 42414621
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "136491715392569345",
  "in_reply_to_user_id" : 42414621,
  "text" : "@DHLPaket WTF \"[..]entspricht nicht den Vertragsbedingungen\" kurz vorm Ziel und jetzt geht das Paket zur\u00FCck?",
  "id" : 136491715392569345,
  "created_at" : "Tue Nov 15 17:12:15 +0000 2011",
  "in_reply_to_screen_name" : "DHLPaket",
  "in_reply_to_user_id_str" : "42414621",
  "user" : {
    "name" : "Felix",
    "screen_name" : "nicidienase",
    "protected" : false,
    "id_str" : "22396883",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3125784966/8223a4c5c9535be22d15c82ec829c2df_normal.jpeg",
    "id" : 22396883,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://getspaz.com\" rel=\"nofollow\">Spaz</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Herr Einspaziert",
      "screen_name" : "maatc",
      "indices" : [ 3, 9 ],
      "id_str" : "39287702",
      "id" : 39287702
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "133582266046754818",
  "text" : "RT @maatc: Hamster in D: ~ 2,9 Mio.\nK\u00E4figfl\u00E4che: \u230040x57cm\nStreu: ca. 2,99\u20AC\n\nBILD-Auflage: ~ 2,9 Mio.\nGr\u00F6\u00DFe: 40x57cm\nPreis: 0,70 \u20AC\n\nDAS E ...",
  "retweeted_status" : {
    "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : {
    },
    "id_str" : "133512657604063232",
    "text" : "Hamster in D: ~ 2,9 Mio.\nK\u00E4figfl\u00E4che: \u230040x57cm\nStreu: ca. 2,99\u20AC\n\nBILD-Auflage: ~ 2,9 Mio.\nGr\u00F6\u00DFe: 40x57cm\nPreis: 0,70 \u20AC\n\nDAS ERKL\u00C4RT ALLES!",
    "id" : 133512657604063232,
    "created_at" : "Mon Nov 07 11:54:32 +0000 2011",
    "user" : {
      "name" : "Herr Einspaziert",
      "screen_name" : "maatc",
      "protected" : false,
      "id_str" : "39287702",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/2822500986/85207062813c5a97a95a48aeeae2eee7_normal.png",
      "id" : 39287702,
      "verified" : false
    }
  },
  "id" : 133582266046754818,
  "created_at" : "Mon Nov 07 16:31:08 +0000 2011",
  "user" : {
    "name" : "Felix",
    "screen_name" : "nicidienase",
    "protected" : false,
    "id_str" : "22396883",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3125784966/8223a4c5c9535be22d15c82ec829c2df_normal.jpeg",
    "id" : 22396883,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://getspaz.com\" rel=\"nofollow\">Spaz</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "li5a",
      "screen_name" : "li5a",
      "indices" : [ 3, 8 ],
      "id_str" : "11712822",
      "id" : 11712822
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "occupy28c3",
      "indices" : [ 56, 67 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "133297042691850240",
  "text" : "RT @li5a: why do 1% of netizens get 99% of the tickets? #occupy28c3",
  "retweeted_status" : {
    "source" : "web",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "occupy28c3",
        "indices" : [ 46, 57 ]
      } ],
      "urls" : [ ]
    },
    "geo" : {
    },
    "id_str" : "133292319385456640",
    "text" : "why do 1% of netizens get 99% of the tickets? #occupy28c3",
    "id" : 133292319385456640,
    "created_at" : "Sun Nov 06 21:19:00 +0000 2011",
    "user" : {
      "name" : "li5a",
      "screen_name" : "li5a",
      "protected" : false,
      "id_str" : "11712822",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/42645812/P1010897_normal.JPG",
      "id" : 11712822,
      "verified" : false
    }
  },
  "id" : 133297042691850240,
  "created_at" : "Sun Nov 06 21:37:46 +0000 2011",
  "user" : {
    "name" : "Felix",
    "screen_name" : "nicidienase",
    "protected" : false,
    "id_str" : "22396883",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3125784966/8223a4c5c9535be22d15c82ec829c2df_normal.jpeg",
    "id" : 22396883,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://getspaz.com\" rel=\"nofollow\">Spaz</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "28C3",
      "indices" : [ 0, 5 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "133288917867839489",
  "text" : "#28C3-Tickets Order Details: \"Status: confirmed\" Yeah!!",
  "id" : 133288917867839489,
  "created_at" : "Sun Nov 06 21:05:29 +0000 2011",
  "user" : {
    "name" : "Felix",
    "screen_name" : "nicidienase",
    "protected" : false,
    "id_str" : "22396883",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3125784966/8223a4c5c9535be22d15c82ec829c2df_normal.jpeg",
    "id" : 22396883,
    "verified" : false
  }
} ]