Grailbird.data.tweets_2011_03 = 
 [ {
  "source" : "<a href=\"http://tweed.pivotallabs.com\" rel=\"nofollow\">Tweed webOS</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 49.007559, 8.408051 ]
  },
  "id_str" : "52865229578715136",
  "text" : "So, Folien sind fertig. Da kann ich morgen mein Tut halten. Jetzt noch kurz unter die Dusche und dann hau ich mich aufs Ohr.",
  "id" : 52865229578715136,
  "created_at" : "Tue Mar 29 22:50:27 +0000 2011",
  "user" : {
    "name" : "Felix",
    "screen_name" : "nicidienase",
    "protected" : false,
    "id_str" : "22396883",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3125784966/8223a4c5c9535be22d15c82ec829c2df_normal.jpeg",
    "id" : 22396883,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "51986085626122240",
  "text" : "So, erste H\u00E4lfte vom Wahldienst is rum. Um 18Uhr gehts weiter mit ausz\u00E4hlen.",
  "id" : 51986085626122240,
  "created_at" : "Sun Mar 27 12:37:03 +0000 2011",
  "user" : {
    "name" : "Felix",
    "screen_name" : "nicidienase",
    "protected" : false,
    "id_str" : "22396883",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3125784966/8223a4c5c9535be22d15c82ec829c2df_normal.jpeg",
    "id" : 22396883,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://tweed.pivotallabs.com\" rel=\"nofollow\">Tweed webOS</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 49.01546, 8.392528 ]
  },
  "id_str" : "50095781239201792",
  "text" : "Und das WLAN is auch schei\u00DFe wie immer. Is eigentlich schon peinlich f\u00FCr die HS, dass das WLAN aufm Congress zuverl\u00E4ssiger is als hier.",
  "id" : 50095781239201792,
  "created_at" : "Tue Mar 22 07:25:39 +0000 2011",
  "user" : {
    "name" : "Felix",
    "screen_name" : "nicidienase",
    "protected" : false,
    "id_str" : "22396883",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3125784966/8223a4c5c9535be22d15c82ec829c2df_normal.jpeg",
    "id" : 22396883,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://tweed.pivotallabs.com\" rel=\"nofollow\">Tweed webOS</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 49.01546, 8.392528 ]
  },
  "id_str" : "50094854008619009",
  "text" : "Die f\u00E4ngt in Mathe ja bei Adam und Eva an, da h\u00E4tte ich echt noch ne Weile schlafen k\u00F6nnen.",
  "id" : 50094854008619009,
  "created_at" : "Tue Mar 22 07:21:58 +0000 2011",
  "user" : {
    "name" : "Felix",
    "screen_name" : "nicidienase",
    "protected" : false,
    "id_str" : "22396883",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3125784966/8223a4c5c9535be22d15c82ec829c2df_normal.jpeg",
    "id" : 22396883,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://tweed.pivotallabs.com\" rel=\"nofollow\">Tweed webOS</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 49.007861, 8.408906 ]
  },
  "id_str" : "49934456491999232",
  "text" : "So heute mittag im Schlosspark gechillt und jetzt geht's noch auf ein paar Bier in die Waldhornbar. Gem\u00FCtlicher Tag heute. :-)",
  "id" : 49934456491999232,
  "created_at" : "Mon Mar 21 20:44:36 +0000 2011",
  "user" : {
    "name" : "Felix",
    "screen_name" : "nicidienase",
    "protected" : false,
    "id_str" : "22396883",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3125784966/8223a4c5c9535be22d15c82ec829c2df_normal.jpeg",
    "id" : 22396883,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://tweed.pivotallabs.com\" rel=\"nofollow\">Tweed webOS</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 49.01546, 8.392528 ]
  },
  "id_str" : "49740317611671554",
  "text" : "Da kommt man einmal p\u00FCnktlich an die HS bevor die Vorlesung anf\u00E4ngt und dann darf man sich in Statistik langweilen.",
  "id" : 49740317611671554,
  "created_at" : "Mon Mar 21 07:53:10 +0000 2011",
  "user" : {
    "name" : "Felix",
    "screen_name" : "nicidienase",
    "protected" : false,
    "id_str" : "22396883",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3125784966/8223a4c5c9535be22d15c82ec829c2df_normal.jpeg",
    "id" : 22396883,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://tweed.pivotallabs.com\" rel=\"nofollow\">Tweed webOS</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Detlef Borchers",
      "screen_name" : "dborch",
      "indices" : [ 3, 10 ],
      "id_str" : "106681773",
      "id" : 106681773
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "48807688930463744",
  "text" : "RT @dborch: \"One sperm cell has 37.5MB of DNA information. A normal ejaculation represents a data transfer of 1587TB in about 3 seconds. ...",
  "retweeted_status" : {
    "source" : "<a href=\"http://www.tweetdeck.com\" rel=\"nofollow\">TweetDeck</a>",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "WWG",
        "indices" : [ 126, 130 ]
      } ],
      "urls" : [ ]
    },
    "geo" : {
    },
    "id_str" : "48799285596258304",
    "text" : "\"One sperm cell has 37.5MB of DNA information. A normal ejaculation represents a data transfer of 1587TB in about 3 seconds.\" #WWG",
    "id" : 48799285596258304,
    "created_at" : "Fri Mar 18 17:33:50 +0000 2011",
    "user" : {
      "name" : "Detlef Borchers",
      "screen_name" : "dborch",
      "protected" : false,
      "id_str" : "106681773",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/643624216/detlef_borchers_normal.jpg",
      "id" : 106681773,
      "verified" : false
    }
  },
  "id" : 48807688930463744,
  "created_at" : "Fri Mar 18 18:07:14 +0000 2011",
  "user" : {
    "name" : "Felix",
    "screen_name" : "nicidienase",
    "protected" : false,
    "id_str" : "22396883",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3125784966/8223a4c5c9535be22d15c82ec829c2df_normal.jpeg",
    "id" : 22396883,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Eve",
      "screen_name" : "ChiisanaIchigo",
      "indices" : [ 0, 15 ],
      "id_str" : "187553346",
      "id" : 187553346
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "48763441334337536",
  "geo" : {
  },
  "id_str" : "48764766285606912",
  "in_reply_to_user_id" : 187553346,
  "text" : "@ChiisanaIchigo Ich krieg ja auch was daf\u00FCr *geldgierigdieh\u00E4ndereib*",
  "id" : 48764766285606912,
  "in_reply_to_status_id" : 48763441334337536,
  "created_at" : "Fri Mar 18 15:16:40 +0000 2011",
  "in_reply_to_screen_name" : "ChiisanaIchigo",
  "in_reply_to_user_id_str" : "187553346",
  "user" : {
    "name" : "Felix",
    "screen_name" : "nicidienase",
    "protected" : false,
    "id_str" : "22396883",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3125784966/8223a4c5c9535be22d15c82ec829c2df_normal.jpeg",
    "id" : 22396883,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "48762751169994752",
  "text" : "Hab heute morgen den HiWi-Vertrag abgegeben, darf diese Semester die Ersties qu\u00E4len, \u00E4\u00E4\u00E4h ich meine ihnen Info1 erkl\u00E4ren",
  "id" : 48762751169994752,
  "created_at" : "Fri Mar 18 15:08:40 +0000 2011",
  "user" : {
    "name" : "Felix",
    "screen_name" : "nicidienase",
    "protected" : false,
    "id_str" : "22396883",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3125784966/8223a4c5c9535be22d15c82ec829c2df_normal.jpeg",
    "id" : 22396883,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://tweed.pivotallabs.com\" rel=\"nofollow\">Tweed webOS</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Eve",
      "screen_name" : "ChiisanaIchigo",
      "indices" : [ 0, 15 ],
      "id_str" : "187553346",
      "id" : 187553346
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "42939968364101632",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 48.899633, 8.685044 ]
  },
  "id_str" : "43052309621645313",
  "in_reply_to_user_id" : 187553346,
  "text" : "@ChiisanaIchigo Wie w\u00E4rs mit nem Aufr\u00E4umroboter? Ich w\u00FCrd auch einen nehmen.",
  "id" : 43052309621645313,
  "in_reply_to_status_id" : 42939968364101632,
  "created_at" : "Wed Mar 02 20:57:25 +0000 2011",
  "in_reply_to_screen_name" : "ChiisanaIchigo",
  "in_reply_to_user_id_str" : "187553346",
  "user" : {
    "name" : "Felix",
    "screen_name" : "nicidienase",
    "protected" : false,
    "id_str" : "22396883",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3125784966/8223a4c5c9535be22d15c82ec829c2df_normal.jpeg",
    "id" : 22396883,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://tweed.pivotallabs.com\" rel=\"nofollow\">Tweed webOS</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sexy Showbiz McK\u00E4se",
      "screen_name" : "Einstueckkaese",
      "indices" : [ 3, 18 ],
      "id_str" : "62560260",
      "id" : 62560260
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "43017143704494080",
  "text" : "RT @Einstueckkaese: Wer das, was Guttenberg gemacht hat, immer noch \"Schummeln\" nennt, bezeichnet auch Krieg als \"kleine Kabbelei\".",
  "retweeted_status" : {
    "source" : "<a href=\"http://www.nambu.com/\" rel=\"nofollow\">Nambu</a>",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : {
    },
    "id_str" : "42643098572029952",
    "text" : "Wer das, was Guttenberg gemacht hat, immer noch \"Schummeln\" nennt, bezeichnet auch Krieg als \"kleine Kabbelei\".",
    "id" : 42643098572029952,
    "created_at" : "Tue Mar 01 17:51:21 +0000 2011",
    "user" : {
      "name" : "Sexy Showbiz McK\u00E4se",
      "screen_name" : "Einstueckkaese",
      "protected" : false,
      "id_str" : "62560260",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/2170303313/C2EB8157-9399-4DE0-B6BF-91112117A790_normal",
      "id" : 62560260,
      "verified" : false
    }
  },
  "id" : 43017143704494080,
  "created_at" : "Wed Mar 02 18:37:40 +0000 2011",
  "user" : {
    "name" : "Felix",
    "screen_name" : "nicidienase",
    "protected" : false,
    "id_str" : "22396883",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3125784966/8223a4c5c9535be22d15c82ec829c2df_normal.jpeg",
    "id" : 22396883,
    "verified" : false
  }
} ]