Grailbird.data.tweets_2011_10 = 
 [ {
  "source" : "<a href=\"http://getspaz.com\" rel=\"nofollow\">Spaz</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "128479804415688704",
  "text" : "Im Schlosspark steht einer und spielt Bagpipes!",
  "id" : 128479804415688704,
  "created_at" : "Mon Oct 24 14:35:47 +0000 2011",
  "user" : {
    "name" : "Felix",
    "screen_name" : "nicidienase",
    "protected" : false,
    "id_str" : "22396883",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3125784966/8223a4c5c9535be22d15c82ec829c2df_normal.jpeg",
    "id" : 22396883,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://getspaz.com\" rel=\"nofollow\">Spaz HD for webOS</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Gerd Eist",
      "screen_name" : "erdgeist",
      "indices" : [ 3, 12 ],
      "id_str" : "16701619",
      "id" : 16701619
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "124969589758099457",
  "text" : "RT @erdgeist: HTTP 413 - That's what SHE said",
  "retweeted_status" : {
    "source" : "web",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : {
    },
    "id_str" : "124946850955526144",
    "text" : "HTTP 413 - That's what SHE said",
    "id" : 124946850955526144,
    "created_at" : "Fri Oct 14 20:37:05 +0000 2011",
    "user" : {
      "name" : "Gerd Eist",
      "screen_name" : "erdgeist",
      "protected" : false,
      "id_str" : "16701619",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/61748149/ta_normal.jpg",
      "id" : 16701619,
      "verified" : false
    }
  },
  "id" : 124969589758099457,
  "created_at" : "Fri Oct 14 22:07:26 +0000 2011",
  "user" : {
    "name" : "Felix",
    "screen_name" : "nicidienase",
    "protected" : false,
    "id_str" : "22396883",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3125784966/8223a4c5c9535be22d15c82ec829c2df_normal.jpeg",
    "id" : 22396883,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://getspaz.com\" rel=\"nofollow\">Spaz</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 22, 42 ],
      "url" : "http://t.co/86OwJnDu",
      "expanded_url" : "http://twitpic.com/6vuzhx",
      "display_url" : "twitpic.com/6vuzhx"
    } ]
  },
  "geo" : {
  },
  "id_str" : "121849514297528320",
  "text" : "Porn Line (HSKA E201) http://t.co/86OwJnDu",
  "id" : 121849514297528320,
  "created_at" : "Thu Oct 06 07:29:22 +0000 2011",
  "user" : {
    "name" : "Felix",
    "screen_name" : "nicidienase",
    "protected" : false,
    "id_str" : "22396883",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3125784966/8223a4c5c9535be22d15c82ec829c2df_normal.jpeg",
    "id" : 22396883,
    "verified" : false
  }
} ]