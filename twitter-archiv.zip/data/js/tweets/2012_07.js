Grailbird.data.tweets_2012_07 = 
 [ {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "monoxyd",
      "screen_name" : "monoxyd",
      "indices" : [ 3, 11 ],
      "id_str" : "14085052",
      "id" : 14085052
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 71, 91 ],
      "url" : "http://t.co/1oAOs4Gj",
      "expanded_url" : "http://www.youtube.com/watch?v=_kDhpFaf4EY",
      "display_url" : "youtube.com/watch?v=_kDhpF\u2026"
    } ]
  },
  "geo" : {
  },
  "id_str" : "230380452895129602",
  "text" : "RT @monoxyd: Soso, Frauen k\u00F6nnen also grunds\u00E4tzlich keine Technik, ja? http://t.co/1oAOs4Gj",
  "retweeted_status" : {
    "source" : "<a href=\"http://itunes.apple.com/us/app/twitter/id409789998?mt=12\" rel=\"nofollow\">Twitter for Mac</a>",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 58, 78 ],
        "url" : "http://t.co/1oAOs4Gj",
        "expanded_url" : "http://www.youtube.com/watch?v=_kDhpFaf4EY",
        "display_url" : "youtube.com/watch?v=_kDhpF\u2026"
      } ]
    },
    "geo" : {
    },
    "id_str" : "230294524465930240",
    "text" : "Soso, Frauen k\u00F6nnen also grunds\u00E4tzlich keine Technik, ja? http://t.co/1oAOs4Gj",
    "id" : 230294524465930240,
    "created_at" : "Tue Jul 31 13:31:07 +0000 2012",
    "user" : {
      "name" : "monoxyd",
      "screen_name" : "monoxyd",
      "protected" : false,
      "id_str" : "14085052",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/1422306657/lampe_normal.jpg",
      "id" : 14085052,
      "verified" : false
    }
  },
  "id" : 230380452895129602,
  "created_at" : "Tue Jul 31 19:12:34 +0000 2012",
  "user" : {
    "name" : "Felix",
    "screen_name" : "nicidienase",
    "protected" : false,
    "id_str" : "22396883",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3125784966/8223a4c5c9535be22d15c82ec829c2df_normal.jpeg",
    "id" : 22396883,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Adel vernichtet",
      "screen_name" : "von_bronkhorst",
      "indices" : [ 3, 18 ],
      "id_str" : "451534254",
      "id" : 451534254
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "230370757060988929",
  "text" : "RT @von_bronkhorst: Erwachsen? Mir reicht, dass ich vollj\u00E4hrig bin.",
  "retweeted_status" : {
    "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : {
    },
    "id_str" : "229651969017516032",
    "text" : "Erwachsen? Mir reicht, dass ich vollj\u00E4hrig bin.",
    "id" : 229651969017516032,
    "created_at" : "Sun Jul 29 18:57:50 +0000 2012",
    "user" : {
      "name" : "Adel vernichtet",
      "screen_name" : "von_bronkhorst",
      "protected" : false,
      "id_str" : "451534254",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/1725877545/persepolis2_normal.jpg",
      "id" : 451534254,
      "verified" : false
    }
  },
  "id" : 230370757060988929,
  "created_at" : "Tue Jul 31 18:34:03 +0000 2012",
  "user" : {
    "name" : "Felix",
    "screen_name" : "nicidienase",
    "protected" : false,
    "id_str" : "22396883",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3125784966/8223a4c5c9535be22d15c82ec829c2df_normal.jpeg",
    "id" : 22396883,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "talynrae",
      "screen_name" : "talynrae",
      "indices" : [ 0, 9 ],
      "id_str" : "28328631",
      "id" : 28328631
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 10, 30 ],
      "url" : "http://t.co/BrK3gunK",
      "expanded_url" : "http://www.etsy.com/shop/nyanpanties",
      "display_url" : "etsy.com/shop/nyanpanti\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "230350239113035777",
  "geo" : {
  },
  "id_str" : "230370007081689089",
  "in_reply_to_user_id" : 28328631,
  "text" : "@talynrae http://t.co/BrK3gunK",
  "id" : 230370007081689089,
  "in_reply_to_status_id" : 230350239113035777,
  "created_at" : "Tue Jul 31 18:31:04 +0000 2012",
  "in_reply_to_screen_name" : "talynrae",
  "in_reply_to_user_id_str" : "28328631",
  "user" : {
    "name" : "Felix",
    "screen_name" : "nicidienase",
    "protected" : false,
    "id_str" : "22396883",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3125784966/8223a4c5c9535be22d15c82ec829c2df_normal.jpeg",
    "id" : 22396883,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http://twitter.com/nicidienase/status/230348062508318720/photo/1",
      "indices" : [ 13, 33 ],
      "url" : "http://t.co/C3R2bQ9e",
      "media_url" : "http://pbs.twimg.com/media/AzJcV6jCAAAmZv3.jpg",
      "id_str" : "230348062512513024",
      "id" : 230348062512513024,
      "media_url_https" : "https://pbs.twimg.com/media/AzJcV6jCAAAmZv3.jpg",
      "sizes" : [ {
        "h" : 450,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 1920,
        "resize" : "fit",
        "w" : 2560
      }, {
        "h" : 768,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 255,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com/C3R2bQ9e"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "230348062508318720",
  "text" : "NyanNyanNyan http://t.co/C3R2bQ9e",
  "id" : 230348062508318720,
  "created_at" : "Tue Jul 31 17:03:54 +0000 2012",
  "user" : {
    "name" : "Felix",
    "screen_name" : "nicidienase",
    "protected" : false,
    "id_str" : "22396883",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3125784966/8223a4c5c9535be22d15c82ec829c2df_normal.jpeg",
    "id" : 22396883,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.echofon.com/\" rel=\"nofollow\">Echofon</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Florian (levu)",
      "screen_name" : "levudev",
      "indices" : [ 3, 11 ],
      "id_str" : "47412865",
      "id" : 47412865
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "230289449525841920",
  "text" : "RT @levudev: Rundmail in $Firma beginnt mit \"Bitte beschleunigen sie ihre Sicherheitsgurte. Die Updates sind kommend\" uargh...",
  "retweeted_status" : {
    "source" : "<a href=\"http://www.tweetdeck.com\" rel=\"nofollow\">TweetDeck</a>",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : {
    },
    "id_str" : "230225801977688065",
    "text" : "Rundmail in $Firma beginnt mit \"Bitte beschleunigen sie ihre Sicherheitsgurte. Die Updates sind kommend\" uargh...",
    "id" : 230225801977688065,
    "created_at" : "Tue Jul 31 08:58:03 +0000 2012",
    "user" : {
      "name" : "Florian (levu)",
      "screen_name" : "levudev",
      "protected" : false,
      "id_str" : "47412865",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/1891801124/nRqUnKww_normal",
      "id" : 47412865,
      "verified" : false
    }
  },
  "id" : 230289449525841920,
  "created_at" : "Tue Jul 31 13:10:57 +0000 2012",
  "user" : {
    "name" : "Felix",
    "screen_name" : "nicidienase",
    "protected" : false,
    "id_str" : "22396883",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3125784966/8223a4c5c9535be22d15c82ec829c2df_normal.jpeg",
    "id" : 22396883,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.echofon.com/\" rel=\"nofollow\">Echofon</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Scott Hanselman",
      "screen_name" : "shanselman",
      "indices" : [ 3, 14 ],
      "id_str" : "5676102",
      "id" : 5676102
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "230289350926163969",
  "text" : "RT @shanselman: HTTPS & SSL doesn't mean \"trust this.\" It means \"this is private.\" You may be having a private conversation with Satan.",
  "retweeted_status" : {
    "source" : "<a href=\"http://tweetlogix.com\" rel=\"nofollow\">Tweetlogix</a>",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : {
    },
    "id_str" : "187572289724887041",
    "text" : "HTTPS & SSL doesn't mean \"trust this.\" It means \"this is private.\" You may be having a private conversation with Satan.",
    "id" : 187572289724887041,
    "created_at" : "Wed Apr 04 16:08:13 +0000 2012",
    "user" : {
      "name" : "Scott Hanselman",
      "screen_name" : "shanselman",
      "protected" : false,
      "id_str" : "5676102",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/2574963755/image_normal.jpg",
      "id" : 5676102,
      "verified" : false
    }
  },
  "id" : 230289350926163969,
  "created_at" : "Tue Jul 31 13:10:34 +0000 2012",
  "user" : {
    "name" : "Felix",
    "screen_name" : "nicidienase",
    "protected" : false,
    "id_str" : "22396883",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3125784966/8223a4c5c9535be22d15c82ec829c2df_normal.jpeg",
    "id" : 22396883,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.echofon.com/\" rel=\"nofollow\">Echofon</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Oliver Gierke",
      "screen_name" : "olivergierke",
      "indices" : [ 3, 16 ],
      "id_str" : "16736130",
      "id" : 16736130
    }, {
      "name" : "Tesco Customer Care",
      "screen_name" : "UKTesco",
      "indices" : [ 41, 49 ],
      "id_str" : "271986064",
      "id" : 271986064
    }, {
      "name" : "Troy Hunt",
      "screen_name" : "troyhunt",
      "indices" : [ 70, 79 ],
      "id_str" : "14414286",
      "id" : 14414286
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "web",
      "indices" : [ 81, 85 ]
    }, {
      "text" : "security",
      "indices" : [ 86, 95 ]
    } ],
    "urls" : [ {
      "indices" : [ 96, 116 ],
      "url" : "http://t.co/ZTdVxguS",
      "expanded_url" : "http://troy.hn/N6o5g1",
      "display_url" : "troy.hn/N6o5g1"
    } ]
  },
  "geo" : {
  },
  "id_str" : "230216859465678848",
  "text" : "RT @olivergierke: Awesome summary of the @UKTesco security debacle by @troyhunt\u2026 #web #security http://t.co/ZTdVxguS",
  "retweeted_status" : {
    "source" : "<a href=\"http://tapbots.com/tweetbot\" rel=\"nofollow\">Tweetbot for iOS</a>",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Tesco Customer Care",
        "screen_name" : "UKTesco",
        "indices" : [ 23, 31 ],
        "id_str" : "271986064",
        "id" : 271986064
      }, {
        "name" : "Troy Hunt",
        "screen_name" : "troyhunt",
        "indices" : [ 52, 61 ],
        "id_str" : "14414286",
        "id" : 14414286
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "web",
        "indices" : [ 63, 67 ]
      }, {
        "text" : "security",
        "indices" : [ 68, 77 ]
      } ],
      "urls" : [ {
        "indices" : [ 78, 98 ],
        "url" : "http://t.co/ZTdVxguS",
        "expanded_url" : "http://troy.hn/N6o5g1",
        "display_url" : "troy.hn/N6o5g1"
      } ]
    },
    "geo" : {
    },
    "id_str" : "230203008456200193",
    "text" : "Awesome summary of the @UKTesco security debacle by @troyhunt\u2026 #web #security http://t.co/ZTdVxguS",
    "id" : 230203008456200193,
    "created_at" : "Tue Jul 31 07:27:28 +0000 2012",
    "user" : {
      "name" : "Oliver Gierke",
      "screen_name" : "olivergierke",
      "protected" : false,
      "id_str" : "16736130",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/69836753/P1000914_normal.JPG",
      "id" : 16736130,
      "verified" : false
    }
  },
  "id" : 230216859465678848,
  "created_at" : "Tue Jul 31 08:22:31 +0000 2012",
  "user" : {
    "name" : "Felix",
    "screen_name" : "nicidienase",
    "protected" : false,
    "id_str" : "22396883",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3125784966/8223a4c5c9535be22d15c82ec829c2df_normal.jpeg",
    "id" : 22396883,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Piet De Vaere",
      "screen_name" : "pietdevaere",
      "indices" : [ 3, 15 ],
      "id_str" : "40921842",
      "id" : 40921842
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "haxogreen",
      "indices" : [ 54, 64 ]
    } ],
    "urls" : [ {
      "indices" : [ 65, 85 ],
      "url" : "http://t.co/Bu4nuRNq",
      "expanded_url" : "http://twitter.com/pietdevaere/status/228981132371320832/photo/1",
      "display_url" : "pic.twitter.com/Bu4nuRNq"
    } ]
  },
  "geo" : {
  },
  "id_str" : "229684684790046720",
  "text" : "RT @pietdevaere: but at least the network is still up #haxogreen http://t.co/Bu4nuRNq",
  "retweeted_status" : {
    "source" : "web",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "http://twitter.com/pietdevaere/status/228981132371320832/photo/1",
        "indices" : [ 48, 68 ],
        "url" : "http://t.co/Bu4nuRNq",
        "media_url" : "http://pbs.twimg.com/media/Ay2BIG-CYAIxFHP.jpg",
        "id_str" : "228981132375515138",
        "id" : 228981132375515138,
        "media_url_https" : "https://pbs.twimg.com/media/Ay2BIG-CYAIxFHP.jpg",
        "sizes" : [ {
          "h" : 399,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 426,
          "resize" : "fit",
          "w" : 640
        }, {
          "h" : 226,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 426,
          "resize" : "fit",
          "w" : 640
        } ],
        "display_url" : "pic.twitter.com/Bu4nuRNq"
      } ],
      "hashtags" : [ {
        "text" : "haxogreen",
        "indices" : [ 37, 47 ]
      } ],
      "urls" : [ ]
    },
    "geo" : {
    },
    "id_str" : "228981132371320832",
    "text" : "but at least the network is still up #haxogreen http://t.co/Bu4nuRNq",
    "id" : 228981132371320832,
    "created_at" : "Fri Jul 27 22:32:11 +0000 2012",
    "user" : {
      "name" : "Piet De Vaere",
      "screen_name" : "pietdevaere",
      "protected" : false,
      "id_str" : "40921842",
      "profile_image_url_https" : "https://si0.twimg.com/sticky/default_profile_images/default_profile_3_normal.png",
      "id" : 40921842,
      "verified" : false
    }
  },
  "id" : 229684684790046720,
  "created_at" : "Sun Jul 29 21:07:50 +0000 2012",
  "user" : {
    "name" : "Felix",
    "screen_name" : "nicidienase",
    "protected" : false,
    "id_str" : "22396883",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3125784966/8223a4c5c9535be22d15c82ec829c2df_normal.jpeg",
    "id" : 22396883,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Piet De Vaere",
      "screen_name" : "pietdevaere",
      "indices" : [ 3, 15 ],
      "id_str" : "40921842",
      "id" : 40921842
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "hackaday",
      "indices" : [ 48, 57 ]
    }, {
      "text" : "haxogreen",
      "indices" : [ 79, 89 ]
    } ],
    "urls" : [ {
      "indices" : [ 58, 78 ],
      "url" : "http://t.co/UeX4KZYr",
      "expanded_url" : "http://hackaday.com/2012/07/29/checking-network-status-with-a-traffic-light/",
      "display_url" : "hackaday.com/2012/07/29/che\u2026"
    } ]
  },
  "geo" : {
  },
  "id_str" : "229684571548033025",
  "text" : "RT @pietdevaere: Achievement unlocked! We're on #hackaday\nhttp://t.co/UeX4KZYr\n#haxogreen",
  "retweeted_status" : {
    "source" : "web",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "hackaday",
        "indices" : [ 31, 40 ]
      }, {
        "text" : "haxogreen",
        "indices" : [ 62, 72 ]
      } ],
      "urls" : [ {
        "indices" : [ 41, 61 ],
        "url" : "http://t.co/UeX4KZYr",
        "expanded_url" : "http://hackaday.com/2012/07/29/checking-network-status-with-a-traffic-light/",
        "display_url" : "hackaday.com/2012/07/29/che\u2026"
      } ]
    },
    "geo" : {
    },
    "id_str" : "229665481240502273",
    "text" : "Achievement unlocked! We're on #hackaday\nhttp://t.co/UeX4KZYr\n#haxogreen",
    "id" : 229665481240502273,
    "created_at" : "Sun Jul 29 19:51:32 +0000 2012",
    "user" : {
      "name" : "Piet De Vaere",
      "screen_name" : "pietdevaere",
      "protected" : false,
      "id_str" : "40921842",
      "profile_image_url_https" : "https://si0.twimg.com/sticky/default_profile_images/default_profile_3_normal.png",
      "id" : 40921842,
      "verified" : false
    }
  },
  "id" : 229684571548033025,
  "created_at" : "Sun Jul 29 21:07:23 +0000 2012",
  "user" : {
    "name" : "Felix",
    "screen_name" : "nicidienase",
    "protected" : false,
    "id_str" : "22396883",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3125784966/8223a4c5c9535be22d15c82ec829c2df_normal.jpeg",
    "id" : 22396883,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http://twitter.com/nicidienase/status/229634135944224769/photo/1",
      "indices" : [ 50, 70 ],
      "url" : "http://t.co/O44bVTMQ",
      "media_url" : "http://pbs.twimg.com/media/Ay_TB62CYAAyLS-.jpg",
      "id_str" : "229634135948419072",
      "id" : 229634135948419072,
      "media_url_https" : "https://pbs.twimg.com/media/Ay_TB62CYAAyLS-.jpg",
      "sizes" : [ {
        "h" : 1365,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 2560,
        "resize" : "fit",
        "w" : 1920
      }, {
        "h" : 453,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 800,
        "resize" : "fit",
        "w" : 600
      } ],
      "display_url" : "pic.twitter.com/O44bVTMQ"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "229634135944224769",
  "text" : "Found a nice way to organise all my poster-stuff! http://t.co/O44bVTMQ",
  "id" : 229634135944224769,
  "created_at" : "Sun Jul 29 17:47:01 +0000 2012",
  "user" : {
    "name" : "Felix",
    "screen_name" : "nicidienase",
    "protected" : false,
    "id_str" : "22396883",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3125784966/8223a4c5c9535be22d15c82ec829c2df_normal.jpeg",
    "id" : 22396883,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http://twitter.com/nicidienase/status/229603266416214016/photo/1",
      "indices" : [ 51, 71 ],
      "url" : "http://t.co/n5ybE8Qn",
      "media_url" : "http://pbs.twimg.com/media/Ay-29E5CAAA7FbM.jpg",
      "id_str" : "229603266420408320",
      "id" : 229603266420408320,
      "media_url_https" : "https://pbs.twimg.com/media/Ay-29E5CAAA7FbM.jpg",
      "sizes" : [ {
        "h" : 450,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 1920,
        "resize" : "fit",
        "w" : 2560
      }, {
        "h" : 768,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 255,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com/n5ybE8Qn"
    } ],
    "hashtags" : [ {
      "text" : "Haxogreen",
      "indices" : [ 40, 50 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "229603266416214016",
  "text" : "Additions to my Sticker-Collection from #Haxogreen http://t.co/n5ybE8Qn",
  "id" : 229603266416214016,
  "created_at" : "Sun Jul 29 15:44:21 +0000 2012",
  "user" : {
    "name" : "Felix",
    "screen_name" : "nicidienase",
    "protected" : false,
    "id_str" : "22396883",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3125784966/8223a4c5c9535be22d15c82ec829c2df_normal.jpeg",
    "id" : 22396883,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "haxogreen",
      "indices" : [ 21, 31 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "229564975948103680",
  "text" : "On the way home from #haxogreen , met a lot of nice people and had a great time. Thanks to the awesome orga!!",
  "id" : 229564975948103680,
  "created_at" : "Sun Jul 29 13:12:10 +0000 2012",
  "user" : {
    "name" : "Felix",
    "screen_name" : "nicidienase",
    "protected" : false,
    "id_str" : "22396883",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3125784966/8223a4c5c9535be22d15c82ec829c2df_normal.jpeg",
    "id" : 22396883,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Uwe Lancier",
      "screen_name" : "Ulan_ka",
      "indices" : [ 3, 11 ],
      "id_str" : "379173142",
      "id" : 379173142
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "genderfail",
      "indices" : [ 13, 24 ]
    } ],
    "urls" : [ {
      "indices" : [ 50, 70 ],
      "url" : "http://t.co/CZVddEiT",
      "expanded_url" : "http://twitpic.com/ad1zlk",
      "display_url" : "twitpic.com/ad1zlk"
    } ]
  },
  "geo" : {
  },
  "id_str" : "229521447071133698",
  "text" : "RT @Ulan_ka: #genderfail schwimm und schwimminnen http://t.co/CZVddEiT",
  "retweeted_status" : {
    "source" : "<a href=\"http://www.tweetcaster.com\" rel=\"nofollow\">TweetCaster for Android</a>",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "genderfail",
        "indices" : [ 0, 11 ]
      } ],
      "urls" : [ {
        "indices" : [ 37, 57 ],
        "url" : "http://t.co/CZVddEiT",
        "expanded_url" : "http://twitpic.com/ad1zlk",
        "display_url" : "twitpic.com/ad1zlk"
      } ]
    },
    "geo" : {
    },
    "id_str" : "229513815727939584",
    "text" : "#genderfail schwimm und schwimminnen http://t.co/CZVddEiT",
    "id" : 229513815727939584,
    "created_at" : "Sun Jul 29 09:48:52 +0000 2012",
    "user" : {
      "name" : "Uwe Lancier",
      "screen_name" : "Ulan_ka",
      "protected" : false,
      "id_str" : "379173142",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/1977104421/profile_normal.jpg",
      "id" : 379173142,
      "verified" : false
    }
  },
  "id" : 229521447071133698,
  "created_at" : "Sun Jul 29 10:19:11 +0000 2012",
  "user" : {
    "name" : "Felix",
    "screen_name" : "nicidienase",
    "protected" : false,
    "id_str" : "22396883",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3125784966/8223a4c5c9535be22d15c82ec829c2df_normal.jpeg",
    "id" : 22396883,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "haxogreen",
      "indices" : [ 49, 59 ]
    } ],
    "urls" : [ {
      "indices" : [ 27, 48 ],
      "url" : "https://t.co/0FsUBEha",
      "expanded_url" : "https://www.youtube.com/watch?v=8RcFVrL6akg&feature=youtube_gdata_player",
      "display_url" : "youtube.com/watch?v=8RcFVr\u2026"
    } ]
  },
  "geo" : {
  },
  "id_str" : "229188185136185344",
  "text" : "Wie Hacker Regen b\u00E4ndigen: https://t.co/0FsUBEha #haxogreen",
  "id" : 229188185136185344,
  "created_at" : "Sat Jul 28 12:14:56 +0000 2012",
  "user" : {
    "name" : "Felix",
    "screen_name" : "nicidienase",
    "protected" : false,
    "id_str" : "22396883",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3125784966/8223a4c5c9535be22d15c82ec829c2df_normal.jpeg",
    "id" : 22396883,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Felix Arndt",
      "screen_name" : "silsha",
      "indices" : [ 3, 10 ],
      "id_str" : "14823325",
      "id" : 14823325
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "haxogreen",
      "indices" : [ 53, 63 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "228980339085824000",
  "text" : "RT @silsha: Internet geht wieder. Wir sind gerettet. #haxogreen",
  "retweeted_status" : {
    "source" : "<a href=\"http://tapbots.com/software/tweetbot/mac\" rel=\"nofollow\">Tweetbot for Mac</a>",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "haxogreen",
        "indices" : [ 41, 51 ]
      } ],
      "urls" : [ ]
    },
    "geo" : {
    },
    "id_str" : "228973204214018048",
    "text" : "Internet geht wieder. Wir sind gerettet. #haxogreen",
    "id" : 228973204214018048,
    "created_at" : "Fri Jul 27 22:00:40 +0000 2012",
    "user" : {
      "name" : "Felix Arndt",
      "screen_name" : "silsha",
      "protected" : false,
      "id_str" : "14823325",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/1372962317/Screen_shot_2011-05-21_at_17.15.27_normal.png",
      "id" : 14823325,
      "verified" : false
    }
  },
  "id" : 228980339085824000,
  "created_at" : "Fri Jul 27 22:29:01 +0000 2012",
  "user" : {
    "name" : "Felix",
    "screen_name" : "nicidienase",
    "protected" : false,
    "id_str" : "22396883",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3125784966/8223a4c5c9535be22d15c82ec829c2df_normal.jpeg",
    "id" : 22396883,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tobias Kirschstein",
      "screen_name" : "owner",
      "indices" : [ 3, 9 ],
      "id_str" : "131458577",
      "id" : 131458577
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "haxogreen",
      "indices" : [ 86, 96 ]
    } ],
    "urls" : [ {
      "indices" : [ 97, 117 ],
      "url" : "http://t.co/j1JcAbCZ",
      "expanded_url" : "http://twitter.com/owner/status/228974799328792576/photo/1",
      "display_url" : "pic.twitter.com/j1JcAbCZ"
    } ]
  },
  "geo" : {
  },
  "id_str" : "228979707050352640",
  "text" : "RT @owner: in dudelange, luxembourg you don't crash the party, the party crashes you! #haxogreen http://t.co/j1JcAbCZ",
  "retweeted_status" : {
    "source" : "<a href=\"http://www.apple.com\" rel=\"nofollow\">Photos on iOS</a>",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "http://twitter.com/owner/status/228974799328792576/photo/1",
        "indices" : [ 86, 106 ],
        "url" : "http://t.co/j1JcAbCZ",
        "media_url" : "http://pbs.twimg.com/media/Ay17XejCUAIxvwP.jpg",
        "id_str" : "228974799332986882",
        "id" : 228974799332986882,
        "media_url_https" : "https://pbs.twimg.com/media/Ay17XejCUAIxvwP.jpg",
        "sizes" : [ {
          "h" : 450,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 612,
          "resize" : "fit",
          "w" : 816
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 255,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 612,
          "resize" : "fit",
          "w" : 816
        } ],
        "display_url" : "pic.twitter.com/j1JcAbCZ"
      } ],
      "hashtags" : [ {
        "text" : "haxogreen",
        "indices" : [ 75, 85 ]
      } ],
      "urls" : [ ]
    },
    "geo" : {
    },
    "id_str" : "228974799328792576",
    "text" : "in dudelange, luxembourg you don't crash the party, the party crashes you! #haxogreen http://t.co/j1JcAbCZ",
    "id" : 228974799328792576,
    "created_at" : "Fri Jul 27 22:07:01 +0000 2012",
    "user" : {
      "name" : "Tobias Kirschstein",
      "screen_name" : "owner",
      "protected" : false,
      "id_str" : "131458577",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/3132168431/84f92a93b53dd4f79eb1870d8523087e_normal.png",
      "id" : 131458577,
      "verified" : false
    }
  },
  "id" : 228979707050352640,
  "created_at" : "Fri Jul 27 22:26:31 +0000 2012",
  "user" : {
    "name" : "Felix",
    "screen_name" : "nicidienase",
    "protected" : false,
    "id_str" : "22396883",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3125784966/8223a4c5c9535be22d15c82ec829c2df_normal.jpeg",
    "id" : 22396883,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "228826633535123456",
  "text" : "WTF eBay? 9 Mails an einem Tag wegen einem Einkauf?",
  "id" : 228826633535123456,
  "created_at" : "Fri Jul 27 12:18:15 +0000 2012",
  "user" : {
    "name" : "Felix",
    "screen_name" : "nicidienase",
    "protected" : false,
    "id_str" : "22396883",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3125784966/8223a4c5c9535be22d15c82ec829c2df_normal.jpeg",
    "id" : 22396883,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http://twitter.com/nicidienase/status/228624836627419136/photo/1",
      "indices" : [ 37, 57 ],
      "url" : "http://t.co/NS7D8rGX",
      "media_url" : "http://pbs.twimg.com/media/Ayw9E95CUAEWSCE.jpg",
      "id_str" : "228624836631613441",
      "id" : 228624836631613441,
      "media_url_https" : "https://pbs.twimg.com/media/Ayw9E95CUAEWSCE.jpg",
      "sizes" : [ {
        "h" : 450,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 1920,
        "resize" : "fit",
        "w" : 2560
      }, {
        "h" : 768,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 255,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com/NS7D8rGX"
    } ],
    "hashtags" : [ {
      "text" : "haxogreen",
      "indices" : [ 26, 36 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "228624836627419136",
  "text" : "So l\u00E4ssts sich aushalten. #haxogreen http://t.co/NS7D8rGX",
  "id" : 228624836627419136,
  "created_at" : "Thu Jul 26 22:56:24 +0000 2012",
  "user" : {
    "name" : "Felix",
    "screen_name" : "nicidienase",
    "protected" : false,
    "id_str" : "22396883",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3125784966/8223a4c5c9535be22d15c82ec829c2df_normal.jpeg",
    "id" : 22396883,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http://twitter.com/nicidienase/status/228157884314288129/photo/1",
      "indices" : [ 17, 37 ],
      "url" : "http://t.co/aD1Tw2D8",
      "media_url" : "http://pbs.twimg.com/media/AyqUYw_CAAAwsBn.jpg",
      "id_str" : "228157884322676736",
      "id" : 228157884322676736,
      "media_url_https" : "https://pbs.twimg.com/media/AyqUYw_CAAAwsBn.jpg",
      "sizes" : [ {
        "h" : 450,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 1920,
        "resize" : "fit",
        "w" : 2560
      }, {
        "h" : 768,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 255,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com/aD1Tw2D8"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 49.0162633, 8.4162632 ]
  },
  "id_str" : "228157884314288129",
  "text" : "Wetter genie\u00DFen! http://t.co/aD1Tw2D8",
  "id" : 228157884314288129,
  "created_at" : "Wed Jul 25 16:00:55 +0000 2012",
  "user" : {
    "name" : "Felix",
    "screen_name" : "nicidienase",
    "protected" : false,
    "id_str" : "22396883",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3125784966/8223a4c5c9535be22d15c82ec829c2df_normal.jpeg",
    "id" : 22396883,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/tweetbutton\" rel=\"nofollow\">Tweet Button</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Johannes K.",
      "screen_name" : "beetlebum",
      "indices" : [ 82, 92 ],
      "id_str" : "1007821",
      "id" : 1007821
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 57, 77 ],
      "url" : "http://t.co/oT9jJyFM",
      "expanded_url" : "http://blog.beetlebum.de/2012/07/25/soteriologischer-koffeinschub/",
      "display_url" : "blog.beetlebum.de/2012/07/25/sot\u2026"
    } ]
  },
  "geo" : {
  },
  "id_str" : "228075978059042816",
  "text" : "Soteriologischer Koffeinschub | Jojos illustrierter Blog http://t.co/oT9jJyFM via @beetlebum",
  "id" : 228075978059042816,
  "created_at" : "Wed Jul 25 10:35:25 +0000 2012",
  "user" : {
    "name" : "Felix",
    "screen_name" : "nicidienase",
    "protected" : false,
    "id_str" : "22396883",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3125784966/8223a4c5c9535be22d15c82ec829c2df_normal.jpeg",
    "id" : 22396883,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Command Line Magic",
      "screen_name" : "climagic",
      "indices" : [ 3, 12 ],
      "id_str" : "91333167",
      "id" : 91333167
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "227838105611272192",
  "text" : "RT @climagic: awk and sed are like the fuck and shit of the \"unix language\". Very powerful and can be used nearly anywhere in a sentence.",
  "retweeted_status" : {
    "source" : "<a href=\"http://suso.suso.org/xulu/Command_Line_Magic\" rel=\"nofollow\">CLI Magic poster</a>",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : {
    },
    "id_str" : "227833041828057088",
    "text" : "awk and sed are like the fuck and shit of the \"unix language\". Very powerful and can be used nearly anywhere in a sentence.",
    "id" : 227833041828057088,
    "created_at" : "Tue Jul 24 18:30:04 +0000 2012",
    "user" : {
      "name" : "Command Line Magic",
      "screen_name" : "climagic",
      "protected" : false,
      "id_str" : "91333167",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/535876218/climagic-icon_normal.png",
      "id" : 91333167,
      "verified" : false
    }
  },
  "id" : 227838105611272192,
  "created_at" : "Tue Jul 24 18:50:12 +0000 2012",
  "user" : {
    "name" : "Felix",
    "screen_name" : "nicidienase",
    "protected" : false,
    "id_str" : "22396883",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3125784966/8223a4c5c9535be22d15c82ec829c2df_normal.jpeg",
    "id" : 22396883,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.echofon.com/\" rel=\"nofollow\">Echofon</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "netzpolitik",
      "screen_name" : "netzpolitik",
      "indices" : [ 63, 75 ],
      "id_str" : "9655032",
      "id" : 9655032
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 99, 119 ],
      "url" : "http://t.co/eajFQD1p",
      "expanded_url" : "http://bit.ly/OnlUUu",
      "display_url" : "bit.ly/OnlUUu"
    } ]
  },
  "geo" : {
  },
  "id_str" : "227770934663200768",
  "text" : "Hab ichs mir doch gedacht, dass das ne Yes Men Aktion ist. RT: @netzpolitik: PR-Desaster bei Shell http://t.co/eajFQD1p",
  "id" : 227770934663200768,
  "created_at" : "Tue Jul 24 14:23:17 +0000 2012",
  "user" : {
    "name" : "Felix",
    "screen_name" : "nicidienase",
    "protected" : false,
    "id_str" : "22396883",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3125784966/8223a4c5c9535be22d15c82ec829c2df_normal.jpeg",
    "id" : 22396883,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.echofon.com/\" rel=\"nofollow\">Echofon</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Michael Seemann",
      "screen_name" : "mspro",
      "indices" : [ 0, 6 ],
      "id_str" : "5751892",
      "id" : 5751892
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "227689901695569920",
  "geo" : {
  },
  "id_str" : "227692031869341696",
  "in_reply_to_user_id" : 5751892,
  "text" : "@mspro Irgendwie ist euer aac im mp3-feed gelandet und umgekehrt",
  "id" : 227692031869341696,
  "in_reply_to_status_id" : 227689901695569920,
  "created_at" : "Tue Jul 24 09:09:45 +0000 2012",
  "in_reply_to_screen_name" : "mspro",
  "in_reply_to_user_id_str" : "5751892",
  "user" : {
    "name" : "Felix",
    "screen_name" : "nicidienase",
    "protected" : false,
    "id_str" : "22396883",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3125784966/8223a4c5c9535be22d15c82ec829c2df_normal.jpeg",
    "id" : 22396883,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.echofon.com/\" rel=\"nofollow\">Echofon</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "ak",
      "screen_name" : "gehirnstuermer",
      "indices" : [ 3, 18 ],
      "id_str" : "60545026",
      "id" : 60545026
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "fb",
      "indices" : [ 115, 118 ]
    } ],
    "urls" : [ {
      "indices" : [ 94, 114 ],
      "url" : "http://t.co/tyqr0Jd2",
      "expanded_url" : "http://theunderstatement.com/post/11982112928/android-orphans-visualizing-a-sad-history-of-support",
      "display_url" : "theunderstatement.com/post/119821129\u2026"
    } ]
  },
  "geo" : {
  },
  "id_str" : "227686637600137216",
  "text" : "RT @gehirnstuermer: the understatement: Android Orphans: Visualizing a Sad History of Support http://t.co/tyqr0Jd2 #fb",
  "retweeted_status" : {
    "source" : "<a href=\"http://twitter.com/tweetbutton\" rel=\"nofollow\">Tweet Button</a>",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "fb",
        "indices" : [ 95, 98 ]
      } ],
      "urls" : [ {
        "indices" : [ 74, 94 ],
        "url" : "http://t.co/tyqr0Jd2",
        "expanded_url" : "http://theunderstatement.com/post/11982112928/android-orphans-visualizing-a-sad-history-of-support",
        "display_url" : "theunderstatement.com/post/119821129\u2026"
      } ]
    },
    "geo" : {
    },
    "id_str" : "227684623470178304",
    "text" : "the understatement: Android Orphans: Visualizing a Sad History of Support http://t.co/tyqr0Jd2 #fb",
    "id" : 227684623470178304,
    "created_at" : "Tue Jul 24 08:40:19 +0000 2012",
    "user" : {
      "name" : "ak",
      "screen_name" : "gehirnstuermer",
      "protected" : false,
      "id_str" : "60545026",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/3516366516/127e48ce18a9feedaf7dcd537ff15c62_normal.jpeg",
      "id" : 60545026,
      "verified" : false
    }
  },
  "id" : 227686637600137216,
  "created_at" : "Tue Jul 24 08:48:19 +0000 2012",
  "user" : {
    "name" : "Felix",
    "screen_name" : "nicidienase",
    "protected" : false,
    "id_str" : "22396883",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3125784966/8223a4c5c9535be22d15c82ec829c2df_normal.jpeg",
    "id" : 22396883,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.echofon.com/\" rel=\"nofollow\">Echofon</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "nutellagangbang",
      "screen_name" : "nutellagangbang",
      "indices" : [ 3, 19 ],
      "id_str" : "113119960",
      "id" : 113119960
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "227678501040447488",
  "text" : "RT @nutellagangbang: \"Statistisch gesehen hat die Vatikanstadt mit ihrer Fl\u00E4che von 0,44 km\u00B2 etwa 2,27 P\u00E4pste pro km\u00B2.\"",
  "retweeted_status" : {
    "source" : "web",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : {
    },
    "id_str" : "221181754994728960",
    "text" : "\"Statistisch gesehen hat die Vatikanstadt mit ihrer Fl\u00E4che von 0,44 km\u00B2 etwa 2,27 P\u00E4pste pro km\u00B2.\"",
    "id" : 221181754994728960,
    "created_at" : "Fri Jul 06 10:00:14 +0000 2012",
    "user" : {
      "name" : "nutellagangbang",
      "screen_name" : "nutellagangbang",
      "protected" : false,
      "id_str" : "113119960",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/2579893238/bgblzhmwz2eqx2ibytla_normal.jpeg",
      "id" : 113119960,
      "verified" : false
    }
  },
  "id" : 227678501040447488,
  "created_at" : "Tue Jul 24 08:15:59 +0000 2012",
  "user" : {
    "name" : "Felix",
    "screen_name" : "nicidienase",
    "protected" : false,
    "id_str" : "22396883",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3125784966/8223a4c5c9535be22d15c82ec829c2df_normal.jpeg",
    "id" : 22396883,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.echofon.com/\" rel=\"nofollow\">Echofon</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "i42n",
      "screen_name" : "i42n",
      "indices" : [ 3, 8 ],
      "id_str" : "22298116",
      "id" : 22298116
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Facebook",
      "indices" : [ 37, 46 ]
    } ],
    "urls" : [ {
      "indices" : [ 47, 67 ],
      "url" : "http://t.co/e37yAmJd",
      "expanded_url" : "http://www.tagesspiegel.de/weltspiegel/nach-dem-attentat-von-denver-machen-sich-facebook-verweigerer-verdaechtig/6911648.html",
      "display_url" : "tagesspiegel.de/weltspiegel/na\u2026"
    } ]
  },
  "geo" : {
  },
  "id_str" : "227677624128921601",
  "text" : "RT @i42n: Diese Denke ist widerlich. #Facebook http://t.co/e37yAmJd",
  "retweeted_status" : {
    "source" : "<a href=\"http://www.echofon.com/\" rel=\"nofollow\">Echofon</a>",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "Facebook",
        "indices" : [ 27, 36 ]
      } ],
      "urls" : [ {
        "indices" : [ 37, 57 ],
        "url" : "http://t.co/e37yAmJd",
        "expanded_url" : "http://www.tagesspiegel.de/weltspiegel/nach-dem-attentat-von-denver-machen-sich-facebook-verweigerer-verdaechtig/6911648.html",
        "display_url" : "tagesspiegel.de/weltspiegel/na\u2026"
      } ]
    },
    "geo" : {
    },
    "id_str" : "227654568442474496",
    "text" : "Diese Denke ist widerlich. #Facebook http://t.co/e37yAmJd",
    "id" : 227654568442474496,
    "created_at" : "Tue Jul 24 06:40:53 +0000 2012",
    "user" : {
      "name" : "i42n",
      "screen_name" : "i42n",
      "protected" : false,
      "id_str" : "22298116",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/3129115691/3c2e9123db7f498d478ace57a0ac1b69_normal.png",
      "id" : 22298116,
      "verified" : false
    }
  },
  "id" : 227677624128921601,
  "created_at" : "Tue Jul 24 08:12:30 +0000 2012",
  "user" : {
    "name" : "Felix",
    "screen_name" : "nicidienase",
    "protected" : false,
    "id_str" : "22396883",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3125784966/8223a4c5c9535be22d15c82ec829c2df_normal.jpeg",
    "id" : 22396883,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.echofon.com/\" rel=\"nofollow\">Echofon</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "RA Sebastian Dosch",
      "screen_name" : "kLAWtext",
      "indices" : [ 3, 12 ],
      "id_str" : "21752339",
      "id" : 21752339
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Hitstorm",
      "indices" : [ 29, 38 ]
    }, {
      "text" : "Abmahnung",
      "indices" : [ 75, 85 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "227425491668303872",
  "text" : "RT @kLAWtext: Zeit f\u00FCr einen #Hitstorm: Von dieser h\u00F6flichen Jack Daniel\u00B4s-#Abmahnung sollte sich manch einer ne Scheibe abschneiden. ht ...",
  "retweeted_status" : {
    "source" : "web",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "Hitstorm",
        "indices" : [ 15, 24 ]
      }, {
        "text" : "Abmahnung",
        "indices" : [ 61, 71 ]
      } ],
      "urls" : [ {
        "indices" : [ 120, 140 ],
        "url" : "http://t.co/b3AqXBFL",
        "expanded_url" : "http://bit.ly/MD7SQz",
        "display_url" : "bit.ly/MD7SQz"
      } ]
    },
    "geo" : {
    },
    "id_str" : "227421145236914176",
    "text" : "Zeit f\u00FCr einen #Hitstorm: Von dieser h\u00F6flichen Jack Daniel\u00B4s-#Abmahnung sollte sich manch einer ne Scheibe abschneiden. http://t.co/b3AqXBFL",
    "id" : 227421145236914176,
    "created_at" : "Mon Jul 23 15:13:20 +0000 2012",
    "user" : {
      "name" : "RA Sebastian Dosch",
      "screen_name" : "kLAWtext",
      "protected" : false,
      "id_str" : "21752339",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/1542432021/dosch150x150_normal.JPG",
      "id" : 21752339,
      "verified" : false
    }
  },
  "id" : 227425491668303872,
  "created_at" : "Mon Jul 23 15:30:37 +0000 2012",
  "user" : {
    "name" : "Felix",
    "screen_name" : "nicidienase",
    "protected" : false,
    "id_str" : "22396883",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3125784966/8223a4c5c9535be22d15c82ec829c2df_normal.jpeg",
    "id" : 22396883,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.echofon.com/\" rel=\"nofollow\">Echofon</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "M. L.",
      "screen_name" : "ML42222157",
      "indices" : [ 0, 11 ],
      "id_str" : "576379330",
      "id" : 576379330
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "227416656387911682",
  "geo" : {
  },
  "id_str" : "227417893267206144",
  "in_reply_to_user_id" : 576379330,
  "text" : "@ML42222157 Entweder klein und zum Falten oder gro\u00DF und mit Anh\u00E4gerkupplung. Alles dazwischen bleibt einfach wo es ist.",
  "id" : 227417893267206144,
  "in_reply_to_status_id" : 227416656387911682,
  "created_at" : "Mon Jul 23 15:00:25 +0000 2012",
  "in_reply_to_screen_name" : "ML42222157",
  "in_reply_to_user_id_str" : "576379330",
  "user" : {
    "name" : "Felix",
    "screen_name" : "nicidienase",
    "protected" : false,
    "id_str" : "22396883",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3125784966/8223a4c5c9535be22d15c82ec829c2df_normal.jpeg",
    "id" : 22396883,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.echofon.com/\" rel=\"nofollow\">Echofon</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "M. L.",
      "screen_name" : "ML42222157",
      "indices" : [ 0, 11 ],
      "id_str" : "576379330",
      "id" : 576379330
    }, {
      "name" : "Sturzelchen.",
      "screen_name" : "randsturz",
      "indices" : [ 12, 22 ],
      "id_str" : "73659102",
      "id" : 73659102
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "227416388413845504",
  "text" : "@ML42222157 @randsturz Gibts schon. Nennt sich Grill!",
  "id" : 227416388413845504,
  "created_at" : "Mon Jul 23 14:54:26 +0000 2012",
  "user" : {
    "name" : "Felix",
    "screen_name" : "nicidienase",
    "protected" : false,
    "id_str" : "22396883",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3125784966/8223a4c5c9535be22d15c82ec829c2df_normal.jpeg",
    "id" : 22396883,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.echofon.com/\" rel=\"nofollow\">Echofon</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Eva Eichhorn",
      "screen_name" : "MamsellChaos",
      "indices" : [ 0, 13 ],
      "id_str" : "140774041",
      "id" : 140774041
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "227406019465211904",
  "geo" : {
  },
  "id_str" : "227407268038189057",
  "in_reply_to_user_id" : 140774041,
  "text" : "@MamsellChaos Ich hab zuerst Overclock-Maschine gelesen.",
  "id" : 227407268038189057,
  "in_reply_to_status_id" : 227406019465211904,
  "created_at" : "Mon Jul 23 14:18:12 +0000 2012",
  "in_reply_to_screen_name" : "MamsellChaos",
  "in_reply_to_user_id_str" : "140774041",
  "user" : {
    "name" : "Felix",
    "screen_name" : "nicidienase",
    "protected" : false,
    "id_str" : "22396883",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3125784966/8223a4c5c9535be22d15c82ec829c2df_normal.jpeg",
    "id" : 22396883,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.echofon.com/\" rel=\"nofollow\">Echofon</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "227355949453701120",
  "text" : "OH: \"Tipp du mal, du hast ne sch\u00F6nere Schrift.\"",
  "id" : 227355949453701120,
  "created_at" : "Mon Jul 23 10:54:17 +0000 2012",
  "user" : {
    "name" : "Felix",
    "screen_name" : "nicidienase",
    "protected" : false,
    "id_str" : "22396883",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3125784966/8223a4c5c9535be22d15c82ec829c2df_normal.jpeg",
    "id" : 22396883,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.echofon.com/\" rel=\"nofollow\">Echofon</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "andreasdotorg",
      "screen_name" : "andreasdotorg",
      "indices" : [ 3, 17 ],
      "id_str" : "14285735",
      "id" : 14285735
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 115, 135 ],
      "url" : "http://t.co/dMl7rfh1",
      "expanded_url" : "http://www.gegen-hartz.de/nachrichtenueberhartziv/hartz-iv-bezieher-laesst-jobcenter-pfaenden-9001059.php",
      "display_url" : "gegen-hartz.de/nachrichtenueb\u2026"
    } ]
  },
  "geo" : {
  },
  "id_str" : "227317815210803200",
  "text" : "RT @andreasdotorg: Hartz-IV-Empf\u00E4nger mu\u00DF ihm zustehendes Geld per Gerichtsvollzieher im Jobcenter pf\u00E4nden lassen: http://t.co/dMl7rfh1",
  "retweeted_status" : {
    "source" : "web",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 96, 116 ],
        "url" : "http://t.co/dMl7rfh1",
        "expanded_url" : "http://www.gegen-hartz.de/nachrichtenueberhartziv/hartz-iv-bezieher-laesst-jobcenter-pfaenden-9001059.php",
        "display_url" : "gegen-hartz.de/nachrichtenueb\u2026"
      } ]
    },
    "geo" : {
    },
    "id_str" : "227316974785556480",
    "text" : "Hartz-IV-Empf\u00E4nger mu\u00DF ihm zustehendes Geld per Gerichtsvollzieher im Jobcenter pf\u00E4nden lassen: http://t.co/dMl7rfh1",
    "id" : 227316974785556480,
    "created_at" : "Mon Jul 23 08:19:24 +0000 2012",
    "user" : {
      "name" : "andreasdotorg",
      "screen_name" : "andreasdotorg",
      "protected" : false,
      "id_str" : "14285735",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/2857263613/87df849b9667509c53079d7bb7fd0b31_normal.jpeg",
      "id" : 14285735,
      "verified" : false
    }
  },
  "id" : 227317815210803200,
  "created_at" : "Mon Jul 23 08:22:45 +0000 2012",
  "user" : {
    "name" : "Felix",
    "screen_name" : "nicidienase",
    "protected" : false,
    "id_str" : "22396883",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3125784966/8223a4c5c9535be22d15c82ec829c2df_normal.jpeg",
    "id" : 22396883,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.echofon.com/\" rel=\"nofollow\">Echofon</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Darkman",
      "screen_name" : "dunkldinx",
      "indices" : [ 3, 13 ],
      "id_str" : "60615255",
      "id" : 60615255
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 27, 47 ],
      "url" : "http://t.co/aQ96wfXz",
      "expanded_url" : "http://xkcd.com/1085/",
      "display_url" : "xkcd.com/1085/"
    } ]
  },
  "geo" : {
  },
  "id_str" : "227316197136400384",
  "text" : "RT @dunkldinx: ContextBot: http://t.co/aQ96wfXz - WANT!",
  "retweeted_status" : {
    "source" : "web",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 12, 32 ],
        "url" : "http://t.co/aQ96wfXz",
        "expanded_url" : "http://xkcd.com/1085/",
        "display_url" : "xkcd.com/1085/"
      } ]
    },
    "geo" : {
    },
    "id_str" : "227311758463885315",
    "text" : "ContextBot: http://t.co/aQ96wfXz - WANT!",
    "id" : 227311758463885315,
    "created_at" : "Mon Jul 23 07:58:41 +0000 2012",
    "user" : {
      "name" : "Darkman",
      "screen_name" : "dunkldinx",
      "protected" : false,
      "id_str" : "60615255",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/2947935934/48dbbf6482caddb3d88a9a525d619111_normal.jpeg",
      "id" : 60615255,
      "verified" : false
    }
  },
  "id" : 227316197136400384,
  "created_at" : "Mon Jul 23 08:16:19 +0000 2012",
  "user" : {
    "name" : "Felix",
    "screen_name" : "nicidienase",
    "protected" : false,
    "id_str" : "22396883",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3125784966/8223a4c5c9535be22d15c82ec829c2df_normal.jpeg",
    "id" : 22396883,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.echofon.com/\" rel=\"nofollow\">Echofon</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "i42n",
      "screen_name" : "i42n",
      "indices" : [ 0, 5 ],
      "id_str" : "22298116",
      "id" : 22298116
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "227309327516565505",
  "geo" : {
  },
  "id_str" : "227315086132396032",
  "in_reply_to_user_id" : 22298116,
  "text" : "@i42n OMG Wir werden alle sterben!!",
  "id" : 227315086132396032,
  "in_reply_to_status_id" : 227309327516565505,
  "created_at" : "Mon Jul 23 08:11:54 +0000 2012",
  "in_reply_to_screen_name" : "i42n",
  "in_reply_to_user_id_str" : "22298116",
  "user" : {
    "name" : "Felix",
    "screen_name" : "nicidienase",
    "protected" : false,
    "id_str" : "22396883",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3125784966/8223a4c5c9535be22d15c82ec829c2df_normal.jpeg",
    "id" : 22396883,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Michel Hoffmann",
      "screen_name" : "HoffmannMich",
      "indices" : [ 3, 16 ],
      "id_str" : "53795315",
      "id" : 53795315
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "haxogreen",
      "indices" : [ 130, 140 ]
    } ],
    "urls" : [ {
      "indices" : [ 18, 38 ],
      "url" : "http://t.co/0gNQU69S",
      "expanded_url" : "http://haxogreen.lu/2012/Registration",
      "display_url" : "haxogreen.lu/2012/Registrat\u2026"
    } ]
  },
  "geo" : {
  },
  "id_str" : "227103781102448640",
  "text" : "RT @HoffmannMich: http://t.co/0gNQU69S\n\n12 tickets remaining, 4 Days to go. Share a retweet and help us to be sold out soon! ;-)\n\n#haxogreen",
  "retweeted_status" : {
    "source" : "web",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "haxogreen",
        "indices" : [ 112, 122 ]
      } ],
      "urls" : [ {
        "indices" : [ 0, 20 ],
        "url" : "http://t.co/0gNQU69S",
        "expanded_url" : "http://haxogreen.lu/2012/Registration",
        "display_url" : "haxogreen.lu/2012/Registrat\u2026"
      } ]
    },
    "geo" : {
    },
    "id_str" : "227048460896059392",
    "text" : "http://t.co/0gNQU69S\n\n12 tickets remaining, 4 Days to go. Share a retweet and help us to be sold out soon! ;-)\n\n#haxogreen",
    "id" : 227048460896059392,
    "created_at" : "Sun Jul 22 14:32:26 +0000 2012",
    "user" : {
      "name" : "Michel Hoffmann",
      "screen_name" : "HoffmannMich",
      "protected" : false,
      "id_str" : "53795315",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/3357251556/3495bcfcb2cecc6a3cfb0fdb1249f4df_normal.jpeg",
      "id" : 53795315,
      "verified" : false
    }
  },
  "id" : 227103781102448640,
  "created_at" : "Sun Jul 22 18:12:15 +0000 2012",
  "user" : {
    "name" : "Felix",
    "screen_name" : "nicidienase",
    "protected" : false,
    "id_str" : "22396883",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3125784966/8223a4c5c9535be22d15c82ec829c2df_normal.jpeg",
    "id" : 22396883,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "226786995677052928",
  "text" : "Yeay, auf meinem Nexus S bootet gerade Jelly Bean :D",
  "id" : 226786995677052928,
  "created_at" : "Sat Jul 21 21:13:27 +0000 2012",
  "user" : {
    "name" : "Felix",
    "screen_name" : "nicidienase",
    "protected" : false,
    "id_str" : "22396883",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3125784966/8223a4c5c9535be22d15c82ec829c2df_normal.jpeg",
    "id" : 22396883,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Antti Mattila",
      "screen_name" : "anttti",
      "indices" : [ 3, 10 ],
      "id_str" : "15365091",
      "id" : 15365091
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 119, 139 ],
      "url" : "http://t.co/2HH9zUDe",
      "expanded_url" : "http://j.mp/NPAgC4",
      "display_url" : "j.mp/NPAgC4"
    } ]
  },
  "geo" : {
  },
  "id_str" : "226685842834456576",
  "text" : "RT @anttti: New Programming Jargon: Hooker code. Mad girlfriend bug. Protoduction. Smurf naming convention. Hilarious! http://t.co/2HH9zUDe",
  "retweeted_status" : {
    "source" : "<a href=\"http://reederapp.com\" rel=\"nofollow\">Reeder</a>",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 107, 127 ],
        "url" : "http://t.co/2HH9zUDe",
        "expanded_url" : "http://j.mp/NPAgC4",
        "display_url" : "j.mp/NPAgC4"
      } ]
    },
    "geo" : {
    },
    "id_str" : "226603649391022080",
    "text" : "New Programming Jargon: Hooker code. Mad girlfriend bug. Protoduction. Smurf naming convention. Hilarious! http://t.co/2HH9zUDe",
    "id" : 226603649391022080,
    "created_at" : "Sat Jul 21 09:04:54 +0000 2012",
    "user" : {
      "name" : "Antti Mattila",
      "screen_name" : "anttti",
      "protected" : false,
      "id_str" : "15365091",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/3340883366/799885ec7d74b450f8e09a755868d488_normal.png",
      "id" : 15365091,
      "verified" : false
    }
  },
  "id" : 226685842834456576,
  "created_at" : "Sat Jul 21 14:31:31 +0000 2012",
  "user" : {
    "name" : "Felix",
    "screen_name" : "nicidienase",
    "protected" : false,
    "id_str" : "22396883",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3125784966/8223a4c5c9535be22d15c82ec829c2df_normal.jpeg",
    "id" : 22396883,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.echofon.com/\" rel=\"nofollow\">Echofon</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "arcticready",
      "indices" : [ 15, 27 ]
    }, {
      "text" : "shellfail",
      "indices" : [ 72, 82 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "226320709444587521",
  "geo" : {
  },
  "id_str" : "226325983152721921",
  "in_reply_to_user_id" : 20689932,
  "text" : "@Geruhn dieses #arcticready sieht mir schwer nach einer Fortsetzung von #shellfail aus",
  "id" : 226325983152721921,
  "in_reply_to_status_id" : 226320709444587521,
  "created_at" : "Fri Jul 20 14:41:33 +0000 2012",
  "in_reply_to_screen_name" : "keinGeruhn",
  "in_reply_to_user_id_str" : "20689932",
  "user" : {
    "name" : "Felix",
    "screen_name" : "nicidienase",
    "protected" : false,
    "id_str" : "22396883",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3125784966/8223a4c5c9535be22d15c82ec829c2df_normal.jpeg",
    "id" : 22396883,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.echofon.com/\" rel=\"nofollow\">Echofon</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Johannes Brakensiek",
      "screen_name" : "letterus",
      "indices" : [ 3, 12 ],
      "id_str" : "142353924",
      "id" : 142353924
    }, {
      "name" : "Sebastian Baumer",
      "screen_name" : "Raventhird",
      "indices" : [ 59, 70 ],
      "id_str" : "18308250",
      "id" : 18308250
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "kirche",
      "indices" : [ 125, 132 ]
    }, {
      "text" : "pr",
      "indices" : [ 133, 136 ]
    } ],
    "urls" : [ {
      "indices" : [ 104, 124 ],
      "url" : "http://t.co/1w2D0PwN",
      "expanded_url" : "http://raventhird.tumblr.com/post/27546493372/ich-bin-ja-nur-ein-atheist-aber",
      "display_url" : "raventhird.tumblr.com/post/275464933\u2026"
    } ]
  },
  "geo" : {
  },
  "id_str" : "226305690564694016",
  "text" : "RT @letterus: Einfach weils so \"einfach\" ist. Ein Text von @Raventhird: \"Ich bin ja nur Atheist, aber\u2026\" http://t.co/1w2D0PwN #kirche #pr ...",
  "retweeted_status" : {
    "source" : "web",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Sebastian Baumer",
        "screen_name" : "Raventhird",
        "indices" : [ 45, 56 ],
        "id_str" : "18308250",
        "id" : 18308250
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "kirche",
        "indices" : [ 111, 118 ]
      }, {
        "text" : "pr",
        "indices" : [ 119, 122 ]
      }, {
        "text" : "humor",
        "indices" : [ 123, 129 ]
      } ],
      "urls" : [ {
        "indices" : [ 90, 110 ],
        "url" : "http://t.co/1w2D0PwN",
        "expanded_url" : "http://raventhird.tumblr.com/post/27546493372/ich-bin-ja-nur-ein-atheist-aber",
        "display_url" : "raventhird.tumblr.com/post/275464933\u2026"
      } ]
    },
    "geo" : {
    },
    "id_str" : "225984270412435456",
    "text" : "Einfach weils so \"einfach\" ist. Ein Text von @Raventhird: \"Ich bin ja nur Atheist, aber\u2026\" http://t.co/1w2D0PwN #kirche #pr #humor",
    "id" : 225984270412435456,
    "created_at" : "Thu Jul 19 16:03:43 +0000 2012",
    "user" : {
      "name" : "Johannes Brakensiek",
      "screen_name" : "letterus",
      "protected" : false,
      "id_str" : "142353924",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/2215167722/PortraitSW_normal.jpg",
      "id" : 142353924,
      "verified" : false
    }
  },
  "id" : 226305690564694016,
  "created_at" : "Fri Jul 20 13:20:55 +0000 2012",
  "user" : {
    "name" : "Felix",
    "screen_name" : "nicidienase",
    "protected" : false,
    "id_str" : "22396883",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3125784966/8223a4c5c9535be22d15c82ec829c2df_normal.jpeg",
    "id" : 22396883,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.echofon.com/\" rel=\"nofollow\">Echofon</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Hendrik Mans",
      "screen_name" : "hmans",
      "indices" : [ 3, 9 ],
      "id_str" : "645333",
      "id" : 645333
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 45, 65 ],
      "url" : "http://t.co/XsEuku34",
      "expanded_url" : "http://twitter.com/hmans/status/226256385837510656/photo/1",
      "display_url" : "pic.twitter.com/XsEuku34"
    } ]
  },
  "geo" : {
  },
  "id_str" : "226264591632588800",
  "text" : "RT @hmans: Dar\u00FCber musste ich gerade lachen. http://t.co/XsEuku34",
  "retweeted_status" : {
    "source" : "<a href=\"http://www.echofon.com/\" rel=\"nofollow\">Echofon</a>",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "http://twitter.com/hmans/status/226256385837510656/photo/1",
        "indices" : [ 34, 54 ],
        "url" : "http://t.co/XsEuku34",
        "media_url" : "http://pbs.twimg.com/media/AyPS-_JCMAAdEel.png",
        "id_str" : "226256385841704960",
        "id" : 226256385841704960,
        "media_url_https" : "https://pbs.twimg.com/media/AyPS-_JCMAAdEel.png",
        "sizes" : [ {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 587,
          "resize" : "fit",
          "w" : 501
        }, {
          "h" : 398,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 587,
          "resize" : "fit",
          "w" : 501
        }, {
          "h" : 587,
          "resize" : "fit",
          "w" : 501
        } ],
        "display_url" : "pic.twitter.com/XsEuku34"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : {
    },
    "id_str" : "226256385837510656",
    "text" : "Dar\u00FCber musste ich gerade lachen. http://t.co/XsEuku34",
    "id" : 226256385837510656,
    "created_at" : "Fri Jul 20 10:05:01 +0000 2012",
    "user" : {
      "name" : "Hendrik Mans",
      "screen_name" : "hmans",
      "protected" : false,
      "id_str" : "645333",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/1787236714/hmans_buerste_square_normal.jpg",
      "id" : 645333,
      "verified" : false
    }
  },
  "id" : 226264591632588800,
  "created_at" : "Fri Jul 20 10:37:37 +0000 2012",
  "user" : {
    "name" : "Felix",
    "screen_name" : "nicidienase",
    "protected" : false,
    "id_str" : "22396883",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3125784966/8223a4c5c9535be22d15c82ec829c2df_normal.jpeg",
    "id" : 22396883,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Holger Klein",
      "screen_name" : "holgi",
      "indices" : [ 3, 9 ],
      "id_str" : "3068271",
      "id" : 3068271
    }, {
      "name" : "Stephan D\u00F6rner",
      "screen_name" : "Doener",
      "indices" : [ 17, 24 ],
      "id_str" : "14742504",
      "id" : 14742504
    }, {
      "name" : "Stefan Niggemeier",
      "screen_name" : "niggi",
      "indices" : [ 66, 72 ],
      "id_str" : "14247715",
      "id" : 14247715
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 82, 102 ],
      "url" : "http://t.co/v7JXhAMl",
      "expanded_url" : "http://www.aliceschwarzer.de/publikationen/blog/?tx_t3blog_pi1[blogList][showUid]=108&tx_t3blog_pi1[blogList][year]=2012&tx_t3blog_pi1[blogList][month]=07&tx_t3blog_pi1[blogList][day]=17&cHash=1344108bc3",
      "display_url" : "aliceschwarzer.de/publikationen/\u2026"
    } ]
  },
  "geo" : {
  },
  "id_str" : "225936221858320384",
  "text" : "RT @holgi: +1 RT @Doener: Ich finde Alice Schwarzer hat recht und @niggi unrecht: http://t.co/v7JXhAMl Das ist echt mal selten.",
  "retweeted_status" : {
    "source" : "<a href=\"http://www.echofon.com/\" rel=\"nofollow\">Echofon</a>",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Stephan D\u00F6rner",
        "screen_name" : "Doener",
        "indices" : [ 6, 13 ],
        "id_str" : "14742504",
        "id" : 14742504
      }, {
        "name" : "Stefan Niggemeier",
        "screen_name" : "niggi",
        "indices" : [ 55, 61 ],
        "id_str" : "14247715",
        "id" : 14247715
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 71, 91 ],
        "url" : "http://t.co/v7JXhAMl",
        "expanded_url" : "http://www.aliceschwarzer.de/publikationen/blog/?tx_t3blog_pi1[blogList][showUid]=108&tx_t3blog_pi1[blogList][year]=2012&tx_t3blog_pi1[blogList][month]=07&tx_t3blog_pi1[blogList][day]=17&cHash=1344108bc3",
        "display_url" : "aliceschwarzer.de/publikationen/\u2026"
      } ]
    },
    "geo" : {
    },
    "id_str" : "225926121508720640",
    "text" : "+1 RT @Doener: Ich finde Alice Schwarzer hat recht und @niggi unrecht: http://t.co/v7JXhAMl Das ist echt mal selten.",
    "id" : 225926121508720640,
    "created_at" : "Thu Jul 19 12:12:39 +0000 2012",
    "user" : {
      "name" : "Holger Klein",
      "screen_name" : "holgi",
      "protected" : false,
      "id_str" : "3068271",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/14606372/ich1_normal.jpg",
      "id" : 3068271,
      "verified" : false
    }
  },
  "id" : 225936221858320384,
  "created_at" : "Thu Jul 19 12:52:47 +0000 2012",
  "user" : {
    "name" : "Felix",
    "screen_name" : "nicidienase",
    "protected" : false,
    "id_str" : "22396883",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3125784966/8223a4c5c9535be22d15c82ec829c2df_normal.jpeg",
    "id" : 22396883,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.echofon.com/\" rel=\"nofollow\">Echofon</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Fressesprecher",
      "screen_name" : "Bediko",
      "indices" : [ 3, 10 ],
      "id_str" : "56530362",
      "id" : 56530362
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "225903806393769984",
  "text" : "RT @Bediko: My little Crypto: Primes are magic",
  "retweeted_status" : {
    "source" : "<a href=\"http://www.tweetdeck.com\" rel=\"nofollow\">TweetDeck</a>",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : {
    },
    "id_str" : "210507750927642627",
    "text" : "My little Crypto: Primes are magic",
    "id" : 210507750927642627,
    "created_at" : "Wed Jun 06 23:05:33 +0000 2012",
    "user" : {
      "name" : "Fressesprecher",
      "screen_name" : "Bediko",
      "protected" : false,
      "id_str" : "56530362",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/2437133177/vbl5pillrzv6o2voc15k_normal.gif",
      "id" : 56530362,
      "verified" : false
    }
  },
  "id" : 225903806393769984,
  "created_at" : "Thu Jul 19 10:43:59 +0000 2012",
  "user" : {
    "name" : "Felix",
    "screen_name" : "nicidienase",
    "protected" : false,
    "id_str" : "22396883",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3125784966/8223a4c5c9535be22d15c82ec829c2df_normal.jpeg",
    "id" : 22396883,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lore Frost",
      "screen_name" : "Lobot",
      "indices" : [ 3, 9 ],
      "id_str" : "1492631",
      "id" : 1492631
    }, {
      "name" : "yetzt",
      "screen_name" : "yetzt",
      "indices" : [ 11, 17 ],
      "id_str" : "2902401",
      "id" : 2902401
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "225902043817181184",
  "text" : "RT @Lobot: @yetzt Und ich mach nen Tuning-Laden auf: \"Autovervollst\u00E4ndigung\".",
  "retweeted_status" : {
    "source" : "web",
    "entities" : {
      "user_mentions" : [ {
        "name" : "yetzt",
        "screen_name" : "yetzt",
        "indices" : [ 0, 6 ],
        "id_str" : "2902401",
        "id" : 2902401
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "in_reply_to_status_id_str" : "225647500705542146",
    "geo" : {
    },
    "id_str" : "225876437700317184",
    "in_reply_to_user_id" : 2902401,
    "text" : "@yetzt Und ich mach nen Tuning-Laden auf: \"Autovervollst\u00E4ndigung\".",
    "id" : 225876437700317184,
    "in_reply_to_status_id" : 225647500705542146,
    "created_at" : "Thu Jul 19 08:55:13 +0000 2012",
    "in_reply_to_screen_name" : "yetzt",
    "in_reply_to_user_id_str" : "2902401",
    "user" : {
      "name" : "Lore Frost",
      "screen_name" : "Lobot",
      "protected" : false,
      "id_str" : "1492631",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/1846171052/user_manual_330x330_sw_normal.jpg",
      "id" : 1492631,
      "verified" : false
    }
  },
  "id" : 225902043817181184,
  "created_at" : "Thu Jul 19 10:36:58 +0000 2012",
  "user" : {
    "name" : "Felix",
    "screen_name" : "nicidienase",
    "protected" : false,
    "id_str" : "22396883",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3125784966/8223a4c5c9535be22d15c82ec829c2df_normal.jpeg",
    "id" : 22396883,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "yetzt",
      "screen_name" : "yetzt",
      "indices" : [ 3, 9 ],
      "id_str" : "2902401",
      "id" : 2902401
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "225902017099464705",
  "text" : "RT @yetzt: wenn ich mal ne kfz-werkstatt aufmache, nenn ich sie \"Autokorrektur\"",
  "retweeted_status" : {
    "source" : "<a href=\"http://tapbots.com/tweetbot\" rel=\"nofollow\">Tweetbot for iOS</a>",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : {
    },
    "id_str" : "225647500705542146",
    "text" : "wenn ich mal ne kfz-werkstatt aufmache, nenn ich sie \"Autokorrektur\"",
    "id" : 225647500705542146,
    "created_at" : "Wed Jul 18 17:45:31 +0000 2012",
    "user" : {
      "name" : "yetzt",
      "screen_name" : "yetzt",
      "protected" : false,
      "id_str" : "2902401",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/2541812133/qp1r3ec2njl54p8lcsp3_normal.png",
      "id" : 2902401,
      "verified" : false
    }
  },
  "id" : 225902017099464705,
  "created_at" : "Thu Jul 19 10:36:52 +0000 2012",
  "user" : {
    "name" : "Felix",
    "screen_name" : "nicidienase",
    "protected" : false,
    "id_str" : "22396883",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3125784966/8223a4c5c9535be22d15c82ec829c2df_normal.jpeg",
    "id" : 22396883,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.echofon.com/\" rel=\"nofollow\">Echofon</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lars Fischer",
      "screen_name" : "Fischblog",
      "indices" : [ 3, 13 ],
      "id_str" : "14700783",
      "id" : 14700783
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 64, 84 ],
      "url" : "http://t.co/XPVrkTpQ",
      "expanded_url" : "http://www.extremetech.com/extreme/132918-the-laser-powered-bionic-eye-that-gives-576-pixel-grayscale-vision-to-the-blind",
      "display_url" : "extremetech.com/extreme/132918\u2026"
    } ]
  },
  "geo" : {
  },
  "id_str" : "225885974528405504",
  "text" : "RT @Fischblog: Das ist krass: Bionische Augen sind einsatzf\u00E4hig http://t.co/XPVrkTpQ",
  "retweeted_status" : {
    "source" : "<a href=\"http://www.echofon.com/\" rel=\"nofollow\">Echofon</a>",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 49, 69 ],
        "url" : "http://t.co/XPVrkTpQ",
        "expanded_url" : "http://www.extremetech.com/extreme/132918-the-laser-powered-bionic-eye-that-gives-576-pixel-grayscale-vision-to-the-blind",
        "display_url" : "extremetech.com/extreme/132918\u2026"
      } ]
    },
    "geo" : {
    },
    "id_str" : "225883557355204608",
    "text" : "Das ist krass: Bionische Augen sind einsatzf\u00E4hig http://t.co/XPVrkTpQ",
    "id" : 225883557355204608,
    "created_at" : "Thu Jul 19 09:23:31 +0000 2012",
    "user" : {
      "name" : "Lars Fischer",
      "screen_name" : "Fischblog",
      "protected" : false,
      "id_str" : "14700783",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/2280490409/tm7beswe21h2t970pke5_normal.jpeg",
      "id" : 14700783,
      "verified" : false
    }
  },
  "id" : 225885974528405504,
  "created_at" : "Thu Jul 19 09:33:07 +0000 2012",
  "user" : {
    "name" : "Felix",
    "screen_name" : "nicidienase",
    "protected" : false,
    "id_str" : "22396883",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3125784966/8223a4c5c9535be22d15c82ec829c2df_normal.jpeg",
    "id" : 22396883,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.echofon.com/\" rel=\"nofollow\">Echofon</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Michael Seemann",
      "screen_name" : "mspro",
      "indices" : [ 3, 9 ],
      "id_str" : "5751892",
      "id" : 5751892
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 17, 37 ],
      "url" : "http://t.co/CU2SXcPx",
      "expanded_url" : "http://www.stefan-niggemeier.de/blog/nach-diesem-urteil-sollten-wir-uns-ueber-die-nsu-nicht-mehr-wundern/",
      "display_url" : "stefan-niggemeier.de/blog/nach-dies\u2026"
    } ]
  },
  "geo" : {
  },
  "id_str" : "225868455419707393",
  "text" : "RT @mspro: urgs. http://t.co/CU2SXcPx",
  "retweeted_status" : {
    "source" : "<a href=\"http://itunes.apple.com/us/app/twitter/id409789998?mt=12\" rel=\"nofollow\">Twitter for Mac</a>",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 6, 26 ],
        "url" : "http://t.co/CU2SXcPx",
        "expanded_url" : "http://www.stefan-niggemeier.de/blog/nach-diesem-urteil-sollten-wir-uns-ueber-die-nsu-nicht-mehr-wundern/",
        "display_url" : "stefan-niggemeier.de/blog/nach-dies\u2026"
      } ]
    },
    "geo" : {
    },
    "id_str" : "225864767217229824",
    "text" : "urgs. http://t.co/CU2SXcPx",
    "id" : 225864767217229824,
    "created_at" : "Thu Jul 19 08:08:51 +0000 2012",
    "user" : {
      "name" : "Michael Seemann",
      "screen_name" : "mspro",
      "protected" : false,
      "id_str" : "5751892",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/3408641243/2edf38d3c995612edf5b3d2e20d74861_normal.jpeg",
      "id" : 5751892,
      "verified" : false
    }
  },
  "id" : 225868455419707393,
  "created_at" : "Thu Jul 19 08:23:30 +0000 2012",
  "user" : {
    "name" : "Felix",
    "screen_name" : "nicidienase",
    "protected" : false,
    "id_str" : "22396883",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3125784966/8223a4c5c9535be22d15c82ec829c2df_normal.jpeg",
    "id" : 22396883,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.echofon.com/\" rel=\"nofollow\">Echofon</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tim Weber",
      "screen_name" : "scy",
      "indices" : [ 3, 7 ],
      "id_str" : "8308632",
      "id" : 8308632
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "225857991679811584",
  "text" : "RT @scy: Hm. Hat schon mal jemand dr\u00FCber nachgedacht, einen Unicode-Block \u201ERagefaces\u201C vorzuschlagen?",
  "retweeted_status" : {
    "source" : "<a href=\"http://www.tweetdeck.com\" rel=\"nofollow\">TweetDeck</a>",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : {
    },
    "id_str" : "225857283534508032",
    "text" : "Hm. Hat schon mal jemand dr\u00FCber nachgedacht, einen Unicode-Block \u201ERagefaces\u201C vorzuschlagen?",
    "id" : 225857283534508032,
    "created_at" : "Thu Jul 19 07:39:07 +0000 2012",
    "user" : {
      "name" : "Tim Weber",
      "screen_name" : "scy",
      "protected" : false,
      "id_str" : "8308632",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/424137519/avatar184_normal.jpg",
      "id" : 8308632,
      "verified" : false
    }
  },
  "id" : 225857991679811584,
  "created_at" : "Thu Jul 19 07:41:56 +0000 2012",
  "user" : {
    "name" : "Felix",
    "screen_name" : "nicidienase",
    "protected" : false,
    "id_str" : "22396883",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3125784966/8223a4c5c9535be22d15c82ec829c2df_normal.jpeg",
    "id" : 22396883,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "psy",
      "screen_name" : "psycon",
      "indices" : [ 0, 7 ],
      "id_str" : "87286054",
      "id" : 87286054
    }, {
      "name" : "memo",
      "screen_name" : "memo42",
      "indices" : [ 8, 15 ],
      "id_str" : "55311456",
      "id" : 55311456
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "225612493089808386",
  "geo" : {
  },
  "id_str" : "225627283279450112",
  "in_reply_to_user_id" : 87286054,
  "text" : "@psycon @memo42 K\u00F6nnt ihr auch noch Grillanz\u00FCnder mitbringen? Da is fast keiner mehr da.",
  "id" : 225627283279450112,
  "in_reply_to_status_id" : 225612493089808386,
  "created_at" : "Wed Jul 18 16:25:10 +0000 2012",
  "in_reply_to_screen_name" : "psycon",
  "in_reply_to_user_id_str" : "87286054",
  "user" : {
    "name" : "Felix",
    "screen_name" : "nicidienase",
    "protected" : false,
    "id_str" : "22396883",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3125784966/8223a4c5c9535be22d15c82ec829c2df_normal.jpeg",
    "id" : 22396883,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.echofon.com/\" rel=\"nofollow\">Echofon</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "psy",
      "screen_name" : "psycon",
      "indices" : [ 0, 7 ],
      "id_str" : "87286054",
      "id" : 87286054
    }, {
      "name" : "memo",
      "screen_name" : "memo42",
      "indices" : [ 41, 48 ],
      "id_str" : "55311456",
      "id" : 55311456
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "225611768301490177",
  "geo" : {
  },
  "id_str" : "225612184548409344",
  "in_reply_to_user_id" : 87286054,
  "text" : "@psycon So ab halb acht. Sprich dich mit @memo42 ab wer Bier und Brot mitbringt.",
  "id" : 225612184548409344,
  "in_reply_to_status_id" : 225611768301490177,
  "created_at" : "Wed Jul 18 15:25:11 +0000 2012",
  "in_reply_to_screen_name" : "psycon",
  "in_reply_to_user_id_str" : "87286054",
  "user" : {
    "name" : "Felix",
    "screen_name" : "nicidienase",
    "protected" : false,
    "id_str" : "22396883",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3125784966/8223a4c5c9535be22d15c82ec829c2df_normal.jpeg",
    "id" : 22396883,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.echofon.com/\" rel=\"nofollow\">Echofon</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "shell",
      "indices" : [ 60, 66 ]
    }, {
      "text" : "arcticready",
      "indices" : [ 67, 79 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "225605728784756737",
  "text" : "Sieht irgendwie nach nem hoax aus, aber einem sehr sch\u00F6nen. #shell #arcticready",
  "id" : 225605728784756737,
  "created_at" : "Wed Jul 18 14:59:31 +0000 2012",
  "user" : {
    "name" : "Felix",
    "screen_name" : "nicidienase",
    "protected" : false,
    "id_str" : "22396883",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3125784966/8223a4c5c9535be22d15c82ec829c2df_normal.jpeg",
    "id" : 22396883,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.echofon.com/\" rel=\"nofollow\">Echofon</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 6, 26 ],
      "url" : "http://t.co/52bmvW5L",
      "expanded_url" : "http://arcticready.com/social/gallery",
      "display_url" : "arcticready.com/social/gallery"
    }, {
      "indices" : [ 27, 47 ],
      "url" : "http://t.co/6TqHgos7",
      "expanded_url" : "http://arcticready.com/social/4760425-its-a-trap",
      "display_url" : "arcticready.com/social/4760425\u2026"
    } ]
  },
  "geo" : {
  },
  "id_str" : "225605239313666049",
  "text" : "Nice! http://t.co/52bmvW5L http://t.co/6TqHgos7",
  "id" : 225605239313666049,
  "created_at" : "Wed Jul 18 14:57:35 +0000 2012",
  "user" : {
    "name" : "Felix",
    "screen_name" : "nicidienase",
    "protected" : false,
    "id_str" : "22396883",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3125784966/8223a4c5c9535be22d15c82ec829c2df_normal.jpeg",
    "id" : 22396883,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.echofon.com/\" rel=\"nofollow\">Echofon</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "nibbler",
      "screen_name" : "nblr",
      "indices" : [ 3, 8 ],
      "id_str" : "174052946",
      "id" : 174052946
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 71, 91 ],
      "url" : "http://t.co/DGJHI1W1",
      "expanded_url" : "http://futterblog.weberphilipp.de/mull-hat-einen-namen-nespresso/",
      "display_url" : "futterblog.weberphilipp.de/mull-hat-einen\u2026"
    } ]
  },
  "geo" : {
  },
  "id_str" : "225596920880566272",
  "text" : "RT @nblr: Warum nespresso kokolores ist, unterhaltsam zusammengefasst: http://t.co/DGJHI1W1",
  "retweeted_status" : {
    "source" : "web",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 61, 81 ],
        "url" : "http://t.co/DGJHI1W1",
        "expanded_url" : "http://futterblog.weberphilipp.de/mull-hat-einen-namen-nespresso/",
        "display_url" : "futterblog.weberphilipp.de/mull-hat-einen\u2026"
      } ]
    },
    "geo" : {
    },
    "id_str" : "225590158622343168",
    "text" : "Warum nespresso kokolores ist, unterhaltsam zusammengefasst: http://t.co/DGJHI1W1",
    "id" : 225590158622343168,
    "created_at" : "Wed Jul 18 13:57:39 +0000 2012",
    "user" : {
      "name" : "nibbler",
      "screen_name" : "nblr",
      "protected" : false,
      "id_str" : "174052946",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/3311942359/003f0d345d2017faf4f04c54b1e19ad6_normal.png",
      "id" : 174052946,
      "verified" : false
    }
  },
  "id" : 225596920880566272,
  "created_at" : "Wed Jul 18 14:24:31 +0000 2012",
  "user" : {
    "name" : "Felix",
    "screen_name" : "nicidienase",
    "protected" : false,
    "id_str" : "22396883",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3125784966/8223a4c5c9535be22d15c82ec829c2df_normal.jpeg",
    "id" : 22396883,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.echofon.com/\" rel=\"nofollow\">Echofon</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "psy",
      "screen_name" : "psycon",
      "indices" : [ 0, 7 ],
      "id_str" : "87286054",
      "id" : 87286054
    }, {
      "name" : "Uwe Lancier",
      "screen_name" : "Ulan_ka",
      "indices" : [ 18, 26 ],
      "id_str" : "379173142",
      "id" : 379173142
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "225319114875478016",
  "geo" : {
  },
  "id_str" : "225493035344080896",
  "in_reply_to_user_id" : 87286054,
  "text" : "@psycon Ja, hier: @Ulan_ka Warum??",
  "id" : 225493035344080896,
  "in_reply_to_status_id" : 225319114875478016,
  "created_at" : "Wed Jul 18 07:31:43 +0000 2012",
  "in_reply_to_screen_name" : "psycon",
  "in_reply_to_user_id_str" : "87286054",
  "user" : {
    "name" : "Felix",
    "screen_name" : "nicidienase",
    "protected" : false,
    "id_str" : "22396883",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3125784966/8223a4c5c9535be22d15c82ec829c2df_normal.jpeg",
    "id" : 22396883,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.echofon.com/\" rel=\"nofollow\">Echofon</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "psy",
      "screen_name" : "psycon",
      "indices" : [ 0, 7 ],
      "id_str" : "87286054",
      "id" : 87286054
    }, {
      "name" : "$(RandomName)",
      "screen_name" : "Ik4ru5",
      "indices" : [ 8, 15 ],
      "id_str" : "48294441",
      "id" : 48294441
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "225205696638107648",
  "geo" : {
  },
  "id_str" : "225206238982582276",
  "in_reply_to_user_id" : 87286054,
  "text" : "@psycon @Ik4ru5 Fleisch is noch genug da (10 Steaks oder so)",
  "id" : 225206238982582276,
  "in_reply_to_status_id" : 225205696638107648,
  "created_at" : "Tue Jul 17 12:32:06 +0000 2012",
  "in_reply_to_screen_name" : "psycon",
  "in_reply_to_user_id_str" : "87286054",
  "user" : {
    "name" : "Felix",
    "screen_name" : "nicidienase",
    "protected" : false,
    "id_str" : "22396883",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3125784966/8223a4c5c9535be22d15c82ec829c2df_normal.jpeg",
    "id" : 22396883,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.echofon.com/\" rel=\"nofollow\">Echofon</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "psy",
      "screen_name" : "psycon",
      "indices" : [ 0, 7 ],
      "id_str" : "87286054",
      "id" : 87286054
    }, {
      "name" : "$(RandomName)",
      "screen_name" : "Ik4ru5",
      "indices" : [ 8, 15 ],
      "id_str" : "48294441",
      "id" : 48294441
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "225202432932716544",
  "geo" : {
  },
  "id_str" : "225203767761567744",
  "in_reply_to_user_id" : 87286054,
  "text" : "@psycon @ik4ru5 da bin ich schon verplant und das Wetter soll net ganz so sch\u00F6n werden",
  "id" : 225203767761567744,
  "in_reply_to_status_id" : 225202432932716544,
  "created_at" : "Tue Jul 17 12:22:16 +0000 2012",
  "in_reply_to_screen_name" : "psycon",
  "in_reply_to_user_id_str" : "87286054",
  "user" : {
    "name" : "Felix",
    "screen_name" : "nicidienase",
    "protected" : false,
    "id_str" : "22396883",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3125784966/8223a4c5c9535be22d15c82ec829c2df_normal.jpeg",
    "id" : 22396883,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.echofon.com/\" rel=\"nofollow\">Echofon</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "psy",
      "screen_name" : "psycon",
      "indices" : [ 0, 7 ],
      "id_str" : "87286054",
      "id" : 87286054
    }, {
      "name" : "$(RandomName)",
      "screen_name" : "Ik4ru5",
      "indices" : [ 8, 15 ],
      "id_str" : "48294441",
      "id" : 48294441
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "225161986659454976",
  "in_reply_to_user_id" : 87286054,
  "text" : "@psycon @Ik4ru5 Seid ihr in KA? Morgen soll sch\u00F6nes Wetter sein und ich hab nen neuen Grill und noch Fleisch im K\u00FChlschrank!",
  "id" : 225161986659454976,
  "created_at" : "Tue Jul 17 09:36:15 +0000 2012",
  "in_reply_to_screen_name" : "psycon",
  "in_reply_to_user_id_str" : "87286054",
  "user" : {
    "name" : "Felix",
    "screen_name" : "nicidienase",
    "protected" : false,
    "id_str" : "22396883",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3125784966/8223a4c5c9535be22d15c82ec829c2df_normal.jpeg",
    "id" : 22396883,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.echofon.com/\" rel=\"nofollow\">Echofon</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Gryff Nick",
      "screen_name" : "gryffnick",
      "indices" : [ 3, 13 ],
      "id_str" : "269408706",
      "id" : 269408706
    }, {
      "name" : "Sexy Showbiz McK\u00E4se",
      "screen_name" : "Einstueckkaese",
      "indices" : [ 66, 81 ],
      "id_str" : "62560260",
      "id" : 62560260
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 39, 59 ],
      "url" : "http://t.co/aaKoGN13",
      "expanded_url" : "http://tmblr.co/Zfzm4wPWrrxI",
      "display_url" : "tmblr.co/Zfzm4wPWrrxI"
    } ]
  },
  "geo" : {
  },
  "id_str" : "225131590035046401",
  "text" : "RT @gryffnick: Wassergehalt in Prozent http://t.co/aaKoGN13 (u.a. @einstueckkaese)",
  "retweeted_status" : {
    "source" : "<a href=\"http://www.tumblr.com/\" rel=\"nofollow\">Tumblr</a>",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Sexy Showbiz McK\u00E4se",
        "screen_name" : "Einstueckkaese",
        "indices" : [ 51, 66 ],
        "id_str" : "62560260",
        "id" : 62560260
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 24, 44 ],
        "url" : "http://t.co/aaKoGN13",
        "expanded_url" : "http://tmblr.co/Zfzm4wPWrrxI",
        "display_url" : "tmblr.co/Zfzm4wPWrrxI"
      } ]
    },
    "geo" : {
    },
    "id_str" : "225122769174667264",
    "text" : "Wassergehalt in Prozent http://t.co/aaKoGN13 (u.a. @einstueckkaese)",
    "id" : 225122769174667264,
    "created_at" : "Tue Jul 17 07:00:25 +0000 2012",
    "user" : {
      "name" : "Gryff Nick",
      "screen_name" : "gryffnick",
      "protected" : false,
      "id_str" : "269408706",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/1399100655/gryffnickfavstar_normal.jpg",
      "id" : 269408706,
      "verified" : false
    }
  },
  "id" : 225131590035046401,
  "created_at" : "Tue Jul 17 07:35:28 +0000 2012",
  "user" : {
    "name" : "Felix",
    "screen_name" : "nicidienase",
    "protected" : false,
    "id_str" : "22396883",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3125784966/8223a4c5c9535be22d15c82ec829c2df_normal.jpeg",
    "id" : 22396883,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "William Hook",
      "screen_name" : "williamtm",
      "indices" : [ 3, 13 ],
      "id_str" : "4874571",
      "id" : 4874571
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 97, 117 ],
      "url" : "http://t.co/LWw0koKM",
      "expanded_url" : "http://i.imgur.com/J5HTt.jpg",
      "display_url" : "i.imgur.com/J5HTt.jpg"
    } ]
  },
  "geo" : {
  },
  "id_str" : "224784604425502720",
  "text" : "RT @williamtm: Koalas are cute, aren't they? NOT WHEN THEY'RE WET. THEY'RE TERRIFYING AND SCARY. http://t.co/LWw0koKM",
  "retweeted_status" : {
    "source" : "<a href=\"http://www.metrotwit.com/\" rel=\"nofollow\">MetroTwit</a>",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 82, 102 ],
        "url" : "http://t.co/LWw0koKM",
        "expanded_url" : "http://i.imgur.com/J5HTt.jpg",
        "display_url" : "i.imgur.com/J5HTt.jpg"
      } ]
    },
    "geo" : {
    },
    "id_str" : "224582304977264640",
    "text" : "Koalas are cute, aren't they? NOT WHEN THEY'RE WET. THEY'RE TERRIFYING AND SCARY. http://t.co/LWw0koKM",
    "id" : 224582304977264640,
    "created_at" : "Sun Jul 15 19:12:48 +0000 2012",
    "user" : {
      "name" : "William Hook",
      "screen_name" : "williamtm",
      "protected" : false,
      "id_str" : "4874571",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/3100378621/7a6e75599a8a6d88127a98521fb67806_normal.png",
      "id" : 4874571,
      "verified" : false
    }
  },
  "id" : 224784604425502720,
  "created_at" : "Mon Jul 16 08:36:40 +0000 2012",
  "user" : {
    "name" : "Felix",
    "screen_name" : "nicidienase",
    "protected" : false,
    "id_str" : "22396883",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3125784966/8223a4c5c9535be22d15c82ec829c2df_normal.jpeg",
    "id" : 22396883,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Claudia Sommer",
      "screen_name" : "csommer",
      "indices" : [ 3, 11 ],
      "id_str" : "14436873",
      "id" : 14436873
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "s\u00E4tzeunsererkindheit",
      "indices" : [ 81, 102 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "224782048471171072",
  "text" : "RT @csommer: \"Kind, geh bitte aus diesem Internet raus, ich m\u00F6chte telefonieren\" #s\u00E4tzeunsererkindheit",
  "retweeted_status" : {
    "source" : "<a href=\"http://twitter.com/#!/download/ipad\" rel=\"nofollow\">Twitter for iPad</a>",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "s\u00E4tzeunsererkindheit",
        "indices" : [ 68, 89 ]
      } ],
      "urls" : [ ]
    },
    "geo" : {
    },
    "id_str" : "224728690821578752",
    "text" : "\"Kind, geh bitte aus diesem Internet raus, ich m\u00F6chte telefonieren\" #s\u00E4tzeunsererkindheit",
    "id" : 224728690821578752,
    "created_at" : "Mon Jul 16 04:54:29 +0000 2012",
    "user" : {
      "name" : "Claudia Sommer",
      "screen_name" : "csommer",
      "protected" : false,
      "id_str" : "14436873",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/3470016771/387b3ffbd016119c8b0d3d786678a357_normal.jpeg",
      "id" : 14436873,
      "verified" : false
    }
  },
  "id" : 224782048471171072,
  "created_at" : "Mon Jul 16 08:26:31 +0000 2012",
  "user" : {
    "name" : "Felix",
    "screen_name" : "nicidienase",
    "protected" : false,
    "id_str" : "22396883",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3125784966/8223a4c5c9535be22d15c82ec829c2df_normal.jpeg",
    "id" : 22396883,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "$(RandomName)",
      "screen_name" : "Ik4ru5",
      "indices" : [ 0, 7 ],
      "id_str" : "48294441",
      "id" : 48294441
    }, {
      "name" : "psy",
      "screen_name" : "psycon",
      "indices" : [ 8, 15 ],
      "id_str" : "87286054",
      "id" : 87286054
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "223701796667924480",
  "geo" : {
  },
  "id_str" : "223702332465086464",
  "in_reply_to_user_id" : 48294441,
  "text" : "@Ik4ru5 @psycon Dann beantrage ich mal von Mittwoch bis Montag Urlaub",
  "id" : 223702332465086464,
  "in_reply_to_status_id" : 223701796667924480,
  "created_at" : "Fri Jul 13 08:56:06 +0000 2012",
  "in_reply_to_screen_name" : "Ik4ru5",
  "in_reply_to_user_id_str" : "48294441",
  "user" : {
    "name" : "Felix",
    "screen_name" : "nicidienase",
    "protected" : false,
    "id_str" : "22396883",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3125784966/8223a4c5c9535be22d15c82ec829c2df_normal.jpeg",
    "id" : 22396883,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "$(RandomName)",
      "screen_name" : "Ik4ru5",
      "indices" : [ 0, 7 ],
      "id_str" : "48294441",
      "id" : 48294441
    }, {
      "name" : "psy",
      "screen_name" : "psycon",
      "indices" : [ 8, 15 ],
      "id_str" : "87286054",
      "id" : 87286054
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "223502598681001984",
  "geo" : {
  },
  "id_str" : "223701075033735168",
  "in_reply_to_user_id" : 48294441,
  "text" : "@Ik4ru5 @psycon Ich beantrag gleich mal Urlaub, wenn ich den krieg bin ich dabei. Wann wollen wir den los? Mittwochs?",
  "id" : 223701075033735168,
  "in_reply_to_status_id" : 223502598681001984,
  "created_at" : "Fri Jul 13 08:51:07 +0000 2012",
  "in_reply_to_screen_name" : "Ik4ru5",
  "in_reply_to_user_id_str" : "48294441",
  "user" : {
    "name" : "Felix",
    "screen_name" : "nicidienase",
    "protected" : false,
    "id_str" : "22396883",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3125784966/8223a4c5c9535be22d15c82ec829c2df_normal.jpeg",
    "id" : 22396883,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "b2run",
      "indices" : [ 0, 6 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "223683887979692032",
  "text" : "#b2run Platz 1840 mit 00:36:23 Ich bin zufrieden!",
  "id" : 223683887979692032,
  "created_at" : "Fri Jul 13 07:42:49 +0000 2012",
  "user" : {
    "name" : "Felix",
    "screen_name" : "nicidienase",
    "protected" : false,
    "id_str" : "22396883",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3125784966/8223a4c5c9535be22d15c82ec829c2df_normal.jpeg",
    "id" : 22396883,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "cluetec GmbH",
      "screen_name" : "cluetec",
      "indices" : [ 3, 11 ],
      "id_str" : "357348558",
      "id" : 357348558
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "b2run",
      "indices" : [ 19, 25 ]
    } ],
    "urls" : [ {
      "indices" : [ 27, 47 ],
      "url" : "http://t.co/M5IDF1J8",
      "expanded_url" : "http://lockerz.com/s/224412296",
      "display_url" : "lockerz.com/s/224412296"
    } ]
  },
  "geo" : {
  },
  "id_str" : "223507049500250112",
  "text" : "RT @cluetec: Done! #b2run  http://t.co/M5IDF1J8",
  "retweeted_status" : {
    "source" : "<a href=\"http://www.echofon.com/\" rel=\"nofollow\">Echofon</a>",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "b2run",
        "indices" : [ 6, 12 ]
      } ],
      "urls" : [ {
        "indices" : [ 14, 34 ],
        "url" : "http://t.co/M5IDF1J8",
        "expanded_url" : "http://lockerz.com/s/224412296",
        "display_url" : "lockerz.com/s/224412296"
      } ]
    },
    "geo" : {
    },
    "id_str" : "223485042813435904",
    "text" : "Done! #b2run  http://t.co/M5IDF1J8",
    "id" : 223485042813435904,
    "created_at" : "Thu Jul 12 18:32:41 +0000 2012",
    "user" : {
      "name" : "cluetec GmbH",
      "screen_name" : "cluetec",
      "protected" : false,
      "id_str" : "357348558",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/1857333043/profil_spirale_normal.png",
      "id" : 357348558,
      "verified" : false
    }
  },
  "id" : 223507049500250112,
  "created_at" : "Thu Jul 12 20:00:07 +0000 2012",
  "user" : {
    "name" : "Felix",
    "screen_name" : "nicidienase",
    "protected" : false,
    "id_str" : "22396883",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3125784966/8223a4c5c9535be22d15c82ec829c2df_normal.jpeg",
    "id" : 22396883,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kate H.",
      "screen_name" : "elaoe7",
      "indices" : [ 3, 10 ],
      "id_str" : "149650777",
      "id" : 149650777
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 85, 105 ],
      "url" : "http://t.co/9JIebYCF",
      "expanded_url" : "http://instagr.am/p/M-mMDwFQaR/",
      "display_url" : "instagr.am/p/M-mMDwFQaR/"
    } ]
  },
  "geo" : {
  },
  "id_str" : "223398012804796416",
  "text" : "RT @elaoe7: Einhorn Joghurt! Wenn das nicht hilft, dann wei\u00DF ich auch nicht weiter!  http://t.co/9JIebYCF",
  "retweeted_status" : {
    "source" : "<a href=\"http://instagram.com\" rel=\"nofollow\">Instagram</a>",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 73, 93 ],
        "url" : "http://t.co/9JIebYCF",
        "expanded_url" : "http://instagr.am/p/M-mMDwFQaR/",
        "display_url" : "instagr.am/p/M-mMDwFQaR/"
      } ]
    },
    "geo" : {
    },
    "id_str" : "223369239799676928",
    "text" : "Einhorn Joghurt! Wenn das nicht hilft, dann wei\u00DF ich auch nicht weiter!  http://t.co/9JIebYCF",
    "id" : 223369239799676928,
    "created_at" : "Thu Jul 12 10:52:31 +0000 2012",
    "user" : {
      "name" : "Kate H.",
      "screen_name" : "elaoe7",
      "protected" : false,
      "id_str" : "149650777",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/2898969671/d3a01e3cfb60bc2e8107233bcb7a88f7_normal.png",
      "id" : 149650777,
      "verified" : false
    }
  },
  "id" : 223398012804796416,
  "created_at" : "Thu Jul 12 12:46:51 +0000 2012",
  "user" : {
    "name" : "Felix",
    "screen_name" : "nicidienase",
    "protected" : false,
    "id_str" : "22396883",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3125784966/8223a4c5c9535be22d15c82ec829c2df_normal.jpeg",
    "id" : 22396883,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Richard Castle",
      "screen_name" : "WriteRCastle",
      "indices" : [ 3, 16 ],
      "id_str" : "59525600",
      "id" : 59525600
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "222804036624203777",
  "text" : "RT @WriteRCastle: Dark matter filaments can be seen in space. The Higgs boson was discovered. Now, all I ask is: how long until we get w ...",
  "retweeted_status" : {
    "source" : "web",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : {
    },
    "id_str" : "222787329843150848",
    "text" : "Dark matter filaments can be seen in space. The Higgs boson was discovered. Now, all I ask is: how long until we get working lightsabers?",
    "id" : 222787329843150848,
    "created_at" : "Tue Jul 10 20:20:13 +0000 2012",
    "user" : {
      "name" : "Richard Castle",
      "screen_name" : "WriteRCastle",
      "protected" : false,
      "id_str" : "59525600",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/1801703366/photo__9__normal.jpg",
      "id" : 59525600,
      "verified" : false
    }
  },
  "id" : 222804036624203777,
  "created_at" : "Tue Jul 10 21:26:36 +0000 2012",
  "user" : {
    "name" : "Felix",
    "screen_name" : "nicidienase",
    "protected" : false,
    "id_str" : "22396883",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3125784966/8223a4c5c9535be22d15c82ec829c2df_normal.jpeg",
    "id" : 22396883,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Wil Wheaton",
      "screen_name" : "wilw",
      "indices" : [ 3, 8 ],
      "id_str" : "1183041",
      "id" : 1183041
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "222803543516651522",
  "text" : "RT @wilw: Google... Google... Google. We need to talk: No doodle for Nikola Tesla's birthday today? I am disappoint.",
  "retweeted_status" : {
    "source" : "web",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : {
    },
    "id_str" : "222782493705777152",
    "text" : "Google... Google... Google. We need to talk: No doodle for Nikola Tesla's birthday today? I am disappoint.",
    "id" : 222782493705777152,
    "created_at" : "Tue Jul 10 20:01:00 +0000 2012",
    "user" : {
      "name" : "Wil Wheaton",
      "screen_name" : "wilw",
      "protected" : false,
      "id_str" : "1183041",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/2449509523/f0gkhyhpwmv7m6ncyxbl_normal.png",
      "id" : 1183041,
      "verified" : true
    }
  },
  "id" : 222803543516651522,
  "created_at" : "Tue Jul 10 21:24:38 +0000 2012",
  "user" : {
    "name" : "Felix",
    "screen_name" : "nicidienase",
    "protected" : false,
    "id_str" : "22396883",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3125784966/8223a4c5c9535be22d15c82ec829c2df_normal.jpeg",
    "id" : 22396883,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.echofon.com/\" rel=\"nofollow\">Echofon</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "grischder",
      "screen_name" : "grischder",
      "indices" : [ 3, 13 ],
      "id_str" : "14377141",
      "id" : 14377141
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 59, 79 ],
      "url" : "http://t.co/q647YW09",
      "expanded_url" : "http://www.ustream.tv/channel-popup/sevenkittens",
      "display_url" : "ustream.tv/channel-popup/\u2026"
    } ]
  },
  "geo" : {
  },
  "id_str" : "222707635206623234",
  "text" : "RT @grischder: Daf\u00FCr wurden Internet-Livestreams erfunden! http://t.co/q647YW09",
  "retweeted_status" : {
    "source" : "<a href=\"http://itunes.apple.com/us/app/twitter/id409789998?mt=12\" rel=\"nofollow\">Twitter for Mac</a>",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 44, 64 ],
        "url" : "http://t.co/q647YW09",
        "expanded_url" : "http://www.ustream.tv/channel-popup/sevenkittens",
        "display_url" : "ustream.tv/channel-popup/\u2026"
      } ]
    },
    "geo" : {
    },
    "id_str" : "222703779349409794",
    "text" : "Daf\u00FCr wurden Internet-Livestreams erfunden! http://t.co/q647YW09",
    "id" : 222703779349409794,
    "created_at" : "Tue Jul 10 14:48:13 +0000 2012",
    "user" : {
      "name" : "grischder",
      "screen_name" : "grischder",
      "protected" : false,
      "id_str" : "14377141",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/2829188706/89fb232553bcd0e924a9e564a016b18a_normal.png",
      "id" : 14377141,
      "verified" : false
    }
  },
  "id" : 222707635206623234,
  "created_at" : "Tue Jul 10 15:03:32 +0000 2012",
  "user" : {
    "name" : "Felix",
    "screen_name" : "nicidienase",
    "protected" : false,
    "id_str" : "22396883",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3125784966/8223a4c5c9535be22d15c82ec829c2df_normal.jpeg",
    "id" : 22396883,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.echofon.com/\" rel=\"nofollow\">Echofon</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "juka",
      "screen_name" : "gruenzeug",
      "indices" : [ 3, 13 ],
      "id_str" : "62966464",
      "id" : 62966464
    }, {
      "name" : "Thilo",
      "screen_name" : "_thilon",
      "indices" : [ 114, 122 ],
      "id_str" : "166611689",
      "id" : 166611689
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 88, 108 ],
      "url" : "http://t.co/goLWb6OA",
      "expanded_url" : "http://www.engadget.com/2012/07/10/austrian-city-builds-public-library-with-qr-codes-nfc-stickers/",
      "display_url" : "engadget.com/2012/07/10/aus\u2026"
    } ]
  },
  "geo" : {
  },
  "id_str" : "222676697206636545",
  "text" : "RT @gruenzeug: E-Books zum Download \u00FCber die Stadt verteilt in Klagenfurt. Voll genial! http://t.co/goLWb6OA (via @_thilon)",
  "retweeted_status" : {
    "source" : "web",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Thilo",
        "screen_name" : "_thilon",
        "indices" : [ 99, 107 ],
        "id_str" : "166611689",
        "id" : 166611689
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 73, 93 ],
        "url" : "http://t.co/goLWb6OA",
        "expanded_url" : "http://www.engadget.com/2012/07/10/austrian-city-builds-public-library-with-qr-codes-nfc-stickers/",
        "display_url" : "engadget.com/2012/07/10/aus\u2026"
      } ]
    },
    "geo" : {
    },
    "id_str" : "222664234817945602",
    "text" : "E-Books zum Download \u00FCber die Stadt verteilt in Klagenfurt. Voll genial! http://t.co/goLWb6OA (via @_thilon)",
    "id" : 222664234817945602,
    "created_at" : "Tue Jul 10 12:11:05 +0000 2012",
    "user" : {
      "name" : "juka",
      "screen_name" : "gruenzeug",
      "protected" : false,
      "id_str" : "62966464",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/1956751239/juka_normal.jpg",
      "id" : 62966464,
      "verified" : false
    }
  },
  "id" : 222676697206636545,
  "created_at" : "Tue Jul 10 13:00:36 +0000 2012",
  "user" : {
    "name" : "Felix",
    "screen_name" : "nicidienase",
    "protected" : false,
    "id_str" : "22396883",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3125784966/8223a4c5c9535be22d15c82ec829c2df_normal.jpeg",
    "id" : 22396883,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.echofon.com/\" rel=\"nofollow\">Echofon</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jemus",
      "screen_name" : "Jemus42",
      "indices" : [ 3, 11 ],
      "id_str" : "50339766",
      "id" : 50339766
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 24, 44 ],
      "url" : "http://t.co/IgLr3mrr",
      "expanded_url" : "http://what-if.xkcd.com/1/",
      "display_url" : "what-if.xkcd.com/1/"
    } ]
  },
  "geo" : {
  },
  "id_str" : "222652883848536064",
  "text" : "RT @Jemus42: xkcd &lt;3 http://t.co/IgLr3mrr",
  "retweeted_status" : {
    "source" : "<a href=\"http://itunes.apple.com/us/app/twitter/id409789998?mt=12\" rel=\"nofollow\">Twitter for Mac</a>",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 11, 31 ],
        "url" : "http://t.co/IgLr3mrr",
        "expanded_url" : "http://what-if.xkcd.com/1/",
        "display_url" : "what-if.xkcd.com/1/"
      } ]
    },
    "geo" : {
    },
    "id_str" : "222640364035645440",
    "text" : "xkcd &lt;3 http://t.co/IgLr3mrr",
    "id" : 222640364035645440,
    "created_at" : "Tue Jul 10 10:36:13 +0000 2012",
    "user" : {
      "name" : "Jemus",
      "screen_name" : "Jemus42",
      "protected" : false,
      "id_str" : "50339766",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/2442155420/13fr1e3on4dzb9fn7i48_normal.jpeg",
      "id" : 50339766,
      "verified" : false
    }
  },
  "id" : 222652883848536064,
  "created_at" : "Tue Jul 10 11:25:58 +0000 2012",
  "user" : {
    "name" : "Felix",
    "screen_name" : "nicidienase",
    "protected" : false,
    "id_str" : "22396883",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3125784966/8223a4c5c9535be22d15c82ec829c2df_normal.jpeg",
    "id" : 22396883,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.echofon.com/\" rel=\"nofollow\">Echofon</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "hdz",
      "screen_name" : "hdznrrd",
      "indices" : [ 3, 11 ],
      "id_str" : "100255193",
      "id" : 100255193
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 35, 55 ],
      "url" : "http://t.co/JxYZLKuR",
      "expanded_url" : "http://theoatmeal.com/blog/charity_money",
      "display_url" : "theoatmeal.com/blog/charity_m\u2026"
    } ]
  },
  "geo" : {
  },
  "id_str" : "222612852052209665",
  "text" : "RT @hdznrrd: internet. i lubs you. http://t.co/JxYZLKuR",
  "retweeted_status" : {
    "source" : "web",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 22, 42 ],
        "url" : "http://t.co/JxYZLKuR",
        "expanded_url" : "http://theoatmeal.com/blog/charity_money",
        "display_url" : "theoatmeal.com/blog/charity_m\u2026"
      } ]
    },
    "geo" : {
    },
    "id_str" : "222603921993105408",
    "text" : "internet. i lubs you. http://t.co/JxYZLKuR",
    "id" : 222603921993105408,
    "created_at" : "Tue Jul 10 08:11:25 +0000 2012",
    "user" : {
      "name" : "hdz",
      "screen_name" : "hdznrrd",
      "protected" : false,
      "id_str" : "100255193",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/1407871966/avatar_normal.jpg",
      "id" : 100255193,
      "verified" : false
    }
  },
  "id" : 222612852052209665,
  "created_at" : "Tue Jul 10 08:46:54 +0000 2012",
  "user" : {
    "name" : "Felix",
    "screen_name" : "nicidienase",
    "protected" : false,
    "id_str" : "22396883",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3125784966/8223a4c5c9535be22d15c82ec829c2df_normal.jpeg",
    "id" : 22396883,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://getspaz.com\" rel=\"nofollow\">Spaz HD for webOS</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Andreas J\u00E4gle",
      "screen_name" : "ajaegle",
      "indices" : [ 3, 11 ],
      "id_str" : "78735610",
      "id" : 78735610
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "github",
      "indices" : [ 17, 24 ]
    }, {
      "text" : "android",
      "indices" : [ 52, 60 ]
    } ],
    "urls" : [ {
      "indices" : [ 84, 105 ],
      "url" : "https://t.co/pchag8kR",
      "expanded_url" : "https://github.com/blog/1187-github-android-app-released",
      "display_url" : "github.com/blog/1187-gith\u2026"
    } ]
  },
  "geo" : {
  },
  "id_str" : "222451618262691841",
  "text" : "RT @ajaegle: the #github app is a great example how #android apps should look like! https://t.co/pchag8kR +1 for the octocat loading ani ...",
  "retweeted_status" : {
    "source" : "<a href=\"http://www.echofon.com/\" rel=\"nofollow\">Echofon</a>",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "github",
        "indices" : [ 4, 11 ]
      }, {
        "text" : "android",
        "indices" : [ 39, 47 ]
      } ],
      "urls" : [ {
        "indices" : [ 71, 92 ],
        "url" : "https://t.co/pchag8kR",
        "expanded_url" : "https://github.com/blog/1187-github-android-app-released",
        "display_url" : "github.com/blog/1187-gith\u2026"
      } ]
    },
    "geo" : {
    },
    "id_str" : "222442219922141184",
    "text" : "the #github app is a great example how #android apps should look like! https://t.co/pchag8kR +1 for the octocat loading animation!",
    "id" : 222442219922141184,
    "created_at" : "Mon Jul 09 21:28:52 +0000 2012",
    "user" : {
      "name" : "Andreas J\u00E4gle",
      "screen_name" : "ajaegle",
      "protected" : false,
      "id_str" : "78735610",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/1586973287/ajaegle_normal.png",
      "id" : 78735610,
      "verified" : false
    }
  },
  "id" : 222451618262691841,
  "created_at" : "Mon Jul 09 22:06:13 +0000 2012",
  "user" : {
    "name" : "Felix",
    "screen_name" : "nicidienase",
    "protected" : false,
    "id_str" : "22396883",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3125784966/8223a4c5c9535be22d15c82ec829c2df_normal.jpeg",
    "id" : 22396883,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kate H.",
      "screen_name" : "elaoe7",
      "indices" : [ 0, 7 ],
      "id_str" : "149650777",
      "id" : 149650777
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "221981840146313219",
  "geo" : {
  },
  "id_str" : "221985044674252800",
  "in_reply_to_user_id" : 149650777,
  "text" : "@elaoe7 H\u00E4ttet ihr alle Zutaten f\u00FCr Flammkuchen?",
  "id" : 221985044674252800,
  "in_reply_to_status_id" : 221981840146313219,
  "created_at" : "Sun Jul 08 15:12:13 +0000 2012",
  "in_reply_to_screen_name" : "elaoe7",
  "in_reply_to_user_id_str" : "149650777",
  "user" : {
    "name" : "Felix",
    "screen_name" : "nicidienase",
    "protected" : false,
    "id_str" : "22396883",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3125784966/8223a4c5c9535be22d15c82ec829c2df_normal.jpeg",
    "id" : 22396883,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "hdz",
      "screen_name" : "hdznrrd",
      "indices" : [ 3, 11 ],
      "id_str" : "100255193",
      "id" : 100255193
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 49, 69 ],
      "url" : "http://t.co/Ddd9j7nx",
      "expanded_url" : "http://d24w6bsrhbeh9d.cloudfront.net/photo/4395741_700b_v1.jpg",
      "display_url" : "d24w6bsrhbeh9d.cloudfront.net/photo/4395741_\u2026"
    } ]
  },
  "geo" : {
  },
  "id_str" : "221594583266627586",
  "text" : "RT @hdznrrd: Science, you're gonna like it here. http://t.co/Ddd9j7nx",
  "retweeted_status" : {
    "source" : "web",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 36, 56 ],
        "url" : "http://t.co/Ddd9j7nx",
        "expanded_url" : "http://d24w6bsrhbeh9d.cloudfront.net/photo/4395741_700b_v1.jpg",
        "display_url" : "d24w6bsrhbeh9d.cloudfront.net/photo/4395741_\u2026"
      } ]
    },
    "geo" : {
    },
    "id_str" : "221530393977962496",
    "text" : "Science, you're gonna like it here. http://t.co/Ddd9j7nx",
    "id" : 221530393977962496,
    "created_at" : "Sat Jul 07 09:05:36 +0000 2012",
    "user" : {
      "name" : "hdz",
      "screen_name" : "hdznrrd",
      "protected" : false,
      "id_str" : "100255193",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/1407871966/avatar_normal.jpg",
      "id" : 100255193,
      "verified" : false
    }
  },
  "id" : 221594583266627586,
  "created_at" : "Sat Jul 07 13:20:40 +0000 2012",
  "user" : {
    "name" : "Felix",
    "screen_name" : "nicidienase",
    "protected" : false,
    "id_str" : "22396883",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3125784966/8223a4c5c9535be22d15c82ec829c2df_normal.jpeg",
    "id" : 22396883,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ashley Winkler",
      "screen_name" : "facella",
      "indices" : [ 0, 8 ],
      "id_str" : "37720367",
      "id" : 37720367
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "221338777145196544",
  "geo" : {
  },
  "id_str" : "221341830913073152",
  "in_reply_to_user_id" : 37720367,
  "text" : "@facella wie w\u00E4rs mit facel.la ?",
  "id" : 221341830913073152,
  "in_reply_to_status_id" : 221338777145196544,
  "created_at" : "Fri Jul 06 20:36:19 +0000 2012",
  "in_reply_to_screen_name" : "facella",
  "in_reply_to_user_id_str" : "37720367",
  "user" : {
    "name" : "Felix",
    "screen_name" : "nicidienase",
    "protected" : false,
    "id_str" : "22396883",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3125784966/8223a4c5c9535be22d15c82ec829c2df_normal.jpeg",
    "id" : 22396883,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Command Line Magic",
      "screen_name" : "climagic",
      "indices" : [ 3, 12 ],
      "id_str" : "91333167",
      "id" : 91333167
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "221339166213021696",
  "text" : "RT @climagic: The CLI isn't an \"old technology\", its an alternative one. You can use it to do modern things too, often times more effici ...",
  "retweeted_status" : {
    "source" : "<a href=\"http://suso.suso.org/xulu/Command_Line_Magic\" rel=\"nofollow\">CLI Magic poster</a>",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : {
    },
    "id_str" : "221276787957702658",
    "text" : "The CLI isn't an \"old technology\", its an alternative one. You can use it to do modern things too, often times more efficiently.",
    "id" : 221276787957702658,
    "created_at" : "Fri Jul 06 16:17:52 +0000 2012",
    "user" : {
      "name" : "Command Line Magic",
      "screen_name" : "climagic",
      "protected" : false,
      "id_str" : "91333167",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/535876218/climagic-icon_normal.png",
      "id" : 91333167,
      "verified" : false
    }
  },
  "id" : 221339166213021696,
  "created_at" : "Fri Jul 06 20:25:44 +0000 2012",
  "user" : {
    "name" : "Felix",
    "screen_name" : "nicidienase",
    "protected" : false,
    "id_str" : "22396883",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3125784966/8223a4c5c9535be22d15c82ec829c2df_normal.jpeg",
    "id" : 22396883,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.echofon.com/\" rel=\"nofollow\">Echofon</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jan B\u00F6hmermann",
      "screen_name" : "janboehm",
      "indices" : [ 3, 12 ],
      "id_str" : "19072286",
      "id" : 19072286
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 49, 69 ],
      "url" : "http://t.co/abyANhLH",
      "expanded_url" : "http://yfrog.com/khnrqnjp",
      "display_url" : "yfrog.com/khnrqnjp"
    } ]
  },
  "geo" : {
  },
  "id_str" : "221256678484619265",
  "text" : "RT @janboehm: Anglifizierung als Wachstumsmotor. http://t.co/abyANhLH",
  "retweeted_status" : {
    "source" : "<a href=\"http://itunes.apple.com/us/app/twitter/id409789998?mt=12\" rel=\"nofollow\">Twitter for Mac</a>",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 35, 55 ],
        "url" : "http://t.co/abyANhLH",
        "expanded_url" : "http://yfrog.com/khnrqnjp",
        "display_url" : "yfrog.com/khnrqnjp"
      } ]
    },
    "geo" : {
    },
    "id_str" : "221192678308724736",
    "text" : "Anglifizierung als Wachstumsmotor. http://t.co/abyANhLH",
    "id" : 221192678308724736,
    "created_at" : "Fri Jul 06 10:43:38 +0000 2012",
    "user" : {
      "name" : "Jan B\u00F6hmermann",
      "screen_name" : "janboehm",
      "protected" : false,
      "id_str" : "19072286",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/2352180597/xbfznu1oflx5t706kocs_normal.jpeg",
      "id" : 19072286,
      "verified" : true
    }
  },
  "id" : 221256678484619265,
  "created_at" : "Fri Jul 06 14:57:57 +0000 2012",
  "user" : {
    "name" : "Felix",
    "screen_name" : "nicidienase",
    "protected" : false,
    "id_str" : "22396883",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3125784966/8223a4c5c9535be22d15c82ec829c2df_normal.jpeg",
    "id" : 22396883,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.echofon.com/\" rel=\"nofollow\">Echofon</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Rob Loach",
      "screen_name" : "RobLoach",
      "indices" : [ 3, 12 ],
      "id_str" : "14067531",
      "id" : 14067531
    }, {
      "name" : "Matt Farina",
      "screen_name" : "mattfarina",
      "indices" : [ 82, 93 ],
      "id_str" : "5926692",
      "id" : 5926692
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Bootstrap",
      "indices" : [ 46, 56 ]
    } ],
    "urls" : [ {
      "indices" : [ 57, 77 ],
      "url" : "http://t.co/Df8pYvRB",
      "expanded_url" : "http://bootswatch.com",
      "display_url" : "bootswatch.com"
    } ]
  },
  "geo" : {
  },
  "id_str" : "221256538327760896",
  "text" : "RT @RobLoach: Saving the web from the default #Bootstrap http://t.co/Df8pYvRB via @mattfarina",
  "retweeted_status" : {
    "source" : "web",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Matt Farina",
        "screen_name" : "mattfarina",
        "indices" : [ 68, 79 ],
        "id_str" : "5926692",
        "id" : 5926692
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "Bootstrap",
        "indices" : [ 32, 42 ]
      } ],
      "urls" : [ {
        "indices" : [ 43, 63 ],
        "url" : "http://t.co/Df8pYvRB",
        "expanded_url" : "http://bootswatch.com",
        "display_url" : "bootswatch.com"
      } ]
    },
    "geo" : {
    },
    "id_str" : "221253177457123329",
    "text" : "Saving the web from the default #Bootstrap http://t.co/Df8pYvRB via @mattfarina",
    "id" : 221253177457123329,
    "created_at" : "Fri Jul 06 14:44:02 +0000 2012",
    "user" : {
      "name" : "Rob Loach",
      "screen_name" : "RobLoach",
      "protected" : false,
      "id_str" : "14067531",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/1501836814/robloach_normal.jpg",
      "id" : 14067531,
      "verified" : false
    }
  },
  "id" : 221256538327760896,
  "created_at" : "Fri Jul 06 14:57:24 +0000 2012",
  "user" : {
    "name" : "Felix",
    "screen_name" : "nicidienase",
    "protected" : false,
    "id_str" : "22396883",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3125784966/8223a4c5c9535be22d15c82ec829c2df_normal.jpeg",
    "id" : 22396883,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.echofon.com/\" rel=\"nofollow\">Echofon</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Command Line Magic",
      "screen_name" : "climagic",
      "indices" : [ 3, 12 ],
      "id_str" : "91333167",
      "id" : 91333167
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "221229186155683841",
  "text" : "RT @climagic: A command line lets you get intimate with your computer, data and protocols. GUIs are like wearing full body condoms.",
  "retweeted_status" : {
    "source" : "<a href=\"http://suso.suso.org/xulu/Command_Line_Magic\" rel=\"nofollow\">CLI Magic poster</a>",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : {
    },
    "id_str" : "221223328575262722",
    "text" : "A command line lets you get intimate with your computer, data and protocols. GUIs are like wearing full body condoms.",
    "id" : 221223328575262722,
    "created_at" : "Fri Jul 06 12:45:26 +0000 2012",
    "user" : {
      "name" : "Command Line Magic",
      "screen_name" : "climagic",
      "protected" : false,
      "id_str" : "91333167",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/535876218/climagic-icon_normal.png",
      "id" : 91333167,
      "verified" : false
    }
  },
  "id" : 221229186155683841,
  "created_at" : "Fri Jul 06 13:08:42 +0000 2012",
  "user" : {
    "name" : "Felix",
    "screen_name" : "nicidienase",
    "protected" : false,
    "id_str" : "22396883",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3125784966/8223a4c5c9535be22d15c82ec829c2df_normal.jpeg",
    "id" : 22396883,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.echofon.com/\" rel=\"nofollow\">Echofon</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "xinitrc",
      "screen_name" : "xinitrc",
      "indices" : [ 3, 11 ],
      "id_str" : "15558660",
      "id" : 15558660
    }, {
      "name" : "Tim Weber",
      "screen_name" : "scy",
      "indices" : [ 13, 17 ],
      "id_str" : "8308632",
      "id" : 8308632
    }, {
      "name" : "F. Nord",
      "screen_name" : "rettetdieborg",
      "indices" : [ 18, 32 ],
      "id_str" : "905841942",
      "id" : 905841942
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "221222227847290881",
  "text" : "RT @xinitrc: @scy @rettetdieborg There are only two hard things in Computer science: cache invalidation, naming things and off by one er ...",
  "retweeted_status" : {
    "source" : "<a href=\"http://itunes.apple.com/us/app/twitter/id409789998?mt=12\" rel=\"nofollow\">Twitter for Mac</a>",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Tim Weber",
        "screen_name" : "scy",
        "indices" : [ 0, 4 ],
        "id_str" : "8308632",
        "id" : 8308632
      }, {
        "name" : "F. Nord",
        "screen_name" : "rettetdieborg",
        "indices" : [ 5, 19 ],
        "id_str" : "905841942",
        "id" : 905841942
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "in_reply_to_status_id_str" : "221220436447465474",
    "geo" : {
    },
    "id_str" : "221220679679348736",
    "in_reply_to_user_id" : 8308632,
    "text" : "@scy @rettetdieborg There are only two hard things in Computer science: cache invalidation, naming things and off by one errors.",
    "id" : 221220679679348736,
    "in_reply_to_status_id" : 221220436447465474,
    "created_at" : "Fri Jul 06 12:34:54 +0000 2012",
    "in_reply_to_screen_name" : "scy",
    "in_reply_to_user_id_str" : "8308632",
    "user" : {
      "name" : "xinitrc",
      "screen_name" : "xinitrc",
      "protected" : false,
      "id_str" : "15558660",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/1813278308/256x256-White-Borders_normal.jpg",
      "id" : 15558660,
      "verified" : false
    }
  },
  "id" : 221222227847290881,
  "created_at" : "Fri Jul 06 12:41:03 +0000 2012",
  "user" : {
    "name" : "Felix",
    "screen_name" : "nicidienase",
    "protected" : false,
    "id_str" : "22396883",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3125784966/8223a4c5c9535be22d15c82ec829c2df_normal.jpeg",
    "id" : 22396883,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.echofon.com/\" rel=\"nofollow\">Echofon</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tim Weber",
      "screen_name" : "scy",
      "indices" : [ 3, 7 ],
      "id_str" : "8308632",
      "id" : 8308632
    }, {
      "name" : "F. Nord",
      "screen_name" : "rettetdieborg",
      "indices" : [ 12, 26 ],
      "id_str" : "905841942",
      "id" : 905841942
    }, {
      "name" : "Tim Weber",
      "screen_name" : "scy",
      "indices" : [ 28, 32 ],
      "id_str" : "8308632",
      "id" : 8308632
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "221222140882591745",
  "text" : "RT @scy: RT @rettetdieborg: @scy \nThere are only two hard things in Computer Science: cache invalidation and naming things. (Phil Karlton)",
  "retweeted_status" : {
    "source" : "<a href=\"http://www.tweetdeck.com\" rel=\"nofollow\">TweetDeck</a>",
    "entities" : {
      "user_mentions" : [ {
        "name" : "F. Nord",
        "screen_name" : "rettetdieborg",
        "indices" : [ 3, 17 ],
        "id_str" : "905841942",
        "id" : 905841942
      }, {
        "name" : "Tim Weber",
        "screen_name" : "scy",
        "indices" : [ 19, 23 ],
        "id_str" : "8308632",
        "id" : 8308632
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : {
    },
    "id_str" : "221220436447465474",
    "text" : "RT @rettetdieborg: @scy \nThere are only two hard things in Computer Science: cache invalidation and naming things. (Phil Karlton)",
    "id" : 221220436447465474,
    "created_at" : "Fri Jul 06 12:33:56 +0000 2012",
    "user" : {
      "name" : "Tim Weber",
      "screen_name" : "scy",
      "protected" : false,
      "id_str" : "8308632",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/424137519/avatar184_normal.jpg",
      "id" : 8308632,
      "verified" : false
    }
  },
  "id" : 221222140882591745,
  "created_at" : "Fri Jul 06 12:40:43 +0000 2012",
  "user" : {
    "name" : "Felix",
    "screen_name" : "nicidienase",
    "protected" : false,
    "id_str" : "22396883",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3125784966/8223a4c5c9535be22d15c82ec829c2df_normal.jpeg",
    "id" : 22396883,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.echofon.com/\" rel=\"nofollow\">Echofon</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "psy",
      "screen_name" : "psycon",
      "indices" : [ 0, 7 ],
      "id_str" : "87286054",
      "id" : 87286054
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "221202088795979776",
  "geo" : {
  },
  "id_str" : "221202910640476161",
  "in_reply_to_user_id" : 87286054,
  "text" : "@psycon Ich will lieber KoFfeIn-Labcoats!",
  "id" : 221202910640476161,
  "in_reply_to_status_id" : 221202088795979776,
  "created_at" : "Fri Jul 06 11:24:18 +0000 2012",
  "in_reply_to_screen_name" : "psycon",
  "in_reply_to_user_id_str" : "87286054",
  "user" : {
    "name" : "Felix",
    "screen_name" : "nicidienase",
    "protected" : false,
    "id_str" : "22396883",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3125784966/8223a4c5c9535be22d15c82ec829c2df_normal.jpeg",
    "id" : 22396883,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.echofon.com/\" rel=\"nofollow\">Echofon</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "psy",
      "screen_name" : "psycon",
      "indices" : [ 0, 7 ],
      "id_str" : "87286054",
      "id" : 87286054
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "221198902764900352",
  "geo" : {
  },
  "id_str" : "221199203232256000",
  "in_reply_to_user_id" : 87286054,
  "text" : "@psycon Bin heute auch mit kurzer Hose und T-Shirt aus dem Haus, zum Gl\u00FCck hatte ich noch nen Pulli in der Tasche.",
  "id" : 221199203232256000,
  "in_reply_to_status_id" : 221198902764900352,
  "created_at" : "Fri Jul 06 11:09:34 +0000 2012",
  "in_reply_to_screen_name" : "psycon",
  "in_reply_to_user_id_str" : "87286054",
  "user" : {
    "name" : "Felix",
    "screen_name" : "nicidienase",
    "protected" : false,
    "id_str" : "22396883",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3125784966/8223a4c5c9535be22d15c82ec829c2df_normal.jpeg",
    "id" : 22396883,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tobias Kr\u00E4ntzer",
      "screen_name" : "anagrom_ataf",
      "indices" : [ 3, 16 ],
      "id_str" : "17561564",
      "id" : 17561564
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 36, 56 ],
      "url" : "http://t.co/mXI6jmcP",
      "expanded_url" : "http://httpstatusdogs.com/",
      "display_url" : "httpstatusdogs.com"
    } ]
  },
  "geo" : {
  },
  "id_str" : "221196798520340480",
  "text" : "RT @anagrom_ataf: Didn't know this: http://t.co/mXI6jmcP",
  "retweeted_status" : {
    "source" : "<a href=\"http://itunes.apple.com/us/app/twitter/id409789998?mt=12\" rel=\"nofollow\">Twitter for Mac</a>",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 18, 38 ],
        "url" : "http://t.co/mXI6jmcP",
        "expanded_url" : "http://httpstatusdogs.com/",
        "display_url" : "httpstatusdogs.com"
      } ]
    },
    "geo" : {
    },
    "id_str" : "221187707299311616",
    "text" : "Didn't know this: http://t.co/mXI6jmcP",
    "id" : 221187707299311616,
    "created_at" : "Fri Jul 06 10:23:53 +0000 2012",
    "user" : {
      "name" : "Tobias Kr\u00E4ntzer",
      "screen_name" : "anagrom_ataf",
      "protected" : false,
      "id_str" : "17561564",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/1246674576/icon_normal.jpg",
      "id" : 17561564,
      "verified" : false
    }
  },
  "id" : 221196798520340480,
  "created_at" : "Fri Jul 06 11:00:01 +0000 2012",
  "user" : {
    "name" : "Felix",
    "screen_name" : "nicidienase",
    "protected" : false,
    "id_str" : "22396883",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3125784966/8223a4c5c9535be22d15c82ec829c2df_normal.jpeg",
    "id" : 22396883,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.echofon.com/\" rel=\"nofollow\">Echofon</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "paulcano",
      "screen_name" : "paulcano",
      "indices" : [ 3, 12 ],
      "id_str" : "15474367",
      "id" : 15474367
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 71, 91 ],
      "url" : "http://t.co/LiNJM5vb",
      "expanded_url" : "http://i.imgur.com/4PLAz.jpg",
      "display_url" : "i.imgur.com/4PLAz.jpg"
    } ]
  },
  "geo" : {
  },
  "id_str" : "221155430867550208",
  "text" : "RT @paulcano: \"I'm no computer genius, but I think it's out of gas...\" http://t.co/LiNJM5vb",
  "retweeted_status" : {
    "source" : "<a href=\"http://www.apple.com\" rel=\"nofollow\">iOS</a>",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 57, 77 ],
        "url" : "http://t.co/LiNJM5vb",
        "expanded_url" : "http://i.imgur.com/4PLAz.jpg",
        "display_url" : "i.imgur.com/4PLAz.jpg"
      } ]
    },
    "geo" : {
    },
    "id_str" : "221088662509731840",
    "text" : "\"I'm no computer genius, but I think it's out of gas...\" http://t.co/LiNJM5vb",
    "id" : 221088662509731840,
    "created_at" : "Fri Jul 06 03:50:19 +0000 2012",
    "user" : {
      "name" : "paulcano",
      "screen_name" : "paulcano",
      "protected" : false,
      "id_str" : "15474367",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/2820862972/17bd0e86279f74d149c83b33ea5bbbd9_normal.jpeg",
      "id" : 15474367,
      "verified" : false
    }
  },
  "id" : 221155430867550208,
  "created_at" : "Fri Jul 06 08:15:38 +0000 2012",
  "user" : {
    "name" : "Felix",
    "screen_name" : "nicidienase",
    "protected" : false,
    "id_str" : "22396883",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3125784966/8223a4c5c9535be22d15c82ec829c2df_normal.jpeg",
    "id" : 22396883,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http://twitter.com/nicidienase/status/221007934182801408/photo/1",
      "indices" : [ 9, 29 ],
      "url" : "http://t.co/UCwvivLT",
      "media_url" : "http://pbs.twimg.com/media/AxEti5SCQAAxRbH.jpg",
      "id_str" : "221007934233133056",
      "id" : 221007934233133056,
      "media_url_https" : "https://pbs.twimg.com/media/AxEti5SCQAAxRbH.jpg",
      "sizes" : [ {
        "h" : 1365,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 2560,
        "resize" : "fit",
        "w" : 1920
      }, {
        "h" : 453,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 800,
        "resize" : "fit",
        "w" : 600
      } ],
      "display_url" : "pic.twitter.com/UCwvivLT"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "221007934182801408",
  "text" : "Nerd-Gun http://t.co/UCwvivLT",
  "id" : 221007934182801408,
  "created_at" : "Thu Jul 05 22:29:34 +0000 2012",
  "user" : {
    "name" : "Felix",
    "screen_name" : "nicidienase",
    "protected" : false,
    "id_str" : "22396883",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3125784966/8223a4c5c9535be22d15c82ec829c2df_normal.jpeg",
    "id" : 22396883,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tim Weber",
      "screen_name" : "scy",
      "indices" : [ 3, 7 ],
      "id_str" : "8308632",
      "id" : 8308632
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 116, 136 ],
      "url" : "http://t.co/9hisKOYC",
      "expanded_url" : "http://thecodelesscode.com/case/33",
      "display_url" : "thecodelesscode.com/case/33"
    } ]
  },
  "geo" : {
  },
  "id_str" : "220905787793477636",
  "text" : "RT @scy: Wieder mal an nem h\u00E4sslichen, gewachsenen Frickelsystem am basteln, das niemand refactoren will? Lest das. http://t.co/9hisKOYC ...",
  "retweeted_status" : {
    "source" : "<a href=\"http://www.tweetdeck.com\" rel=\"nofollow\">TweetDeck</a>",
    "entities" : {
      "user_mentions" : [ {
        "name" : "thetaphi",
        "screen_name" : "thetaphi",
        "indices" : [ 131, 140 ],
        "id_str" : "18846006",
        "id" : 18846006
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 107, 127 ],
        "url" : "http://t.co/9hisKOYC",
        "expanded_url" : "http://thecodelesscode.com/case/33",
        "display_url" : "thecodelesscode.com/case/33"
      } ]
    },
    "geo" : {
    },
    "id_str" : "220833905492754433",
    "text" : "Wieder mal an nem h\u00E4sslichen, gewachsenen Frickelsystem am basteln, das niemand refactoren will? Lest das. http://t.co/9hisKOYC /v @thetaphi",
    "id" : 220833905492754433,
    "created_at" : "Thu Jul 05 10:58:00 +0000 2012",
    "user" : {
      "name" : "Tim Weber",
      "screen_name" : "scy",
      "protected" : false,
      "id_str" : "8308632",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/424137519/avatar184_normal.jpg",
      "id" : 8308632,
      "verified" : false
    }
  },
  "id" : 220905787793477636,
  "created_at" : "Thu Jul 05 15:43:38 +0000 2012",
  "user" : {
    "name" : "Felix",
    "screen_name" : "nicidienase",
    "protected" : false,
    "id_str" : "22396883",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3125784966/8223a4c5c9535be22d15c82ec829c2df_normal.jpeg",
    "id" : 22396883,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.echofon.com/\" rel=\"nofollow\">Echofon</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Etienne Gard\u00E9",
      "screen_name" : "EtienneToGo",
      "indices" : [ 3, 15 ],
      "id_str" : "29463130",
      "id" : 29463130
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "220845496686739457",
  "text" : "RT @EtienneToGo: Leute, es ist meine quasi journalistische Pflicht euch \u00FCber die neusten Entwicklungen in Sachen HTML5 zu informieren: h ...",
  "retweeted_status" : {
    "source" : "web",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 118, 138 ],
        "url" : "http://t.co/HRmYQ2lt",
        "expanded_url" : "http://www.weberleifels.com/?p=518",
        "display_url" : "weberleifels.com/?p=518"
      } ]
    },
    "geo" : {
    },
    "id_str" : "220810851156897792",
    "text" : "Leute, es ist meine quasi journalistische Pflicht euch \u00FCber die neusten Entwicklungen in Sachen HTML5 zu informieren: http://t.co/HRmYQ2lt",
    "id" : 220810851156897792,
    "created_at" : "Thu Jul 05 09:26:24 +0000 2012",
    "user" : {
      "name" : "Etienne Gard\u00E9",
      "screen_name" : "EtienneToGo",
      "protected" : false,
      "id_str" : "29463130",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/2732765993/4e1adfb1c03a3467fef55cd8a12436ac_normal.jpeg",
      "id" : 29463130,
      "verified" : true
    }
  },
  "id" : 220845496686739457,
  "created_at" : "Thu Jul 05 11:44:04 +0000 2012",
  "user" : {
    "name" : "Felix",
    "screen_name" : "nicidienase",
    "protected" : false,
    "id_str" : "22396883",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3125784966/8223a4c5c9535be22d15c82ec829c2df_normal.jpeg",
    "id" : 22396883,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.echofon.com/\" rel=\"nofollow\">Echofon</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Eva Eichhorn",
      "screen_name" : "MamsellChaos",
      "indices" : [ 10, 23 ],
      "id_str" : "140774041",
      "id" : 140774041
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "nyanpanties",
      "indices" : [ 37, 49 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "220807089600217089",
  "text" : "Yipee RT: @MamsellChaos: Erste Fuhre #nyanpanties verschickt: Check.",
  "id" : 220807089600217089,
  "created_at" : "Thu Jul 05 09:11:27 +0000 2012",
  "user" : {
    "name" : "Felix",
    "screen_name" : "nicidienase",
    "protected" : false,
    "id_str" : "22396883",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3125784966/8223a4c5c9535be22d15c82ec829c2df_normal.jpeg",
    "id" : 22396883,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.echofon.com/\" rel=\"nofollow\">Echofon</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tim Weber",
      "screen_name" : "scy",
      "indices" : [ 3, 7 ],
      "id_str" : "8308632",
      "id" : 8308632
    }, {
      "name" : "(\u261E\uFF9F\u2200\uFF9F)\u261E",
      "screen_name" : "bluegene_",
      "indices" : [ 102, 112 ],
      "id_str" : "18237053",
      "id" : 18237053
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 76, 96 ],
      "url" : "http://t.co/76qRfEsf",
      "expanded_url" : "http://try.github.com/",
      "display_url" : "try.github.com"
    } ]
  },
  "geo" : {
  },
  "id_str" : "220799635130822656",
  "text" : "RT @scy: \u201EGot 15\u00A0minutes and want to learn Git?\u201C Ein interaktives Tutorial. http://t.co/76qRfEsf (via @bluegene_)",
  "retweeted_status" : {
    "source" : "<a href=\"http://www.tweetdeck.com\" rel=\"nofollow\">TweetDeck</a>",
    "entities" : {
      "user_mentions" : [ {
        "name" : "(\u261E\uFF9F\u2200\uFF9F)\u261E",
        "screen_name" : "bluegene_",
        "indices" : [ 93, 103 ],
        "id_str" : "18237053",
        "id" : 18237053
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 67, 87 ],
        "url" : "http://t.co/76qRfEsf",
        "expanded_url" : "http://try.github.com/",
        "display_url" : "try.github.com"
      } ]
    },
    "geo" : {
    },
    "id_str" : "220788327153016832",
    "text" : "\u201EGot 15\u00A0minutes and want to learn Git?\u201C Ein interaktives Tutorial. http://t.co/76qRfEsf (via @bluegene_)",
    "id" : 220788327153016832,
    "created_at" : "Thu Jul 05 07:56:53 +0000 2012",
    "user" : {
      "name" : "Tim Weber",
      "screen_name" : "scy",
      "protected" : false,
      "id_str" : "8308632",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/424137519/avatar184_normal.jpg",
      "id" : 8308632,
      "verified" : false
    }
  },
  "id" : 220799635130822656,
  "created_at" : "Thu Jul 05 08:41:49 +0000 2012",
  "user" : {
    "name" : "Felix",
    "screen_name" : "nicidienase",
    "protected" : false,
    "id_str" : "22396883",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3125784966/8223a4c5c9535be22d15c82ec829c2df_normal.jpeg",
    "id" : 22396883,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.echofon.com/\" rel=\"nofollow\">Echofon</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "OReilly_Verlag",
      "screen_name" : "OReilly_Verlag",
      "indices" : [ 3, 18 ],
      "id_str" : "16309106",
      "id" : 16309106
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "urban",
      "indices" : [ 118, 124 ]
    }, {
      "text" : "knitting",
      "indices" : [ 125, 134 ]
    } ],
    "urls" : [ {
      "indices" : [ 97, 117 ],
      "url" : "http://t.co/If8VnMEQ",
      "expanded_url" : "http://de.engadget.com/2012/07/04/strickgrafitti-r2-d2-pulli-macht-den-poller-zum-bot-nice/",
      "display_url" : "de.engadget.com/2012/07/04/str\u2026"
    } ]
  },
  "geo" : {
  },
  "id_str" : "220519074705309696",
  "text" : "RT @OReilly_Verlag: Wenn unser Sysadmin vom Stricken schw\u00E4rmt, dann steckt so etwas dahinter ... http://t.co/If8VnMEQ #urban #knitting",
  "retweeted_status" : {
    "source" : "web",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "urban",
        "indices" : [ 98, 104 ]
      }, {
        "text" : "knitting",
        "indices" : [ 105, 114 ]
      } ],
      "urls" : [ {
        "indices" : [ 77, 97 ],
        "url" : "http://t.co/If8VnMEQ",
        "expanded_url" : "http://de.engadget.com/2012/07/04/strickgrafitti-r2-d2-pulli-macht-den-poller-zum-bot-nice/",
        "display_url" : "de.engadget.com/2012/07/04/str\u2026"
      } ]
    },
    "geo" : {
    },
    "id_str" : "220511044248944640",
    "text" : "Wenn unser Sysadmin vom Stricken schw\u00E4rmt, dann steckt so etwas dahinter ... http://t.co/If8VnMEQ #urban #knitting",
    "id" : 220511044248944640,
    "created_at" : "Wed Jul 04 13:35:04 +0000 2012",
    "user" : {
      "name" : "OReilly_Verlag",
      "screen_name" : "OReilly_Verlag",
      "protected" : false,
      "id_str" : "16309106",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/2195486750/fb_banner_icon_normal.jpg",
      "id" : 16309106,
      "verified" : false
    }
  },
  "id" : 220519074705309696,
  "created_at" : "Wed Jul 04 14:06:59 +0000 2012",
  "user" : {
    "name" : "Felix",
    "screen_name" : "nicidienase",
    "protected" : false,
    "id_str" : "22396883",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3125784966/8223a4c5c9535be22d15c82ec829c2df_normal.jpeg",
    "id" : 22396883,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.echofon.com/\" rel=\"nofollow\">Echofon</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lars Fischer",
      "screen_name" : "Fischblog",
      "indices" : [ 3, 13 ],
      "id_str" : "14700783",
      "id" : 14700783
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "220451526727045120",
  "text" : "RT @Fischblog: Fun Fact: Das Higgs-Boson ist ein Teilchen ohne Quark.",
  "retweeted_status" : {
    "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : {
    },
    "id_str" : "220451329309540352",
    "text" : "Fun Fact: Das Higgs-Boson ist ein Teilchen ohne Quark.",
    "id" : 220451329309540352,
    "created_at" : "Wed Jul 04 09:37:47 +0000 2012",
    "user" : {
      "name" : "Lars Fischer",
      "screen_name" : "Fischblog",
      "protected" : false,
      "id_str" : "14700783",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/2280490409/tm7beswe21h2t970pke5_normal.jpeg",
      "id" : 14700783,
      "verified" : false
    }
  },
  "id" : 220451526727045120,
  "created_at" : "Wed Jul 04 09:38:34 +0000 2012",
  "user" : {
    "name" : "Felix",
    "screen_name" : "nicidienase",
    "protected" : false,
    "id_str" : "22396883",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3125784966/8223a4c5c9535be22d15c82ec829c2df_normal.jpeg",
    "id" : 22396883,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.echofon.com/\" rel=\"nofollow\">Echofon</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Public",
      "screen_name" : "publictorsten",
      "indices" : [ 3, 17 ],
      "id_str" : "69526491",
      "id" : 69526491
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "220449517080809472",
  "text" : "RT @publictorsten: Der Verfassungsschutz hatte BTW das Higgs-Boson schon vor Jahren gefunden, aber dann die Akten geschreddert",
  "retweeted_status" : {
    "source" : "<a href=\"http://choqok.gnufolks.org/\" rel=\"nofollow\">Choqok</a>",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : {
    },
    "id_str" : "220447752063172608",
    "text" : "Der Verfassungsschutz hatte BTW das Higgs-Boson schon vor Jahren gefunden, aber dann die Akten geschreddert",
    "id" : 220447752063172608,
    "created_at" : "Wed Jul 04 09:23:34 +0000 2012",
    "user" : {
      "name" : "Public",
      "screen_name" : "publictorsten",
      "protected" : false,
      "id_str" : "69526491",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/1137073893/20060711223624_Iceberg_normal.jpg",
      "id" : 69526491,
      "verified" : false
    }
  },
  "id" : 220449517080809472,
  "created_at" : "Wed Jul 04 09:30:35 +0000 2012",
  "user" : {
    "name" : "Felix",
    "screen_name" : "nicidienase",
    "protected" : false,
    "id_str" : "22396883",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3125784966/8223a4c5c9535be22d15c82ec829c2df_normal.jpeg",
    "id" : 22396883,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.echofon.com/\" rel=\"nofollow\">Echofon</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tom Scott",
      "screen_name" : "tomscott",
      "indices" : [ 3, 12 ],
      "id_str" : "7816392",
      "id" : 7816392
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "higgs",
      "indices" : [ 32, 38 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "220441887646035968",
  "text" : "RT @tomscott: At the end of the #higgs announcement, one of the CERN team will pause, nonchalantly say \"oh, one more thing\", then calmly ...",
  "retweeted_status" : {
    "source" : "<a href=\"http://www.tweetdeck.com\" rel=\"nofollow\">TweetDeck</a>",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "higgs",
        "indices" : [ 18, 24 ]
      } ],
      "urls" : [ ]
    },
    "geo" : {
    },
    "id_str" : "220429625816383489",
    "text" : "At the end of the #higgs announcement, one of the CERN team will pause, nonchalantly say \"oh, one more thing\", then calmly teleport away.",
    "id" : 220429625816383489,
    "created_at" : "Wed Jul 04 08:11:32 +0000 2012",
    "user" : {
      "name" : "Tom Scott",
      "screen_name" : "tomscott",
      "protected" : false,
      "id_str" : "7816392",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/2049904488/twitter_normal.jpg",
      "id" : 7816392,
      "verified" : false
    }
  },
  "id" : 220441887646035968,
  "created_at" : "Wed Jul 04 09:00:16 +0000 2012",
  "user" : {
    "name" : "Felix",
    "screen_name" : "nicidienase",
    "protected" : false,
    "id_str" : "22396883",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3125784966/8223a4c5c9535be22d15c82ec829c2df_normal.jpeg",
    "id" : 22396883,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "CERN",
      "screen_name" : "CERN",
      "indices" : [ 3, 8 ],
      "id_str" : "15234407",
      "id" : 15234407
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Higgs",
      "indices" : [ 92, 98 ]
    }, {
      "text" : "ICHEP2012",
      "indices" : [ 126, 136 ]
    } ],
    "urls" : [ {
      "indices" : [ 105, 125 ],
      "url" : "http://t.co/MBjIwytL",
      "expanded_url" : "http://cern.ch/press/PressReleases/Releases2012/PR17.12E.html",
      "display_url" : "cern.ch/press/PressRel\u2026"
    } ]
  },
  "geo" : {
  },
  "id_str" : "220430407517208577",
  "text" : "RT @CERN: CERN Press Release: CERN experiments observe particle consistent with long-sought #Higgs boson\nhttp://t.co/MBjIwytL #ICHEP2012",
  "retweeted_status" : {
    "source" : "web",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "Higgs",
        "indices" : [ 82, 88 ]
      }, {
        "text" : "ICHEP2012",
        "indices" : [ 116, 126 ]
      } ],
      "urls" : [ {
        "indices" : [ 95, 115 ],
        "url" : "http://t.co/MBjIwytL",
        "expanded_url" : "http://cern.ch/press/PressReleases/Releases2012/PR17.12E.html",
        "display_url" : "cern.ch/press/PressRel\u2026"
      } ]
    },
    "geo" : {
    },
    "id_str" : "220428195655196673",
    "text" : "CERN Press Release: CERN experiments observe particle consistent with long-sought #Higgs boson\nhttp://t.co/MBjIwytL #ICHEP2012",
    "id" : 220428195655196673,
    "created_at" : "Wed Jul 04 08:05:51 +0000 2012",
    "user" : {
      "name" : "CERN",
      "screen_name" : "CERN",
      "protected" : false,
      "id_str" : "15234407",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/117374181/twitter_cern_normal.png",
      "id" : 15234407,
      "verified" : true
    }
  },
  "id" : 220430407517208577,
  "created_at" : "Wed Jul 04 08:14:39 +0000 2012",
  "user" : {
    "name" : "Felix",
    "screen_name" : "nicidienase",
    "protected" : false,
    "id_str" : "22396883",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3125784966/8223a4c5c9535be22d15c82ec829c2df_normal.jpeg",
    "id" : 22396883,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Andy Hedges",
      "screen_name" : "andyhedges",
      "indices" : [ 3, 14 ],
      "id_str" : "19483200",
      "id" : 19483200
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 37, 57 ],
      "url" : "http://t.co/LTRB3LPA",
      "expanded_url" : "http://i.imgur.com/Wx91Z.jpg",
      "display_url" : "i.imgur.com/Wx91Z.jpg"
    } ]
  },
  "geo" : {
  },
  "id_str" : "220287432589983744",
  "text" : "RT @andyhedges: RIP Computer Science http://t.co/LTRB3LPA",
  "retweeted_status" : {
    "source" : "<a href=\"http://www.tweetdeck.com\" rel=\"nofollow\">TweetDeck</a>",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 21, 41 ],
        "url" : "http://t.co/LTRB3LPA",
        "expanded_url" : "http://i.imgur.com/Wx91Z.jpg",
        "display_url" : "i.imgur.com/Wx91Z.jpg"
      } ]
    },
    "geo" : {
    },
    "id_str" : "220237753231745025",
    "text" : "RIP Computer Science http://t.co/LTRB3LPA",
    "id" : 220237753231745025,
    "created_at" : "Tue Jul 03 19:29:06 +0000 2012",
    "user" : {
      "name" : "Andy Hedges",
      "screen_name" : "andyhedges",
      "protected" : false,
      "id_str" : "19483200",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/3419102997/02569108e2fc66b75b4c4fd9a3140523_normal.png",
      "id" : 19483200,
      "verified" : false
    }
  },
  "id" : 220287432589983744,
  "created_at" : "Tue Jul 03 22:46:31 +0000 2012",
  "user" : {
    "name" : "Felix",
    "screen_name" : "nicidienase",
    "protected" : false,
    "id_str" : "22396883",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3125784966/8223a4c5c9535be22d15c82ec829c2df_normal.jpeg",
    "id" : 22396883,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.echofon.com/\" rel=\"nofollow\">Echofon</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Michael Merk",
      "screen_name" : "DerMorb",
      "indices" : [ 3, 11 ],
      "id_str" : "95022235",
      "id" : 95022235
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 57, 77 ],
      "url" : "http://t.co/UZwAJXrl",
      "expanded_url" : "http://en.wikipedia.org/wiki/Travelling_Salesman_(2012_film)",
      "display_url" : "en.wikipedia.org/wiki/Travellin\u2026"
    } ]
  },
  "geo" : {
  },
  "id_str" : "220174771508363266",
  "text" : "RT @DerMorb: Neuer Film f\u00FCr Informatik-Interessierte: :) http://t.co/UZwAJXrl",
  "retweeted_status" : {
    "source" : "web",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 44, 64 ],
        "url" : "http://t.co/UZwAJXrl",
        "expanded_url" : "http://en.wikipedia.org/wiki/Travelling_Salesman_(2012_film)",
        "display_url" : "en.wikipedia.org/wiki/Travellin\u2026"
      } ]
    },
    "geo" : {
    },
    "id_str" : "220162132799520768",
    "text" : "Neuer Film f\u00FCr Informatik-Interessierte: :) http://t.co/UZwAJXrl",
    "id" : 220162132799520768,
    "created_at" : "Tue Jul 03 14:28:37 +0000 2012",
    "user" : {
      "name" : "Michael Merk",
      "screen_name" : "DerMorb",
      "protected" : false,
      "id_str" : "95022235",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/561722284/36527823_normal.jpg",
      "id" : 95022235,
      "verified" : false
    }
  },
  "id" : 220174771508363266,
  "created_at" : "Tue Jul 03 15:18:50 +0000 2012",
  "user" : {
    "name" : "Felix",
    "screen_name" : "nicidienase",
    "protected" : false,
    "id_str" : "22396883",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3125784966/8223a4c5c9535be22d15c82ec829c2df_normal.jpeg",
    "id" : 22396883,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "219215337219043329",
  "text" : "Unifest: In der Sauna mit Pornophonique",
  "id" : 219215337219043329,
  "created_at" : "Sat Jun 30 23:46:23 +0000 2012",
  "user" : {
    "name" : "Felix",
    "screen_name" : "nicidienase",
    "protected" : false,
    "id_str" : "22396883",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3125784966/8223a4c5c9535be22d15c82ec829c2df_normal.jpeg",
    "id" : 22396883,
    "verified" : false
  }
} ]