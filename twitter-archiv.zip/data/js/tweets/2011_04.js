Grailbird.data.tweets_2011_04 = 
 [ {
  "source" : "<a href=\"http://tweed.pivotallabs.com\" rel=\"nofollow\">Tweed webOS</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 49.016446, 8.543048 ]
  },
  "id_str" : "64030060528664577",
  "text" : "Baum auf den Gleisen zwischen PF und Wilferdingen.\nS-Bahn f\u00E4hrt jetzt \u00FCber Bretten und M\u00FChlacker nach Pforzheim.",
  "id" : 64030060528664577,
  "created_at" : "Fri Apr 29 18:15:30 +0000 2011",
  "user" : {
    "name" : "Felix",
    "screen_name" : "nicidienase",
    "protected" : false,
    "id_str" : "22396883",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3125784966/8223a4c5c9535be22d15c82ec829c2df_normal.jpeg",
    "id" : 22396883,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://tweed.pivotallabs.com\" rel=\"nofollow\">Tweed webOS</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Bahn",
      "screen_name" : "bahn",
      "indices" : [ 4, 9 ],
      "id_str" : "14700845",
      "id" : 14700845
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "bahn",
      "indices" : [ 104, 109 ]
    }, {
      "text" : "fail",
      "indices" : [ 110, 115 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 49.002143, 8.448772 ]
  },
  "id_str" : "64026197281091585",
  "text" : "Hey @Bahn was soll den das? Warum halten keine RE/IREs in Pforzheim? Jetzt darf ich ewig S-Bahn fahren. #bahn #fail",
  "id" : 64026197281091585,
  "created_at" : "Fri Apr 29 18:00:09 +0000 2011",
  "user" : {
    "name" : "Felix",
    "screen_name" : "nicidienase",
    "protected" : false,
    "id_str" : "22396883",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3125784966/8223a4c5c9535be22d15c82ec829c2df_normal.jpeg",
    "id" : 22396883,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://tweed.pivotallabs.com\" rel=\"nofollow\">Tweed webOS</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mario Sixtus",
      "screen_name" : "sixtus",
      "indices" : [ 3, 10 ],
      "id_str" : "9334352",
      "id" : 9334352
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "61536176603021312",
  "text" : "RT @sixtus: \"How to fix any Computer\"  http://bit.ly/fwLmJc",
  "retweeted_status" : {
    "source" : "<a href=\"http://bitly.com\" rel=\"nofollow\">bitly</a>",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : {
    },
    "id_str" : "61348416147558400",
    "text" : "\"How to fix any Computer\"  http://bit.ly/fwLmJc",
    "id" : 61348416147558400,
    "created_at" : "Fri Apr 22 08:39:36 +0000 2011",
    "user" : {
      "name" : "Mario Sixtus",
      "screen_name" : "sixtus",
      "protected" : false,
      "id_str" : "9334352",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/274542155/mario_normal.gif",
      "id" : 9334352,
      "verified" : true
    }
  },
  "id" : 61536176603021312,
  "created_at" : "Fri Apr 22 21:05:42 +0000 2011",
  "user" : {
    "name" : "Felix",
    "screen_name" : "nicidienase",
    "protected" : false,
    "id_str" : "22396883",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3125784966/8223a4c5c9535be22d15c82ec829c2df_normal.jpeg",
    "id" : 22396883,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitpic.com\" rel=\"nofollow\">Twitpic</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "60847243195981824",
  "text" : "Was macht man in alkoholisiertem Zustand mit einem Fenster und Post-Its? Space Invaders! http://twitpic.com/4nd2jt",
  "id" : 60847243195981824,
  "created_at" : "Wed Apr 20 23:28:07 +0000 2011",
  "user" : {
    "name" : "Felix",
    "screen_name" : "nicidienase",
    "protected" : false,
    "id_str" : "22396883",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3125784966/8223a4c5c9535be22d15c82ec829c2df_normal.jpeg",
    "id" : 22396883,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://tweed.pivotallabs.com\" rel=\"nofollow\">Tweed webOS</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "words like swords",
      "screen_name" : "Weltregierung",
      "indices" : [ 3, 17 ],
      "id_str" : "6413902",
      "id" : 6413902
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "60267316398661632",
  "text" : "RT @Weltregierung: Pizza, Cola, wenig Licht ... fertig ist das Nerdgesicht.",
  "retweeted_status" : {
    "source" : "web",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : {
    },
    "id_str" : "59956437077590016",
    "text" : "Pizza, Cola, wenig Licht ... fertig ist das Nerdgesicht.",
    "id" : 59956437077590016,
    "created_at" : "Mon Apr 18 12:28:23 +0000 2011",
    "user" : {
      "name" : "words like swords",
      "screen_name" : "Weltregierung",
      "protected" : false,
      "id_str" : "6413902",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/3509683546/f17e80d411fe259225cdebb9ecdb45ff_normal.jpeg",
      "id" : 6413902,
      "verified" : false
    }
  },
  "id" : 60267316398661632,
  "created_at" : "Tue Apr 19 09:03:42 +0000 2011",
  "user" : {
    "name" : "Felix",
    "screen_name" : "nicidienase",
    "protected" : false,
    "id_str" : "22396883",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3125784966/8223a4c5c9535be22d15c82ec829c2df_normal.jpeg",
    "id" : 22396883,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.smartrunner.com\" rel=\"nofollow\">SmartRunner</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "smartrunner",
      "indices" : [ 67, 79 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "60031649747963904",
  "text" : "Ich war heute 6 km Laufen. Hab daf\u00FCr 0:40:29 h ben\u00F6tigt. Schau auf #smartrunner: http://bit.ly/iiaX6A",
  "id" : 60031649747963904,
  "created_at" : "Mon Apr 18 17:27:15 +0000 2011",
  "user" : {
    "name" : "Felix",
    "screen_name" : "nicidienase",
    "protected" : false,
    "id_str" : "22396883",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3125784966/8223a4c5c9535be22d15c82ec829c2df_normal.jpeg",
    "id" : 22396883,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://tweed.pivotallabs.com\" rel=\"nofollow\">Tweed webOS</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Caalie",
      "screen_name" : "caalie",
      "indices" : [ 3, 10 ],
      "id_str" : "16361928",
      "id" : 16361928
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "56723119800459264",
  "text" : "RT @caalie: \"The trouble with quotes on the internet is that you never know if they are genuine\" - Abraham Lincoln",
  "retweeted_status" : {
    "source" : "web",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : {
    },
    "id_str" : "56140833170276353",
    "text" : "\"The trouble with quotes on the internet is that you never know if they are genuine\" - Abraham Lincoln",
    "id" : 56140833170276353,
    "created_at" : "Thu Apr 07 23:46:32 +0000 2011",
    "user" : {
      "name" : "Caalie",
      "screen_name" : "caalie",
      "protected" : false,
      "id_str" : "16361928",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/60392625/Clookingdown_normal.jpg",
      "id" : 16361928,
      "verified" : false
    }
  },
  "id" : 56723119800459264,
  "created_at" : "Sat Apr 09 14:20:20 +0000 2011",
  "user" : {
    "name" : "Felix",
    "screen_name" : "nicidienase",
    "protected" : false,
    "id_str" : "22396883",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3125784966/8223a4c5c9535be22d15c82ec829c2df_normal.jpeg",
    "id" : 22396883,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://tweed.pivotallabs.com\" rel=\"nofollow\">Tweed webOS</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Waldhornbar",
      "indices" : [ 21, 33 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 49.007559, 8.408051 ]
  },
  "id_str" : "55049156548501505",
  "text" : "Grade zur\u00FCck aus der #Waldhornbar, mal schaun ob das was wird mit Mathe morgen fr\u00FCh um acht...",
  "id" : 55049156548501505,
  "created_at" : "Mon Apr 04 23:28:36 +0000 2011",
  "user" : {
    "name" : "Felix",
    "screen_name" : "nicidienase",
    "protected" : false,
    "id_str" : "22396883",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3125784966/8223a4c5c9535be22d15c82ec829c2df_normal.jpeg",
    "id" : 22396883,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://tweed.pivotallabs.com\" rel=\"nofollow\">Tweed webOS</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 48.962092, 8.626167 ]
  },
  "id_str" : "54580586874019840",
  "text" : "War heute mittag das erste mal dieses Jahr Eis essen. Und meine Family is grade Ski fahren.",
  "id" : 54580586874019840,
  "created_at" : "Sun Apr 03 16:26:40 +0000 2011",
  "user" : {
    "name" : "Felix",
    "screen_name" : "nicidienase",
    "protected" : false,
    "id_str" : "22396883",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3125784966/8223a4c5c9535be22d15c82ec829c2df_normal.jpeg",
    "id" : 22396883,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://tweed.pivotallabs.com\" rel=\"nofollow\">Tweed webOS</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 48.968938, 8.610396 ]
  },
  "id_str" : "54510402754711552",
  "text" : "Mittagessen bei Oma war lecker. Jetzt is mein Bauch voll :)",
  "id" : 54510402754711552,
  "created_at" : "Sun Apr 03 11:47:47 +0000 2011",
  "user" : {
    "name" : "Felix",
    "screen_name" : "nicidienase",
    "protected" : false,
    "id_str" : "22396883",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3125784966/8223a4c5c9535be22d15c82ec829c2df_normal.jpeg",
    "id" : 22396883,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://tweed.pivotallabs.com\" rel=\"nofollow\">Tweed webOS</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 49.007559, 8.408051 ]
  },
  "id_str" : "53813257055645696",
  "text" : "Hmm, soll ich joggen gehen oder nicht .. ?",
  "id" : 53813257055645696,
  "created_at" : "Fri Apr 01 13:37:34 +0000 2011",
  "user" : {
    "name" : "Felix",
    "screen_name" : "nicidienase",
    "protected" : false,
    "id_str" : "22396883",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3125784966/8223a4c5c9535be22d15c82ec829c2df_normal.jpeg",
    "id" : 22396883,
    "verified" : false
  }
} ]