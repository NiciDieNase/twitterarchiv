Grailbird.data.tweets_2011_02 = 
 [ {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "40278393878618112",
  "text" : "Ne gute Stunde bis Sonnenaufgang, langsam wirds Zeit das ich ins Bett komme. Gut n8!",
  "id" : 40278393878618112,
  "created_at" : "Wed Feb 23 05:14:52 +0000 2011",
  "user" : {
    "name" : "Felix",
    "screen_name" : "nicidienase",
    "protected" : false,
    "id_str" : "22396883",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3125784966/8223a4c5c9535be22d15c82ec829c2df_normal.jpeg",
    "id" : 22396883,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://tweed.pivotallabs.com\" rel=\"nofollow\">Tweed webOS</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 49.01546, 8.392528 ]
  },
  "id_str" : "35978550490312704",
  "text" : "Letzte Klausur rum! 120 min Zeit, nach 80 war ich fertig, hatte alles zweimal nochmal durchgelesen und hab angefangen mich zu langweilen:-)",
  "id" : 35978550490312704,
  "created_at" : "Fri Feb 11 08:28:49 +0000 2011",
  "user" : {
    "name" : "Felix",
    "screen_name" : "nicidienase",
    "protected" : false,
    "id_str" : "22396883",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3125784966/8223a4c5c9535be22d15c82ec829c2df_normal.jpeg",
    "id" : 22396883,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://tweed.pivotallabs.com\" rel=\"nofollow\">Tweed webOS</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 49.015126, 8.392652 ]
  },
  "id_str" : "35322637345366017",
  "text" : "Die ersten Klausurergebnisse sind online. 1,0 in Theo.Der Rest kann jetzt aber leider nur noch schlechter sein.Vor allem nach Mathe heute.",
  "id" : 35322637345366017,
  "created_at" : "Wed Feb 09 13:02:27 +0000 2011",
  "user" : {
    "name" : "Felix",
    "screen_name" : "nicidienase",
    "protected" : false,
    "id_str" : "22396883",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3125784966/8223a4c5c9535be22d15c82ec829c2df_normal.jpeg",
    "id" : 22396883,
    "verified" : false
  }
} ]