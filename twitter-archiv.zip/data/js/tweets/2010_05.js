Grailbird.data.tweets_2010_05 = 
 [ {
  "source" : "<a href=\"http://pivotallabs.com/landing/tweed\" rel=\"nofollow\">Tweed</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Edward",
      "screen_name" : "twitgeridoo",
      "indices" : [ 3, 15 ],
      "id_str" : "46379961",
      "id" : 46379961
    }, {
      "name" : "Carsten Knobloch",
      "screen_name" : "caschy",
      "indices" : [ 106, 113 ],
      "id_str" : "15822932",
      "id" : 15822932
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "BP",
      "indices" : [ 48, 51 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "15065258302",
  "text" : "RT @twitgeridoo: Self-fulfilling prophecy \u00BB Die #BP Werbung von 1999 http://j.mp/aYyUvW Schon hart.. (via @caschy)",
  "id" : 15065258302,
  "created_at" : "Sun May 30 21:25:48 +0000 2010",
  "user" : {
    "name" : "Felix",
    "screen_name" : "nicidienase",
    "protected" : false,
    "id_str" : "22396883",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3125784966/8223a4c5c9535be22d15c82ec829c2df_normal.jpeg",
    "id" : 22396883,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://pivotallabs.com/landing/tweed\" rel=\"nofollow\">Tweed</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "litervollmilch",
      "screen_name" : "litervollmilch",
      "indices" : [ 3, 18 ],
      "id_str" : "19151669",
      "id" : 19151669
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "GEMA",
      "indices" : [ 38, 43 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "14947557647",
  "text" : "RT @litervollmilch: FFFFFFFFUUUUUUUUU #GEMA http://twitpic.com/1rxgei",
  "id" : 14947557647,
  "created_at" : "Sat May 29 02:14:50 +0000 2010",
  "user" : {
    "name" : "Felix",
    "screen_name" : "nicidienase",
    "protected" : false,
    "id_str" : "22396883",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3125784966/8223a4c5c9535be22d15c82ec829c2df_normal.jpeg",
    "id" : 22396883,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://pivotallabs.com/landing/tweed\" rel=\"nofollow\">Tweed</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "memo",
      "screen_name" : "memo42",
      "indices" : [ 3, 10 ],
      "id_str" : "55311456",
      "id" : 55311456
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "14947456783",
  "text" : "RT @memo42: dary",
  "id" : 14947456783,
  "created_at" : "Sat May 29 02:12:56 +0000 2010",
  "user" : {
    "name" : "Felix",
    "screen_name" : "nicidienase",
    "protected" : false,
    "id_str" : "22396883",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3125784966/8223a4c5c9535be22d15c82ec829c2df_normal.jpeg",
    "id" : 22396883,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://pivotallabs.com/landing/tweed\" rel=\"nofollow\">Tweed</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "memo",
      "screen_name" : "memo42",
      "indices" : [ 3, 10 ],
      "id_str" : "55311456",
      "id" : 55311456
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Waldhornbar",
      "indices" : [ 50, 62 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "14947448470",
  "text" : "RT @memo42: N\u00E4chsten Montag ist Quiz-Abend in der #Waldhornbar. www.wh36.uni-karlsruhe.de/zimmer/bar It's gonna be legen -wait for it-",
  "id" : 14947448470,
  "created_at" : "Sat May 29 02:12:46 +0000 2010",
  "user" : {
    "name" : "Felix",
    "screen_name" : "nicidienase",
    "protected" : false,
    "id_str" : "22396883",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3125784966/8223a4c5c9535be22d15c82ec829c2df_normal.jpeg",
    "id" : 22396883,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitpic.com/\" rel=\"nofollow\">TwitPic</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "14631069239",
  "text" : "Chillen im Schlossgarten http://twitpic.com/1qnp3c",
  "id" : 14631069239,
  "created_at" : "Mon May 24 15:45:46 +0000 2010",
  "user" : {
    "name" : "Felix",
    "screen_name" : "nicidienase",
    "protected" : false,
    "id_str" : "22396883",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3125784966/8223a4c5c9535be22d15c82ec829c2df_normal.jpeg",
    "id" : 22396883,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://pivotallabs.com/landing/tweed\" rel=\"nofollow\">Tweed</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "14578326512",
  "text" : "http://xkcd.com/743/",
  "id" : 14578326512,
  "created_at" : "Sun May 23 20:55:37 +0000 2010",
  "user" : {
    "name" : "Felix",
    "screen_name" : "nicidienase",
    "protected" : false,
    "id_str" : "22396883",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3125784966/8223a4c5c9535be22d15c82ec829c2df_normal.jpeg",
    "id" : 22396883,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "14530797168",
  "text" : "ICH  BIN   EIN   NERD !!! http://www.youtube.com/watch?v=JCjs-QhJYcs",
  "id" : 14530797168,
  "created_at" : "Sun May 23 02:34:33 +0000 2010",
  "user" : {
    "name" : "Felix",
    "screen_name" : "nicidienase",
    "protected" : false,
    "id_str" : "22396883",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3125784966/8223a4c5c9535be22d15c82ec829c2df_normal.jpeg",
    "id" : 22396883,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://pivotallabs.com/landing/tweed\" rel=\"nofollow\">Tweed</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jewel Staite",
      "screen_name" : "JewelStaite",
      "indices" : [ 3, 15 ],
      "id_str" : "34175976",
      "id" : 34175976
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "13484852547",
  "text" : "RT @JewelStaite: This is pretty much awesome. http://www.youtube.com/watch?v=CKNqc3a9Xqs&feature=player_embedded",
  "id" : 13484852547,
  "created_at" : "Thu May 06 12:36:28 +0000 2010",
  "user" : {
    "name" : "Felix",
    "screen_name" : "nicidienase",
    "protected" : false,
    "id_str" : "22396883",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3125784966/8223a4c5c9535be22d15c82ec829c2df_normal.jpeg",
    "id" : 22396883,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://pivotallabs.com/landing/tweed\" rel=\"nofollow\">Tweed</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "13388165468",
  "text" : "Mein neues Lieblingswort: Morbidit\u00E4tsorientierter Risikostrukturausgleich",
  "id" : 13388165468,
  "created_at" : "Tue May 04 22:31:39 +0000 2010",
  "user" : {
    "name" : "Felix",
    "screen_name" : "nicidienase",
    "protected" : false,
    "id_str" : "22396883",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3125784966/8223a4c5c9535be22d15c82ec829c2df_normal.jpeg",
    "id" : 22396883,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitpic.com/\" rel=\"nofollow\">TwitPic</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Waldhornbar",
      "indices" : [ 26, 38 ]
    }, {
      "text" : "ichliebemontage",
      "indices" : [ 39, 55 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "13329509732",
  "text" : "Stiefel Nr. 4 heute Abend #Waldhornbar #ichliebemontage http://twitpic.com/1kr2cf",
  "id" : 13329509732,
  "created_at" : "Mon May 03 22:26:30 +0000 2010",
  "user" : {
    "name" : "Felix",
    "screen_name" : "nicidienase",
    "protected" : false,
    "id_str" : "22396883",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3125784966/8223a4c5c9535be22d15c82ec829c2df_normal.jpeg",
    "id" : 22396883,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitpic.com/\" rel=\"nofollow\">TwitPic</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Waldhornbar",
      "indices" : [ 30, 42 ]
    }, {
      "text" : "ichliebemontage",
      "indices" : [ 43, 59 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "13323427259",
  "text" : "Cocktail-Probier-Abend in der #Waldhornbar #ichliebemontage http://twitpic.com/1kq4lt",
  "id" : 13323427259,
  "created_at" : "Mon May 03 20:06:41 +0000 2010",
  "user" : {
    "name" : "Felix",
    "screen_name" : "nicidienase",
    "protected" : false,
    "id_str" : "22396883",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3125784966/8223a4c5c9535be22d15c82ec829c2df_normal.jpeg",
    "id" : 22396883,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://pivotallabs.com/landing/tweed\" rel=\"nofollow\">Tweed</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "13313833601",
  "text" : "WTF Mir is grade ein Vogel ins Zimmer geflogen, hat sich ne halbe Sekunde auf meinen Bildschirm gesetzt und is wieder davongeflogen.",
  "id" : 13313833601,
  "created_at" : "Mon May 03 16:25:48 +0000 2010",
  "user" : {
    "name" : "Felix",
    "screen_name" : "nicidienase",
    "protected" : false,
    "id_str" : "22396883",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3125784966/8223a4c5c9535be22d15c82ec829c2df_normal.jpeg",
    "id" : 22396883,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://pivotallabs.com/landing/tweed\" rel=\"nofollow\">Tweed</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kante",
      "screen_name" : "broaaaa",
      "indices" : [ 73, 81 ],
      "id_str" : "46670604",
      "id" : 46670604
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Neusprech",
      "indices" : [ 13, 23 ]
    }, {
      "text" : "piraten",
      "indices" : [ 125, 133 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "13304337975",
  "text" : "Oh Gott, das #Neusprech-schild des Jahres (http://twitpic.com/1km98m von @broaaaa) steht direkt bei mir ums Eck aufm Campus. #piraten",
  "id" : 13304337975,
  "created_at" : "Mon May 03 13:07:48 +0000 2010",
  "user" : {
    "name" : "Felix",
    "screen_name" : "nicidienase",
    "protected" : false,
    "id_str" : "22396883",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3125784966/8223a4c5c9535be22d15c82ec829c2df_normal.jpeg",
    "id" : 22396883,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://pivotallabs.com/landing/tweed\" rel=\"nofollow\">Tweed</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kante",
      "screen_name" : "broaaaa",
      "indices" : [ 3, 11 ],
      "id_str" : "46670604",
      "id" : 46670604
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "piraten",
      "indices" : [ 120, 128 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "13302358720",
  "text" : "RT @broaaaa: Das Ministerium fuer Wahrheit informiert: Ueberwachung heisst jetzt Kameraschutz http://twitpic.com/1km98m #piraten++",
  "id" : 13302358720,
  "created_at" : "Mon May 03 12:22:04 +0000 2010",
  "user" : {
    "name" : "Felix",
    "screen_name" : "nicidienase",
    "protected" : false,
    "id_str" : "22396883",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3125784966/8223a4c5c9535be22d15c82ec829c2df_normal.jpeg",
    "id" : 22396883,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://pivotallabs.com/landing/tweed\" rel=\"nofollow\">Tweed</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "memo",
      "screen_name" : "memo42",
      "indices" : [ 3, 10 ],
      "id_str" : "55311456",
      "id" : 55311456
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "13293935583",
  "text" : "RT @memo42: Unsere geliebte Waldhornbar hat jetzt eine frisch aktualisierte Homepage:http://tinyurl.com/357mwbg #Waldhornbar#ichliebemontage",
  "id" : 13293935583,
  "created_at" : "Mon May 03 08:00:27 +0000 2010",
  "user" : {
    "name" : "Felix",
    "screen_name" : "nicidienase",
    "protected" : false,
    "id_str" : "22396883",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3125784966/8223a4c5c9535be22d15c82ec829c2df_normal.jpeg",
    "id" : 22396883,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://pivotallabs.com/landing/tweed\" rel=\"nofollow\">Tweed</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "serienjunkies",
      "screen_name" : "serienjunkies",
      "indices" : [ 3, 17 ],
      "id_str" : "15597707",
      "id" : 15597707
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Obama",
      "indices" : [ 52, 58 ]
    }, {
      "text" : "Leno",
      "indices" : [ 75, 80 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "13293827962",
  "text" : "RT @serienjunkies: Politische Satire mal andersrum: #Obama macht sich \u00FCber #Leno lustig http://4sj.de/obama",
  "id" : 13293827962,
  "created_at" : "Mon May 03 07:56:43 +0000 2010",
  "user" : {
    "name" : "Felix",
    "screen_name" : "nicidienase",
    "protected" : false,
    "id_str" : "22396883",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3125784966/8223a4c5c9535be22d15c82ec829c2df_normal.jpeg",
    "id" : 22396883,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://pivotallabs.com/landing/tweed\" rel=\"nofollow\">Tweed</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mario Sixtus",
      "screen_name" : "sixtus",
      "indices" : [ 3, 10 ],
      "id_str" : "9334352",
      "id" : 9334352
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "13273706758",
  "text" : "RT @sixtus: Aaaargh! Von wegen \"das Netz vergisst nichts\"! http://bit.ly/9N7j4W",
  "id" : 13273706758,
  "created_at" : "Sun May 02 23:56:49 +0000 2010",
  "user" : {
    "name" : "Felix",
    "screen_name" : "nicidienase",
    "protected" : false,
    "id_str" : "22396883",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3125784966/8223a4c5c9535be22d15c82ec829c2df_normal.jpeg",
    "id" : 22396883,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitpic.com/\" rel=\"nofollow\">TwitPic</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "13176535021",
  "text" : "Das Wetter ist sch\u00F6n, die Grillfete im Garten ist gerettet. Yuchuu. http://twitpic.com/1jvtfp",
  "id" : 13176535021,
  "created_at" : "Sat May 01 07:16:06 +0000 2010",
  "user" : {
    "name" : "Felix",
    "screen_name" : "nicidienase",
    "protected" : false,
    "id_str" : "22396883",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3125784966/8223a4c5c9535be22d15c82ec829c2df_normal.jpeg",
    "id" : 22396883,
    "verified" : false
  }
} ]