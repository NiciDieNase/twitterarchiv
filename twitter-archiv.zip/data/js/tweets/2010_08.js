Grailbird.data.tweets_2010_08 = 
 [ {
  "source" : "<a href=\"http://tweed.pivotallabs.com\" rel=\"nofollow\">Tweed webOS</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Bulo",
      "screen_name" : "DerBulo",
      "indices" : [ 3, 11 ],
      "id_str" : "42403765",
      "id" : 42403765
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "22579773420",
  "text" : "RT @DerBulo: Sarrazin bei Beckmann - Warum bekommt dieser Schw\u00E4tzer so ein Forum? Und dann l\u00E4dt der auch noch den Sarrazin ein!...",
  "retweeted_status" : {
    "source" : "web",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : {
    },
    "id_str" : "22556935703",
    "text" : "Sarrazin bei Beckmann - Warum bekommt dieser Schw\u00E4tzer so ein Forum? Und dann l\u00E4dt der auch noch den Sarrazin ein!...",
    "id" : 22556935703,
    "created_at" : "Mon Aug 30 21:18:34 +0000 2010",
    "user" : {
      "name" : "Bulo",
      "screen_name" : "DerBulo",
      "protected" : false,
      "id_str" : "42403765",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/2220075801/SW_3_normal.jpg",
      "id" : 42403765,
      "verified" : false
    }
  },
  "id" : 22579773420,
  "created_at" : "Tue Aug 31 02:38:50 +0000 2010",
  "user" : {
    "name" : "Felix",
    "screen_name" : "nicidienase",
    "protected" : false,
    "id_str" : "22396883",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3125784966/8223a4c5c9535be22d15c82ec829c2df_normal.jpeg",
    "id" : 22396883,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://tweed.pivotallabs.com\" rel=\"nofollow\">Tweed webOS</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "AK Vorrat",
      "screen_name" : "akvorrat",
      "indices" : [ 3, 12 ],
      "id_str" : "13595222",
      "id" : 13595222
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Petition",
      "indices" : [ 24, 33 ]
    }, {
      "text" : "Netzneutralit\u00E4t",
      "indices" : [ 71, 87 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "22464060999",
  "text" : "RT @akvorrat: Jetzt die #Petition f\u00FCr eine gesetzliche Verankerung der #Netzneutralit\u00E4t unterzeichnen: http://is.gd/eK8PW",
  "retweeted_status" : {
    "source" : "web",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "Petition",
        "indices" : [ 10, 19 ]
      }, {
        "text" : "Netzneutralit\u00E4t",
        "indices" : [ 57, 73 ]
      } ],
      "urls" : [ ]
    },
    "geo" : {
    },
    "id_str" : "22457282049",
    "text" : "Jetzt die #Petition f\u00FCr eine gesetzliche Verankerung der #Netzneutralit\u00E4t unterzeichnen: http://is.gd/eK8PW",
    "id" : 22457282049,
    "created_at" : "Sun Aug 29 18:14:54 +0000 2010",
    "user" : {
      "name" : "AK Vorrat",
      "screen_name" : "akvorrat",
      "protected" : false,
      "id_str" : "13595222",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/49654472/logo_normal.png",
      "id" : 13595222,
      "verified" : false
    }
  },
  "id" : 22464060999,
  "created_at" : "Sun Aug 29 20:10:33 +0000 2010",
  "user" : {
    "name" : "Felix",
    "screen_name" : "nicidienase",
    "protected" : false,
    "id_str" : "22396883",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3125784966/8223a4c5c9535be22d15c82ec829c2df_normal.jpeg",
    "id" : 22396883,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://tweed.pivotallabs.com\" rel=\"nofollow\">Tweed webOS</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "die ennomane",
      "screen_name" : "ennomane",
      "indices" : [ 3, 12 ],
      "id_str" : "16034275",
      "id" : 16034275
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "22460212760",
  "text" : "RT @ennomane: Warum werden Informatiker immer gebeten, Computer bzw Windows zu reparieren? Wenn ihr krank seid, fragt ihr doch auch kein ...",
  "retweeted_status" : {
    "source" : "<a href=\"http://www.echofon.com/\" rel=\"nofollow\">Echofon</a>",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : {
    },
    "id_str" : "22356987360",
    "text" : "Warum werden Informatiker immer gebeten, Computer bzw Windows zu reparieren? Wenn ihr krank seid, fragt ihr doch auch keinen Biologen.",
    "id" : 22356987360,
    "created_at" : "Sat Aug 28 14:31:06 +0000 2010",
    "user" : {
      "name" : "die ennomane",
      "screen_name" : "ennomane",
      "protected" : false,
      "id_str" : "16034275",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/2924474278/6c4b8d0fa2de3f77efca06ef2c7721f1_normal.png",
      "id" : 16034275,
      "verified" : false
    }
  },
  "id" : 22460212760,
  "created_at" : "Sun Aug 29 19:03:19 +0000 2010",
  "user" : {
    "name" : "Felix",
    "screen_name" : "nicidienase",
    "protected" : false,
    "id_str" : "22396883",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3125784966/8223a4c5c9535be22d15c82ec829c2df_normal.jpeg",
    "id" : 22396883,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://tweed.pivotallabs.com\" rel=\"nofollow\">Tweed webOS</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Edward",
      "screen_name" : "twitgeridoo",
      "indices" : [ 3, 15 ],
      "id_str" : "46379961",
      "id" : 46379961
    }, {
      "name" : "Clubmietze",
      "screen_name" : "Clubmietze",
      "indices" : [ 20, 31 ],
      "id_str" : "54885055",
      "id" : 54885055
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "22459831900",
  "text" : "RT @twitgeridoo: RT @Clubmietze: (ohne Worte) http://twitpic.com/2iytf9",
  "retweeted_status" : {
    "source" : "web",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Clubmietze",
        "screen_name" : "Clubmietze",
        "indices" : [ 3, 14 ],
        "id_str" : "54885055",
        "id" : 54885055
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : {
    },
    "id_str" : "22355105949",
    "text" : "RT @Clubmietze: (ohne Worte) http://twitpic.com/2iytf9",
    "id" : 22355105949,
    "created_at" : "Sat Aug 28 14:04:16 +0000 2010",
    "user" : {
      "name" : "Edward",
      "screen_name" : "twitgeridoo",
      "protected" : false,
      "id_str" : "46379961",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/3502478342/0af3d55532e64d7f0a23b5470207bf76_normal.jpeg",
      "id" : 46379961,
      "verified" : false
    }
  },
  "id" : 22459831900,
  "created_at" : "Sun Aug 29 18:57:12 +0000 2010",
  "user" : {
    "name" : "Felix",
    "screen_name" : "nicidienase",
    "protected" : false,
    "id_str" : "22396883",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3125784966/8223a4c5c9535be22d15c82ec829c2df_normal.jpeg",
    "id" : 22396883,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://tweed.pivotallabs.com\" rel=\"nofollow\">Tweed webOS</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "getDigital Team",
      "screen_name" : "getDigital_de",
      "indices" : [ 3, 17 ],
      "id_str" : "45354877",
      "id" : 45354877
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "22458808373",
  "text" : "RT @getDigital_de: Es ist wieder Zeit f\u00FCr unser Gewinnspiel. RT mich, um eine rote Bin\u00E4ruhr zu gewinnen: http://bit.ly/bpXlJV",
  "retweeted_status" : {
    "source" : "<a href=\"http://www.getdigital.de\" rel=\"nofollow\">getDigital Write</a>",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : {
    },
    "id_str" : "22253218714",
    "text" : "Es ist wieder Zeit f\u00FCr unser Gewinnspiel. RT mich, um eine rote Bin\u00E4ruhr zu gewinnen: http://bit.ly/bpXlJV",
    "id" : 22253218714,
    "created_at" : "Fri Aug 27 09:30:20 +0000 2010",
    "user" : {
      "name" : "getDigital Team",
      "screen_name" : "getDigital_de",
      "protected" : false,
      "id_str" : "45354877",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/253278066/logo2_normal.png",
      "id" : 45354877,
      "verified" : false
    }
  },
  "id" : 22458808373,
  "created_at" : "Sun Aug 29 18:39:52 +0000 2010",
  "user" : {
    "name" : "Felix",
    "screen_name" : "nicidienase",
    "protected" : false,
    "id_str" : "22396883",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3125784966/8223a4c5c9535be22d15c82ec829c2df_normal.jpeg",
    "id" : 22396883,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://tweed.pivotallabs.com\" rel=\"nofollow\">Tweed webOS</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "jensbest",
      "screen_name" : "jensbest",
      "indices" : [ 3, 12 ],
      "id_str" : "14599545",
      "id" : 14599545
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "21907341241",
  "text" : "RT @jensbest: Ja, was machen wir denn jetzt, liebe Frau Aigner? Staat verkauft Luftfotos & GPS-Daten von H\u00E4usern f\u00FCr \u20AC140.000/CD http:// ...",
  "retweeted_status" : {
    "source" : "<a href=\"http://www.hootsuite.com\" rel=\"nofollow\">HootSuite</a>",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : {
    },
    "id_str" : "21846893278",
    "text" : "Ja, was machen wir denn jetzt, liebe Frau Aigner? Staat verkauft Luftfotos & GPS-Daten von H\u00E4usern f\u00FCr \u20AC140.000/CD http://ow.ly/2t4g8",
    "id" : 21846893278,
    "created_at" : "Sun Aug 22 17:48:50 +0000 2010",
    "user" : {
      "name" : "jensbest",
      "screen_name" : "jensbest",
      "protected" : false,
      "id_str" : "14599545",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/2790613560/001126665d1f441e3f619ca5f266d9a4_normal.jpeg",
      "id" : 14599545,
      "verified" : false
    }
  },
  "id" : 21907341241,
  "created_at" : "Mon Aug 23 11:51:58 +0000 2010",
  "user" : {
    "name" : "Felix",
    "screen_name" : "nicidienase",
    "protected" : false,
    "id_str" : "22396883",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3125784966/8223a4c5c9535be22d15c82ec829c2df_normal.jpeg",
    "id" : 22396883,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://tweed.pivotallabs.com\" rel=\"nofollow\">Tweed webOS</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "ZEIT ONLINE",
      "screen_name" : "zeitonline",
      "indices" : [ 3, 14 ],
      "id_str" : "5715752",
      "id" : 5715752
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "21906512771",
  "text" : "RT @zeitonline: Drei Studenten entdeckten eine Gesetzesl\u00FCcke und gr\u00FCndeten eine Mitfahrzentrale f\u00FCr \u00DCberlandfahrten mit Bussen. http://b ...",
  "retweeted_status" : {
    "source" : "<a href=\"http://www.tweetdeck.com\" rel=\"nofollow\">TweetDeck</a>",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : {
    },
    "id_str" : "21815872794",
    "text" : "Drei Studenten entdeckten eine Gesetzesl\u00FCcke und gr\u00FCndeten eine Mitfahrzentrale f\u00FCr \u00DCberlandfahrten mit Bussen. http://bit.ly/boXUla (sv)",
    "id" : 21815872794,
    "created_at" : "Sun Aug 22 08:32:31 +0000 2010",
    "user" : {
      "name" : "ZEIT ONLINE",
      "screen_name" : "zeitonline",
      "protected" : false,
      "id_str" : "5715752",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/1683000232/ZEIT-Z-Facebook-final-4_normal.jpg",
      "id" : 5715752,
      "verified" : true
    }
  },
  "id" : 21906512771,
  "created_at" : "Mon Aug 23 11:37:30 +0000 2010",
  "user" : {
    "name" : "Felix",
    "screen_name" : "nicidienase",
    "protected" : false,
    "id_str" : "22396883",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3125784966/8223a4c5c9535be22d15c82ec829c2df_normal.jpeg",
    "id" : 22396883,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://tweed.pivotallabs.com\" rel=\"nofollow\">Tweed webOS</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Oliver Gassner",
      "screen_name" : "oliverg",
      "indices" : [ 3, 11 ],
      "id_str" : "66653",
      "id" : 66653
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "21737247209",
  "text" : "RT @oliverg: W\u00FCrde heut das Feuer erfunden, der Innenminister w\u00E4re sicher dagegen. W\u00FCrde heute die Schrift erfunden, der Datenschutz w\u00FCr ...",
  "retweeted_status" : {
    "source" : "web",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : {
    },
    "id_str" : "21678459088",
    "text" : "W\u00FCrde heut das Feuer erfunden, der Innenminister w\u00E4re sicher dagegen. W\u00FCrde heute die Schrift erfunden, der Datenschutz w\u00FCrd sie blockieren.",
    "id" : 21678459088,
    "created_at" : "Fri Aug 20 16:42:31 +0000 2010",
    "user" : {
      "name" : "Oliver Gassner",
      "screen_name" : "oliverg",
      "protected" : false,
      "id_str" : "66653",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/1440853090/og_gplus_square_normal.png",
      "id" : 66653,
      "verified" : false
    }
  },
  "id" : 21737247209,
  "created_at" : "Sat Aug 21 09:37:21 +0000 2010",
  "user" : {
    "name" : "Felix",
    "screen_name" : "nicidienase",
    "protected" : false,
    "id_str" : "22396883",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3125784966/8223a4c5c9535be22d15c82ec829c2df_normal.jpeg",
    "id" : 22396883,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Manu",
      "screen_name" : "Mini_Tequila",
      "indices" : [ 0, 13 ],
      "id_str" : "177909051",
      "id" : 177909051
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "21055726437",
  "geo" : {
  },
  "id_str" : "21059375995",
  "in_reply_to_user_id" : 177909051,
  "text" : "@Mini_Tequila Schau ich so b\u00F6se?",
  "id" : 21059375995,
  "in_reply_to_status_id" : 21055726437,
  "created_at" : "Fri Aug 13 12:22:25 +0000 2010",
  "in_reply_to_screen_name" : "Mini_Tequila",
  "in_reply_to_user_id_str" : "177909051",
  "user" : {
    "name" : "Felix",
    "screen_name" : "nicidienase",
    "protected" : false,
    "id_str" : "22396883",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3125784966/8223a4c5c9535be22d15c82ec829c2df_normal.jpeg",
    "id" : 22396883,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://tweed.pivotallabs.com\" rel=\"nofollow\">Tweed webOS</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Benedikt Koehler",
      "screen_name" : "furukama",
      "indices" : [ 3, 12 ],
      "id_str" : "5717402",
      "id" : 5717402
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "20972965732",
  "text" : "RT @furukama: Okay, das ist dann schon etwas kurios: StreetView-Gegner mit Namen, Foto und Haus in der Zeitung http://bit.ly/ayCg4R",
  "retweeted_status" : {
    "source" : "<a href=\"http://www.tweetdeck.com\" rel=\"nofollow\">TweetDeck</a>",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : {
    },
    "id_str" : "20968444665",
    "text" : "Okay, das ist dann schon etwas kurios: StreetView-Gegner mit Namen, Foto und Haus in der Zeitung http://bit.ly/ayCg4R",
    "id" : 20968444665,
    "created_at" : "Thu Aug 12 11:44:07 +0000 2010",
    "user" : {
      "name" : "Benedikt Koehler",
      "screen_name" : "furukama",
      "protected" : false,
      "id_str" : "5717402",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/3446610296/00577d820b8c227840460a85105d559f_normal.jpeg",
      "id" : 5717402,
      "verified" : false
    }
  },
  "id" : 20972965732,
  "created_at" : "Thu Aug 12 12:59:30 +0000 2010",
  "user" : {
    "name" : "Felix",
    "screen_name" : "nicidienase",
    "protected" : false,
    "id_str" : "22396883",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3125784966/8223a4c5c9535be22d15c82ec829c2df_normal.jpeg",
    "id" : 22396883,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://tweed.pivotallabs.com\" rel=\"nofollow\">Tweed webOS</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "memo",
      "screen_name" : "memo42",
      "indices" : [ 3, 10 ],
      "id_str" : "55311456",
      "id" : 55311456
    }, {
      "name" : "Piraten KV Augsburg",
      "screen_name" : "PiratenAugsburg",
      "indices" : [ 15, 31 ],
      "id_str" : "49954179",
      "id" : 49954179
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "20925880019",
  "text" : "RT @memo42: RT @PiratenAugsburg: Konrad Adenauer (CDU): \"Wir brauchen keine Fingerabdr\u00FCcke im Ausweis, die Deutschen sind kein Volk von  ...",
  "retweeted_status" : {
    "source" : "<a href=\"http://twitterrific.com\" rel=\"nofollow\">Twitterrific</a>",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Piraten KV Augsburg",
        "screen_name" : "PiratenAugsburg",
        "indices" : [ 3, 19 ],
        "id_str" : "49954179",
        "id" : 49954179
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : {
    },
    "id_str" : "20925374656",
    "text" : "RT @PiratenAugsburg: Konrad Adenauer (CDU): \"Wir brauchen keine Fingerabdr\u00FCcke im Ausweis, die Deutschen sind kein Volk von Verbrechern. ...",
    "id" : 20925374656,
    "created_at" : "Wed Aug 11 23:20:41 +0000 2010",
    "user" : {
      "name" : "memo",
      "screen_name" : "memo42",
      "protected" : false,
      "id_str" : "55311456",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/2873023937/3ae32f81f1fe847dc5c5820e297028ad_normal.jpeg",
      "id" : 55311456,
      "verified" : false
    }
  },
  "id" : 20925880019,
  "created_at" : "Wed Aug 11 23:28:37 +0000 2010",
  "user" : {
    "name" : "Felix",
    "screen_name" : "nicidienase",
    "protected" : false,
    "id_str" : "22396883",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3125784966/8223a4c5c9535be22d15c82ec829c2df_normal.jpeg",
    "id" : 22396883,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://tweed.pivotallabs.com\" rel=\"nofollow\">Tweed webOS</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 49.008119, 8.411494 ]
  },
  "id_str" : "20057336157",
  "text" : "Grade entdeckt, dass es neue Folgen von The IT Crowd gibt. Yeah!",
  "id" : 20057336157,
  "created_at" : "Sun Aug 01 11:55:14 +0000 2010",
  "user" : {
    "name" : "Felix",
    "screen_name" : "nicidienase",
    "protected" : false,
    "id_str" : "22396883",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3125784966/8223a4c5c9535be22d15c82ec829c2df_normal.jpeg",
    "id" : 22396883,
    "verified" : false
  }
} ]