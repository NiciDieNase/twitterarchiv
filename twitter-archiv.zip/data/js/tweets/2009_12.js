Grailbird.data.tweets_2009_12 = 
 [ {
  "source" : "<a href=\"http://pivotallabs.com/landing/tweed\" rel=\"nofollow\">Tweed</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Strubbl",
      "screen_name" : "Strubbl",
      "indices" : [ 3, 11 ],
      "id_str" : "14400668",
      "id" : 14400668
    }, {
      "name" : "t.j.",
      "screen_name" : "holpergeist",
      "indices" : [ 17, 29 ],
      "id_str" : "24567087",
      "id" : 24567087
    }, {
      "name" : "Mirco El-Nomany",
      "screen_name" : "seo2feel",
      "indices" : [ 34, 43 ],
      "id_str" : "41362186",
      "id" : 41362186
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "7168266485",
  "text" : "RT @Strubbl: RT: @holpergeist: RT @seo2feel: LOL &gt; Wenn Browser Frauen w\u00E4ren http://bit.ly/5Ukgn4",
  "id" : 7168266485,
  "created_at" : "Tue Dec 29 19:04:27 +0000 2009",
  "user" : {
    "name" : "Felix",
    "screen_name" : "nicidienase",
    "protected" : false,
    "id_str" : "22396883",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3125784966/8223a4c5c9535be22d15c82ec829c2df_normal.jpeg",
    "id" : 22396883,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://pivotallabs.com/landing/tweed\" rel=\"nofollow\">Tweed</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Edward",
      "screen_name" : "twitgeridoo",
      "indices" : [ 3, 15 ],
      "id_str" : "46379961",
      "id" : 46379961
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "csu",
      "indices" : [ 76, 80 ]
    }, {
      "text" : "rosenheim",
      "indices" : [ 81, 91 ]
    }, {
      "text" : "stoppschild",
      "indices" : [ 92, 104 ]
    }, {
      "text" : "zensursula",
      "indices" : [ 105, 116 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "7136697988",
  "text" : "RT @Twitgeridoo: http://twitpic.com/vlw5s - F\u00FCr die Nachwelt gesichert.. :) #csu #rosenheim #stoppschild #zensursula",
  "id" : 7136697988,
  "created_at" : "Mon Dec 28 22:13:12 +0000 2009",
  "user" : {
    "name" : "Felix",
    "screen_name" : "nicidienase",
    "protected" : false,
    "id_str" : "22396883",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3125784966/8223a4c5c9535be22d15c82ec829c2df_normal.jpeg",
    "id" : 22396883,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://pivotallabs.com/landing/tweed\" rel=\"nofollow\">Tweed</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "dragonseverywhere",
      "indices" : [ 122, 140 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "7080635035",
  "text" : "Ist eigentlich noch niemandem aufgefallen das Epsilon Eridani \u00FCber 10 Lj weg is? Das wird schwer mit dem Livestream dort. #dragonseverywhere",
  "id" : 7080635035,
  "created_at" : "Sun Dec 27 04:34:52 +0000 2009",
  "user" : {
    "name" : "Felix",
    "screen_name" : "nicidienase",
    "protected" : false,
    "id_str" : "22396883",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3125784966/8223a4c5c9535be22d15c82ec829c2df_normal.jpeg",
    "id" : 22396883,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://pivotallabs.com/landing/tweed\" rel=\"nofollow\">Tweed</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "astrodicticum",
      "screen_name" : "astrodicticum",
      "indices" : [ 3, 17 ],
      "id_str" : "15318271",
      "id" : 15318271
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "newtonmas",
      "indices" : [ 75, 85 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "7034417477",
  "text" : "RT @astrodicticum: Feiert ihr auch alle brav Newtonmas? http://is.gd/5B6V4 #newtonmas",
  "id" : 7034417477,
  "created_at" : "Fri Dec 25 15:23:15 +0000 2009",
  "user" : {
    "name" : "Felix",
    "screen_name" : "nicidienase",
    "protected" : false,
    "id_str" : "22396883",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3125784966/8223a4c5c9535be22d15c82ec829c2df_normal.jpeg",
    "id" : 22396883,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://pivotallabs.com/landing/tweed\" rel=\"nofollow\">Tweed</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Darth Vader",
      "screen_name" : "darthvader",
      "indices" : [ 3, 14 ],
      "id_str" : "618593",
      "id" : 618593
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "7032251460",
  "text" : "RT @darthvader: \"What to my wondering eyes would I spy, But a speeder-sleigh, being pulled by eight ghost Jedi\" - http://bit.ly/92Pu4V",
  "id" : 7032251460,
  "created_at" : "Fri Dec 25 13:39:44 +0000 2009",
  "user" : {
    "name" : "Felix",
    "screen_name" : "nicidienase",
    "protected" : false,
    "id_str" : "22396883",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3125784966/8223a4c5c9535be22d15c82ec829c2df_normal.jpeg",
    "id" : 22396883,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://pivotallabs.com/landing/tweed\" rel=\"nofollow\">Tweed</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Max Winde",
      "screen_name" : "343max",
      "indices" : [ 3, 10 ],
      "id_str" : "2284151",
      "id" : 2284151
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "6983541013",
  "text" : "RT @343max: Tolle Idee, diese Z\u00FCge, die nicht bei Frost fahren k\u00F6nnen ausgerechnet nach gefrohrenem Wasser zu benennen.",
  "id" : 6983541013,
  "created_at" : "Thu Dec 24 01:31:22 +0000 2009",
  "user" : {
    "name" : "Felix",
    "screen_name" : "nicidienase",
    "protected" : false,
    "id_str" : "22396883",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3125784966/8223a4c5c9535be22d15c82ec829c2df_normal.jpeg",
    "id" : 22396883,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://pivotallabs.com/landing/tweed\" rel=\"nofollow\">Tweed</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "6970202233",
  "text" : "So, noch geschwind duschen. In ner Stunde is Klassentreffen. Soll ich irgendwen mitnehmen?",
  "id" : 6970202233,
  "created_at" : "Wed Dec 23 17:07:22 +0000 2009",
  "user" : {
    "name" : "Felix",
    "screen_name" : "nicidienase",
    "protected" : false,
    "id_str" : "22396883",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3125784966/8223a4c5c9535be22d15c82ec829c2df_normal.jpeg",
    "id" : 22396883,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://pivotallabs.com/landing/tweed\" rel=\"nofollow\">Tweed</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "winterstimmung",
      "indices" : [ 64, 79 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "6947471148",
  "text" : "Kaum is der Schnee weggeschmolzen schneits schon wieder. Yuchuu #winterstimmung",
  "id" : 6947471148,
  "created_at" : "Wed Dec 23 00:40:41 +0000 2009",
  "user" : {
    "name" : "Felix",
    "screen_name" : "nicidienase",
    "protected" : false,
    "id_str" : "22396883",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3125784966/8223a4c5c9535be22d15c82ec829c2df_normal.jpeg",
    "id" : 22396883,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "daseike",
      "screen_name" : "daseike",
      "indices" : [ 0, 8 ],
      "id_str" : "41660531",
      "id" : 41660531
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "6925234919",
  "geo" : {
  },
  "id_str" : "6943467130",
  "in_reply_to_user_id" : 41660531,
  "text" : "@daseike Nur her damit!",
  "id" : 6943467130,
  "in_reply_to_status_id" : 6925234919,
  "created_at" : "Tue Dec 22 22:13:25 +0000 2009",
  "in_reply_to_screen_name" : "daseike",
  "in_reply_to_user_id_str" : "41660531",
  "user" : {
    "name" : "Felix",
    "screen_name" : "nicidienase",
    "protected" : false,
    "id_str" : "22396883",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3125784966/8223a4c5c9535be22d15c82ec829c2df_normal.jpeg",
    "id" : 22396883,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://pivotallabs.com/landing/tweed\" rel=\"nofollow\">Tweed</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "6932363756",
  "text" : "Meine Weihnachtsmusik f\u00FCr dieses Jahr: The 8bits of Christmas http://tinyurl.com/5zjldr\nUnd alles unter ner CC-Lizenz",
  "id" : 6932363756,
  "created_at" : "Tue Dec 22 15:47:29 +0000 2009",
  "user" : {
    "name" : "Felix",
    "screen_name" : "nicidienase",
    "protected" : false,
    "id_str" : "22396883",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3125784966/8223a4c5c9535be22d15c82ec829c2df_normal.jpeg",
    "id" : 22396883,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://pivotallabs.com/landing/tweed\" rel=\"nofollow\">Tweed</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Max Winde",
      "screen_name" : "343max",
      "indices" : [ 3, 10 ],
      "id_str" : "2284151",
      "id" : 2284151
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "6932203037",
  "text" : "RT @343max: Hm! \u03C0zza! http://www.b3ta.com/board/9845550",
  "id" : 6932203037,
  "created_at" : "Tue Dec 22 15:42:01 +0000 2009",
  "user" : {
    "name" : "Felix",
    "screen_name" : "nicidienase",
    "protected" : false,
    "id_str" : "22396883",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3125784966/8223a4c5c9535be22d15c82ec829c2df_normal.jpeg",
    "id" : 22396883,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://pivotallabs.com/landing/tweed\" rel=\"nofollow\">Tweed</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "weihnachtsferien",
      "indices" : [ 68, 85 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "6928198832",
  "text" : "Programmieren f\u00FCr Physiker. Meine letzte Vorlesung f\u00FCr dieses Jahr. #weihnachtsferien",
  "id" : 6928198832,
  "created_at" : "Tue Dec 22 13:05:51 +0000 2009",
  "user" : {
    "name" : "Felix",
    "screen_name" : "nicidienase",
    "protected" : false,
    "id_str" : "22396883",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3125784966/8223a4c5c9535be22d15c82ec829c2df_normal.jpeg",
    "id" : 22396883,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://pivotallabs.com/landing/tweed\" rel=\"nofollow\">Tweed</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Edward",
      "screen_name" : "twitgeridoo",
      "indices" : [ 0, 12 ],
      "id_str" : "46379961",
      "id" : 46379961
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "6925092765",
  "geo" : {
  },
  "id_str" : "6925234774",
  "in_reply_to_user_id" : 46379961,
  "text" : "@Twitgeridoo Und falls du jetzt gleich nach dem Ursprung des Namens fragst: http://memory-alpha.org/de/wiki/Nicky_die_Nase",
  "id" : 6925234774,
  "in_reply_to_status_id" : 6925092765,
  "created_at" : "Tue Dec 22 10:17:24 +0000 2009",
  "in_reply_to_screen_name" : "twitgeridoo",
  "in_reply_to_user_id_str" : "46379961",
  "user" : {
    "name" : "Felix",
    "screen_name" : "nicidienase",
    "protected" : false,
    "id_str" : "22396883",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3125784966/8223a4c5c9535be22d15c82ec829c2df_normal.jpeg",
    "id" : 22396883,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://pivotallabs.com/landing/tweed\" rel=\"nofollow\">Tweed</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Edward",
      "screen_name" : "twitgeridoo",
      "indices" : [ 0, 12 ],
      "id_str" : "46379961",
      "id" : 46379961
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "6925092765",
  "geo" : {
  },
  "id_str" : "6925178890",
  "in_reply_to_user_id" : 46379961,
  "text" : "@Twitgeridoo Ja, die is ein .. sagen wir mal sehr hervorstehendes Merkmal in meinem Gesicht. In der Kategorie Gottschalk/Kr\u00FCger.",
  "id" : 6925178890,
  "in_reply_to_status_id" : 6925092765,
  "created_at" : "Tue Dec 22 10:13:53 +0000 2009",
  "in_reply_to_screen_name" : "twitgeridoo",
  "in_reply_to_user_id_str" : "46379961",
  "user" : {
    "name" : "Felix",
    "screen_name" : "nicidienase",
    "protected" : false,
    "id_str" : "22396883",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3125784966/8223a4c5c9535be22d15c82ec829c2df_normal.jpeg",
    "id" : 22396883,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitpic.com/\" rel=\"nofollow\">TwitPic</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "6925106870",
  "text" : "http://twitpic.com/umlwf - Schei\u00DF Wetter! Der ganze sch\u00F6ne Schnee is (bis aus das kleine H\u00E4uflein) wieder weg.",
  "id" : 6925106870,
  "created_at" : "Tue Dec 22 10:09:06 +0000 2009",
  "user" : {
    "name" : "Felix",
    "screen_name" : "nicidienase",
    "protected" : false,
    "id_str" : "22396883",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3125784966/8223a4c5c9535be22d15c82ec829c2df_normal.jpeg",
    "id" : 22396883,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://pivotallabs.com/landing/tweed\" rel=\"nofollow\">Tweed</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Edward",
      "screen_name" : "twitgeridoo",
      "indices" : [ 0, 12 ],
      "id_str" : "46379961",
      "id" : 46379961
    }, {
      "name" : "Nicole Young",
      "screen_name" : "nici",
      "indices" : [ 69, 74 ],
      "id_str" : "5533512",
      "id" : 5533512
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "6919743140",
  "geo" : {
  },
  "id_str" : "6924969451",
  "in_reply_to_user_id" : 46379961,
  "text" : "@Twitgeridoo Ja. Wenn Twitter - in den Namen zulassen w\u00FCrde w\u00E4re ich @Nici-die-Nase",
  "id" : 6924969451,
  "in_reply_to_status_id" : 6919743140,
  "created_at" : "Tue Dec 22 10:00:24 +0000 2009",
  "in_reply_to_screen_name" : "twitgeridoo",
  "in_reply_to_user_id_str" : "46379961",
  "user" : {
    "name" : "Felix",
    "screen_name" : "nicidienase",
    "protected" : false,
    "id_str" : "22396883",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3125784966/8223a4c5c9535be22d15c82ec829c2df_normal.jpeg",
    "id" : 22396883,
    "verified" : false
  }
}, {
  "source" : "<a href=\"https://launchpad.net/gwibber/\" rel=\"nofollow\">Gwibber</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "winterstimmung",
      "indices" : [ 33, 48 ]
    }, {
      "text" : "karlsruhe",
      "indices" : [ 49, 59 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "6861994546",
  "text" : "Drau\u00DFen schneit es wie verr\u00FCckt! #winterstimmung #karlsruhe",
  "id" : 6861994546,
  "created_at" : "Sun Dec 20 15:01:33 +0000 2009",
  "user" : {
    "name" : "Felix",
    "screen_name" : "nicidienase",
    "protected" : false,
    "id_str" : "22396883",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3125784966/8223a4c5c9535be22d15c82ec829c2df_normal.jpeg",
    "id" : 22396883,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://pivotallabs.com/landing/tweed\" rel=\"nofollow\">Tweed</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "stefan",
      "screen_name" : "stefan005",
      "indices" : [ 68, 78 ],
      "id_str" : "49648872",
      "id" : 49648872
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "6813649068",
  "text" : "Per Jabber Transport? Oder gibt's da noch ne andere M\u00F6glichkeit? RT @stefan005: Jawoll!!! Icq geht aufm palm pre:-)",
  "id" : 6813649068,
  "created_at" : "Sat Dec 19 00:29:45 +0000 2009",
  "user" : {
    "name" : "Felix",
    "screen_name" : "nicidienase",
    "protected" : false,
    "id_str" : "22396883",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3125784966/8223a4c5c9535be22d15c82ec829c2df_normal.jpeg",
    "id" : 22396883,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://pivotallabs.com/landing/tweed\" rel=\"nofollow\">Tweed</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "winterstimmung",
      "indices" : [ 53, 68 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "6801075424",
  "text" : "Es schneit!! Und es bleibt sogar bissl Schnee liegen #winterstimmung",
  "id" : 6801075424,
  "created_at" : "Fri Dec 18 16:36:48 +0000 2009",
  "user" : {
    "name" : "Felix",
    "screen_name" : "nicidienase",
    "protected" : false,
    "id_str" : "22396883",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3125784966/8223a4c5c9535be22d15c82ec829c2df_normal.jpeg",
    "id" : 22396883,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://pivotallabs.com/landing/tweed\" rel=\"nofollow\">Tweed</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "6795719929",
  "text" : "24 Christmas Special ;-) http://www.slashfilm.com/2009/12/18/votd-jack-bauer-interrogates-santa-claus/",
  "id" : 6795719929,
  "created_at" : "Fri Dec 18 13:21:44 +0000 2009",
  "user" : {
    "name" : "Felix",
    "screen_name" : "nicidienase",
    "protected" : false,
    "id_str" : "22396883",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3125784966/8223a4c5c9535be22d15c82ec829c2df_normal.jpeg",
    "id" : 22396883,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitpic.com/\" rel=\"nofollow\">TwitPic</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "6792027948",
  "text" : "http://twitpic.com/tzwsw - Und 10 von den kleinen Dingern hier waren auch noch dabei.",
  "id" : 6792027948,
  "created_at" : "Fri Dec 18 09:59:07 +0000 2009",
  "user" : {
    "name" : "Felix",
    "screen_name" : "nicidienase",
    "protected" : false,
    "id_str" : "22396883",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3125784966/8223a4c5c9535be22d15c82ec829c2df_normal.jpeg",
    "id" : 22396883,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitpic.com/\" rel=\"nofollow\">TwitPic</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "6791865179",
  "text" : "http://twitpic.com/tzvve - Vom UPS-Mann ausm Bett geklingelt:Meine Twitter-Wandkalender sind gekommen.Genauer gesagt 12 St\u00FCck.Will wer eine",
  "id" : 6791865179,
  "created_at" : "Fri Dec 18 09:48:03 +0000 2009",
  "user" : {
    "name" : "Felix",
    "screen_name" : "nicidienase",
    "protected" : false,
    "id_str" : "22396883",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3125784966/8223a4c5c9535be22d15c82ec829c2df_normal.jpeg",
    "id" : 22396883,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://pivotallabs.com/landing/tweed\" rel=\"nofollow\">Tweed</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sunday8pm",
      "screen_name" : "sunday_8pm",
      "indices" : [ 0, 11 ],
      "id_str" : "80762004",
      "id" : 80762004
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "6764332036",
  "geo" : {
  },
  "id_str" : "6767537816",
  "in_reply_to_user_id" : 80762004,
  "text" : "@Sunday_8pm  Jap, Demozug von der PH zum Kronenplatz. Ich war allerding selber nicht dabei.",
  "id" : 6767537816,
  "in_reply_to_status_id" : 6764332036,
  "created_at" : "Thu Dec 17 16:20:34 +0000 2009",
  "in_reply_to_screen_name" : "sunday_8pm",
  "in_reply_to_user_id_str" : "80762004",
  "user" : {
    "name" : "Felix",
    "screen_name" : "nicidienase",
    "protected" : false,
    "id_str" : "22396883",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3125784966/8223a4c5c9535be22d15c82ec829c2df_normal.jpeg",
    "id" : 22396883,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://pivotallabs.com/landing/tweed\" rel=\"nofollow\">Tweed</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "6631025875",
  "text" : "Es schneit!! :-))",
  "id" : 6631025875,
  "created_at" : "Sun Dec 13 15:25:39 +0000 2009",
  "user" : {
    "name" : "Felix",
    "screen_name" : "nicidienase",
    "protected" : false,
    "id_str" : "22396883",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3125784966/8223a4c5c9535be22d15c82ec829c2df_normal.jpeg",
    "id" : 22396883,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://pivotallabs.com/landing/tweed\" rel=\"nofollow\">Tweed</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "6582794684",
  "text" : "Yuchuu, bald ist Deutschland schuldenfrei ... LOL http://blog.fefe.de/?ts=b5dc5505",
  "id" : 6582794684,
  "created_at" : "Fri Dec 11 23:39:36 +0000 2009",
  "user" : {
    "name" : "Felix",
    "screen_name" : "nicidienase",
    "protected" : false,
    "id_str" : "22396883",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3125784966/8223a4c5c9535be22d15c82ec829c2df_normal.jpeg",
    "id" : 22396883,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://pivotallabs.com/landing/tweed\" rel=\"nofollow\">Tweed</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tim Pritlove",
      "screen_name" : "timpritlove",
      "indices" : [ 0, 12 ],
      "id_str" : "11268812",
      "id" : 11268812
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "6578562181",
  "geo" : {
  },
  "id_str" : "6579228598",
  "in_reply_to_user_id" : 11268812,
  "text" : "@timpritlove Ich finds immer toll wenn von CO2 Verbrauchern geredet wir.Das Problem is die CO2-Produktion wird.CO2-Verbraucher sind B\u00E4ume.",
  "id" : 6579228598,
  "in_reply_to_status_id" : 6578562181,
  "created_at" : "Fri Dec 11 21:25:07 +0000 2009",
  "in_reply_to_screen_name" : "timpritlove",
  "in_reply_to_user_id_str" : "11268812",
  "user" : {
    "name" : "Felix",
    "screen_name" : "nicidienase",
    "protected" : false,
    "id_str" : "22396883",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3125784966/8223a4c5c9535be22d15c82ec829c2df_normal.jpeg",
    "id" : 22396883,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://pivotallabs.com/landing/tweed\" rel=\"nofollow\">Tweed</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "6339091415",
  "text" : "Schl\u00FCssel f\u00FCr daheim in KA vergessen. Zum Gl\u00FCck hab ich ne warme Jacke an und mein Vater kommt bald heim.",
  "id" : 6339091415,
  "created_at" : "Fri Dec 04 15:04:09 +0000 2009",
  "user" : {
    "name" : "Felix",
    "screen_name" : "nicidienase",
    "protected" : false,
    "id_str" : "22396883",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3125784966/8223a4c5c9535be22d15c82ec829c2df_normal.jpeg",
    "id" : 22396883,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://pivotallabs.com/landing/tweed\" rel=\"nofollow\">Tweed</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "6332844020",
  "text" : "Grade in TheoC:\"Nennen sie noch einen Faktor des Integrals der nicht falsch sein kann\" Antwort:\"1\"",
  "id" : 6332844020,
  "created_at" : "Fri Dec 04 09:56:04 +0000 2009",
  "user" : {
    "name" : "Felix",
    "screen_name" : "nicidienase",
    "protected" : false,
    "id_str" : "22396883",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3125784966/8223a4c5c9535be22d15c82ec829c2df_normal.jpeg",
    "id" : 22396883,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "6321404345",
  "text" : "http://www.youtube.com/watch?v=8aogkvXy9Jc& deh\u00FCngerize!",
  "id" : 6321404345,
  "created_at" : "Fri Dec 04 00:57:22 +0000 2009",
  "user" : {
    "name" : "Felix",
    "screen_name" : "nicidienase",
    "protected" : false,
    "id_str" : "22396883",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3125784966/8223a4c5c9535be22d15c82ec829c2df_normal.jpeg",
    "id" : 22396883,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://pivotallabs.com/landing/tweed\" rel=\"nofollow\">Tweed</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "6283183581",
  "text" : "LOL http://nichtlustig.de/comics/full/080808.jpg",
  "id" : 6283183581,
  "created_at" : "Wed Dec 02 22:23:51 +0000 2009",
  "user" : {
    "name" : "Felix",
    "screen_name" : "nicidienase",
    "protected" : false,
    "id_str" : "22396883",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3125784966/8223a4c5c9535be22d15c82ec829c2df_normal.jpeg",
    "id" : 22396883,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://pivotallabs.com/landing/tweed\" rel=\"nofollow\">Tweed</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "J\u00F6rg Tauss",
      "screen_name" : "tauss",
      "indices" : [ 110, 116 ],
      "id_str" : "18219170",
      "id" : 18219170
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "6282213026",
  "text" : "Grade Tippfehler in meinem letzten Tweet entdeckt: \"hesslichen Ministerpr\u00E4sidenten Koch\" hie\u00DF es nat\u00FCrlich in @tauss Minarett-Artikel",
  "id" : 6282213026,
  "created_at" : "Wed Dec 02 21:49:18 +0000 2009",
  "user" : {
    "name" : "Felix",
    "screen_name" : "nicidienase",
    "protected" : false,
    "id_str" : "22396883",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3125784966/8223a4c5c9535be22d15c82ec829c2df_normal.jpeg",
    "id" : 22396883,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://pivotallabs.com/landing/tweed\" rel=\"nofollow\">Tweed</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "J\u00F6rg Tauss",
      "screen_name" : "tauss",
      "indices" : [ 76, 82 ],
      "id_str" : "18219170",
      "id" : 18219170
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "6278373399",
  "text" : "Musste grade herzhaft \u00FCber den \"hesslichen Minister Ministerpr\u00E4sidenten\" in @tauss Minarett-Artikel http://tinyurl.com/yh3jput lachen",
  "id" : 6278373399,
  "created_at" : "Wed Dec 02 19:25:43 +0000 2009",
  "user" : {
    "name" : "Felix",
    "screen_name" : "nicidienase",
    "protected" : false,
    "id_str" : "22396883",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3125784966/8223a4c5c9535be22d15c82ec829c2df_normal.jpeg",
    "id" : 22396883,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://pivotallabs.com/landing/tweed\" rel=\"nofollow\">Tweed</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Michael Seemann",
      "screen_name" : "mspro",
      "indices" : [ 3, 9 ],
      "id_str" : "5751892",
      "id" : 5751892
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "6252806162",
  "text" : "RT @mspro: idee: minarettbauflashmob in der schweiz. wer macht mit?",
  "id" : 6252806162,
  "created_at" : "Wed Dec 02 00:32:03 +0000 2009",
  "user" : {
    "name" : "Felix",
    "screen_name" : "nicidienase",
    "protected" : false,
    "id_str" : "22396883",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3125784966/8223a4c5c9535be22d15c82ec829c2df_normal.jpeg",
    "id" : 22396883,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://pivotallabs.com/landing/tweed\" rel=\"nofollow\">Tweed</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "martinhaase",
      "screen_name" : "martinhaase",
      "indices" : [ 3, 15 ],
      "id_str" : "14166720",
      "id" : 14166720
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Orwell",
      "indices" : [ 26, 33 ]
    }, {
      "text" : "swift",
      "indices" : [ 35, 41 ]
    }, {
      "text" : "Minarettverbot",
      "indices" : [ 59, 74 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "6238001315",
  "text" : "RT @martinhaase Frei nach #Orwell: #swift ist Datenschutz, #Minarettverbot ist Demokratie, Ignoranz ist St\u00E4rke #1984",
  "id" : 6238001315,
  "created_at" : "Tue Dec 01 15:33:25 +0000 2009",
  "user" : {
    "name" : "Felix",
    "screen_name" : "nicidienase",
    "protected" : false,
    "id_str" : "22396883",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3125784966/8223a4c5c9535be22d15c82ec829c2df_normal.jpeg",
    "id" : 22396883,
    "verified" : false
  }
} ]