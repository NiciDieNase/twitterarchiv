Grailbird.data.tweets_2010_02 = 
 [ {
  "source" : "<a href=\"http://pivotallabs.com/landing/tweed\" rel=\"nofollow\">Tweed</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "JCN",
      "screen_name" : "cessor",
      "indices" : [ 3, 10 ],
      "id_str" : "43900860",
      "id" : 43900860
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "zensursula",
      "indices" : [ 87, 98 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "9652612351",
  "text" : "RT @cessor Die CDU ist wie ein Compiler - f\u00E4ngt mit C an und ignoriert alle Kommentare #zensursula",
  "id" : 9652612351,
  "created_at" : "Fri Feb 26 00:57:13 +0000 2010",
  "user" : {
    "name" : "Felix",
    "screen_name" : "nicidienase",
    "protected" : false,
    "id_str" : "22396883",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3125784966/8223a4c5c9535be22d15c82ec829c2df_normal.jpeg",
    "id" : 22396883,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://pivotallabs.com/landing/tweed\" rel=\"nofollow\">Tweed</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Edward",
      "screen_name" : "twitgeridoo",
      "indices" : [ 3, 15 ],
      "id_str" : "46379961",
      "id" : 46379961
    }, {
      "name" : "Susan R\u00F6nisch",
      "screen_name" : "redakteur",
      "indices" : [ 97, 107 ],
      "id_str" : "18020337",
      "id" : 18020337
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Entschuldigung",
      "indices" : [ 31, 46 ]
    }, {
      "text" : "Nerdisch",
      "indices" : [ 51, 60 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "9652558700",
  "text" : "RT @twitgeridoo: So sieht eine #Entschuldigung auf #Nerdisch aus: http://twitpic.com/14r7vh (via @redakteur)",
  "id" : 9652558700,
  "created_at" : "Fri Feb 26 00:55:59 +0000 2010",
  "user" : {
    "name" : "Felix",
    "screen_name" : "nicidienase",
    "protected" : false,
    "id_str" : "22396883",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3125784966/8223a4c5c9535be22d15c82ec829c2df_normal.jpeg",
    "id" : 22396883,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://pivotallabs.com/landing/tweed\" rel=\"nofollow\">Tweed</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Wil Wheaton",
      "screen_name" : "wilw",
      "indices" : [ 3, 8 ],
      "id_str" : "1183041",
      "id" : 1183041
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "9599431893",
  "text" : "RT @wilw: The Who's Baba O'Reily, played using only items from Think Geek. http://bit.ly/9aC8eW",
  "id" : 9599431893,
  "created_at" : "Wed Feb 24 23:59:12 +0000 2010",
  "user" : {
    "name" : "Felix",
    "screen_name" : "nicidienase",
    "protected" : false,
    "id_str" : "22396883",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3125784966/8223a4c5c9535be22d15c82ec829c2df_normal.jpeg",
    "id" : 22396883,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://pivotallabs.com/landing/tweed\" rel=\"nofollow\">Tweed</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "9142877583",
  "text" : "Schei\u00DF unp\u00FCnktliche Busse, wegen denen is mir die Bahn vor der Nase weggefahren und ich darf jetzt ne halbe Stunde auf die n\u00E4chste warten.",
  "id" : 9142877583,
  "created_at" : "Mon Feb 15 14:54:49 +0000 2010",
  "user" : {
    "name" : "Felix",
    "screen_name" : "nicidienase",
    "protected" : false,
    "id_str" : "22396883",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3125784966/8223a4c5c9535be22d15c82ec829c2df_normal.jpeg",
    "id" : 22396883,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitpic.com/\" rel=\"nofollow\">TwitPic</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Karlsruhe",
      "indices" : [ 53, 63 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "8998195064",
  "text" : "http://twitpic.com/12q8me - Es schneit immer noch in #Karlsruhe.",
  "id" : 8998195064,
  "created_at" : "Fri Feb 12 06:39:14 +0000 2010",
  "user" : {
    "name" : "Felix",
    "screen_name" : "nicidienase",
    "protected" : false,
    "id_str" : "22396883",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3125784966/8223a4c5c9535be22d15c82ec829c2df_normal.jpeg",
    "id" : 22396883,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://pivotallabs.com/landing/tweed\" rel=\"nofollow\">Tweed</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dsch\u00E4ikop",
      "screen_name" : "jakob_bl",
      "indices" : [ 3, 12 ],
      "id_str" : "75007992",
      "id" : 75007992
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "8748390725",
  "text" : "RT @jakob_bl: wow wenn man die Antwort (42) durch pi teilt bekommt man rund 13,37 raus, das nenn ich mal leet",
  "id" : 8748390725,
  "created_at" : "Sun Feb 07 03:07:05 +0000 2010",
  "user" : {
    "name" : "Felix",
    "screen_name" : "nicidienase",
    "protected" : false,
    "id_str" : "22396883",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3125784966/8223a4c5c9535be22d15c82ec829c2df_normal.jpeg",
    "id" : 22396883,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://pivotallabs.com/landing/tweed\" rel=\"nofollow\">Tweed</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sunday8pm",
      "screen_name" : "sunday_8pm",
      "indices" : [ 0, 11 ],
      "id_str" : "80762004",
      "id" : 80762004
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "8589718051",
  "geo" : {
  },
  "id_str" : "8590030737",
  "in_reply_to_user_id" : 80762004,
  "text" : "@Sunday_8pm Wenn morgen alle mit dem Auto fahren bist du wahrscheinlich genau so lang unterwegs wie mit der Bahn.",
  "id" : 8590030737,
  "in_reply_to_status_id" : 8589718051,
  "created_at" : "Wed Feb 03 14:47:14 +0000 2010",
  "in_reply_to_screen_name" : "sunday_8pm",
  "in_reply_to_user_id_str" : "80762004",
  "user" : {
    "name" : "Felix",
    "screen_name" : "nicidienase",
    "protected" : false,
    "id_str" : "22396883",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3125784966/8223a4c5c9535be22d15c82ec829c2df_normal.jpeg",
    "id" : 22396883,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://pivotallabs.com/landing/tweed\" rel=\"nofollow\">Tweed</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sunday8pm",
      "screen_name" : "sunday_8pm",
      "indices" : [ 0, 11 ],
      "id_str" : "80762004",
      "id" : 80762004
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "KA",
      "indices" : [ 72, 75 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "8557594908",
  "geo" : {
  },
  "id_str" : "8588781325",
  "in_reply_to_user_id" : 80762004,
  "text" : "@Sunday_8pm Morgen wird's noch schlimmer, da fahren gar keine Bahnen in #KA",
  "id" : 8588781325,
  "in_reply_to_status_id" : 8557594908,
  "created_at" : "Wed Feb 03 14:12:03 +0000 2010",
  "in_reply_to_screen_name" : "sunday_8pm",
  "in_reply_to_user_id_str" : "80762004",
  "user" : {
    "name" : "Felix",
    "screen_name" : "nicidienase",
    "protected" : false,
    "id_str" : "22396883",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3125784966/8223a4c5c9535be22d15c82ec829c2df_normal.jpeg",
    "id" : 22396883,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://pivotallabs.com/landing/tweed\" rel=\"nofollow\">Tweed</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Holger Klein",
      "screen_name" : "holgi",
      "indices" : [ 3, 9 ],
      "id_str" : "3068271",
      "id" : 3068271
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "8553436762",
  "text" : "RT @holgi: \"Wie riechts denn hier drinnen?\" ... \"Unklar.\"  http://twitpic.com/111eyh",
  "id" : 8553436762,
  "created_at" : "Tue Feb 02 18:52:55 +0000 2010",
  "user" : {
    "name" : "Felix",
    "screen_name" : "nicidienase",
    "protected" : false,
    "id_str" : "22396883",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3125784966/8223a4c5c9535be22d15c82ec829c2df_normal.jpeg",
    "id" : 22396883,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://pivotallabs.com/landing/tweed\" rel=\"nofollow\">Tweed</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sunday8pm",
      "screen_name" : "sunday_8pm",
      "indices" : [ 0, 11 ],
      "id_str" : "80762004",
      "id" : 80762004
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "8546001626",
  "geo" : {
  },
  "id_str" : "8553209056",
  "in_reply_to_user_id" : 80762004,
  "text" : "@Sunday_8pm Ich war vorhin kurz in der Stadt(zum Gl\u00FCck mitm Rad)und von Kronenplatz bis Marktplatz stand echt eine Bahn an der anderen.",
  "id" : 8553209056,
  "in_reply_to_status_id" : 8546001626,
  "created_at" : "Tue Feb 02 18:46:07 +0000 2010",
  "in_reply_to_screen_name" : "sunday_8pm",
  "in_reply_to_user_id_str" : "80762004",
  "user" : {
    "name" : "Felix",
    "screen_name" : "nicidienase",
    "protected" : false,
    "id_str" : "22396883",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3125784966/8223a4c5c9535be22d15c82ec829c2df_normal.jpeg",
    "id" : 22396883,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitpic.com/\" rel=\"nofollow\">TwitPic</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "8515110805",
  "text" : "http://twitpic.com/10x5h7 - Duff Bier beim Simpsons-Abend in der Waldhornbar.",
  "id" : 8515110805,
  "created_at" : "Mon Feb 01 21:46:57 +0000 2010",
  "user" : {
    "name" : "Felix",
    "screen_name" : "nicidienase",
    "protected" : false,
    "id_str" : "22396883",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3125784966/8223a4c5c9535be22d15c82ec829c2df_normal.jpeg",
    "id" : 22396883,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitpic.com/\" rel=\"nofollow\">TwitPic</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "8508682811",
  "text" : "http://twitpic.com/10w9ps - Das Jahr is zu einem zw\u00F6lftel rum,und ich hab immer noch n paar Twitte-Wandkalender rumliegen.Will wer?",
  "id" : 8508682811,
  "created_at" : "Mon Feb 01 18:32:11 +0000 2010",
  "user" : {
    "name" : "Felix",
    "screen_name" : "nicidienase",
    "protected" : false,
    "id_str" : "22396883",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3125784966/8223a4c5c9535be22d15c82ec829c2df_normal.jpeg",
    "id" : 22396883,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Rudi Dutschke",
      "screen_name" : "dutschke_rudi",
      "indices" : [ 3, 17 ],
      "id_str" : "91354727",
      "id" : 91354727
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "8496772737",
  "text" : "RT @dutschke_rudi: Rechts au\u00DFen im Bundestag (in Form von Kristina K\u00F6hler) wird gerne von Linker-Gewalt gesprochen. Das ist Linke-Gewalt ...",
  "retweeted_status" : {
    "source" : "<a href=\"http://adium.im\" rel=\"nofollow\">Adium</a>",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : {
    },
    "id_str" : "8494604842",
    "text" : "Rechts au\u00DFen im Bundestag (in Form von Kristina K\u00F6hler) wird gerne von Linker-Gewalt gesprochen. Das ist Linke-Gewalt: http://bit.ly/6orkNw",
    "id" : 8494604842,
    "created_at" : "Mon Feb 01 11:13:15 +0000 2010",
    "user" : {
      "name" : "Rudi Dutschke",
      "screen_name" : "dutschke_rudi",
      "protected" : false,
      "id_str" : "91354727",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/535621942/images_normal.jpeg",
      "id" : 91354727,
      "verified" : false
    }
  },
  "id" : 8496772737,
  "created_at" : "Mon Feb 01 12:39:13 +0000 2010",
  "user" : {
    "name" : "Felix",
    "screen_name" : "nicidienase",
    "protected" : false,
    "id_str" : "22396883",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3125784966/8223a4c5c9535be22d15c82ec829c2df_normal.jpeg",
    "id" : 22396883,
    "verified" : false
  }
} ]