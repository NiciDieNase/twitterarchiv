Grailbird.data.tweets_2012_08 = 
 [ {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "241551552412786689",
  "text" : "Mein letzter Arbeitstag im Praxissemester liegt hinter mir \\o/ Wenn ich da nur nicht noch einen Bericht dr\u00FCber schreiben m\u00FCsste.",
  "id" : 241551552412786689,
  "created_at" : "Fri Aug 31 15:02:32 +0000 2012",
  "user" : {
    "name" : "Felix",
    "screen_name" : "nicidienase",
    "protected" : false,
    "id_str" : "22396883",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3125784966/8223a4c5c9535be22d15c82ec829c2df_normal.jpeg",
    "id" : 22396883,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.echofon.com/\" rel=\"nofollow\">Echofon</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "MythBusters Official",
      "screen_name" : "MythBusters",
      "indices" : [ 0, 12 ],
      "id_str" : "52146755",
      "id" : 52146755
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 76, 96 ],
      "url" : "http://t.co/GQOFt7Wl",
      "expanded_url" : "http://en.wikipedia.org/wiki/Dandy_horse",
      "display_url" : "en.wikipedia.org/wiki/Dandy_hor\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "241539281091436545",
  "geo" : {
  },
  "id_str" : "241540120665280512",
  "in_reply_to_user_id" : 52146755,
  "text" : "@MythBusters There already where bikes without pedals almost 200 years ago: http://t.co/GQOFt7Wl",
  "id" : 241540120665280512,
  "in_reply_to_status_id" : 241539281091436545,
  "created_at" : "Fri Aug 31 14:17:07 +0000 2012",
  "in_reply_to_screen_name" : "MythBusters",
  "in_reply_to_user_id_str" : "52146755",
  "user" : {
    "name" : "Felix",
    "screen_name" : "nicidienase",
    "protected" : false,
    "id_str" : "22396883",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3125784966/8223a4c5c9535be22d15c82ec829c2df_normal.jpeg",
    "id" : 22396883,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.echofon.com/\" rel=\"nofollow\">Echofon</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "http",
      "screen_name" : "SwissHttp",
      "indices" : [ 3, 13 ],
      "id_str" : "136790590",
      "id" : 136790590
    }, {
      "name" : "Henning Klevjer",
      "screen_name" : "hennikl",
      "indices" : [ 122, 130 ],
      "id_str" : "22480741",
      "id" : 22480741
    }, {
      "name" : "Mikko Hypponen \u2718",
      "screen_name" : "mikko",
      "indices" : [ 131, 137 ],
      "id_str" : "23566038",
      "id" : 23566038
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 97, 117 ],
      "url" : "http://t.co/UEk6B9mv",
      "expanded_url" : "http://bit.ly/U8vmAx",
      "display_url" : "bit.ly/U8vmAx"
    } ]
  },
  "geo" : {
  },
  "id_str" : "241490525369270272",
  "text" : "RT @SwissHttp: I remember when URLs were limited to 1024 characters. Now they host entire pages:\nhttp://t.co/UEk6B9mv\nvia @hennikl @mikko",
  "retweeted_status" : {
    "source" : "<a href=\"http://www.osfoora.com\" rel=\"nofollow\">Osfoora for iOS</a>",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Henning Klevjer",
        "screen_name" : "hennikl",
        "indices" : [ 107, 115 ],
        "id_str" : "22480741",
        "id" : 22480741
      }, {
        "name" : "Mikko Hypponen \u2718",
        "screen_name" : "mikko",
        "indices" : [ 116, 122 ],
        "id_str" : "23566038",
        "id" : 23566038
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 82, 102 ],
        "url" : "http://t.co/UEk6B9mv",
        "expanded_url" : "http://bit.ly/U8vmAx",
        "display_url" : "bit.ly/U8vmAx"
      } ]
    },
    "geo" : {
    },
    "id_str" : "240488675266412544",
    "text" : "I remember when URLs were limited to 1024 characters. Now they host entire pages:\nhttp://t.co/UEk6B9mv\nvia @hennikl @mikko",
    "id" : 240488675266412544,
    "created_at" : "Tue Aug 28 16:39:02 +0000 2012",
    "user" : {
      "name" : "http",
      "screen_name" : "SwissHttp",
      "protected" : false,
      "id_str" : "136790590",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/1189935998/logo1_small_normal.jpg",
      "id" : 136790590,
      "verified" : false
    }
  },
  "id" : 241490525369270272,
  "created_at" : "Fri Aug 31 11:00:02 +0000 2012",
  "user" : {
    "name" : "Felix",
    "screen_name" : "nicidienase",
    "protected" : false,
    "id_str" : "22396883",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3125784966/8223a4c5c9535be22d15c82ec829c2df_normal.jpeg",
    "id" : 22396883,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.echofon.com/\" rel=\"nofollow\">Echofon</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Holger Klein",
      "screen_name" : "holgi",
      "indices" : [ 0, 6 ],
      "id_str" : "3068271",
      "id" : 3068271
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "241171443109462016",
  "geo" : {
  },
  "id_str" : "241171748823896065",
  "in_reply_to_user_id" : 3068271,
  "text" : "@holgi Vieleicht mahnen die alle ab die dr\u00FCber berichten wollen",
  "id" : 241171748823896065,
  "in_reply_to_status_id" : 241171443109462016,
  "created_at" : "Thu Aug 30 13:53:20 +0000 2012",
  "in_reply_to_screen_name" : "holgi",
  "in_reply_to_user_id_str" : "3068271",
  "user" : {
    "name" : "Felix",
    "screen_name" : "nicidienase",
    "protected" : false,
    "id_str" : "22396883",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3125784966/8223a4c5c9535be22d15c82ec829c2df_normal.jpeg",
    "id" : 22396883,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.echofon.com/\" rel=\"nofollow\">Echofon</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Max",
      "screen_name" : "Demelium",
      "indices" : [ 3, 12 ],
      "id_str" : "194198571",
      "id" : 194198571
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 64, 84 ],
      "url" : "http://t.co/rAPkDqZL",
      "expanded_url" : "http://bit.ly/PPXsjZ",
      "display_url" : "bit.ly/PPXsjZ"
    } ]
  },
  "geo" : {
  },
  "id_str" : "241165959476424705",
  "text" : "RT @Demelium: Hallo Apple, wer ist hier nochmal der Kopierer? - http://t.co/rAPkDqZL",
  "retweeted_status" : {
    "source" : "<a href=\"http://www.tweetdeck.com\" rel=\"nofollow\">TweetDeck</a>",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 50, 70 ],
        "url" : "http://t.co/rAPkDqZL",
        "expanded_url" : "http://bit.ly/PPXsjZ",
        "display_url" : "bit.ly/PPXsjZ"
      } ]
    },
    "geo" : {
    },
    "id_str" : "241156093953310720",
    "text" : "Hallo Apple, wer ist hier nochmal der Kopierer? - http://t.co/rAPkDqZL",
    "id" : 241156093953310720,
    "created_at" : "Thu Aug 30 12:51:07 +0000 2012",
    "user" : {
      "name" : "Max",
      "screen_name" : "Demelium",
      "protected" : false,
      "id_str" : "194198571",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/3292430420/6a222578bddcf9d530b006277eb04eb4_normal.png",
      "id" : 194198571,
      "verified" : false
    }
  },
  "id" : 241165959476424705,
  "created_at" : "Thu Aug 30 13:30:20 +0000 2012",
  "user" : {
    "name" : "Felix",
    "screen_name" : "nicidienase",
    "protected" : false,
    "id_str" : "22396883",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3125784966/8223a4c5c9535be22d15c82ec829c2df_normal.jpeg",
    "id" : 22396883,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.echofon.com/\" rel=\"nofollow\">Echofon</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Leigh Honeywell",
      "screen_name" : "hypatiadotca",
      "indices" : [ 3, 16 ],
      "id_str" : "6742522",
      "id" : 6742522
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "241083285592231936",
  "text" : "RT @hypatiadotca: OH: \"I always tell little girls I'm a computer programmer and that's why I get to have my hair any way I want\" :D :D :D",
  "retweeted_status" : {
    "source" : "<a href=\"http://www.tweetdeck.com\" rel=\"nofollow\">TweetDeck</a>",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : {
    },
    "id_str" : "236946728761319424",
    "text" : "OH: \"I always tell little girls I'm a computer programmer and that's why I get to have my hair any way I want\" :D :D :D",
    "id" : 236946728761319424,
    "created_at" : "Sat Aug 18 22:04:37 +0000 2012",
    "user" : {
      "name" : "Leigh Honeywell",
      "screen_name" : "hypatiadotca",
      "protected" : false,
      "id_str" : "6742522",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/1370529948/leigh-square_normal.jpg",
      "id" : 6742522,
      "verified" : false
    }
  },
  "id" : 241083285592231936,
  "created_at" : "Thu Aug 30 08:01:49 +0000 2012",
  "user" : {
    "name" : "Felix",
    "screen_name" : "nicidienase",
    "protected" : false,
    "id_str" : "22396883",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3125784966/8223a4c5c9535be22d15c82ec829c2df_normal.jpeg",
    "id" : 22396883,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "$(RandomName)",
      "screen_name" : "Ik4ru5",
      "indices" : [ 0, 7 ],
      "id_str" : "48294441",
      "id" : 48294441
    }, {
      "name" : "psy",
      "screen_name" : "psycon",
      "indices" : [ 8, 15 ],
      "id_str" : "87286054",
      "id" : 87286054
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "240839103724281856",
  "geo" : {
  },
  "id_str" : "240858469874413568",
  "in_reply_to_user_id" : 48294441,
  "text" : "@Ik4ru5 @psycon bin 19.15 bei der Java user group, Vortrag \u00FCber Ruby. Danach will ich erst mal Heim und duschen.",
  "id" : 240858469874413568,
  "in_reply_to_status_id" : 240839103724281856,
  "created_at" : "Wed Aug 29 17:08:28 +0000 2012",
  "in_reply_to_screen_name" : "Ik4ru5",
  "in_reply_to_user_id_str" : "48294441",
  "user" : {
    "name" : "Felix",
    "screen_name" : "nicidienase",
    "protected" : false,
    "id_str" : "22396883",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3125784966/8223a4c5c9535be22d15c82ec829c2df_normal.jpeg",
    "id" : 22396883,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.echofon.com/\" rel=\"nofollow\">Echofon</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "nibbler",
      "screen_name" : "nblr",
      "indices" : [ 3, 8 ],
      "id_str" : "174052946",
      "id" : 174052946
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 31, 52 ],
      "url" : "https://t.co/eC6yMeDY",
      "expanded_url" : "https://fbcdn-sphotos-h-a.akamaihd.net/hphotos-ak-ash4/293059_10151113596789014_626758415_n.jpg",
      "display_url" : "fbcdn-sphotos-h-a.akamaihd.net/hphotos-ak-ash\u2026"
    } ]
  },
  "geo" : {
  },
  "id_str" : "240826117685125122",
  "text" : "RT @nblr: Neulich in Muenchen: https://t.co/eC6yMeDY \"Warum liegt hier denn Stroh rum?\"",
  "retweeted_status" : {
    "source" : "web",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 21, 42 ],
        "url" : "https://t.co/eC6yMeDY",
        "expanded_url" : "https://fbcdn-sphotos-h-a.akamaihd.net/hphotos-ak-ash4/293059_10151113596789014_626758415_n.jpg",
        "display_url" : "fbcdn-sphotos-h-a.akamaihd.net/hphotos-ak-ash\u2026"
      } ]
    },
    "geo" : {
    },
    "id_str" : "240823677225140224",
    "text" : "Neulich in Muenchen: https://t.co/eC6yMeDY \"Warum liegt hier denn Stroh rum?\"",
    "id" : 240823677225140224,
    "created_at" : "Wed Aug 29 14:50:13 +0000 2012",
    "user" : {
      "name" : "nibbler",
      "screen_name" : "nblr",
      "protected" : false,
      "id_str" : "174052946",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/3311942359/003f0d345d2017faf4f04c54b1e19ad6_normal.png",
      "id" : 174052946,
      "verified" : false
    }
  },
  "id" : 240826117685125122,
  "created_at" : "Wed Aug 29 14:59:55 +0000 2012",
  "user" : {
    "name" : "Felix",
    "screen_name" : "nicidienase",
    "protected" : false,
    "id_str" : "22396883",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3125784966/8223a4c5c9535be22d15c82ec829c2df_normal.jpeg",
    "id" : 22396883,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.echofon.com/\" rel=\"nofollow\">Echofon</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "getDigital Team",
      "screen_name" : "getDigital_de",
      "indices" : [ 0, 14 ],
      "id_str" : "45354877",
      "id" : 45354877
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "240815512802689024",
  "geo" : {
  },
  "id_str" : "240816635001307136",
  "in_reply_to_user_id" : 45354877,
  "text" : "@getDigital_de Einen 1GB-USB-Stick kriegt man f\u00FCr unter 5\u20AC. 20\u20AC f\u00FCr ein St\u00FCck bedruckte und gefaltete Pappe sind schon nicht grade wenig.",
  "id" : 240816635001307136,
  "in_reply_to_status_id" : 240815512802689024,
  "created_at" : "Wed Aug 29 14:22:14 +0000 2012",
  "in_reply_to_screen_name" : "getDigital_de",
  "in_reply_to_user_id_str" : "45354877",
  "user" : {
    "name" : "Felix",
    "screen_name" : "nicidienase",
    "protected" : false,
    "id_str" : "22396883",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3125784966/8223a4c5c9535be22d15c82ec829c2df_normal.jpeg",
    "id" : 22396883,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.echofon.com/\" rel=\"nofollow\">Echofon</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "pfleidi",
      "screen_name" : "pfleidi",
      "indices" : [ 3, 11 ],
      "id_str" : "15647796",
      "id" : 15647796
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 50, 70 ],
      "url" : "http://t.co/wyWWhPgg",
      "expanded_url" : "http://fc09.deviantart.net/fs70/i/2012/232/0/a/welcome_to_the_internet__please_follow_me_by_sharpwriter-d5buwfu.jpg",
      "display_url" : "fc09.deviantart.net/fs70/i/2012/23\u2026"
    } ]
  },
  "geo" : {
  },
  "id_str" : "240808723541528576",
  "text" : "RT @pfleidi: Don\u2019t worry, I\u2019m from the Internet \u2026 http://t.co/wyWWhPgg",
  "retweeted_status" : {
    "source" : "<a href=\"http://tapbots.com/tweetbot\" rel=\"nofollow\">Tweetbot for iOS</a>",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 37, 57 ],
        "url" : "http://t.co/wyWWhPgg",
        "expanded_url" : "http://fc09.deviantart.net/fs70/i/2012/232/0/a/welcome_to_the_internet__please_follow_me_by_sharpwriter-d5buwfu.jpg",
        "display_url" : "fc09.deviantart.net/fs70/i/2012/23\u2026"
      } ]
    },
    "geo" : {
    },
    "id_str" : "240803648546934785",
    "text" : "Don\u2019t worry, I\u2019m from the Internet \u2026 http://t.co/wyWWhPgg",
    "id" : 240803648546934785,
    "created_at" : "Wed Aug 29 13:30:38 +0000 2012",
    "user" : {
      "name" : "pfleidi",
      "screen_name" : "pfleidi",
      "protected" : false,
      "id_str" : "15647796",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/2992339395/7f60afee5ffff6e961831ba8d07d0850_normal.png",
      "id" : 15647796,
      "verified" : false
    }
  },
  "id" : 240808723541528576,
  "created_at" : "Wed Aug 29 13:50:48 +0000 2012",
  "user" : {
    "name" : "Felix",
    "screen_name" : "nicidienase",
    "protected" : false,
    "id_str" : "22396883",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3125784966/8223a4c5c9535be22d15c82ec829c2df_normal.jpeg",
    "id" : 22396883,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.echofon.com/\" rel=\"nofollow\">Echofon</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tim Weber",
      "screen_name" : "scy",
      "indices" : [ 0, 4 ],
      "id_str" : "8308632",
      "id" : 8308632
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "240774852208910337",
  "geo" : {
  },
  "id_str" : "240775409879379968",
  "in_reply_to_user_id" : 8308632,
  "text" : "@scy 1Mrd. $ in 5ct-St\u00FCcken macht auf 30 Trucks verteil \u00FCber 3000t pro Truck.",
  "id" : 240775409879379968,
  "in_reply_to_status_id" : 240774852208910337,
  "created_at" : "Wed Aug 29 11:38:25 +0000 2012",
  "in_reply_to_screen_name" : "scy",
  "in_reply_to_user_id_str" : "8308632",
  "user" : {
    "name" : "Felix",
    "screen_name" : "nicidienase",
    "protected" : false,
    "id_str" : "22396883",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3125784966/8223a4c5c9535be22d15c82ec829c2df_normal.jpeg",
    "id" : 22396883,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.echofon.com/\" rel=\"nofollow\">Echofon</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tim Weber",
      "screen_name" : "scy",
      "indices" : [ 0, 4 ],
      "id_str" : "8308632",
      "id" : 8308632
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "240772500869488640",
  "geo" : {
  },
  "id_str" : "240774952788320257",
  "in_reply_to_user_id" : 8308632,
  "text" : "@scy Die Story is genial, aber ich halte es f\u00FCr unwahrscheinlich das die so schnell 20Mrd. 5ct-M\u00FCnzen aufgetrieben haben.",
  "id" : 240774952788320257,
  "in_reply_to_status_id" : 240772500869488640,
  "created_at" : "Wed Aug 29 11:36:36 +0000 2012",
  "in_reply_to_screen_name" : "scy",
  "in_reply_to_user_id_str" : "8308632",
  "user" : {
    "name" : "Felix",
    "screen_name" : "nicidienase",
    "protected" : false,
    "id_str" : "22396883",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3125784966/8223a4c5c9535be22d15c82ec829c2df_normal.jpeg",
    "id" : 22396883,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.echofon.com/\" rel=\"nofollow\">Echofon</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "@zeitweise",
      "screen_name" : "zeitweise",
      "indices" : [ 3, 13 ],
      "id_str" : "15494684",
      "id" : 15494684
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "240766330175881216",
  "text" : "RT @zeitweise: CamelCase, SnAkEcAsE, fISHCaSE, Sp4mc4$e, SHITSTORMCASE!!1!",
  "retweeted_status" : {
    "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : {
    },
    "id_str" : "240764735455387649",
    "text" : "CamelCase, SnAkEcAsE, fISHCaSE, Sp4mc4$e, SHITSTORMCASE!!1!",
    "id" : 240764735455387649,
    "created_at" : "Wed Aug 29 10:56:00 +0000 2012",
    "user" : {
      "name" : "@zeitweise",
      "screen_name" : "zeitweise",
      "protected" : false,
      "id_str" : "15494684",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/2537661538/iysgc8dedep2s9qk7gyc_normal.jpeg",
      "id" : 15494684,
      "verified" : false
    }
  },
  "id" : 240766330175881216,
  "created_at" : "Wed Aug 29 11:02:20 +0000 2012",
  "user" : {
    "name" : "Felix",
    "screen_name" : "nicidienase",
    "protected" : false,
    "id_str" : "22396883",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3125784966/8223a4c5c9535be22d15c82ec829c2df_normal.jpeg",
    "id" : 22396883,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.echofon.com/\" rel=\"nofollow\">Echofon</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Malte Welding",
      "screen_name" : "maltewelding",
      "indices" : [ 3, 16 ],
      "id_str" : "6274082",
      "id" : 6274082
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "240747225645461504",
  "text" : "RT @maltewelding: 2009 habe ich f\u00FCr die mittlerweile verblichene Netzzeitung den Kampf der Verlage gegen Google geschildert http://t.co/ ...",
  "retweeted_status" : {
    "source" : "<a href=\"http://twitpic.com\" rel=\"nofollow\">Twitpic</a>",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 106, 126 ],
        "url" : "http://t.co/cqBFFMhx",
        "expanded_url" : "http://twitpic.com/aoumke",
        "display_url" : "twitpic.com/aoumke"
      } ]
    },
    "geo" : {
    },
    "id_str" : "240743280780926976",
    "text" : "2009 habe ich f\u00FCr die mittlerweile verblichene Netzzeitung den Kampf der Verlage gegen Google geschildert http://t.co/cqBFFMhx",
    "id" : 240743280780926976,
    "created_at" : "Wed Aug 29 09:30:45 +0000 2012",
    "user" : {
      "name" : "Malte Welding",
      "screen_name" : "maltewelding",
      "protected" : false,
      "id_str" : "6274082",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/3320406057/95789ea4ea12c6f13647be61b7e33eb9_normal.jpeg",
      "id" : 6274082,
      "verified" : false
    }
  },
  "id" : 240747225645461504,
  "created_at" : "Wed Aug 29 09:46:26 +0000 2012",
  "user" : {
    "name" : "Felix",
    "screen_name" : "nicidienase",
    "protected" : false,
    "id_str" : "22396883",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3125784966/8223a4c5c9535be22d15c82ec829c2df_normal.jpeg",
    "id" : 22396883,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.echofon.com/\" rel=\"nofollow\">Echofon</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mathias Meyer",
      "screen_name" : "roidrage",
      "indices" : [ 3, 12 ],
      "id_str" : "14658472",
      "id" : 14658472
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 39, 59 ],
      "url" : "http://t.co/AdPiDL8D",
      "expanded_url" : "http://lh6.ggpht.com/_zLwHwqx7gy4/S-wOATaUxOI/AAAAAAAAFaQ/w14V4XjAwAU/catgifpage71.gif",
      "display_url" : "lh6.ggpht.com/_zLwHwqx7gy4/S\u2026"
    } ]
  },
  "geo" : {
  },
  "id_str" : "240746638581325824",
  "text" : "RT @roidrage: Work smarter not harder: http://t.co/AdPiDL8D",
  "retweeted_status" : {
    "source" : "<a href=\"http://tapbots.com/software/tweetbot/mac\" rel=\"nofollow\">Tweetbot for Mac</a>",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 25, 45 ],
        "url" : "http://t.co/AdPiDL8D",
        "expanded_url" : "http://lh6.ggpht.com/_zLwHwqx7gy4/S-wOATaUxOI/AAAAAAAAFaQ/w14V4XjAwAU/catgifpage71.gif",
        "display_url" : "lh6.ggpht.com/_zLwHwqx7gy4/S\u2026"
      } ]
    },
    "geo" : {
    },
    "id_str" : "240507717700161538",
    "text" : "Work smarter not harder: http://t.co/AdPiDL8D",
    "id" : 240507717700161538,
    "created_at" : "Tue Aug 28 17:54:42 +0000 2012",
    "user" : {
      "name" : "Mathias Meyer",
      "screen_name" : "roidrage",
      "protected" : false,
      "id_str" : "14658472",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/2938540224/9ffc554b0eabb077a915cfe0d56f3c1f_normal.jpeg",
      "id" : 14658472,
      "verified" : false
    }
  },
  "id" : 240746638581325824,
  "created_at" : "Wed Aug 29 09:44:06 +0000 2012",
  "user" : {
    "name" : "Felix",
    "screen_name" : "nicidienase",
    "protected" : false,
    "id_str" : "22396883",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3125784966/8223a4c5c9535be22d15c82ec829c2df_normal.jpeg",
    "id" : 22396883,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.echofon.com/\" rel=\"nofollow\">Echofon</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "cupe",
      "screen_name" : "cupe_cupe",
      "indices" : [ 0, 10 ],
      "id_str" : "143922800",
      "id" : 143922800
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "240721640558850048",
  "geo" : {
  },
  "id_str" : "240723320444694529",
  "in_reply_to_user_id" : 143922800,
  "text" : "@cupe_cupe Ah, mein Licht is sein nem halben Jahr kaputt. Da kann ich mir ja noch ein bissl Zeit lassen mit dem Reparieren.",
  "id" : 240723320444694529,
  "in_reply_to_status_id" : 240721640558850048,
  "created_at" : "Wed Aug 29 08:11:26 +0000 2012",
  "in_reply_to_screen_name" : "cupe_cupe",
  "in_reply_to_user_id_str" : "143922800",
  "user" : {
    "name" : "Felix",
    "screen_name" : "nicidienase",
    "protected" : false,
    "id_str" : "22396883",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3125784966/8223a4c5c9535be22d15c82ec829c2df_normal.jpeg",
    "id" : 22396883,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.echofon.com/\" rel=\"nofollow\">Echofon</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mario Sixtus",
      "screen_name" : "sixtus",
      "indices" : [ 0, 7 ],
      "id_str" : "9334352",
      "id" : 9334352
    }, {
      "name" : "DB Bahn",
      "screen_name" : "DB_Bahn",
      "indices" : [ 119, 127 ],
      "id_str" : "39999078",
      "id" : 39999078
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "240365012433125377",
  "geo" : {
  },
  "id_str" : "240366585636868096",
  "in_reply_to_user_id" : 9334352,
  "text" : "@sixtus Ein schlechter Job in 0,1% aller Situationen d\u00FCrften nicht grade wenig sein. Wieviele pro Tag sind das den? // @DB_BAHN",
  "id" : 240366585636868096,
  "in_reply_to_status_id" : 240365012433125377,
  "created_at" : "Tue Aug 28 08:33:54 +0000 2012",
  "in_reply_to_screen_name" : "sixtus",
  "in_reply_to_user_id_str" : "9334352",
  "user" : {
    "name" : "Felix",
    "screen_name" : "nicidienase",
    "protected" : false,
    "id_str" : "22396883",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3125784966/8223a4c5c9535be22d15c82ec829c2df_normal.jpeg",
    "id" : 22396883,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Monika Urbonait\u0117",
      "screen_name" : "MonikaUrbon",
      "indices" : [ 3, 15 ],
      "id_str" : "112710155",
      "id" : 112710155
    }, {
      "name" : "NYAN CAT",
      "screen_name" : "nyannyancat",
      "indices" : [ 17, 29 ],
      "id_str" : "281670654",
      "id" : 281670654
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 52, 72 ],
      "url" : "http://t.co/vmVvTsGf",
      "expanded_url" : "http://twitter.com/MonikaUrbon/status/240146860961042432/photo/1",
      "display_url" : "pic.twitter.com/vmVvTsGf"
    } ]
  },
  "geo" : {
  },
  "id_str" : "240187329292148736",
  "text" : "RT @MonikaUrbon: @nyannyancat was that you ?? \uD83D\uDC9C\uD83D\uDC99\uD83D\uDC9A\uD83D\uDC9B\u2764 http://t.co/vmVvTsGf",
  "retweeted_status" : {
    "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
    "entities" : {
      "user_mentions" : [ {
        "name" : "NYAN CAT",
        "screen_name" : "nyannyancat",
        "indices" : [ 0, 12 ],
        "id_str" : "281670654",
        "id" : 281670654
      } ],
      "media" : [ {
        "expanded_url" : "http://twitter.com/MonikaUrbon/status/240146860961042432/photo/1",
        "indices" : [ 35, 55 ],
        "url" : "http://t.co/vmVvTsGf",
        "media_url" : "http://pbs.twimg.com/media/A1UsTDXCEAA09dZ.jpg",
        "id_str" : "240146860965236736",
        "id" : 240146860965236736,
        "media_url_https" : "https://pbs.twimg.com/media/A1UsTDXCEAA09dZ.jpg",
        "sizes" : [ {
          "h" : 640,
          "resize" : "fit",
          "w" : 960
        }, {
          "h" : 227,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 640,
          "resize" : "fit",
          "w" : 960
        }, {
          "h" : 400,
          "resize" : "fit",
          "w" : 600
        } ],
        "display_url" : "pic.twitter.com/vmVvTsGf"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : {
    },
    "id_str" : "240146860961042432",
    "in_reply_to_user_id" : 281670654,
    "text" : "@nyannyancat was that you ?? \uD83D\uDC9C\uD83D\uDC99\uD83D\uDC9A\uD83D\uDC9B\u2764 http://t.co/vmVvTsGf",
    "id" : 240146860961042432,
    "created_at" : "Mon Aug 27 18:00:48 +0000 2012",
    "in_reply_to_screen_name" : "nyannyancat",
    "in_reply_to_user_id_str" : "281670654",
    "user" : {
      "name" : "Monika Urbonait\u0117",
      "screen_name" : "MonikaUrbon",
      "protected" : false,
      "id_str" : "112710155",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/3277324877/b3203521b62b7ada7a8cdbeed0281e41_normal.jpeg",
      "id" : 112710155,
      "verified" : false
    }
  },
  "id" : 240187329292148736,
  "created_at" : "Mon Aug 27 20:41:36 +0000 2012",
  "user" : {
    "name" : "Felix",
    "screen_name" : "nicidienase",
    "protected" : false,
    "id_str" : "22396883",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3125784966/8223a4c5c9535be22d15c82ec829c2df_normal.jpeg",
    "id" : 22396883,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.echofon.com/\" rel=\"nofollow\">Echofon</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Eva Eichhorn",
      "screen_name" : "MamsellChaos",
      "indices" : [ 0, 13 ],
      "id_str" : "140774041",
      "id" : 140774041
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "240111515703848960",
  "geo" : {
  },
  "id_str" : "240112518901690368",
  "in_reply_to_user_id" : 140774041,
  "text" : "@MamsellChaos Schade, kein Foto im Artikel.",
  "id" : 240112518901690368,
  "in_reply_to_status_id" : 240111515703848960,
  "created_at" : "Mon Aug 27 15:44:20 +0000 2012",
  "in_reply_to_screen_name" : "MamsellChaos",
  "in_reply_to_user_id_str" : "140774041",
  "user" : {
    "name" : "Felix",
    "screen_name" : "nicidienase",
    "protected" : false,
    "id_str" : "22396883",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3125784966/8223a4c5c9535be22d15c82ec829c2df_normal.jpeg",
    "id" : 22396883,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.echofon.com/\" rel=\"nofollow\">Echofon</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "i42n",
      "screen_name" : "i42n",
      "indices" : [ 0, 5 ],
      "id_str" : "22298116",
      "id" : 22298116
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "240039629573738496",
  "geo" : {
  },
  "id_str" : "240062747646251008",
  "in_reply_to_user_id" : 22298116,
  "text" : "@i42n Bestellen? Ich hab meine alle bei Hacker-Events gesammelt.",
  "id" : 240062747646251008,
  "in_reply_to_status_id" : 240039629573738496,
  "created_at" : "Mon Aug 27 12:26:33 +0000 2012",
  "in_reply_to_screen_name" : "i42n",
  "in_reply_to_user_id_str" : "22298116",
  "user" : {
    "name" : "Felix",
    "screen_name" : "nicidienase",
    "protected" : false,
    "id_str" : "22396883",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3125784966/8223a4c5c9535be22d15c82ec829c2df_normal.jpeg",
    "id" : 22396883,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Gerd Eist",
      "screen_name" : "erdgeist",
      "indices" : [ 3, 12 ],
      "id_str" : "16701619",
      "id" : 16701619
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 56, 76 ],
      "url" : "http://t.co/BirYiiiF",
      "expanded_url" : "http://www.hex2.net/2012/06/11/ritter-sport-sorten-die-fehlen/",
      "display_url" : "hex2.net/2012/06/11/rit\u2026"
    } ]
  },
  "geo" : {
  },
  "id_str" : "239797753440514049",
  "text" : "RT @erdgeist: Quadratisch, praktisch, nicht im Angebot. http://t.co/BirYiiiF",
  "retweeted_status" : {
    "source" : "web",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 42, 62 ],
        "url" : "http://t.co/BirYiiiF",
        "expanded_url" : "http://www.hex2.net/2012/06/11/ritter-sport-sorten-die-fehlen/",
        "display_url" : "hex2.net/2012/06/11/rit\u2026"
      } ]
    },
    "geo" : {
    },
    "id_str" : "239791787923869697",
    "text" : "Quadratisch, praktisch, nicht im Angebot. http://t.co/BirYiiiF",
    "id" : 239791787923869697,
    "created_at" : "Sun Aug 26 18:29:52 +0000 2012",
    "user" : {
      "name" : "Gerd Eist",
      "screen_name" : "erdgeist",
      "protected" : false,
      "id_str" : "16701619",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/61748149/ta_normal.jpg",
      "id" : 16701619,
      "verified" : false
    }
  },
  "id" : 239797753440514049,
  "created_at" : "Sun Aug 26 18:53:34 +0000 2012",
  "user" : {
    "name" : "Felix",
    "screen_name" : "nicidienase",
    "protected" : false,
    "id_str" : "22396883",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3125784966/8223a4c5c9535be22d15c82ec829c2df_normal.jpeg",
    "id" : 22396883,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Frau Wunder \u221E",
      "screen_name" : "Tina_is_da",
      "indices" : [ 3, 14 ],
      "id_str" : "61745691",
      "id" : 61745691
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "239682207655022592",
  "text" : "RT @Tina_is_da: Merke: Knutschen und kuscheln hilft. Immer!",
  "retweeted_status" : {
    "source" : "<a href=\"http://twicca.r246.jp/\" rel=\"nofollow\">twicca</a>",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : {
    },
    "id_str" : "238919388244361216",
    "text" : "Merke: Knutschen und kuscheln hilft. Immer!",
    "id" : 238919388244361216,
    "created_at" : "Fri Aug 24 08:43:15 +0000 2012",
    "user" : {
      "name" : "Frau Wunder \u221E",
      "screen_name" : "Tina_is_da",
      "protected" : false,
      "id_str" : "61745691",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/3455199371/3e99f9a1dea2210ba433e57ec008769f_normal.png",
      "id" : 61745691,
      "verified" : false
    }
  },
  "id" : 239682207655022592,
  "created_at" : "Sun Aug 26 11:14:26 +0000 2012",
  "user" : {
    "name" : "Felix",
    "screen_name" : "nicidienase",
    "protected" : false,
    "id_str" : "22396883",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3125784966/8223a4c5c9535be22d15c82ec829c2df_normal.jpeg",
    "id" : 22396883,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "SarcasticRover",
      "screen_name" : "SarcasticRover",
      "indices" : [ 3, 18 ],
      "id_str" : "740109097",
      "id" : 740109097
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "238790729693011968",
  "text" : "RT @SarcasticRover: If the nerds at NASA don't call out \"Engage!\" every time they upload driving commands to me, then I have lost all fa ...",
  "retweeted_status" : {
    "source" : "<a href=\"http://itunes.apple.com/us/app/twitter/id409789998?mt=12\" rel=\"nofollow\">Twitter for Mac</a>",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : {
    },
    "id_str" : "238774383647264770",
    "text" : "If the nerds at NASA don't call out \"Engage!\" every time they upload driving commands to me, then I have lost all faith in science.",
    "id" : 238774383647264770,
    "created_at" : "Thu Aug 23 23:07:03 +0000 2012",
    "user" : {
      "name" : "SarcasticRover",
      "screen_name" : "SarcasticRover",
      "protected" : false,
      "id_str" : "740109097",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/2489313748/kcd8565sp9t7e0h3n39i_normal.jpeg",
      "id" : 740109097,
      "verified" : false
    }
  },
  "id" : 238790729693011968,
  "created_at" : "Fri Aug 24 00:12:01 +0000 2012",
  "user" : {
    "name" : "Felix",
    "screen_name" : "nicidienase",
    "protected" : false,
    "id_str" : "22396883",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3125784966/8223a4c5c9535be22d15c82ec829c2df_normal.jpeg",
    "id" : 22396883,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "i42n",
      "screen_name" : "i42n",
      "indices" : [ 0, 5 ],
      "id_str" : "22298116",
      "id" : 22298116
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "238739265960435712",
  "geo" : {
  },
  "id_str" : "238788071582208000",
  "in_reply_to_user_id" : 22298116,
  "text" : "@i42n interessanter Fluchtplan ...",
  "id" : 238788071582208000,
  "in_reply_to_status_id" : 238739265960435712,
  "created_at" : "Fri Aug 24 00:01:27 +0000 2012",
  "in_reply_to_screen_name" : "i42n",
  "in_reply_to_user_id_str" : "22298116",
  "user" : {
    "name" : "Felix",
    "screen_name" : "nicidienase",
    "protected" : false,
    "id_str" : "22396883",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3125784966/8223a4c5c9535be22d15c82ec829c2df_normal.jpeg",
    "id" : 22396883,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "238730681809788928",
  "text" : "Mmmmh. Schoko-Souffle zum Nachtisch.",
  "id" : 238730681809788928,
  "created_at" : "Thu Aug 23 20:13:24 +0000 2012",
  "user" : {
    "name" : "Felix",
    "screen_name" : "nicidienase",
    "protected" : false,
    "id_str" : "22396883",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3125784966/8223a4c5c9535be22d15c82ec829c2df_normal.jpeg",
    "id" : 22396883,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "238728162136174592",
  "text" : "Lecker Lassagne essen bei der Schwester auf dem Balkon. Sch\u00F6ner Abschluss meiner Woche Verwandtschafts-Urlaub.",
  "id" : 238728162136174592,
  "created_at" : "Thu Aug 23 20:03:23 +0000 2012",
  "user" : {
    "name" : "Felix",
    "screen_name" : "nicidienase",
    "protected" : false,
    "id_str" : "22396883",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3125784966/8223a4c5c9535be22d15c82ec829c2df_normal.jpeg",
    "id" : 22396883,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "238399669217132544",
  "geo" : {
  },
  "id_str" : "238449345471606785",
  "in_reply_to_user_id" : 20689932,
  "text" : "@Geruhn Solange dein Kopf deswegen nicht schief h\u00E4ngt.",
  "id" : 238449345471606785,
  "in_reply_to_status_id" : 238399669217132544,
  "created_at" : "Thu Aug 23 01:35:28 +0000 2012",
  "in_reply_to_screen_name" : "keinGeruhn",
  "in_reply_to_user_id_str" : "20689932",
  "user" : {
    "name" : "Felix",
    "screen_name" : "nicidienase",
    "protected" : false,
    "id_str" : "22396883",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3125784966/8223a4c5c9535be22d15c82ec829c2df_normal.jpeg",
    "id" : 22396883,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Bernard Keane",
      "screen_name" : "BernardKeane",
      "indices" : [ 3, 16 ],
      "id_str" : "21055261",
      "id" : 21055261
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "238218167825100801",
  "text" : "RT @BernardKeane: 42% of filesharers would pay for content if it was available across the world at the same time and for a decent price  ...",
  "retweeted_status" : {
    "source" : "<a href=\"http://www.tweetdeck.com\" rel=\"nofollow\">TweetDeck</a>",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 118, 138 ],
        "url" : "http://t.co/PLblPuFK",
        "expanded_url" : "http://is.gd/JStPfB",
        "display_url" : "is.gd/JStPfB"
      } ]
    },
    "geo" : {
    },
    "id_str" : "237890412453429248",
    "text" : "42% of filesharers would pay for content if it was available across the world at the same time and for a decent price http://t.co/PLblPuFK",
    "id" : 237890412453429248,
    "created_at" : "Tue Aug 21 12:34:28 +0000 2012",
    "user" : {
      "name" : "Bernard Keane",
      "screen_name" : "BernardKeane",
      "protected" : false,
      "id_str" : "21055261",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/2928317678/317726db0b99ed23ea4e8c8d61e9a14d_normal.jpeg",
      "id" : 21055261,
      "verified" : false
    }
  },
  "id" : 238218167825100801,
  "created_at" : "Wed Aug 22 10:16:51 +0000 2012",
  "user" : {
    "name" : "Felix",
    "screen_name" : "nicidienase",
    "protected" : false,
    "id_str" : "22396883",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3125784966/8223a4c5c9535be22d15c82ec829c2df_normal.jpeg",
    "id" : 22396883,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "monoxyd",
      "screen_name" : "monoxyd",
      "indices" : [ 3, 11 ],
      "id_str" : "14085052",
      "id" : 14085052
    }, {
      "name" : "Nicolas Semak",
      "screen_name" : "nsemak",
      "indices" : [ 99, 106 ],
      "id_str" : "10603962",
      "id" : 10603962
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 74, 94 ],
      "url" : "http://t.co/NnVAby5C",
      "expanded_url" : "http://www.youtube.com/watch?v=uIRBxRlsYR0&feature=share",
      "display_url" : "youtube.com/watch?v=uIRBxR\u2026"
    } ]
  },
  "geo" : {
  },
  "id_str" : "238212922831151104",
  "text" : "RT @monoxyd: Yeah! Jetzt muss ich mir das neue iPhone doch sofort kaufen. http://t.co/NnVAby5C /cc @nsemak",
  "retweeted_status" : {
    "source" : "<a href=\"http://itunes.apple.com/us/app/twitter/id409789998?mt=12\" rel=\"nofollow\">Twitter for Mac</a>",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Nicolas Semak",
        "screen_name" : "nsemak",
        "indices" : [ 86, 93 ],
        "id_str" : "10603962",
        "id" : 10603962
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 61, 81 ],
        "url" : "http://t.co/NnVAby5C",
        "expanded_url" : "http://www.youtube.com/watch?v=uIRBxRlsYR0&feature=share",
        "display_url" : "youtube.com/watch?v=uIRBxR\u2026"
      } ]
    },
    "geo" : {
    },
    "id_str" : "238142135910690817",
    "text" : "Yeah! Jetzt muss ich mir das neue iPhone doch sofort kaufen. http://t.co/NnVAby5C /cc @nsemak",
    "id" : 238142135910690817,
    "created_at" : "Wed Aug 22 05:14:44 +0000 2012",
    "user" : {
      "name" : "monoxyd",
      "screen_name" : "monoxyd",
      "protected" : false,
      "id_str" : "14085052",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/1422306657/lampe_normal.jpg",
      "id" : 14085052,
      "verified" : false
    }
  },
  "id" : 238212922831151104,
  "created_at" : "Wed Aug 22 09:56:01 +0000 2012",
  "user" : {
    "name" : "Felix",
    "screen_name" : "nicidienase",
    "protected" : false,
    "id_str" : "22396883",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3125784966/8223a4c5c9535be22d15c82ec829c2df_normal.jpeg",
    "id" : 22396883,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "psy",
      "screen_name" : "psycon",
      "indices" : [ 0, 7 ],
      "id_str" : "87286054",
      "id" : 87286054
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "237959869074919424",
  "geo" : {
  },
  "id_str" : "237960979663695872",
  "in_reply_to_user_id" : 87286054,
  "text" : "@psycon Bin am Freitag wieder in KA. Mal wieder ein Besuch im Entropia?",
  "id" : 237960979663695872,
  "in_reply_to_status_id" : 237959869074919424,
  "created_at" : "Tue Aug 21 17:14:53 +0000 2012",
  "in_reply_to_screen_name" : "psycon",
  "in_reply_to_user_id_str" : "87286054",
  "user" : {
    "name" : "Felix",
    "screen_name" : "nicidienase",
    "protected" : false,
    "id_str" : "22396883",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3125784966/8223a4c5c9535be22d15c82ec829c2df_normal.jpeg",
    "id" : 22396883,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "psy",
      "screen_name" : "psycon",
      "indices" : [ 0, 7 ],
      "id_str" : "87286054",
      "id" : 87286054
    }, {
      "name" : "qchn",
      "screen_name" : "qchn_",
      "indices" : [ 23, 29 ],
      "id_str" : "74522279",
      "id" : 74522279
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "237957432079417344",
  "geo" : {
  },
  "id_str" : "237959291942875136",
  "in_reply_to_user_id" : 87286054,
  "text" : "@psycon also ich kenne @qchn_ vom sehen. Von GPN oder Camp.",
  "id" : 237959291942875136,
  "in_reply_to_status_id" : 237957432079417344,
  "created_at" : "Tue Aug 21 17:08:10 +0000 2012",
  "in_reply_to_screen_name" : "psycon",
  "in_reply_to_user_id_str" : "87286054",
  "user" : {
    "name" : "Felix",
    "screen_name" : "nicidienase",
    "protected" : false,
    "id_str" : "22396883",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3125784966/8223a4c5c9535be22d15c82ec829c2df_normal.jpeg",
    "id" : 22396883,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sebastian",
      "screen_name" : "muzzelchen",
      "indices" : [ 3, 14 ],
      "id_str" : "246717112",
      "id" : 246717112
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 16, 36 ],
      "url" : "http://t.co/mMJtgJVg",
      "expanded_url" : "http://bedbash.org",
      "display_url" : "bedbash.org"
    } ]
  },
  "geo" : {
  },
  "id_str" : "237540562272661505",
  "text" : "RT @muzzelchen: http://t.co/mMJtgJVg is working now - add your quote and laugh about what has been said in your bed! :)",
  "retweeted_status" : {
    "source" : "<a href=\"http://hotot.org\" rel=\"nofollow\">Hotot for Chrome</a>",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 0, 20 ],
        "url" : "http://t.co/mMJtgJVg",
        "expanded_url" : "http://bedbash.org",
        "display_url" : "bedbash.org"
      } ]
    },
    "geo" : {
    },
    "id_str" : "237516236026703872",
    "text" : "http://t.co/mMJtgJVg is working now - add your quote and laugh about what has been said in your bed! :)",
    "id" : 237516236026703872,
    "created_at" : "Mon Aug 20 11:47:38 +0000 2012",
    "user" : {
      "name" : "Sebastian",
      "screen_name" : "muzzelchen",
      "protected" : false,
      "id_str" : "246717112",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/2906451342/d3ba691b8726657b5955afe0076bf8da_normal.jpeg",
      "id" : 246717112,
      "verified" : false
    }
  },
  "id" : 237540562272661505,
  "created_at" : "Mon Aug 20 13:24:17 +0000 2012",
  "user" : {
    "name" : "Felix",
    "screen_name" : "nicidienase",
    "protected" : false,
    "id_str" : "22396883",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3125784966/8223a4c5c9535be22d15c82ec829c2df_normal.jpeg",
    "id" : 22396883,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "jennifer bendery",
      "screen_name" : "jbendery",
      "indices" : [ 3, 12 ],
      "id_str" : "15837659",
      "id" : 15837659
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 61, 81 ],
      "url" : "http://t.co/1Q5HPXCe",
      "expanded_url" : "http://twitter.com/jbendery/status/237261946666250240/photo/1",
      "display_url" : "pic.twitter.com/1Q5HPXCe"
    } ]
  },
  "geo" : {
  },
  "id_str" : "237505585241796609",
  "text" : "RT @jbendery: Check out this photo of Earth. FROM MARS. WOW. http://t.co/1Q5HPXCe",
  "retweeted_status" : {
    "source" : "web",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "http://twitter.com/jbendery/status/237261946666250240/photo/1",
        "indices" : [ 47, 67 ],
        "url" : "http://t.co/1Q5HPXCe",
        "media_url" : "http://pbs.twimg.com/media/A0rse8ICcAECUxa.jpg",
        "id_str" : "237261946670444545",
        "id" : 237261946670444545,
        "media_url_https" : "https://pbs.twimg.com/media/A0rse8ICcAECUxa.jpg",
        "sizes" : [ {
          "h" : 502,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 803,
          "resize" : "fit",
          "w" : 960
        }, {
          "h" : 284,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 803,
          "resize" : "fit",
          "w" : 960
        } ],
        "display_url" : "pic.twitter.com/1Q5HPXCe"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : {
    },
    "id_str" : "237261946666250240",
    "text" : "Check out this photo of Earth. FROM MARS. WOW. http://t.co/1Q5HPXCe",
    "id" : 237261946666250240,
    "created_at" : "Sun Aug 19 18:57:11 +0000 2012",
    "user" : {
      "name" : "jennifer bendery",
      "screen_name" : "jbendery",
      "protected" : false,
      "id_str" : "15837659",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/2610862419/4v17ciyg0erwx6uffdvw_normal.jpeg",
      "id" : 15837659,
      "verified" : false
    }
  },
  "id" : 237505585241796609,
  "created_at" : "Mon Aug 20 11:05:18 +0000 2012",
  "user" : {
    "name" : "Felix",
    "screen_name" : "nicidienase",
    "protected" : false,
    "id_str" : "22396883",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3125784966/8223a4c5c9535be22d15c82ec829c2df_normal.jpeg",
    "id" : 22396883,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http://twitter.com/nicidienase/status/236751306876940288/photo/1",
      "indices" : [ 25, 45 ],
      "url" : "http://t.co/U32789QJ",
      "media_url" : "http://pbs.twimg.com/media/A0kcDyrCcAEIgTX.jpg",
      "id_str" : "236751306881134593",
      "id" : 236751306881134593,
      "media_url_https" : "https://pbs.twimg.com/media/A0kcDyrCcAEIgTX.jpg",
      "sizes" : [ {
        "h" : 1365,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 2560,
        "resize" : "fit",
        "w" : 1920
      }, {
        "h" : 453,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 800,
        "resize" : "fit",
        "w" : 600
      } ],
      "display_url" : "pic.twitter.com/U32789QJ"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "236751306876940288",
  "text" : "Schnip Schnap, Haare ab! http://t.co/U32789QJ",
  "id" : 236751306876940288,
  "created_at" : "Sat Aug 18 09:08:06 +0000 2012",
  "user" : {
    "name" : "Felix",
    "screen_name" : "nicidienase",
    "protected" : false,
    "id_str" : "22396883",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3125784966/8223a4c5c9535be22d15c82ec829c2df_normal.jpeg",
    "id" : 22396883,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "236412815081091073",
  "text" : "Damn it! 20\u20AC \u00E4rmer. Das kommt davon wenn man lose Scheine in der gleichen Tasche hat wie sein Handy. Der gl\u00FCckliche Finder wird sich freuen.",
  "id" : 236412815081091073,
  "created_at" : "Fri Aug 17 10:43:02 +0000 2012",
  "user" : {
    "name" : "Felix",
    "screen_name" : "nicidienase",
    "protected" : false,
    "id_str" : "22396883",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3125784966/8223a4c5c9535be22d15c82ec829c2df_normal.jpeg",
    "id" : 22396883,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http://twitter.com/nicidienase/status/236156082265919488/photo/1",
      "indices" : [ 7, 27 ],
      "url" : "http://t.co/rmYW9ye4",
      "media_url" : "http://pbs.twimg.com/media/A0b-tKMCEAEQ87E.jpg",
      "id_str" : "236156082265919489",
      "id" : 236156082265919489,
      "media_url_https" : "https://pbs.twimg.com/media/A0b-tKMCEAEQ87E.jpg",
      "sizes" : [ {
        "h" : 450,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 1920,
        "resize" : "fit",
        "w" : 2560
      }, {
        "h" : 768,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 255,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com/rmYW9ye4"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "236156082265919488",
  "text" : "Mmmmmh http://t.co/rmYW9ye4",
  "id" : 236156082265919488,
  "created_at" : "Thu Aug 16 17:42:54 +0000 2012",
  "user" : {
    "name" : "Felix",
    "screen_name" : "nicidienase",
    "protected" : false,
    "id_str" : "22396883",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3125784966/8223a4c5c9535be22d15c82ec829c2df_normal.jpeg",
    "id" : 22396883,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Chris Bidmead",
      "screen_name" : "chbidmead",
      "indices" : [ 3, 13 ],
      "id_str" : "360450538",
      "id" : 360450538
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "236090783923593217",
  "text" : "RT @chbidmead: Julian Assange Look-Alike Contest, Equadorian Embassy tonight. Fab prizes: free trip to Equador for winner and three runn ...",
  "retweeted_status" : {
    "source" : "<a href=\"http://www.tweetcaster.com\" rel=\"nofollow\">TweetCaster for Android</a>",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : {
    },
    "id_str" : "236082774728118272",
    "text" : "Julian Assange Look-Alike Contest, Equadorian Embassy tonight. Fab prizes: free trip to Equador for winner and three runners-up.",
    "id" : 236082774728118272,
    "created_at" : "Thu Aug 16 12:51:34 +0000 2012",
    "user" : {
      "name" : "Chris Bidmead",
      "screen_name" : "chbidmead",
      "protected" : false,
      "id_str" : "360450538",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/1535582816/BidHatTwitter_normal.png",
      "id" : 360450538,
      "verified" : false
    }
  },
  "id" : 236090783923593217,
  "created_at" : "Thu Aug 16 13:23:23 +0000 2012",
  "user" : {
    "name" : "Felix",
    "screen_name" : "nicidienase",
    "protected" : false,
    "id_str" : "22396883",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3125784966/8223a4c5c9535be22d15c82ec829c2df_normal.jpeg",
    "id" : 22396883,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.echofon.com/\" rel=\"nofollow\">Echofon</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Der Postillon",
      "screen_name" : "Der_Postillon",
      "indices" : [ 3, 17 ],
      "id_str" : "105554801",
      "id" : 105554801
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "BER",
      "indices" : [ 111, 115 ]
    } ],
    "urls" : [ {
      "indices" : [ 116, 136 ],
      "url" : "http://t.co/zAgOf4yO",
      "expanded_url" : "http://bit.ly/MZyH5V",
      "display_url" : "bit.ly/MZyH5V"
    } ]
  },
  "geo" : {
  },
  "id_str" : "235711689880920064",
  "text" : "RT @Der_Postillon: Neue Zeitform Futur III eingef\u00FChrt, um Gespr\u00E4che \u00FCber Berliner Flughafen zu erm\u00F6glichen ... #BER http://t.co/zAgOf4yO",
  "retweeted_status" : {
    "source" : "web",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "BER",
        "indices" : [ 92, 96 ]
      } ],
      "urls" : [ {
        "indices" : [ 97, 117 ],
        "url" : "http://t.co/zAgOf4yO",
        "expanded_url" : "http://bit.ly/MZyH5V",
        "display_url" : "bit.ly/MZyH5V"
      } ]
    },
    "geo" : {
    },
    "id_str" : "235707310645837825",
    "text" : "Neue Zeitform Futur III eingef\u00FChrt, um Gespr\u00E4che \u00FCber Berliner Flughafen zu erm\u00F6glichen ... #BER http://t.co/zAgOf4yO",
    "id" : 235707310645837825,
    "created_at" : "Wed Aug 15 11:59:36 +0000 2012",
    "user" : {
      "name" : "Der Postillon",
      "screen_name" : "Der_Postillon",
      "protected" : false,
      "id_str" : "105554801",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/1274516114/Twitterpferd_normal.jpg",
      "id" : 105554801,
      "verified" : false
    }
  },
  "id" : 235711689880920064,
  "created_at" : "Wed Aug 15 12:17:00 +0000 2012",
  "user" : {
    "name" : "Felix",
    "screen_name" : "nicidienase",
    "protected" : false,
    "id_str" : "22396883",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3125784966/8223a4c5c9535be22d15c82ec829c2df_normal.jpeg",
    "id" : 22396883,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.echofon.com/\" rel=\"nofollow\">Echofon</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "AJ Kuftic",
      "screen_name" : "ajkuftic",
      "indices" : [ 3, 12 ],
      "id_str" : "126323249",
      "id" : 126323249
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "235702723604017152",
  "text" : "RT @ajkuftic: Dear IT Managers. Your staff does not need to be on site to patch servers. NASA just patched Curiosity on Mars. ON. MARS.",
  "retweeted_status" : {
    "source" : "<a href=\"http://tapbots.com/software/tweetbot/mac\" rel=\"nofollow\">Tweetbot for Mac</a>",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : {
    },
    "id_str" : "235526144978464769",
    "text" : "Dear IT Managers. Your staff does not need to be on site to patch servers. NASA just patched Curiosity on Mars. ON. MARS.",
    "id" : 235526144978464769,
    "created_at" : "Tue Aug 14 23:59:43 +0000 2012",
    "user" : {
      "name" : "AJ Kuftic",
      "screen_name" : "ajkuftic",
      "protected" : false,
      "id_str" : "126323249",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/2626919196/hbiw7rzazphpv5tvy2td_normal.png",
      "id" : 126323249,
      "verified" : false
    }
  },
  "id" : 235702723604017152,
  "created_at" : "Wed Aug 15 11:41:23 +0000 2012",
  "user" : {
    "name" : "Felix",
    "screen_name" : "nicidienase",
    "protected" : false,
    "id_str" : "22396883",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3125784966/8223a4c5c9535be22d15c82ec829c2df_normal.jpeg",
    "id" : 22396883,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.echofon.com/\" rel=\"nofollow\">Echofon</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Timo A. Hummel",
      "screen_name" : "_felicitus",
      "indices" : [ 3, 14 ],
      "id_str" : "107309554",
      "id" : 107309554
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 75, 95 ],
      "url" : "http://t.co/RDJEIzuo",
      "expanded_url" : "http://twitter.com/_felicitus/status/235371593763799041/photo/1",
      "display_url" : "pic.twitter.com/RDJEIzuo"
    } ]
  },
  "geo" : {
  },
  "id_str" : "235376227509223424",
  "text" : "RT @_felicitus: Wenn die Telekom scheisse baut, gibt's was von Ratiopharm. http://t.co/RDJEIzuo",
  "retweeted_status" : {
    "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "http://twitter.com/_felicitus/status/235371593763799041/photo/1",
        "indices" : [ 59, 79 ],
        "url" : "http://t.co/RDJEIzuo",
        "media_url" : "http://pbs.twimg.com/media/A0Q1N6zCQAAgyRm.jpg",
        "id_str" : "235371593767993344",
        "id" : 235371593767993344,
        "media_url_https" : "https://pbs.twimg.com/media/A0Q1N6zCQAAgyRm.jpg",
        "sizes" : [ {
          "h" : 765,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 254,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 448,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 1936,
          "resize" : "fit",
          "w" : 2592
        } ],
        "display_url" : "pic.twitter.com/RDJEIzuo"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : {
    },
    "id_str" : "235371593763799041",
    "text" : "Wenn die Telekom scheisse baut, gibt's was von Ratiopharm. http://t.co/RDJEIzuo",
    "id" : 235371593763799041,
    "created_at" : "Tue Aug 14 13:45:37 +0000 2012",
    "user" : {
      "name" : "Timo A. Hummel",
      "screen_name" : "_felicitus",
      "protected" : false,
      "id_str" : "107309554",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/1785069176/test2_normal.jpeg",
      "id" : 107309554,
      "verified" : false
    }
  },
  "id" : 235376227509223424,
  "created_at" : "Tue Aug 14 14:04:00 +0000 2012",
  "user" : {
    "name" : "Felix",
    "screen_name" : "nicidienase",
    "protected" : false,
    "id_str" : "22396883",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3125784966/8223a4c5c9535be22d15c82ec829c2df_normal.jpeg",
    "id" : 22396883,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.echofon.com/\" rel=\"nofollow\">Echofon</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Peter Glaser",
      "screen_name" : "peterglaser",
      "indices" : [ 3, 15 ],
      "id_str" : "67278209",
      "id" : 67278209
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "235364904293523457",
  "text" : "RT @peterglaser: Neulich bei den Wait Watchers: \"Ich hei\u00DFe Peter und prokrastiniere.\"",
  "retweeted_status" : {
    "source" : "web",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : {
    },
    "id_str" : "235337970142547968",
    "text" : "Neulich bei den Wait Watchers: \"Ich hei\u00DFe Peter und prokrastiniere.\"",
    "id" : 235337970142547968,
    "created_at" : "Tue Aug 14 11:31:59 +0000 2012",
    "user" : {
      "name" : "Peter Glaser",
      "screen_name" : "peterglaser",
      "protected" : false,
      "id_str" : "67278209",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/372004147/peterglaser_normal.jpg",
      "id" : 67278209,
      "verified" : false
    }
  },
  "id" : 235364904293523457,
  "created_at" : "Tue Aug 14 13:19:00 +0000 2012",
  "user" : {
    "name" : "Felix",
    "screen_name" : "nicidienase",
    "protected" : false,
    "id_str" : "22396883",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3125784966/8223a4c5c9535be22d15c82ec829c2df_normal.jpeg",
    "id" : 22396883,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.echofon.com/\" rel=\"nofollow\">Echofon</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Eva Eichhorn",
      "screen_name" : "MamsellChaos",
      "indices" : [ 3, 16 ],
      "id_str" : "140774041",
      "id" : 140774041
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 21, 41 ],
      "url" : "http://t.co/3YmCAZ29",
      "expanded_url" : "http://graafland.files.wordpress.com/2012/07/564015_10151003971984483_1138291757_n.jpg?w=500",
      "display_url" : "graafland.files.wordpress.com/2012/07/564015\u2026"
    } ]
  },
  "geo" : {
  },
  "id_str" : "235285725598339072",
  "text" : "RT @MamsellChaos: :) http://t.co/3YmCAZ29",
  "retweeted_status" : {
    "source" : "<a href=\"http://tapbots.com/software/tweetbot/mac\" rel=\"nofollow\">Tweetbot for Mac</a>",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 3, 23 ],
        "url" : "http://t.co/3YmCAZ29",
        "expanded_url" : "http://graafland.files.wordpress.com/2012/07/564015_10151003971984483_1138291757_n.jpg?w=500",
        "display_url" : "graafland.files.wordpress.com/2012/07/564015\u2026"
      } ]
    },
    "geo" : {
    },
    "id_str" : "235147928900096000",
    "text" : ":) http://t.co/3YmCAZ29",
    "id" : 235147928900096000,
    "created_at" : "Mon Aug 13 22:56:49 +0000 2012",
    "user" : {
      "name" : "Eva Eichhorn",
      "screen_name" : "MamsellChaos",
      "protected" : false,
      "id_str" : "140774041",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/3231510280/b59cd7b5771078fb646882e5e5882940_normal.jpeg",
      "id" : 140774041,
      "verified" : false
    }
  },
  "id" : 235285725598339072,
  "created_at" : "Tue Aug 14 08:04:23 +0000 2012",
  "user" : {
    "name" : "Felix",
    "screen_name" : "nicidienase",
    "protected" : false,
    "id_str" : "22396883",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3125784966/8223a4c5c9535be22d15c82ec829c2df_normal.jpeg",
    "id" : 22396883,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.echofon.com/\" rel=\"nofollow\">Echofon</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 22, 42 ],
      "url" : "http://t.co/s2PWMxLy",
      "expanded_url" : "http://hakim.se/experiments/html5/404/netmag.html",
      "display_url" : "hakim.se/experiments/ht\u2026"
    } ]
  },
  "geo" : {
  },
  "id_str" : "235285070091530240",
  "text" : "RT @NervengiftC: 404: http://t.co/s2PWMxLy",
  "retweeted_status" : {
    "source" : "<a href=\"http://hotot.org\" rel=\"nofollow\">Hotot</a>",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 5, 25 ],
        "url" : "http://t.co/s2PWMxLy",
        "expanded_url" : "http://hakim.se/experiments/html5/404/netmag.html",
        "display_url" : "hakim.se/experiments/ht\u2026"
      } ]
    },
    "geo" : {
    },
    "id_str" : "235135474442829826",
    "text" : "404: http://t.co/s2PWMxLy",
    "id" : 235135474442829826,
    "created_at" : "Mon Aug 13 22:07:20 +0000 2012",
    "user" : {
      "name" : "\u2623Das Nervengift",
      "screen_name" : "nervengiftlabs",
      "protected" : false,
      "id_str" : "121226933",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/969113240/6-563bee5733b3613c_normal.jpg",
      "id" : 121226933,
      "verified" : false
    }
  },
  "id" : 235285070091530240,
  "created_at" : "Tue Aug 14 08:01:46 +0000 2012",
  "user" : {
    "name" : "Felix",
    "screen_name" : "nicidienase",
    "protected" : false,
    "id_str" : "22396883",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3125784966/8223a4c5c9535be22d15c82ec829c2df_normal.jpeg",
    "id" : 22396883,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.echofon.com/\" rel=\"nofollow\">Echofon</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Timo A. Hummel",
      "screen_name" : "_felicitus",
      "indices" : [ 3, 14 ],
      "id_str" : "107309554",
      "id" : 107309554
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "234966287812534272",
  "text" : "RT @_felicitus: der Gott der Eisenwaren, er tr\u00E4gt einen gigantischen Schraubendreher: Thorx",
  "retweeted_status" : {
    "source" : "<a href=\"http://www.tweetdeck.com\" rel=\"nofollow\">TweetDeck</a>",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : {
    },
    "id_str" : "234955805911289857",
    "text" : "der Gott der Eisenwaren, er tr\u00E4gt einen gigantischen Schraubendreher: Thorx",
    "id" : 234955805911289857,
    "created_at" : "Mon Aug 13 10:13:24 +0000 2012",
    "user" : {
      "name" : "Timo A. Hummel",
      "screen_name" : "_felicitus",
      "protected" : false,
      "id_str" : "107309554",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/1785069176/test2_normal.jpeg",
      "id" : 107309554,
      "verified" : false
    }
  },
  "id" : 234966287812534272,
  "created_at" : "Mon Aug 13 10:55:03 +0000 2012",
  "user" : {
    "name" : "Felix",
    "screen_name" : "nicidienase",
    "protected" : false,
    "id_str" : "22396883",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3125784966/8223a4c5c9535be22d15c82ec829c2df_normal.jpeg",
    "id" : 22396883,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.echofon.com/\" rel=\"nofollow\">Echofon</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Terence Eden",
      "screen_name" : "edent",
      "indices" : [ 3, 9 ],
      "id_str" : "14054507",
      "id" : 14054507
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "234943788085293056",
  "text" : "RT @edent: Liven things up by substituting \"Cloud\" with \"Clown\".\n\n\"Our infrastructure runs on the clown\"\n\"I'm a clown expert\"\n\"This is c ...",
  "retweeted_status" : {
    "source" : "<a href=\"http://shkspr.mobi/blog/index.php/copyright-terence-eden/\" rel=\"nofollow\">\u00A9Terence Eden SomeRightsReserved</a>",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : {
    },
    "id_str" : "234937974154989568",
    "text" : "Liven things up by substituting \"Cloud\" with \"Clown\".\n\n\"Our infrastructure runs on the clown\"\n\"I'm a clown expert\"\n\"This is clown based\"",
    "id" : 234937974154989568,
    "created_at" : "Mon Aug 13 09:02:32 +0000 2012",
    "user" : {
      "name" : "Terence Eden",
      "screen_name" : "edent",
      "protected" : false,
      "id_str" : "14054507",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/2998429947/f949317e8881273375131028f76d142c_normal.jpeg",
      "id" : 14054507,
      "verified" : false
    }
  },
  "id" : 234943788085293056,
  "created_at" : "Mon Aug 13 09:25:38 +0000 2012",
  "user" : {
    "name" : "Felix",
    "screen_name" : "nicidienase",
    "protected" : false,
    "id_str" : "22396883",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3125784966/8223a4c5c9535be22d15c82ec829c2df_normal.jpeg",
    "id" : 22396883,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.echofon.com/\" rel=\"nofollow\">Echofon</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Rochus Wolff",
      "screen_name" : "rrho",
      "indices" : [ 3, 8 ],
      "id_str" : "3302401",
      "id" : 3302401
    }, {
      "name" : "Caspar C. Mierau",
      "screen_name" : "leitmedium",
      "indices" : [ 13, 24 ],
      "id_str" : "58569837",
      "id" : 58569837
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 78, 98 ],
      "url" : "http://t.co/doTs98XY",
      "expanded_url" : "http://golem.mobi/1208/93792.html",
      "display_url" : "golem.mobi/1208/93792.html"
    } ]
  },
  "geo" : {
  },
  "id_str" : "234915536092401664",
  "text" : "RT @rrho: RT @leitmedium: Erste Tiergattung \u00FCber Flickr-Zufallsfund entdeckt: http://t.co/doTs98XY",
  "retweeted_status" : {
    "source" : "<a href=\"http://www.tweetdeck.com\" rel=\"nofollow\">TweetDeck</a>",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Caspar C. Mierau",
        "screen_name" : "leitmedium",
        "indices" : [ 3, 14 ],
        "id_str" : "58569837",
        "id" : 58569837
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 68, 88 ],
        "url" : "http://t.co/doTs98XY",
        "expanded_url" : "http://golem.mobi/1208/93792.html",
        "display_url" : "golem.mobi/1208/93792.html"
      } ]
    },
    "geo" : {
    },
    "id_str" : "234907458492043265",
    "text" : "RT @leitmedium: Erste Tiergattung \u00FCber Flickr-Zufallsfund entdeckt: http://t.co/doTs98XY",
    "id" : 234907458492043265,
    "created_at" : "Mon Aug 13 07:01:17 +0000 2012",
    "user" : {
      "name" : "Rochus Wolff",
      "screen_name" : "rrho",
      "protected" : false,
      "id_str" : "3302401",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/52597680/selbstikonisch24_normal.gif",
      "id" : 3302401,
      "verified" : false
    }
  },
  "id" : 234915536092401664,
  "created_at" : "Mon Aug 13 07:33:22 +0000 2012",
  "user" : {
    "name" : "Felix",
    "screen_name" : "nicidienase",
    "protected" : false,
    "id_str" : "22396883",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3125784966/8223a4c5c9535be22d15c82ec829c2df_normal.jpeg",
    "id" : 22396883,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.echofon.com/\" rel=\"nofollow\">Echofon</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Hannah",
      "screen_name" : "aHeadwork",
      "indices" : [ 3, 13 ],
      "id_str" : "20561270",
      "id" : 20561270
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 91, 111 ],
      "url" : "http://t.co/5SuyoG0A",
      "expanded_url" : "http://flpbd.it/GZzou",
      "display_url" : "flpbd.it/GZzou"
    } ]
  },
  "geo" : {
  },
  "id_str" : "234915289412816896",
  "text" : "RT @aHeadwork: Hier ist ein See rot geworden und an den Pflanzen wachsen Kristalle! Srsly! http://t.co/5SuyoG0A",
  "retweeted_status" : {
    "source" : "<a href=\"http://www.flipboard.com\" rel=\"nofollow\">Flipboard</a>",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 76, 96 ],
        "url" : "http://t.co/5SuyoG0A",
        "expanded_url" : "http://flpbd.it/GZzou",
        "display_url" : "flpbd.it/GZzou"
      } ]
    },
    "geo" : {
    },
    "id_str" : "234902496202592256",
    "text" : "Hier ist ein See rot geworden und an den Pflanzen wachsen Kristalle! Srsly! http://t.co/5SuyoG0A",
    "id" : 234902496202592256,
    "created_at" : "Mon Aug 13 06:41:34 +0000 2012",
    "user" : {
      "name" : "Hannah",
      "screen_name" : "aHeadwork",
      "protected" : false,
      "id_str" : "20561270",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/3226200594/9147e56c8c30ed605aa1a3c84091721b_normal.jpeg",
      "id" : 20561270,
      "verified" : false
    }
  },
  "id" : 234915289412816896,
  "created_at" : "Mon Aug 13 07:32:24 +0000 2012",
  "user" : {
    "name" : "Felix",
    "screen_name" : "nicidienase",
    "protected" : false,
    "id_str" : "22396883",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3125784966/8223a4c5c9535be22d15c82ec829c2df_normal.jpeg",
    "id" : 22396883,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.echofon.com/\" rel=\"nofollow\">Echofon</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "234914564116975616",
  "text" : "Habeo Thinkpad! \\o/ \\o/",
  "id" : 234914564116975616,
  "created_at" : "Mon Aug 13 07:29:31 +0000 2012",
  "user" : {
    "name" : "Felix",
    "screen_name" : "nicidienase",
    "protected" : false,
    "id_str" : "22396883",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3125784966/8223a4c5c9535be22d15c82ec829c2df_normal.jpeg",
    "id" : 22396883,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Curiosity Rover",
      "screen_name" : "MarsCuriosity",
      "indices" : [ 3, 17 ],
      "id_str" : "15473958",
      "id" : 15473958
    }, {
      "name" : "MythBusters Official",
      "screen_name" : "MythBusters",
      "indices" : [ 19, 31 ],
      "id_str" : "52146755",
      "id" : 52146755
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "DareMightyThings",
      "indices" : [ 41, 58 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "234584950790307840",
  "text" : "RT @MarsCuriosity: @MythBusters When you #DareMightyThings, you learn, go back to drawing board, try again. Seen my early parachute test ...",
  "retweeted_status" : {
    "source" : "<a href=\"http://itunes.apple.com/us/app/twitter/id409789998?mt=12\" rel=\"nofollow\">Twitter for Mac</a>",
    "entities" : {
      "user_mentions" : [ {
        "name" : "MythBusters Official",
        "screen_name" : "MythBusters",
        "indices" : [ 0, 12 ],
        "id_str" : "52146755",
        "id" : 52146755
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "DareMightyThings",
        "indices" : [ 22, 39 ]
      } ],
      "urls" : [ {
        "indices" : [ 120, 140 ],
        "url" : "http://t.co/oKS6YrHa",
        "expanded_url" : "http://bit.ly/PMaSc3",
        "display_url" : "bit.ly/PMaSc3"
      } ]
    },
    "in_reply_to_status_id_str" : "234288141459132417",
    "geo" : {
    },
    "id_str" : "234325620019040256",
    "in_reply_to_user_id" : 52146755,
    "text" : "@MythBusters When you #DareMightyThings, you learn, go back to drawing board, try again. Seen my early parachute tests? http://t.co/oKS6YrHa",
    "id" : 234325620019040256,
    "in_reply_to_status_id" : 234288141459132417,
    "created_at" : "Sat Aug 11 16:29:16 +0000 2012",
    "in_reply_to_screen_name" : "MythBusters",
    "in_reply_to_user_id_str" : "52146755",
    "user" : {
      "name" : "Curiosity Rover",
      "screen_name" : "MarsCuriosity",
      "protected" : false,
      "id_str" : "15473958",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/2793288186/43e756fd0434d6ad43a8364b0e777239_normal.jpeg",
      "id" : 15473958,
      "verified" : true
    }
  },
  "id" : 234584950790307840,
  "created_at" : "Sun Aug 12 09:39:45 +0000 2012",
  "user" : {
    "name" : "Felix",
    "screen_name" : "nicidienase",
    "protected" : false,
    "id_str" : "22396883",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3125784966/8223a4c5c9535be22d15c82ec829c2df_normal.jpeg",
    "id" : 22396883,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.echofon.com/\" rel=\"nofollow\">Echofon</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 114, 134 ],
      "url" : "http://t.co/prXk6UaW",
      "expanded_url" : "http://what-if.xkcd.com/6/",
      "display_url" : "what-if.xkcd.com/6/"
    } ]
  },
  "geo" : {
  },
  "id_str" : "234574504792313857",
  "text" : "If the optimist says the glass is half full, and the pessimist says the glass is half empty, the physicist ducks. http://t.co/prXk6UaW",
  "id" : 234574504792313857,
  "created_at" : "Sun Aug 12 08:58:14 +0000 2012",
  "user" : {
    "name" : "Felix",
    "screen_name" : "nicidienase",
    "protected" : false,
    "id_str" : "22396883",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3125784966/8223a4c5c9535be22d15c82ec829c2df_normal.jpeg",
    "id" : 22396883,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Andreas J\u00E4gle",
      "screen_name" : "ajaegle",
      "indices" : [ 0, 8 ],
      "id_str" : "78735610",
      "id" : 78735610
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "234072573158236161",
  "geo" : {
  },
  "id_str" : "234073209098629121",
  "in_reply_to_user_id" : 78735610,
  "text" : "@ajaegle Mission accomplished!",
  "id" : 234073209098629121,
  "in_reply_to_status_id" : 234072573158236161,
  "created_at" : "Fri Aug 10 23:46:16 +0000 2012",
  "in_reply_to_screen_name" : "ajaegle",
  "in_reply_to_user_id_str" : "78735610",
  "user" : {
    "name" : "Felix",
    "screen_name" : "nicidienase",
    "protected" : false,
    "id_str" : "22396883",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3125784966/8223a4c5c9535be22d15c82ec829c2df_normal.jpeg",
    "id" : 22396883,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "cluetec GmbH",
      "screen_name" : "cluetec",
      "indices" : [ 46, 54 ],
      "id_str" : "357348558",
      "id" : 357348558
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "betriebsausflug",
      "indices" : [ 55, 71 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "233894890432520193",
  "text" : "Zweiten Cache gefunden, jetzt schnell zur\u00FCck. @cluetec #betriebsausflug",
  "id" : 233894890432520193,
  "created_at" : "Fri Aug 10 11:57:42 +0000 2012",
  "user" : {
    "name" : "Felix",
    "screen_name" : "nicidienase",
    "protected" : false,
    "id_str" : "22396883",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3125784966/8223a4c5c9535be22d15c82ec829c2df_normal.jpeg",
    "id" : 22396883,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.echofon.com/\" rel=\"nofollow\">Echofon</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "MythBusters Official",
      "screen_name" : "MythBusters",
      "indices" : [ 3, 15 ],
      "id_str" : "52146755",
      "id" : 52146755
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 75, 95 ],
      "url" : "http://t.co/SFblW7a0",
      "expanded_url" : "http://bit.ly/RuvOsw",
      "display_url" : "bit.ly/RuvOsw"
    } ]
  },
  "geo" : {
  },
  "id_str" : "233830316983332864",
  "text" : "RT @MythBusters: An alien invasion... on Mars. Check out these cool photos http://t.co/SFblW7a0",
  "retweeted_status" : {
    "source" : "<a href=\"http://www.hootsuite.com\" rel=\"nofollow\">HootSuite</a>",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 58, 78 ],
        "url" : "http://t.co/SFblW7a0",
        "expanded_url" : "http://bit.ly/RuvOsw",
        "display_url" : "bit.ly/RuvOsw"
      } ]
    },
    "geo" : {
    },
    "id_str" : "233729404646326272",
    "text" : "An alien invasion... on Mars. Check out these cool photos http://t.co/SFblW7a0",
    "id" : 233729404646326272,
    "created_at" : "Fri Aug 10 01:00:07 +0000 2012",
    "user" : {
      "name" : "MythBusters Official",
      "screen_name" : "MythBusters",
      "protected" : false,
      "id_str" : "52146755",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/3498697267/c53f617226a22f52774bfb4ddedeb21c_normal.jpeg",
      "id" : 52146755,
      "verified" : true
    }
  },
  "id" : 233830316983332864,
  "created_at" : "Fri Aug 10 07:41:06 +0000 2012",
  "user" : {
    "name" : "Felix",
    "screen_name" : "nicidienase",
    "protected" : false,
    "id_str" : "22396883",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3125784966/8223a4c5c9535be22d15c82ec829c2df_normal.jpeg",
    "id" : 22396883,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.echofon.com/\" rel=\"nofollow\">Echofon</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ikseno",
      "screen_name" : "ikseno",
      "indices" : [ 3, 10 ],
      "id_str" : "131848372",
      "id" : 131848372
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 20, 40 ],
      "url" : "http://t.co/L7XdubWi",
      "expanded_url" : "http://bundestag.github.com/gesetze",
      "display_url" : "bundestag.github.com/gesetze"
    } ]
  },
  "geo" : {
  },
  "id_str" : "233568052606808064",
  "text" : "RT @ikseno: curl -L http://t.co/L7XdubWi | sed -e 's/Bundes/Schlumpf/g' -e 's/bundes/schlumpf/g'",
  "retweeted_status" : {
    "source" : "web",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 8, 28 ],
        "url" : "http://t.co/L7XdubWi",
        "expanded_url" : "http://bundestag.github.com/gesetze",
        "display_url" : "bundestag.github.com/gesetze"
      } ]
    },
    "geo" : {
    },
    "id_str" : "233521824007348224",
    "text" : "curl -L http://t.co/L7XdubWi | sed -e 's/Bundes/Schlumpf/g' -e 's/bundes/schlumpf/g'",
    "id" : 233521824007348224,
    "created_at" : "Thu Aug 09 11:15:16 +0000 2012",
    "user" : {
      "name" : "Ikseno",
      "screen_name" : "ikseno",
      "protected" : false,
      "id_str" : "131848372",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/814473649/twitternuke_normal.png",
      "id" : 131848372,
      "verified" : false
    }
  },
  "id" : 233568052606808064,
  "created_at" : "Thu Aug 09 14:18:57 +0000 2012",
  "user" : {
    "name" : "Felix",
    "screen_name" : "nicidienase",
    "protected" : false,
    "id_str" : "22396883",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3125784966/8223a4c5c9535be22d15c82ec829c2df_normal.jpeg",
    "id" : 22396883,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.echofon.com/\" rel=\"nofollow\">Echofon</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "maltejk",
      "screen_name" : "maltejk",
      "indices" : [ 3, 11 ],
      "id_str" : "66683044",
      "id" : 66683044
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 43, 63 ],
      "url" : "http://t.co/rjG9rGjf",
      "expanded_url" : "http://instagr.am/p/OGnGxXw9w0/",
      "display_url" : "instagr.am/p/OGnGxXw9w0/"
    } ]
  },
  "geo" : {
  },
  "id_str" : "233521763449978882",
  "text" : "RT @maltejk: Anonymous - powered by Saturn http://t.co/rjG9rGjf",
  "retweeted_status" : {
    "source" : "<a href=\"http://instagram.com\" rel=\"nofollow\">Instagram</a>",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 30, 50 ],
        "url" : "http://t.co/rjG9rGjf",
        "expanded_url" : "http://instagr.am/p/OGnGxXw9w0/",
        "display_url" : "instagr.am/p/OGnGxXw9w0/"
      } ]
    },
    "geo" : {
    },
    "id_str" : "233504543151910912",
    "text" : "Anonymous - powered by Saturn http://t.co/rjG9rGjf",
    "id" : 233504543151910912,
    "created_at" : "Thu Aug 09 10:06:36 +0000 2012",
    "user" : {
      "name" : "maltejk",
      "screen_name" : "maltejk",
      "protected" : false,
      "id_str" : "66683044",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/1756449114/epic_twitter_kittah_by_dino_kleinerdrei_normal.png",
      "id" : 66683044,
      "verified" : false
    }
  },
  "id" : 233521763449978882,
  "created_at" : "Thu Aug 09 11:15:01 +0000 2012",
  "user" : {
    "name" : "Felix",
    "screen_name" : "nicidienase",
    "protected" : false,
    "id_str" : "22396883",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3125784966/8223a4c5c9535be22d15c82ec829c2df_normal.jpeg",
    "id" : 22396883,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.echofon.com/\" rel=\"nofollow\">Echofon</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Carlo Zottmann",
      "screen_name" : "municode",
      "indices" : [ 3, 12 ],
      "id_str" : "63893",
      "id" : 63893
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 54, 75 ],
      "url" : "https://t.co/YdH0d9rb",
      "expanded_url" : "https://lh5.googleusercontent.com/-h7VmGh6dYIc/UCNucNgNbfI/AAAAAAAAFH0/yg1tNtV8fyM/s949/curio.jpg",
      "display_url" : "lh5.googleusercontent.com/-h7VmGh6dYIc/U\u2026"
    } ]
  },
  "geo" : {
  },
  "id_str" : "233495438043537408",
  "text" : "RT @municode: Curiosity re-imagined: Can't be unseen. https://t.co/YdH0d9rb",
  "retweeted_status" : {
    "source" : "<a href=\"http://www.echofon.com/\" rel=\"nofollow\">Echofon</a>",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 40, 61 ],
        "url" : "https://t.co/YdH0d9rb",
        "expanded_url" : "https://lh5.googleusercontent.com/-h7VmGh6dYIc/UCNucNgNbfI/AAAAAAAAFH0/yg1tNtV8fyM/s949/curio.jpg",
        "display_url" : "lh5.googleusercontent.com/-h7VmGh6dYIc/U\u2026"
      } ]
    },
    "geo" : {
    },
    "id_str" : "233483011520339968",
    "text" : "Curiosity re-imagined: Can't be unseen. https://t.co/YdH0d9rb",
    "id" : 233483011520339968,
    "created_at" : "Thu Aug 09 08:41:02 +0000 2012",
    "user" : {
      "name" : "Carlo Zottmann",
      "screen_name" : "municode",
      "protected" : false,
      "id_str" : "63893",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/2939498690/dda7d075c81dbb5f943853d5b8cab292_normal.png",
      "id" : 63893,
      "verified" : false
    }
  },
  "id" : 233495438043537408,
  "created_at" : "Thu Aug 09 09:30:25 +0000 2012",
  "user" : {
    "name" : "Felix",
    "screen_name" : "nicidienase",
    "protected" : false,
    "id_str" : "22396883",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3125784966/8223a4c5c9535be22d15c82ec829c2df_normal.jpeg",
    "id" : 22396883,
    "verified" : false
  }
}, {
  "source" : "<a href=\"https://play.google.com/store/apps/details?id=org.mariotaku.twidere\" rel=\"nofollow\">Twidere for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "cluetec GmbH",
      "screen_name" : "cluetec",
      "indices" : [ 21, 29 ],
      "id_str" : "357348558",
      "id" : 357348558
    } ],
    "media" : [ {
      "expanded_url" : "http://twitter.com/nicidienase/status/233464223081058305/photo/1",
      "indices" : [ 30, 50 ],
      "url" : "http://t.co/47wUa0dW",
      "media_url" : "http://pbs.twimg.com/media/Az1ueVTCUAAEClQ.jpg",
      "id_str" : "233464223085252608",
      "id" : 233464223085252608,
      "media_url_https" : "https://pbs.twimg.com/media/Az1ueVTCUAAEClQ.jpg",
      "sizes" : [ {
        "h" : 450,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 1920,
        "resize" : "fit",
        "w" : 2560
      }, {
        "h" : 768,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 255,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com/47wUa0dW"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "233464223081058305",
  "text" : "Awesome Cluetec-Cake @cluetec http://t.co/47wUa0dW",
  "id" : 233464223081058305,
  "created_at" : "Thu Aug 09 07:26:24 +0000 2012",
  "user" : {
    "name" : "Felix",
    "screen_name" : "nicidienase",
    "protected" : false,
    "id_str" : "22396883",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3125784966/8223a4c5c9535be22d15c82ec829c2df_normal.jpeg",
    "id" : 22396883,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.echofon.com/\" rel=\"nofollow\">Echofon</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Command Line Magic",
      "screen_name" : "climagic",
      "indices" : [ 3, 12 ],
      "id_str" : "91333167",
      "id" : 91333167
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "233209073942798336",
  "text" : "RT @climagic: And before you think of running cd $OLDPWD. You can just do 'cd -' instead to get to the previous directory you were in.",
  "retweeted_status" : {
    "source" : "<a href=\"http://suso.suso.org/xulu/Command_Line_Magic\" rel=\"nofollow\">CLI Magic poster</a>",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : {
    },
    "id_str" : "233208396617228289",
    "text" : "And before you think of running cd $OLDPWD. You can just do 'cd -' instead to get to the previous directory you were in.",
    "id" : 233208396617228289,
    "created_at" : "Wed Aug 08 14:29:49 +0000 2012",
    "user" : {
      "name" : "Command Line Magic",
      "screen_name" : "climagic",
      "protected" : false,
      "id_str" : "91333167",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/535876218/climagic-icon_normal.png",
      "id" : 91333167,
      "verified" : false
    }
  },
  "id" : 233209073942798336,
  "created_at" : "Wed Aug 08 14:32:30 +0000 2012",
  "user" : {
    "name" : "Felix",
    "screen_name" : "nicidienase",
    "protected" : false,
    "id_str" : "22396883",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3125784966/8223a4c5c9535be22d15c82ec829c2df_normal.jpeg",
    "id" : 22396883,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.echofon.com/\" rel=\"nofollow\">Echofon</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Timm",
      "screen_name" : "Endzeitkind",
      "indices" : [ 3, 15 ],
      "id_str" : "281440648",
      "id" : 281440648
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 75, 95 ],
      "url" : "http://t.co/MW9qVYqd",
      "expanded_url" : "http://i.imgur.com/tlEV9.jpg",
      "display_url" : "i.imgur.com/tlEV9.jpg"
    } ]
  },
  "geo" : {
  },
  "id_str" : "233195318622183424",
  "text" : "RT @Endzeitkind: My sister fell asleep while she was reading a magazine... http://t.co/MW9qVYqd",
  "retweeted_status" : {
    "source" : "<a href=\"http://www.apple.com\" rel=\"nofollow\">iOS</a>",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 58, 78 ],
        "url" : "http://t.co/MW9qVYqd",
        "expanded_url" : "http://i.imgur.com/tlEV9.jpg",
        "display_url" : "i.imgur.com/tlEV9.jpg"
      } ]
    },
    "geo" : {
    },
    "id_str" : "233185060117950464",
    "text" : "My sister fell asleep while she was reading a magazine... http://t.co/MW9qVYqd",
    "id" : 233185060117950464,
    "created_at" : "Wed Aug 08 12:57:05 +0000 2012",
    "user" : {
      "name" : "Timm",
      "screen_name" : "Endzeitkind",
      "protected" : false,
      "id_str" : "281440648",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/3440573242/b7ee987343da7fae1f2fc235983cb367_normal.jpeg",
      "id" : 281440648,
      "verified" : false
    }
  },
  "id" : 233195318622183424,
  "created_at" : "Wed Aug 08 13:37:51 +0000 2012",
  "user" : {
    "name" : "Felix",
    "screen_name" : "nicidienase",
    "protected" : false,
    "id_str" : "22396883",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3125784966/8223a4c5c9535be22d15c82ec829c2df_normal.jpeg",
    "id" : 22396883,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.echofon.com/\" rel=\"nofollow\">Echofon</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Not Safe For Work",
      "screen_name" : "me_nsfw",
      "indices" : [ 61, 69 ],
      "id_str" : "198895800",
      "id" : 198895800
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "232951104219000833",
  "geo" : {
  },
  "id_str" : "232953299974885376",
  "in_reply_to_user_id" : 198895800,
  "text" : "Arrrg, jetzt wo ich so langsam schlafen sollte geht die neue @me_nsfw online",
  "id" : 232953299974885376,
  "in_reply_to_status_id" : 232951104219000833,
  "created_at" : "Tue Aug 07 21:36:09 +0000 2012",
  "in_reply_to_screen_name" : "me_nsfw",
  "in_reply_to_user_id_str" : "198895800",
  "user" : {
    "name" : "Felix",
    "screen_name" : "nicidienase",
    "protected" : false,
    "id_str" : "22396883",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3125784966/8223a4c5c9535be22d15c82ec829c2df_normal.jpeg",
    "id" : 22396883,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.echofon.com/\" rel=\"nofollow\">Echofon</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Metaebene",
      "screen_name" : "metaebene",
      "indices" : [ 0, 10 ],
      "id_str" : "188055655",
      "id" : 188055655
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "232924991061114881",
  "geo" : {
  },
  "id_str" : "232925307039010816",
  "in_reply_to_user_id" : 188055655,
  "text" : "@metaebene Yeay!!",
  "id" : 232925307039010816,
  "in_reply_to_status_id" : 232924991061114881,
  "created_at" : "Tue Aug 07 19:44:55 +0000 2012",
  "in_reply_to_screen_name" : "metaebene",
  "in_reply_to_user_id_str" : "188055655",
  "user" : {
    "name" : "Felix",
    "screen_name" : "nicidienase",
    "protected" : false,
    "id_str" : "22396883",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3125784966/8223a4c5c9535be22d15c82ec829c2df_normal.jpeg",
    "id" : 22396883,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.echofon.com/\" rel=\"nofollow\">Echofon</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tim Pritlove",
      "screen_name" : "timpritlove",
      "indices" : [ 0, 12 ],
      "id_str" : "11268812",
      "id" : 11268812
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "232909493036539904",
  "geo" : {
  },
  "id_str" : "232910921956220929",
  "in_reply_to_user_id" : 11268812,
  "text" : "@timpritlove GIbts ne Prognose wann das sein k\u00F6nnte?",
  "id" : 232910921956220929,
  "in_reply_to_status_id" : 232909493036539904,
  "created_at" : "Tue Aug 07 18:47:45 +0000 2012",
  "in_reply_to_screen_name" : "timpritlove",
  "in_reply_to_user_id_str" : "11268812",
  "user" : {
    "name" : "Felix",
    "screen_name" : "nicidienase",
    "protected" : false,
    "id_str" : "22396883",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3125784966/8223a4c5c9535be22d15c82ec829c2df_normal.jpeg",
    "id" : 22396883,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.echofon.com/\" rel=\"nofollow\">Echofon</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tim Pritlove",
      "screen_name" : "timpritlove",
      "indices" : [ 0, 12 ],
      "id_str" : "11268812",
      "id" : 11268812
    }, {
      "name" : "Metaebene",
      "screen_name" : "metaebene",
      "indices" : [ 13, 23 ],
      "id_str" : "188055655",
      "id" : 188055655
    }, {
      "name" : "Not Safe For Work",
      "screen_name" : "me_nsfw",
      "indices" : [ 43, 51 ],
      "id_str" : "198895800",
      "id" : 198895800
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "232855177093345280",
  "in_reply_to_user_id" : 11268812,
  "text" : "@timpritlove @metaebene Was is den mit dem @me_nsfw von gestern? Gibts das erst wenn der Downloadserver wieder l\u00E4uft?",
  "id" : 232855177093345280,
  "created_at" : "Tue Aug 07 15:06:15 +0000 2012",
  "in_reply_to_screen_name" : "timpritlove",
  "in_reply_to_user_id_str" : "11268812",
  "user" : {
    "name" : "Felix",
    "screen_name" : "nicidienase",
    "protected" : false,
    "id_str" : "22396883",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3125784966/8223a4c5c9535be22d15c82ec829c2df_normal.jpeg",
    "id" : 22396883,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.echofon.com/\" rel=\"nofollow\">Echofon</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "nico",
      "screen_name" : "nicoduck",
      "indices" : [ 3, 12 ],
      "id_str" : "9460032",
      "id" : 9460032
    }, {
      "name" : "A Googler",
      "screen_name" : "google",
      "indices" : [ 28, 35 ],
      "id_str" : "20536157",
      "id" : 20536157
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "232852078194720768",
  "text" : "RT @nicoduck: Tomorrow as a @google doodle: Landing a rover on mars :-)",
  "retweeted_status" : {
    "source" : "web",
    "entities" : {
      "user_mentions" : [ {
        "name" : "A Googler",
        "screen_name" : "google",
        "indices" : [ 14, 21 ],
        "id_str" : "20536157",
        "id" : 20536157
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : {
    },
    "id_str" : "232773845675823104",
    "text" : "Tomorrow as a @google doodle: Landing a rover on mars :-)",
    "id" : 232773845675823104,
    "created_at" : "Tue Aug 07 09:43:04 +0000 2012",
    "user" : {
      "name" : "nico",
      "screen_name" : "nicoduck",
      "protected" : false,
      "id_str" : "9460032",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/422373835/ich_normal.jpg",
      "id" : 9460032,
      "verified" : false
    }
  },
  "id" : 232852078194720768,
  "created_at" : "Tue Aug 07 14:53:56 +0000 2012",
  "user" : {
    "name" : "Felix",
    "screen_name" : "nicidienase",
    "protected" : false,
    "id_str" : "22396883",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3125784966/8223a4c5c9535be22d15c82ec829c2df_normal.jpeg",
    "id" : 22396883,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.echofon.com/\" rel=\"nofollow\">Echofon</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Christian Munthe",
      "screen_name" : "christianmunthe",
      "indices" : [ 3, 19 ],
      "id_str" : "94352635",
      "id" : 94352635
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "232833916673880064",
  "text" : "RT @christianmunthe: Newborn baby gorilla at Melbourne Zoo gets a checkup at the hospital and reacts to the coldness of the stethoscope  ...",
  "retweeted_status" : {
    "source" : "web",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "http://twitter.com/christianmunthe/status/232782214906134528/photo/1",
        "indices" : [ 115, 135 ],
        "url" : "http://t.co/Fk8H7PRh",
        "media_url" : "http://pbs.twimg.com/media/AzsCMO3CQAAEySM.jpg",
        "id_str" : "232782214910328832",
        "id" : 232782214910328832,
        "media_url_https" : "https://pbs.twimg.com/media/AzsCMO3CQAAEySM.jpg",
        "sizes" : [ {
          "h" : 273,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 412,
          "resize" : "fit",
          "w" : 514
        }, {
          "h" : 412,
          "resize" : "fit",
          "w" : 514
        }, {
          "h" : 412,
          "resize" : "fit",
          "w" : 514
        } ],
        "display_url" : "pic.twitter.com/Fk8H7PRh"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : {
    },
    "id_str" : "232782214906134528",
    "text" : "Newborn baby gorilla at Melbourne Zoo gets a checkup at the hospital and reacts to the coldness of the stethoscope http://t.co/Fk8H7PRh",
    "id" : 232782214906134528,
    "created_at" : "Tue Aug 07 10:16:20 +0000 2012",
    "user" : {
      "name" : "Christian Munthe",
      "screen_name" : "christianmunthe",
      "protected" : false,
      "id_str" : "94352635",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/1537288468/large_christian.munthe_normal.jpg",
      "id" : 94352635,
      "verified" : false
    }
  },
  "id" : 232833916673880064,
  "created_at" : "Tue Aug 07 13:41:46 +0000 2012",
  "user" : {
    "name" : "Felix",
    "screen_name" : "nicidienase",
    "protected" : false,
    "id_str" : "22396883",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3125784966/8223a4c5c9535be22d15c82ec829c2df_normal.jpeg",
    "id" : 22396883,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.echofon.com/\" rel=\"nofollow\">Echofon</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Katrin Zinoun",
      "screen_name" : "dialogtexte",
      "indices" : [ 3, 15 ],
      "id_str" : "80647339",
      "id" : 80647339
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "232739484951789568",
  "text" : "RT @dialogtexte: Eines der \u00E4rmsten D\u00F6rfer Zentralamerikas bietet Einwohnern freies Wi-Fi und erkl\u00E4rt Internetzugang zum Menschenrecht ht ...",
  "retweeted_status" : {
    "source" : "<a href=\"http://www.tweetdeck.com\" rel=\"nofollow\">TweetDeck</a>",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 117, 137 ],
        "url" : "http://t.co/fNH9CDDH",
        "expanded_url" : "http://bit.ly/Q5sboN",
        "display_url" : "bit.ly/Q5sboN"
      } ]
    },
    "geo" : {
    },
    "id_str" : "232729342373933056",
    "text" : "Eines der \u00E4rmsten D\u00F6rfer Zentralamerikas bietet Einwohnern freies Wi-Fi und erkl\u00E4rt Internetzugang zum Menschenrecht http://t.co/fNH9CDDH",
    "id" : 232729342373933056,
    "created_at" : "Tue Aug 07 06:46:13 +0000 2012",
    "user" : {
      "name" : "Katrin Zinoun",
      "screen_name" : "dialogtexte",
      "protected" : false,
      "id_str" : "80647339",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/1986179931/logotoplefthell_normal.jpg",
      "id" : 80647339,
      "verified" : false
    }
  },
  "id" : 232739484951789568,
  "created_at" : "Tue Aug 07 07:26:31 +0000 2012",
  "user" : {
    "name" : "Felix",
    "screen_name" : "nicidienase",
    "protected" : false,
    "id_str" : "22396883",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3125784966/8223a4c5c9535be22d15c82ec829c2df_normal.jpeg",
    "id" : 22396883,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.echofon.com/\" rel=\"nofollow\">Echofon</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "David Calkins",
      "screen_name" : "Mister_Robotics",
      "indices" : [ 3, 19 ],
      "id_str" : "14135993",
      "id" : 14135993
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "232734107539476480",
  "text" : "RT @Mister_Robotics: Putting a robot on Mars: $2.5 billion. TSA budget 2012: $7.85 billion. And the robot works.",
  "retweeted_status" : {
    "source" : "web",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : {
    },
    "id_str" : "232551993137319937",
    "text" : "Putting a robot on Mars: $2.5 billion. TSA budget 2012: $7.85 billion. And the robot works.",
    "id" : 232551993137319937,
    "created_at" : "Mon Aug 06 19:01:30 +0000 2012",
    "user" : {
      "name" : "David Calkins",
      "screen_name" : "Mister_Robotics",
      "protected" : false,
      "id_str" : "14135993",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/51756738/dc2_normal.jpg",
      "id" : 14135993,
      "verified" : false
    }
  },
  "id" : 232734107539476480,
  "created_at" : "Tue Aug 07 07:05:09 +0000 2012",
  "user" : {
    "name" : "Felix",
    "screen_name" : "nicidienase",
    "protected" : false,
    "id_str" : "22396883",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3125784966/8223a4c5c9535be22d15c82ec829c2df_normal.jpeg",
    "id" : 22396883,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.echofon.com/\" rel=\"nofollow\">Echofon</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Su-Shee",
      "screen_name" : "sheeshee",
      "indices" : [ 3, 12 ],
      "id_str" : "16009329",
      "id" : 16009329
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 49, 69 ],
      "url" : "http://t.co/ftJL0Txn",
      "expanded_url" : "http://baconipsum.com/",
      "display_url" : "baconipsum.com"
    } ]
  },
  "geo" : {
  },
  "id_str" : "232481478972420097",
  "text" : "RT @sheeshee: _Everything_ is better with bacon: http://t.co/ftJL0Txn",
  "retweeted_status" : {
    "source" : "web",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 35, 55 ],
        "url" : "http://t.co/ftJL0Txn",
        "expanded_url" : "http://baconipsum.com/",
        "display_url" : "baconipsum.com"
      } ]
    },
    "geo" : {
    },
    "id_str" : "232476376228315136",
    "text" : "_Everything_ is better with bacon: http://t.co/ftJL0Txn",
    "id" : 232476376228315136,
    "created_at" : "Mon Aug 06 14:01:01 +0000 2012",
    "user" : {
      "name" : "Su-Shee",
      "screen_name" : "sheeshee",
      "protected" : false,
      "id_str" : "16009329",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/215623267/susi-google_normal.jpg",
      "id" : 16009329,
      "verified" : false
    }
  },
  "id" : 232481478972420097,
  "created_at" : "Mon Aug 06 14:21:18 +0000 2012",
  "user" : {
    "name" : "Felix",
    "screen_name" : "nicidienase",
    "protected" : false,
    "id_str" : "22396883",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3125784966/8223a4c5c9535be22d15c82ec829c2df_normal.jpeg",
    "id" : 22396883,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.echofon.com/\" rel=\"nofollow\">Echofon</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Znuh",
      "screen_name" : "ElZnuh",
      "indices" : [ 3, 10 ],
      "id_str" : "98703205",
      "id" : 98703205
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "232474029271953408",
  "text" : "RT @ElZnuh: 17 Kameras hat der Mars-Rover. Hoffentlich snifft er nicht auch noch Wifi",
  "retweeted_status" : {
    "source" : "web",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : {
    },
    "id_str" : "232471391402856448",
    "text" : "17 Kameras hat der Mars-Rover. Hoffentlich snifft er nicht auch noch Wifi",
    "id" : 232471391402856448,
    "created_at" : "Mon Aug 06 13:41:13 +0000 2012",
    "user" : {
      "name" : "Znuh",
      "screen_name" : "ElZnuh",
      "protected" : false,
      "id_str" : "98703205",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/2315882882/30lnkjoxh1ajn1a9zebg_normal.png",
      "id" : 98703205,
      "verified" : false
    }
  },
  "id" : 232474029271953408,
  "created_at" : "Mon Aug 06 13:51:42 +0000 2012",
  "user" : {
    "name" : "Felix",
    "screen_name" : "nicidienase",
    "protected" : false,
    "id_str" : "22396883",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3125784966/8223a4c5c9535be22d15c82ec829c2df_normal.jpeg",
    "id" : 22396883,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.echofon.com/\" rel=\"nofollow\">Echofon</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ben Dolman",
      "screen_name" : "bdolman",
      "indices" : [ 3, 11 ],
      "id_str" : "15447634",
      "id" : 15447634
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "232473701956849664",
  "text" : "RT @bdolman: Gold medal for NASA in the 563 billion meters",
  "retweeted_status" : {
    "source" : "<a href=\"http://tapbots.com/tweetbot\" rel=\"nofollow\">Tweetbot for iOS</a>",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : {
    },
    "id_str" : "232348836503355392",
    "text" : "Gold medal for NASA in the 563 billion meters",
    "id" : 232348836503355392,
    "created_at" : "Mon Aug 06 05:34:14 +0000 2012",
    "user" : {
      "name" : "Ben Dolman",
      "screen_name" : "bdolman",
      "protected" : false,
      "id_str" : "15447634",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/1931974317/Ben_Avatar_Square_normal.jpg",
      "id" : 15447634,
      "verified" : false
    }
  },
  "id" : 232473701956849664,
  "created_at" : "Mon Aug 06 13:50:24 +0000 2012",
  "user" : {
    "name" : "Felix",
    "screen_name" : "nicidienase",
    "protected" : false,
    "id_str" : "22396883",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3125784966/8223a4c5c9535be22d15c82ec829c2df_normal.jpeg",
    "id" : 22396883,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.echofon.com/\" rel=\"nofollow\">Echofon</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Georg Molzer",
      "screen_name" : "georgraphics",
      "indices" : [ 3, 16 ],
      "id_str" : "86435512",
      "id" : 86435512
    }, {
      "name" : "Curiosity Rover",
      "screen_name" : "MarsCuriosity",
      "indices" : [ 31, 45 ],
      "id_str" : "15473958",
      "id" : 15473958
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "232471979431710721",
  "text" : "RT @georgraphics: uber-curious @MarsCuriosity delivers 2mbit/256kbit down/up. wireless. to mars. carriers all over the world, you may wa ...",
  "retweeted_status" : {
    "source" : "<a href=\"http://tapbots.com/software/tweetbot/mac\" rel=\"nofollow\">Tweetbot for Mac</a>",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Curiosity Rover",
        "screen_name" : "MarsCuriosity",
        "indices" : [ 13, 27 ],
        "id_str" : "15473958",
        "id" : 15473958
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : {
    },
    "id_str" : "232429636783579136",
    "text" : "uber-curious @MarsCuriosity delivers 2mbit/256kbit down/up. wireless. to mars. carriers all over the world, you may want to take notice.",
    "id" : 232429636783579136,
    "created_at" : "Mon Aug 06 10:55:18 +0000 2012",
    "user" : {
      "name" : "Georg Molzer",
      "screen_name" : "georgraphics",
      "protected" : false,
      "id_str" : "86435512",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/1498618103/Bildschirmfoto_2011-08-16_um_19.39.20_normal.png",
      "id" : 86435512,
      "verified" : false
    }
  },
  "id" : 232471979431710721,
  "created_at" : "Mon Aug 06 13:43:33 +0000 2012",
  "user" : {
    "name" : "Felix",
    "screen_name" : "nicidienase",
    "protected" : false,
    "id_str" : "22396883",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3125784966/8223a4c5c9535be22d15c82ec829c2df_normal.jpeg",
    "id" : 22396883,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.echofon.com/\" rel=\"nofollow\">Echofon</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Eli James",
      "screen_name" : "ejames_c",
      "indices" : [ 3, 12 ],
      "id_str" : "14243237",
      "id" : 14243237
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 76, 96 ],
      "url" : "http://t.co/lsouioNx",
      "expanded_url" : "http://yfrog.com/kh5hqhp",
      "display_url" : "yfrog.com/kh5hqhp"
    } ]
  },
  "geo" : {
  },
  "id_str" : "232456834638831617",
  "text" : "RT @ejames_c: You might as well write SQL INJECTION PLEASE! above the form. http://t.co/lsouioNx",
  "retweeted_status" : {
    "source" : "<a href=\"http://itunes.apple.com/us/app/twitter/id409789998?mt=12\" rel=\"nofollow\">Twitter for Mac</a>",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 62, 82 ],
        "url" : "http://t.co/lsouioNx",
        "expanded_url" : "http://yfrog.com/kh5hqhp",
        "display_url" : "yfrog.com/kh5hqhp"
      } ]
    },
    "geo" : {
    },
    "id_str" : "232322637790072832",
    "text" : "You might as well write SQL INJECTION PLEASE! above the form. http://t.co/lsouioNx",
    "id" : 232322637790072832,
    "created_at" : "Mon Aug 06 03:50:07 +0000 2012",
    "user" : {
      "name" : "Eli James",
      "screen_name" : "ejames_c",
      "protected" : false,
      "id_str" : "14243237",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/52174578/avatar_normal.jpg",
      "id" : 14243237,
      "verified" : false
    }
  },
  "id" : 232456834638831617,
  "created_at" : "Mon Aug 06 12:43:22 +0000 2012",
  "user" : {
    "name" : "Felix",
    "screen_name" : "nicidienase",
    "protected" : false,
    "id_str" : "22396883",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3125784966/8223a4c5c9535be22d15c82ec829c2df_normal.jpeg",
    "id" : 22396883,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.echofon.com/\" rel=\"nofollow\">Echofon</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Herr Einspaziert",
      "screen_name" : "maatc",
      "indices" : [ 3, 9 ],
      "id_str" : "39287702",
      "id" : 39287702
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 81, 101 ],
      "url" : "http://t.co/JRkjJOqe",
      "expanded_url" : "http://www.youtube.com/watch?v=or86iaDamE8",
      "display_url" : "youtube.com/watch?v=or86ia\u2026"
    } ]
  },
  "geo" : {
  },
  "id_str" : "232453769483399168",
  "text" : "RT @maatc: Wow! Die ersten hochaufl\u00F6senden Bewegtbilder der Marslandung sind da! http://t.co/JRkjJOqe",
  "retweeted_status" : {
    "source" : "web",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 70, 90 ],
        "url" : "http://t.co/JRkjJOqe",
        "expanded_url" : "http://www.youtube.com/watch?v=or86iaDamE8",
        "display_url" : "youtube.com/watch?v=or86ia\u2026"
      } ]
    },
    "geo" : {
    },
    "id_str" : "232452342996418562",
    "text" : "Wow! Die ersten hochaufl\u00F6senden Bewegtbilder der Marslandung sind da! http://t.co/JRkjJOqe",
    "id" : 232452342996418562,
    "created_at" : "Mon Aug 06 12:25:31 +0000 2012",
    "user" : {
      "name" : "Herr Einspaziert",
      "screen_name" : "maatc",
      "protected" : false,
      "id_str" : "39287702",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/2822500986/85207062813c5a97a95a48aeeae2eee7_normal.png",
      "id" : 39287702,
      "verified" : false
    }
  },
  "id" : 232453769483399168,
  "created_at" : "Mon Aug 06 12:31:12 +0000 2012",
  "user" : {
    "name" : "Felix",
    "screen_name" : "nicidienase",
    "protected" : false,
    "id_str" : "22396883",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3125784966/8223a4c5c9535be22d15c82ec829c2df_normal.jpeg",
    "id" : 22396883,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.echofon.com/\" rel=\"nofollow\">Echofon</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lars Reineke",
      "screen_name" : "larsreineke",
      "indices" : [ 3, 15 ],
      "id_str" : "6338182",
      "id" : 6338182
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "232446319233482752",
  "text" : "RT @larsreineke: Erste Marsbilder sehen aus wie mit Instagram gemacht. Rechne jederzeit damit, dass \"Curiosity\" einen Decaf Soy Latte Ve ...",
  "retweeted_status" : {
    "source" : "<a href=\"http://janetter.net/\" rel=\"nofollow\">Janetter</a>",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : {
    },
    "id_str" : "232415763313614848",
    "text" : "Erste Marsbilder sehen aus wie mit Instagram gemacht. Rechne jederzeit damit, dass \"Curiosity\" einen Decaf Soy Latte Venti hochl\u00E4dt.",
    "id" : 232415763313614848,
    "created_at" : "Mon Aug 06 10:00:10 +0000 2012",
    "user" : {
      "name" : "Lars Reineke",
      "screen_name" : "larsreineke",
      "protected" : false,
      "id_str" : "6338182",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/1461819946/larsreineke_2_normal.jpg",
      "id" : 6338182,
      "verified" : false
    }
  },
  "id" : 232446319233482752,
  "created_at" : "Mon Aug 06 12:01:35 +0000 2012",
  "user" : {
    "name" : "Felix",
    "screen_name" : "nicidienase",
    "protected" : false,
    "id_str" : "22396883",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3125784966/8223a4c5c9535be22d15c82ec829c2df_normal.jpeg",
    "id" : 22396883,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.echofon.com/\" rel=\"nofollow\">Echofon</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mikko Hypponen \u2718",
      "screen_name" : "mikko",
      "indices" : [ 3, 9 ],
      "id_str" : "23566038",
      "id" : 23566038
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 18, 38 ],
      "url" : "http://t.co/kDn9hyPt",
      "expanded_url" : "http://curiosity.mars.jpl.nasa.gov",
      "display_url" : "curiosity.mars.jpl.nasa.gov"
    } ]
  },
  "geo" : {
  },
  "id_str" : "232439852635914240",
  "text" : "RT @mikko: % ping http://t.co/kDn9hyPt                                             \nReply from 198.122.199.235: bytes=32 time=1680000ms  ...",
  "retweeted_status" : {
    "source" : "<a href=\"http://twitter.com/tweetbutton\" rel=\"nofollow\">Tweet Button</a>",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 7, 27 ],
        "url" : "http://t.co/kDn9hyPt",
        "expanded_url" : "http://curiosity.mars.jpl.nasa.gov",
        "display_url" : "curiosity.mars.jpl.nasa.gov"
      } ]
    },
    "geo" : {
    },
    "id_str" : "232363594434637824",
    "text" : "% ping http://t.co/kDn9hyPt                                             \nReply from 198.122.199.235: bytes=32 time=1680000ms TTL=58",
    "id" : 232363594434637824,
    "created_at" : "Mon Aug 06 06:32:52 +0000 2012",
    "user" : {
      "name" : "Mikko Hypponen \u2718",
      "screen_name" : "mikko",
      "protected" : false,
      "id_str" : "23566038",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/3428497729/8a03810d1c84ab31c512fb6660e85477_normal.jpeg",
      "id" : 23566038,
      "verified" : false
    }
  },
  "id" : 232439852635914240,
  "created_at" : "Mon Aug 06 11:35:54 +0000 2012",
  "user" : {
    "name" : "Felix",
    "screen_name" : "nicidienase",
    "protected" : false,
    "id_str" : "22396883",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3125784966/8223a4c5c9535be22d15c82ec829c2df_normal.jpeg",
    "id" : 22396883,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.echofon.com/\" rel=\"nofollow\">Echofon</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "O.L.",
      "screen_name" : "JetztNochBesser",
      "indices" : [ 3, 19 ],
      "id_str" : "34615606",
      "id" : 34615606
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "232438183323922432",
  "text" : "RT @JetztNochBesser: Witzig w\u00E4re, wenn die morgens ins Kontrollzentrum kommen und Curiosity steht da, ohne R\u00E4der und auf Backsteine aufg ...",
  "retweeted_status" : {
    "source" : "<a href=\"http://tapbots.com/software/tweetbot/mac\" rel=\"nofollow\">Tweetbot for Mac</a>",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : {
    },
    "id_str" : "232391715779125248",
    "text" : "Witzig w\u00E4re, wenn die morgens ins Kontrollzentrum kommen und Curiosity steht da, ohne R\u00E4der und auf Backsteine aufgebockt.",
    "id" : 232391715779125248,
    "created_at" : "Mon Aug 06 08:24:37 +0000 2012",
    "user" : {
      "name" : "O.L.",
      "screen_name" : "JetztNochBesser",
      "protected" : false,
      "id_str" : "34615606",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/1822351435/eightbit-3ba80fd8-8a57-4583-a8cf-7ea40df14d00_normal.png",
      "id" : 34615606,
      "verified" : false
    }
  },
  "id" : 232438183323922432,
  "created_at" : "Mon Aug 06 11:29:16 +0000 2012",
  "user" : {
    "name" : "Felix",
    "screen_name" : "nicidienase",
    "protected" : false,
    "id_str" : "22396883",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3125784966/8223a4c5c9535be22d15c82ec829c2df_normal.jpeg",
    "id" : 22396883,
    "verified" : false
  }
}, {
  "source" : "<a href=\"https://play.google.com/store/apps/details?id=org.mariotaku.twidere\" rel=\"nofollow\">Twidere for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Luke Simulacrum",
      "screen_name" : "lukesimulacrum",
      "indices" : [ 3, 18 ],
      "id_str" : "18594417",
      "id" : 18594417
    }, {
      "name" : "Gabriella Coleman",
      "screen_name" : "BiellaColeman",
      "indices" : [ 20, 34 ],
      "id_str" : "31030273",
      "id" : 31030273
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 95, 115 ],
      "url" : "http://t.co/tse9zxMg",
      "expanded_url" : "http://www.ubuntuvibes.com/2012/08/moognu-gnulinux-fans-create-alternative.html",
      "display_url" : "ubuntuvibes.com/2012/08/moognu\u2026"
    } ]
  },
  "geo" : {
  },
  "id_str" : "232197082751066112",
  "text" : "RT @lukesimulacrum: @BiellaColeman Have you seen MooGNU, the copyleft alternative to Nyan Cat? http://t.co/tse9zxMg",
  "retweeted_status" : {
    "source" : "<a href=\"https://launchpad.net/polly\" rel=\"nofollow\">Polly</a>",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Gabriella Coleman",
        "screen_name" : "BiellaColeman",
        "indices" : [ 0, 14 ],
        "id_str" : "31030273",
        "id" : 31030273
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 75, 95 ],
        "url" : "http://t.co/tse9zxMg",
        "expanded_url" : "http://www.ubuntuvibes.com/2012/08/moognu-gnulinux-fans-create-alternative.html",
        "display_url" : "ubuntuvibes.com/2012/08/moognu\u2026"
      } ]
    },
    "geo" : {
    },
    "id_str" : "232158941235253248",
    "in_reply_to_user_id" : 31030273,
    "text" : "@BiellaColeman Have you seen MooGNU, the copyleft alternative to Nyan Cat? http://t.co/tse9zxMg",
    "id" : 232158941235253248,
    "created_at" : "Sun Aug 05 16:59:39 +0000 2012",
    "in_reply_to_screen_name" : "BiellaColeman",
    "in_reply_to_user_id_str" : "31030273",
    "user" : {
      "name" : "Luke Simulacrum",
      "screen_name" : "lukesimulacrum",
      "protected" : false,
      "id_str" : "18594417",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/3362660610/babb9362ebb8c18506fbb5ac98cb157d_normal.jpeg",
      "id" : 18594417,
      "verified" : false
    }
  },
  "id" : 232197082751066112,
  "created_at" : "Sun Aug 05 19:31:13 +0000 2012",
  "user" : {
    "name" : "Felix",
    "screen_name" : "nicidienase",
    "protected" : false,
    "id_str" : "22396883",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3125784966/8223a4c5c9535be22d15c82ec829c2df_normal.jpeg",
    "id" : 22396883,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Uwe Lancier",
      "screen_name" : "Ulan_ka",
      "indices" : [ 0, 8 ],
      "id_str" : "379173142",
      "id" : 379173142
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "231811281009664000",
  "geo" : {
  },
  "id_str" : "231851822032228352",
  "in_reply_to_user_id" : 379173142,
  "text" : "@Ulan_ka in der Fachschaft",
  "id" : 231851822032228352,
  "in_reply_to_status_id" : 231811281009664000,
  "created_at" : "Sat Aug 04 20:39:16 +0000 2012",
  "in_reply_to_screen_name" : "Ulan_ka",
  "in_reply_to_user_id_str" : "379173142",
  "user" : {
    "name" : "Felix",
    "screen_name" : "nicidienase",
    "protected" : false,
    "id_str" : "22396883",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3125784966/8223a4c5c9535be22d15c82ec829c2df_normal.jpeg",
    "id" : 22396883,
    "verified" : false
  }
}, {
  "source" : "<a href=\"https://play.google.com/store/apps/details?id=org.mariotaku.twidere\" rel=\"nofollow\">Twidere for Android</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "fsi",
      "indices" : [ 80, 84 ]
    }, {
      "text" : "cwp",
      "indices" : [ 85, 89 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "231797322768592896",
  "text" : "Wir kochen hier grade deutlich mehr Chili als wie essen k\u00F6nnen. Kommt noch wer? #fsi #cwp",
  "id" : 231797322768592896,
  "created_at" : "Sat Aug 04 17:02:42 +0000 2012",
  "user" : {
    "name" : "Felix",
    "screen_name" : "nicidienase",
    "protected" : false,
    "id_str" : "22396883",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3125784966/8223a4c5c9535be22d15c82ec829c2df_normal.jpeg",
    "id" : 22396883,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.echofon.com/\" rel=\"nofollow\">Echofon</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "29C3",
      "indices" : [ 65, 70 ]
    } ],
    "urls" : [ {
      "indices" : [ 43, 63 ],
      "url" : "http://t.co/ha720NRe",
      "expanded_url" : "http://www.cch.de/organisieren/raeumeundflaechen/rundgang/vr_saal1/",
      "display_url" : "cch.de/organisieren/r\u2026"
    } ]
  },
  "geo" : {
  },
  "id_str" : "231698884001398784",
  "text" : "Genug Sitzepl\u00E4tze bei der Fnord-News-Show: http://t.co/ha720NRe  #29C3",
  "id" : 231698884001398784,
  "created_at" : "Sat Aug 04 10:31:33 +0000 2012",
  "user" : {
    "name" : "Felix",
    "screen_name" : "nicidienase",
    "protected" : false,
    "id_str" : "22396883",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3125784966/8223a4c5c9535be22d15c82ec829c2df_normal.jpeg",
    "id" : 22396883,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Grant Imahara",
      "screen_name" : "grantimahara",
      "indices" : [ 3, 16 ],
      "id_str" : "28521141",
      "id" : 28521141
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "TARDIS",
      "indices" : [ 38, 45 ]
    }, {
      "text" : "geekvacation",
      "indices" : [ 47, 60 ]
    } ],
    "urls" : [ {
      "indices" : [ 61, 81 ],
      "url" : "http://t.co/yJHtvitD",
      "expanded_url" : "http://twitter.com/grantimahara/status/231490114205917184/photo/1",
      "display_url" : "pic.twitter.com/yJHtvitD"
    } ]
  },
  "geo" : {
  },
  "id_str" : "231656110866722816",
  "text" : "RT @grantimahara: My other towel is a #TARDIS. #geekvacation http://t.co/yJHtvitD",
  "retweeted_status" : {
    "source" : "<a href=\"http://www.apple.com\" rel=\"nofollow\">Photos on iOS</a>",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "http://twitter.com/grantimahara/status/231490114205917184/photo/1",
        "indices" : [ 43, 63 ],
        "url" : "http://t.co/yJHtvitD",
        "media_url" : "http://pbs.twimg.com/media/AzZrCEqCIAAAMMB.jpg",
        "id_str" : "231490114210111488",
        "id" : 231490114210111488,
        "media_url_https" : "https://pbs.twimg.com/media/AzZrCEqCIAAAMMB.jpg",
        "sizes" : [ {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 255,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 402,
          "resize" : "fit",
          "w" : 536
        }, {
          "h" : 402,
          "resize" : "fit",
          "w" : 536
        }, {
          "h" : 402,
          "resize" : "fit",
          "w" : 536
        } ],
        "display_url" : "pic.twitter.com/yJHtvitD"
      } ],
      "hashtags" : [ {
        "text" : "TARDIS",
        "indices" : [ 20, 27 ]
      }, {
        "text" : "geekvacation",
        "indices" : [ 29, 42 ]
      } ],
      "urls" : [ ]
    },
    "geo" : {
    },
    "id_str" : "231490114205917184",
    "text" : "My other towel is a #TARDIS. #geekvacation http://t.co/yJHtvitD",
    "id" : 231490114205917184,
    "created_at" : "Fri Aug 03 20:41:59 +0000 2012",
    "user" : {
      "name" : "Grant Imahara",
      "screen_name" : "grantimahara",
      "protected" : false,
      "id_str" : "28521141",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/3003132229/53338ad2b848f7f59261f53901a391a6_normal.jpeg",
      "id" : 28521141,
      "verified" : true
    }
  },
  "id" : 231656110866722816,
  "created_at" : "Sat Aug 04 07:41:35 +0000 2012",
  "user" : {
    "name" : "Felix",
    "screen_name" : "nicidienase",
    "protected" : false,
    "id_str" : "22396883",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3125784966/8223a4c5c9535be22d15c82ec829c2df_normal.jpeg",
    "id" : 22396883,
    "verified" : false
  }
}, {
  "source" : "<a href=\"https://play.google.com/store/apps/details?id=org.mariotaku.twidere\" rel=\"nofollow\">Twidere for Android</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "twidere",
      "indices" : [ 16, 24 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "231142551871176704",
  "text" : "Just discovered #twidere, nice Twitter-Client for android with great tablet-layout. And it\u2019s GPL!",
  "id" : 231142551871176704,
  "created_at" : "Thu Aug 02 21:40:53 +0000 2012",
  "user" : {
    "name" : "Felix",
    "screen_name" : "nicidienase",
    "protected" : false,
    "id_str" : "22396883",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3125784966/8223a4c5c9535be22d15c82ec829c2df_normal.jpeg",
    "id" : 22396883,
    "verified" : false
  }
}, {
  "source" : "<a href=\"https://play.google.com/store/apps/details?id=org.mariotaku.twidere\" rel=\"nofollow\">Twidere for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "ubahnverleih",
      "screen_name" : "ubahnverleih",
      "indices" : [ 3, 16 ],
      "id_str" : "28865239",
      "id" : 28865239
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "231140958723526656",
  "text" : "RT @ubahnverleih: Wird die Bundeswehr bei Vollmond eigentlich zur Wehrmacht?",
  "retweeted_status" : {
    "source" : "<a href=\"http://itunes.apple.com/us/app/twitter/id409789998?mt=12\" rel=\"nofollow\">Twitter for Mac</a>",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : {
    },
    "id_str" : "231112007728918528",
    "text" : "Wird die Bundeswehr bei Vollmond eigentlich zur Wehrmacht?",
    "id" : 231112007728918528,
    "created_at" : "Thu Aug 02 19:39:31 +0000 2012",
    "user" : {
      "name" : "ubahnverleih",
      "screen_name" : "ubahnverleih",
      "protected" : false,
      "id_str" : "28865239",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/122321424/ubahnverleih_normal.jpg",
      "id" : 28865239,
      "verified" : false
    }
  },
  "id" : 231140958723526656,
  "created_at" : "Thu Aug 02 21:34:33 +0000 2012",
  "user" : {
    "name" : "Felix",
    "screen_name" : "nicidienase",
    "protected" : false,
    "id_str" : "22396883",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3125784966/8223a4c5c9535be22d15c82ec829c2df_normal.jpeg",
    "id" : 22396883,
    "verified" : false
  }
}, {
  "source" : "<a href=\"https://play.google.com/store/apps/details?id=org.mariotaku.twidere\" rel=\"nofollow\">Twidere for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Gerd Eist",
      "screen_name" : "erdgeist",
      "indices" : [ 3, 12 ],
      "id_str" : "16701619",
      "id" : 16701619
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 92, 112 ],
      "url" : "http://t.co/IantJ1ys",
      "expanded_url" : "http://www.youtube.com/watch?v=GJ4Qp2xeRds",
      "display_url" : "youtube.com/watch?v=GJ4Qp2\u2026"
    } ]
  },
  "geo" : {
  },
  "id_str" : "231140302524665856",
  "text" : "RT @erdgeist: Die Nachfahren der Knoff-Hoff-Show. Heute: Wie hoch kann man eigentlich bauen http://t.co/IantJ1ys",
  "retweeted_status" : {
    "source" : "web",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 78, 98 ],
        "url" : "http://t.co/IantJ1ys",
        "expanded_url" : "http://www.youtube.com/watch?v=GJ4Qp2xeRds",
        "display_url" : "youtube.com/watch?v=GJ4Qp2\u2026"
      } ]
    },
    "geo" : {
    },
    "id_str" : "231134053305307137",
    "text" : "Die Nachfahren der Knoff-Hoff-Show. Heute: Wie hoch kann man eigentlich bauen http://t.co/IantJ1ys",
    "id" : 231134053305307137,
    "created_at" : "Thu Aug 02 21:07:07 +0000 2012",
    "user" : {
      "name" : "Gerd Eist",
      "screen_name" : "erdgeist",
      "protected" : false,
      "id_str" : "16701619",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/61748149/ta_normal.jpg",
      "id" : 16701619,
      "verified" : false
    }
  },
  "id" : 231140302524665856,
  "created_at" : "Thu Aug 02 21:31:57 +0000 2012",
  "user" : {
    "name" : "Felix",
    "screen_name" : "nicidienase",
    "protected" : false,
    "id_str" : "22396883",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3125784966/8223a4c5c9535be22d15c82ec829c2df_normal.jpeg",
    "id" : 22396883,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://getspaz.com\" rel=\"nofollow\">Spaz HD for webOS</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "i42n",
      "screen_name" : "i42n",
      "indices" : [ 0, 5 ],
      "id_str" : "22298116",
      "id" : 22298116
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "231071011792101376",
  "geo" : {
  },
  "id_str" : "231105000099704832",
  "in_reply_to_user_id" : 22298116,
  "text" : "@i42n \\o/ freies WLAN",
  "id" : 231105000099704832,
  "in_reply_to_status_id" : 231071011792101376,
  "created_at" : "Thu Aug 02 19:11:40 +0000 2012",
  "in_reply_to_screen_name" : "i42n",
  "in_reply_to_user_id_str" : "22298116",
  "user" : {
    "name" : "Felix",
    "screen_name" : "nicidienase",
    "protected" : false,
    "id_str" : "22396883",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3125784966/8223a4c5c9535be22d15c82ec829c2df_normal.jpeg",
    "id" : 22396883,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.echofon.com/\" rel=\"nofollow\">Echofon</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "schu",
      "screen_name" : "schu__",
      "indices" : [ 3, 10 ],
      "id_str" : "116923586",
      "id" : 116923586
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 16, 37 ],
      "url" : "https://t.co/3XhDNjzh",
      "expanded_url" : "https://code.google.com/p/corkami/downloads/detail?name=CorkaMIX.zip",
      "display_url" : "code.google.com/p/corkami/down\u2026"
    } ]
  },
  "geo" : {
  },
  "id_str" : "231005304035348480",
  "text" : "RT @schu__: o_O https://t.co/3XhDNjzh",
  "retweeted_status" : {
    "source" : "web",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 4, 25 ],
        "url" : "https://t.co/3XhDNjzh",
        "expanded_url" : "https://code.google.com/p/corkami/downloads/detail?name=CorkaMIX.zip",
        "display_url" : "code.google.com/p/corkami/down\u2026"
      } ]
    },
    "geo" : {
    },
    "id_str" : "230977656869511170",
    "text" : "o_O https://t.co/3XhDNjzh",
    "id" : 230977656869511170,
    "created_at" : "Thu Aug 02 10:45:39 +0000 2012",
    "user" : {
      "name" : "schu",
      "screen_name" : "schu__",
      "protected" : false,
      "id_str" : "116923586",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/783740957/null_normal.jpg",
      "id" : 116923586,
      "verified" : false
    }
  },
  "id" : 231005304035348480,
  "created_at" : "Thu Aug 02 12:35:31 +0000 2012",
  "user" : {
    "name" : "Felix",
    "screen_name" : "nicidienase",
    "protected" : false,
    "id_str" : "22396883",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3125784966/8223a4c5c9535be22d15c82ec829c2df_normal.jpeg",
    "id" : 22396883,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.echofon.com/\" rel=\"nofollow\">Echofon</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sadao Turner Esq.",
      "screen_name" : "SadaoTurner",
      "indices" : [ 3, 15 ],
      "id_str" : "20475017",
      "id" : 20475017
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "230955027534069760",
  "text" : "RT @SadaoTurner: Something you won't see on TV, this is the Olympics Wi-Fi Police. They seek unauthorized wifi signals &amp; shut them d ...",
  "retweeted_status" : {
    "source" : "<a href=\"http://www.apple.com\" rel=\"nofollow\">Photos on iOS</a>",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "http://twitter.com/SadaoTurner/status/230737352958566401/photo/1",
        "indices" : [ 124, 144 ],
        "url" : "http://t.co/h9L2RYWc",
        "media_url" : "http://pbs.twimg.com/media/AzO-ZmgCYAAFra0.jpg",
        "id_str" : "230737352966955008",
        "id" : 230737352966955008,
        "media_url_https" : "https://pbs.twimg.com/media/AzO-ZmgCYAAFra0.jpg",
        "sizes" : [ {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 816,
          "resize" : "fit",
          "w" : 612
        }, {
          "h" : 453,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 816,
          "resize" : "fit",
          "w" : 612
        }, {
          "h" : 800,
          "resize" : "fit",
          "w" : 600
        } ],
        "display_url" : "pic.twitter.com/h9L2RYWc"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : {
    },
    "id_str" : "230737352958566401",
    "text" : "Something you won't see on TV, this is the Olympics Wi-Fi Police. They seek unauthorized wifi signals &amp; shut them down. http://t.co/h9L2RYWc",
    "id" : 230737352958566401,
    "created_at" : "Wed Aug 01 18:50:47 +0000 2012",
    "user" : {
      "name" : "Sadao Turner Esq.",
      "screen_name" : "SadaoTurner",
      "protected" : false,
      "id_str" : "20475017",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/1331523747/500-newtwitter-122710_normal.jpg",
      "id" : 20475017,
      "verified" : false
    }
  },
  "id" : 230955027534069760,
  "created_at" : "Thu Aug 02 09:15:44 +0000 2012",
  "user" : {
    "name" : "Felix",
    "screen_name" : "nicidienase",
    "protected" : false,
    "id_str" : "22396883",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3125784966/8223a4c5c9535be22d15c82ec829c2df_normal.jpeg",
    "id" : 22396883,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.echofon.com/\" rel=\"nofollow\">Echofon</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 120, 140 ],
      "url" : "http://t.co/ZPiHxrbW",
      "expanded_url" : "http://www.loopinsight.com/2012/08/01/apple-regains-worldwide-lead-in-pc-shipments/",
      "display_url" : "loopinsight.com/2012/08/01/app\u2026"
    } ]
  },
  "geo" : {
  },
  "id_str" : "230954702500659200",
  "text" : "lol \u201CWe expect the Surface pads to have a similar impact on the PC industry as the Zune did in portable music players.\u201D http://t.co/ZPiHxrbW",
  "id" : 230954702500659200,
  "created_at" : "Thu Aug 02 09:14:26 +0000 2012",
  "user" : {
    "name" : "Felix",
    "screen_name" : "nicidienase",
    "protected" : false,
    "id_str" : "22396883",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3125784966/8223a4c5c9535be22d15c82ec829c2df_normal.jpeg",
    "id" : 22396883,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Eva Eichhorn",
      "screen_name" : "MamsellChaos",
      "indices" : [ 0, 13 ],
      "id_str" : "140774041",
      "id" : 140774041
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "230776676034957313",
  "geo" : {
  },
  "id_str" : "230794306099748864",
  "in_reply_to_user_id" : 140774041,
  "text" : "@MamsellChaos So ein Magnet-Finger ist echt awesome!!",
  "id" : 230794306099748864,
  "in_reply_to_status_id" : 230776676034957313,
  "created_at" : "Wed Aug 01 22:37:05 +0000 2012",
  "in_reply_to_screen_name" : "MamsellChaos",
  "in_reply_to_user_id_str" : "140774041",
  "user" : {
    "name" : "Felix",
    "screen_name" : "nicidienase",
    "protected" : false,
    "id_str" : "22396883",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3125784966/8223a4c5c9535be22d15c82ec829c2df_normal.jpeg",
    "id" : 22396883,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Eva Eichhorn",
      "screen_name" : "MamsellChaos",
      "indices" : [ 36, 49 ],
      "id_str" : "140774041",
      "id" : 140774041
    } ],
    "media" : [ {
      "expanded_url" : "http://twitter.com/nicidienase/status/230557796733706242/photo/1",
      "indices" : [ 50, 70 ],
      "url" : "http://t.co/tc4egmqR",
      "media_url" : "http://pbs.twimg.com/media/AzMbGDbCYAAjc9y.jpg",
      "id_str" : "230557796737900544",
      "id" : 230557796737900544,
      "media_url_https" : "https://pbs.twimg.com/media/AzMbGDbCYAAjc9y.jpg",
      "sizes" : [ {
        "h" : 450,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 1920,
        "resize" : "fit",
        "w" : 2560
      }, {
        "h" : 768,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 255,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com/tc4egmqR"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "230557796733706242",
  "text" : "Unterw\u00E4schstatus: Nyanynyannyan /cc @MamsellChaos http://t.co/tc4egmqR",
  "id" : 230557796733706242,
  "created_at" : "Wed Aug 01 06:57:18 +0000 2012",
  "user" : {
    "name" : "Felix",
    "screen_name" : "nicidienase",
    "protected" : false,
    "id_str" : "22396883",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3125784966/8223a4c5c9535be22d15c82ec829c2df_normal.jpeg",
    "id" : 22396883,
    "verified" : false
  }
} ]