Grailbird.data.tweets_2011_01 = 
 [ {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "31056256974196736",
  "text" : "Little Bobby Tables hat den F\u00FChrerschein gemacht: http://pics.nase-bohren.de/radar_injection.jpg/1296238697",
  "id" : 31056256974196736,
  "created_at" : "Fri Jan 28 18:29:23 +0000 2011",
  "user" : {
    "name" : "Felix",
    "screen_name" : "nicidienase",
    "protected" : false,
    "id_str" : "22396883",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3125784966/8223a4c5c9535be22d15c82ec829c2df_normal.jpeg",
    "id" : 22396883,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.bravenewcode.com/products/wordtwit\" rel=\"nofollow\">WordTwit Plugin</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "29950133101662208",
  "text" : "Neuer Blog-Beitrag, Clifford Stoll on ... everything - http://tinyurl.com/5vsv296",
  "id" : 29950133101662208,
  "created_at" : "Tue Jan 25 17:14:02 +0000 2011",
  "user" : {
    "name" : "Felix",
    "screen_name" : "nicidienase",
    "protected" : false,
    "id_str" : "22396883",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3125784966/8223a4c5c9535be22d15c82ec829c2df_normal.jpeg",
    "id" : 22396883,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://tweed.pivotallabs.com\" rel=\"nofollow\">Tweed webOS</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "@mchlpchl folgen",
      "screen_name" : "piratenmichel",
      "indices" : [ 3, 17 ],
      "id_str" : "226123862",
      "id" : 226123862
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "29463152890486784",
  "text" : "RT @piratenmichel: Das hei\u00DFt nicht Mensch, das hei\u00DFt Affe mit Evolutionshintergrund.",
  "retweeted_status" : {
    "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : {
    },
    "id_str" : "28958582363914240",
    "text" : "Das hei\u00DFt nicht Mensch, das hei\u00DFt Affe mit Evolutionshintergrund.",
    "id" : 28958582363914240,
    "created_at" : "Sat Jan 22 23:33:58 +0000 2011",
    "user" : {
      "name" : "Mchl",
      "screen_name" : "mchlpchl",
      "protected" : false,
      "id_str" : "11568372",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/2498549253/nlpt7euiez4bbmyrzsy4_normal.jpeg",
      "id" : 11568372,
      "verified" : false
    }
  },
  "id" : 29463152890486784,
  "created_at" : "Mon Jan 24 08:58:57 +0000 2011",
  "user" : {
    "name" : "Felix",
    "screen_name" : "nicidienase",
    "protected" : false,
    "id_str" : "22396883",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3125784966/8223a4c5c9535be22d15c82ec829c2df_normal.jpeg",
    "id" : 22396883,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://tweed.pivotallabs.com\" rel=\"nofollow\">Tweed webOS</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sonne",
      "screen_name" : "mrs_krolock",
      "indices" : [ 0, 12 ],
      "id_str" : "213821462",
      "id" : 213821462
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "27391233936592896",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 49.015424, 8.392541 ]
  },
  "id_str" : "27652855804465152",
  "in_reply_to_user_id" : 213821462,
  "text" : "@mrs_krolock will auch sehen",
  "id" : 27652855804465152,
  "in_reply_to_status_id" : 27391233936592896,
  "created_at" : "Wed Jan 19 09:05:29 +0000 2011",
  "in_reply_to_screen_name" : "mrs_krolock",
  "in_reply_to_user_id_str" : "213821462",
  "user" : {
    "name" : "Felix",
    "screen_name" : "nicidienase",
    "protected" : false,
    "id_str" : "22396883",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3125784966/8223a4c5c9535be22d15c82ec829c2df_normal.jpeg",
    "id" : 22396883,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://tweed.pivotallabs.com\" rel=\"nofollow\">Tweed webOS</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mario Sixtus",
      "screen_name" : "sixtus",
      "indices" : [ 3, 10 ],
      "id_str" : "9334352",
      "id" : 9334352
    }, {
      "name" : "Steve Dekorte",
      "screen_name" : "stevedekorte",
      "indices" : [ 28, 41 ],
      "id_str" : "3237831",
      "id" : 3237831
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "yfrog",
      "indices" : [ 58, 64 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "27652181721088000",
  "text" : "RT @sixtus: I just saw that @stevedekorte tweeted this on #yfrog. http://yfrog.com/h4rsmoj",
  "retweeted_status" : {
    "source" : "<a href=\"http://yfrog.com\" rel=\"nofollow\">Yfrog</a>",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Steve Dekorte",
        "screen_name" : "stevedekorte",
        "indices" : [ 16, 29 ],
        "id_str" : "3237831",
        "id" : 3237831
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "yfrog",
        "indices" : [ 46, 52 ]
      } ],
      "urls" : [ ]
    },
    "geo" : {
    },
    "id_str" : "27374649935400960",
    "text" : "I just saw that @stevedekorte tweeted this on #yfrog. http://yfrog.com/h4rsmoj",
    "id" : 27374649935400960,
    "created_at" : "Tue Jan 18 14:39:59 +0000 2011",
    "user" : {
      "name" : "Mario Sixtus",
      "screen_name" : "sixtus",
      "protected" : false,
      "id_str" : "9334352",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/274542155/mario_normal.gif",
      "id" : 9334352,
      "verified" : true
    }
  },
  "id" : 27652181721088000,
  "created_at" : "Wed Jan 19 09:02:48 +0000 2011",
  "user" : {
    "name" : "Felix",
    "screen_name" : "nicidienase",
    "protected" : false,
    "id_str" : "22396883",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3125784966/8223a4c5c9535be22d15c82ec829c2df_normal.jpeg",
    "id" : 22396883,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.bravenewcode.com/products/wordtwit\" rel=\"nofollow\">WordTwit Plugin</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "27485502777069568",
  "text" : "Neuer Blog-Beitrag, Lustig - http://tinyurl.com/6f5b6h4",
  "id" : 27485502777069568,
  "created_at" : "Tue Jan 18 22:00:29 +0000 2011",
  "user" : {
    "name" : "Felix",
    "screen_name" : "nicidienase",
    "protected" : false,
    "id_str" : "22396883",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3125784966/8223a4c5c9535be22d15c82ec829c2df_normal.jpeg",
    "id" : 22396883,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://tweed.pivotallabs.com\" rel=\"nofollow\">Tweed webOS</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Bud Caddell",
      "screen_name" : "bud_caddell",
      "indices" : [ 3, 15 ],
      "id_str" : "1543551",
      "id" : 1543551
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "26625277706637312",
  "text" : "RT @bud_caddell: If bored, google img search 'DSC00001.JPG' to see people's first photos taken, then dream up little stories about why t ...",
  "retweeted_status" : {
    "source" : "<a href=\"http://www.tweetdeck.com\" rel=\"nofollow\">TweetDeck</a>",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : {
    },
    "id_str" : "26417845625692160",
    "text" : "If bored, google img search 'DSC00001.JPG' to see people's first photos taken, then dream up little stories about why they chose that shot.",
    "id" : 26417845625692160,
    "created_at" : "Sat Jan 15 23:17:59 +0000 2011",
    "user" : {
      "name" : "Bud Caddell",
      "screen_name" : "bud_caddell",
      "protected" : false,
      "id_str" : "1543551",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/3285197369/efd04c59eaff1592c0b2f432ed661f74_normal.jpeg",
      "id" : 1543551,
      "verified" : false
    }
  },
  "id" : 26625277706637312,
  "created_at" : "Sun Jan 16 13:02:15 +0000 2011",
  "user" : {
    "name" : "Felix",
    "screen_name" : "nicidienase",
    "protected" : false,
    "id_str" : "22396883",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3125784966/8223a4c5c9535be22d15c82ec829c2df_normal.jpeg",
    "id" : 22396883,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://tweed.pivotallabs.com\" rel=\"nofollow\">Tweed webOS</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "superkatinka",
      "screen_name" : "diekathrin",
      "indices" : [ 3, 14 ],
      "id_str" : "15082960",
      "id" : 15082960
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "25010235135496192",
  "text" : "RT @diekathrin: Oh? MTV ist weg?\nEnthielt bestimmt Content von Sony Entertainment und ist deswegen in meinem Fernseher nicht mehr verf\u00FCgbar.",
  "retweeted_status" : {
    "source" : "<a href=\"http://mobile.twitter.com\" rel=\"nofollow\">Mobile Web</a>",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : {
    },
    "id_str" : "24925616167981056",
    "text" : "Oh? MTV ist weg?\nEnthielt bestimmt Content von Sony Entertainment und ist deswegen in meinem Fernseher nicht mehr verf\u00FCgbar.",
    "id" : 24925616167981056,
    "created_at" : "Tue Jan 11 20:28:24 +0000 2011",
    "user" : {
      "name" : "superkatinka",
      "screen_name" : "diekathrin",
      "protected" : false,
      "id_str" : "15082960",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/2360191825/qxz7op1ieb721hosed87_normal.png",
      "id" : 15082960,
      "verified" : false
    }
  },
  "id" : 25010235135496192,
  "created_at" : "Wed Jan 12 02:04:39 +0000 2011",
  "user" : {
    "name" : "Felix",
    "screen_name" : "nicidienase",
    "protected" : false,
    "id_str" : "22396883",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3125784966/8223a4c5c9535be22d15c82ec829c2df_normal.jpeg",
    "id" : 22396883,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "24112716809510913",
  "text" : "FREE HUGS\nhttp://www.wimp.com/hugsamsterdam/",
  "id" : 24112716809510913,
  "created_at" : "Sun Jan 09 14:38:14 +0000 2011",
  "user" : {
    "name" : "Felix",
    "screen_name" : "nicidienase",
    "protected" : false,
    "id_str" : "22396883",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3125784966/8223a4c5c9535be22d15c82ec829c2df_normal.jpeg",
    "id" : 22396883,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://tweed.pivotallabs.com\" rel=\"nofollow\">Tweed webOS</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sascha Lobo",
      "screen_name" : "saschalobo",
      "indices" : [ 3, 14 ],
      "id_str" : "5876652",
      "id" : 5876652
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "22136371325960192",
  "text" : "RT @saschalobo: Stefan Niggemeier leitet wunderbar das Gegen-Mem her: Gratiskultur Print. http://1.ly/GratiskulturPrint",
  "retweeted_status" : {
    "source" : "<a href=\"http://bitly.com\" rel=\"nofollow\">bitly</a>",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : {
    },
    "id_str" : "21948347979923456",
    "text" : "Stefan Niggemeier leitet wunderbar das Gegen-Mem her: Gratiskultur Print. http://1.ly/GratiskulturPrint",
    "id" : 21948347979923456,
    "created_at" : "Mon Jan 03 15:17:48 +0000 2011",
    "user" : {
      "name" : "Sascha Lobo",
      "screen_name" : "saschalobo",
      "protected" : false,
      "id_str" : "5876652",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/516226876/saschalobo_icon_normal.png",
      "id" : 5876652,
      "verified" : true
    }
  },
  "id" : 22136371325960192,
  "created_at" : "Tue Jan 04 03:44:56 +0000 2011",
  "user" : {
    "name" : "Felix",
    "screen_name" : "nicidienase",
    "protected" : false,
    "id_str" : "22396883",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3125784966/8223a4c5c9535be22d15c82ec829c2df_normal.jpeg",
    "id" : 22396883,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://tweed.pivotallabs.com\" rel=\"nofollow\">Tweed webOS</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Giulio De Luise",
      "screen_name" : "giuliodeluise",
      "indices" : [ 3, 17 ],
      "id_str" : "13044612",
      "id" : 13044612
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "prime",
      "indices" : [ 29, 35 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "21270686689402880",
  "text" : "RT @giuliodeluise: 2011 is a #prime number and also the sum of 11 consecutive prime numbers: 2011=157+163+167+173+179+181+191+193+197+19 ...",
  "retweeted_status" : {
    "source" : "web",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "prime",
        "indices" : [ 10, 16 ]
      }, {
        "text" : "math",
        "indices" : [ 123, 128 ]
      }, {
        "text" : "geek",
        "indices" : [ 129, 134 ]
      } ],
      "urls" : [ ]
    },
    "geo" : {
    },
    "id_str" : "21047150066532353",
    "text" : "2011 is a #prime number and also the sum of 11 consecutive prime numbers: 2011=157+163+167+173+179+181+191+193+197+199+211 #math #geek",
    "id" : 21047150066532353,
    "created_at" : "Sat Jan 01 03:36:46 +0000 2011",
    "user" : {
      "name" : "Giulio De Luise",
      "screen_name" : "giuliodeluise",
      "protected" : false,
      "id_str" : "13044612",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/1032407506/Giulio_De_Luise_web_normal.jpg",
      "id" : 13044612,
      "verified" : false
    }
  },
  "id" : 21270686689402880,
  "created_at" : "Sat Jan 01 18:25:01 +0000 2011",
  "user" : {
    "name" : "Felix",
    "screen_name" : "nicidienase",
    "protected" : false,
    "id_str" : "22396883",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3125784966/8223a4c5c9535be22d15c82ec829c2df_normal.jpeg",
    "id" : 22396883,
    "verified" : false
  }
} ]