Grailbird.data.tweets_2012_11 = 
 [ {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "T_i_B",
      "screen_name" : "T_i_B",
      "indices" : [ 3, 9 ],
      "id_str" : "76582352",
      "id" : 76582352
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 50, 70 ],
      "url" : "http://t.co/Z93myTPz",
      "expanded_url" : "http://twitter.com/T_i_B/status/274471230122381313/photo/1",
      "display_url" : "pic.twitter.com/Z93myTPz"
    } ]
  },
  "geo" : {
  },
  "id_str" : "274530554643353603",
  "text" : "RT @T_i_B: When pub staff T-shirts go wrong...... http://t.co/Z93myTPz",
  "retweeted_status" : {
    "source" : "web",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "http://twitter.com/T_i_B/status/274471230122381313/photo/1",
        "indices" : [ 39, 59 ],
        "url" : "http://t.co/Z93myTPz",
        "media_url" : "http://pbs.twimg.com/media/A88eISzCUAAkysT.jpg",
        "id_str" : "274471230126575616",
        "id" : 274471230126575616,
        "media_url_https" : "https://pbs.twimg.com/media/A88eISzCUAAkysT.jpg",
        "sizes" : [ {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 453,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 640,
          "resize" : "fit",
          "w" : 480
        }, {
          "h" : 640,
          "resize" : "fit",
          "w" : 480
        }, {
          "h" : 640,
          "resize" : "fit",
          "w" : 480
        } ],
        "display_url" : "pic.twitter.com/Z93myTPz"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : {
    },
    "id_str" : "274471230122381313",
    "text" : "When pub staff T-shirts go wrong...... http://t.co/Z93myTPz",
    "id" : 274471230122381313,
    "created_at" : "Fri Nov 30 11:13:35 +0000 2012",
    "user" : {
      "name" : "T_i_B",
      "screen_name" : "T_i_B",
      "protected" : false,
      "id_str" : "76582352",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/3027482313/428b57257e3ea2eb783e466b0f9982fa_normal.jpeg",
      "id" : 76582352,
      "verified" : false
    }
  },
  "id" : 274530554643353603,
  "created_at" : "Fri Nov 30 15:09:19 +0000 2012",
  "user" : {
    "name" : "Felix",
    "screen_name" : "nicidienase",
    "protected" : false,
    "id_str" : "22396883",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3125784966/8223a4c5c9535be22d15c82ec829c2df_normal.jpeg",
    "id" : 22396883,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "psy",
      "screen_name" : "psycon",
      "indices" : [ 0, 7 ],
      "id_str" : "87286054",
      "id" : 87286054
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "274476822585028608",
  "geo" : {
  },
  "id_str" : "274483970157203457",
  "in_reply_to_user_id" : 87286054,
  "text" : "@psycon wurde ich auch gern. Aber ich bin Arbeiten.",
  "id" : 274483970157203457,
  "in_reply_to_status_id" : 274476822585028608,
  "created_at" : "Fri Nov 30 12:04:12 +0000 2012",
  "in_reply_to_screen_name" : "psycon",
  "in_reply_to_user_id_str" : "87286054",
  "user" : {
    "name" : "Felix",
    "screen_name" : "nicidienase",
    "protected" : false,
    "id_str" : "22396883",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3125784966/8223a4c5c9535be22d15c82ec829c2df_normal.jpeg",
    "id" : 22396883,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Eichohrkatz",
      "screen_name" : "eichohrkatzerl",
      "indices" : [ 3, 18 ],
      "id_str" : "226937754",
      "id" : 226937754
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "274478419683717120",
  "text" : "RT @eichohrkatzerl: Du hast Kinder, bist alleinerziehend? Wir bieten erstklassige Betreuung und einen Arbeitsplatz. Come to the dark sid ...",
  "retweeted_status" : {
    "source" : "<a href=\"http://janetter.net/\" rel=\"nofollow\">Janetter</a>",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "http://twitter.com/LordSticky/status/273889498927079427/photo/1",
        "indices" : [ 118, 138 ],
        "url" : "http://t.co/1lHDletQ",
        "media_url" : "http://pbs.twimg.com/media/A80NDFOCIAArVVW.jpg",
        "id_str" : "273889498931273728",
        "id" : 273889498931273728,
        "media_url_https" : "https://pbs.twimg.com/media/A80NDFOCIAArVVW.jpg",
        "sizes" : [ {
          "h" : 687,
          "resize" : "fit",
          "w" : 515
        }, {
          "h" : 687,
          "resize" : "fit",
          "w" : 515
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 454,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 687,
          "resize" : "fit",
          "w" : 515
        } ],
        "display_url" : "pic.twitter.com/1lHDletQ"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : {
    },
    "id_str" : "273891213394980864",
    "text" : "Du hast Kinder, bist alleinerziehend? Wir bieten erstklassige Betreuung und einen Arbeitsplatz. Come to the dark side http://t.co/1lHDletQ",
    "id" : 273891213394980864,
    "created_at" : "Wed Nov 28 20:48:48 +0000 2012",
    "user" : {
      "name" : "Eichohrkatz",
      "screen_name" : "eichohrkatzerl",
      "protected" : false,
      "id_str" : "226937754",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/3026145631/1eb0ee337adfd060735cb5c271dce187_normal.jpeg",
      "id" : 226937754,
      "verified" : false
    }
  },
  "id" : 274478419683717120,
  "created_at" : "Fri Nov 30 11:42:09 +0000 2012",
  "user" : {
    "name" : "Felix",
    "screen_name" : "nicidienase",
    "protected" : false,
    "id_str" : "22396883",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3125784966/8223a4c5c9535be22d15c82ec829c2df_normal.jpeg",
    "id" : 22396883,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Gl\u00FChweinAufLeerenMagen",
      "indices" : [ 9, 32 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "274090946101121024",
  "text" : "Huuuiii. #Gl\u00FChweinAufLeerenMagen :D",
  "id" : 274090946101121024,
  "created_at" : "Thu Nov 29 10:02:28 +0000 2012",
  "user" : {
    "name" : "Felix",
    "screen_name" : "nicidienase",
    "protected" : false,
    "id_str" : "22396883",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3125784966/8223a4c5c9535be22d15c82ec829c2df_normal.jpeg",
    "id" : 22396883,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Fiona",
      "screen_name" : "Fotografiona",
      "indices" : [ 3, 16 ],
      "id_str" : "59090320",
      "id" : 59090320
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "274080560194920450",
  "text" : "RT @Fotografiona: I don't feel very Turing-vollst\u00E4ndig today :(",
  "retweeted_status" : {
    "source" : "web",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : {
    },
    "id_str" : "274064506836103168",
    "text" : "I don't feel very Turing-vollst\u00E4ndig today :(",
    "id" : 274064506836103168,
    "created_at" : "Thu Nov 29 08:17:24 +0000 2012",
    "user" : {
      "name" : "Fiona",
      "screen_name" : "Fotografiona",
      "protected" : false,
      "id_str" : "59090320",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/2546078946/lfyc2rzsxw67cbv89x37_normal.jpeg",
      "id" : 59090320,
      "verified" : false
    }
  },
  "id" : 274080560194920450,
  "created_at" : "Thu Nov 29 09:21:12 +0000 2012",
  "user" : {
    "name" : "Felix",
    "screen_name" : "nicidienase",
    "protected" : false,
    "id_str" : "22396883",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3125784966/8223a4c5c9535be22d15c82ec829c2df_normal.jpeg",
    "id" : 22396883,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "*andy",
      "screen_name" : "derGeruhn",
      "indices" : [ 3, 13 ],
      "id_str" : "936437276",
      "id" : 936437276
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "fsiKA",
      "indices" : [ 15, 21 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "274079193409675264",
  "text" : "RT @derGeruhn: #fsiKA verkauft Gl\u00FChwein und M\u00FChwein mit und ohne Amaretto",
  "retweeted_status" : {
    "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "fsiKA",
        "indices" : [ 0, 6 ]
      } ],
      "urls" : [ ]
    },
    "geo" : {
    },
    "id_str" : "274054515320303617",
    "text" : "#fsiKA verkauft Gl\u00FChwein und M\u00FChwein mit und ohne Amaretto",
    "id" : 274054515320303617,
    "created_at" : "Thu Nov 29 07:37:42 +0000 2012",
    "user" : {
      "name" : "*andy",
      "screen_name" : "derGeruhn",
      "protected" : false,
      "id_str" : "936437276",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/3034420321/a4487789b515735fbc9522da5029aa43_normal.png",
      "id" : 936437276,
      "verified" : false
    }
  },
  "id" : 274079193409675264,
  "created_at" : "Thu Nov 29 09:15:46 +0000 2012",
  "user" : {
    "name" : "Felix",
    "screen_name" : "nicidienase",
    "protected" : false,
    "id_str" : "22396883",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3125784966/8223a4c5c9535be22d15c82ec829c2df_normal.jpeg",
    "id" : 22396883,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "FML",
      "indices" : [ 58, 62 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "274078477299351553",
  "text" : "Vorgestern Hinterrad gewechselt. Heute plattes Vorderrad. #FML",
  "id" : 274078477299351553,
  "created_at" : "Thu Nov 29 09:12:55 +0000 2012",
  "user" : {
    "name" : "Felix",
    "screen_name" : "nicidienase",
    "protected" : false,
    "id_str" : "22396883",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3125784966/8223a4c5c9535be22d15c82ec829c2df_normal.jpeg",
    "id" : 22396883,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "*andy",
      "screen_name" : "derGeruhn",
      "indices" : [ 3, 13 ],
      "id_str" : "936437276",
      "id" : 936437276
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "273716430011260929",
  "text" : "RT @derGeruhn: OH(Handy): \"Hey Mama, kann ich heute Abend ein M\u00E4del mitbringen?\" - \"...\" - \"Ja, nur eine.\"",
  "retweeted_status" : {
    "source" : "<a href=\"https://twitter.com/#!/joenrv\" rel=\"nofollow\">Falcon for Android</a>",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : {
    },
    "id_str" : "273706386628681729",
    "text" : "OH(Handy): \"Hey Mama, kann ich heute Abend ein M\u00E4del mitbringen?\" - \"...\" - \"Ja, nur eine.\"",
    "id" : 273706386628681729,
    "created_at" : "Wed Nov 28 08:34:22 +0000 2012",
    "user" : {
      "name" : "*andy",
      "screen_name" : "derGeruhn",
      "protected" : false,
      "id_str" : "936437276",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/3034420321/a4487789b515735fbc9522da5029aa43_normal.png",
      "id" : 936437276,
      "verified" : false
    }
  },
  "id" : 273716430011260929,
  "created_at" : "Wed Nov 28 09:14:16 +0000 2012",
  "user" : {
    "name" : "Felix",
    "screen_name" : "nicidienase",
    "protected" : false,
    "id_str" : "22396883",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3125784966/8223a4c5c9535be22d15c82ec829c2df_normal.jpeg",
    "id" : 22396883,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "fRED",
      "screen_name" : "fRANDOM74",
      "indices" : [ 3, 13 ],
      "id_str" : "21088644",
      "id" : 21088644
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 42, 62 ],
      "url" : "http://t.co/hH4UXg05",
      "expanded_url" : "http://twitter.com/fRANDOM74/status/273231367586869248/photo/1",
      "display_url" : "pic.twitter.com/hH4UXg05"
    } ]
  },
  "geo" : {
  },
  "id_str" : "273346737635221504",
  "text" : "RT @fRANDOM74: Popcorn ist das neue Gr\u00FCn. http://t.co/hH4UXg05",
  "retweeted_status" : {
    "source" : "<a href=\"http://www.apple.com\" rel=\"nofollow\">Photos on iOS</a>",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "http://twitter.com/fRANDOM74/status/273231367586869248/photo/1",
        "indices" : [ 27, 47 ],
        "url" : "http://t.co/hH4UXg05",
        "media_url" : "http://pbs.twimg.com/media/A8q2ey8CcAAP3UB.jpg",
        "id_str" : "273231367595257856",
        "id" : 273231367595257856,
        "media_url_https" : "https://pbs.twimg.com/media/A8q2ey8CcAAP3UB.jpg",
        "sizes" : [ {
          "h" : 1136,
          "resize" : "fit",
          "w" : 852
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 453,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 800,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 1136,
          "resize" : "fit",
          "w" : 852
        } ],
        "display_url" : "pic.twitter.com/hH4UXg05"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : {
    },
    "id_str" : "273231367586869248",
    "text" : "Popcorn ist das neue Gr\u00FCn. http://t.co/hH4UXg05",
    "id" : 273231367586869248,
    "created_at" : "Tue Nov 27 01:06:49 +0000 2012",
    "user" : {
      "name" : "fRED",
      "screen_name" : "fRANDOM74",
      "protected" : false,
      "id_str" : "21088644",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/2496030121/onfzh66acb6exx474gcr_normal.png",
      "id" : 21088644,
      "verified" : false
    }
  },
  "id" : 273346737635221504,
  "created_at" : "Tue Nov 27 08:45:15 +0000 2012",
  "user" : {
    "name" : "Felix",
    "screen_name" : "nicidienase",
    "protected" : false,
    "id_str" : "22396883",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3125784966/8223a4c5c9535be22d15c82ec829c2df_normal.jpeg",
    "id" : 22396883,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mario Sixtus",
      "screen_name" : "sixtus",
      "indices" : [ 3, 10 ],
      "id_str" : "9334352",
      "id" : 9334352
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 42, 62 ],
      "url" : "http://t.co/0Gq64bhc",
      "expanded_url" : "http://www.thinkgeek.com/product/f029/",
      "display_url" : "thinkgeek.com/product/f029/"
    } ]
  },
  "geo" : {
  },
  "id_str" : "272688560988123136",
  "text" : "RT @sixtus: Endlich: Star-Trek-Unterhosen http://t.co/0Gq64bhc",
  "retweeted_status" : {
    "source" : "web",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 30, 50 ],
        "url" : "http://t.co/0Gq64bhc",
        "expanded_url" : "http://www.thinkgeek.com/product/f029/",
        "display_url" : "thinkgeek.com/product/f029/"
      } ]
    },
    "geo" : {
    },
    "id_str" : "272680609300770816",
    "text" : "Endlich: Star-Trek-Unterhosen http://t.co/0Gq64bhc",
    "id" : 272680609300770816,
    "created_at" : "Sun Nov 25 12:38:18 +0000 2012",
    "user" : {
      "name" : "Mario Sixtus",
      "screen_name" : "sixtus",
      "protected" : false,
      "id_str" : "9334352",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/274542155/mario_normal.gif",
      "id" : 9334352,
      "verified" : true
    }
  },
  "id" : 272688560988123136,
  "created_at" : "Sun Nov 25 13:09:53 +0000 2012",
  "user" : {
    "name" : "Felix",
    "screen_name" : "nicidienase",
    "protected" : false,
    "id_str" : "22396883",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3125784966/8223a4c5c9535be22d15c82ec829c2df_normal.jpeg",
    "id" : 22396883,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Unix tool tip",
      "screen_name" : "UnixToolTip",
      "indices" : [ 3, 15 ],
      "id_str" : "363210621",
      "id" : 363210621
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 102, 122 ],
      "url" : "http://t.co/RhR2J69p",
      "expanded_url" : "http://ow.ly/fxfUw",
      "display_url" : "ow.ly/fxfUw"
    } ]
  },
  "geo" : {
  },
  "id_str" : "272304139566997504",
  "text" : "RT @UnixToolTip: \"Git\u2019s overloaded, confusing language is absolutely the only part of it that sucks.\" http://t.co/RhR2J69p",
  "retweeted_status" : {
    "source" : "<a href=\"http://www.hootsuite.com\" rel=\"nofollow\">HootSuite</a>",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 85, 105 ],
        "url" : "http://t.co/RhR2J69p",
        "expanded_url" : "http://ow.ly/fxfUw",
        "display_url" : "ow.ly/fxfUw"
      } ]
    },
    "geo" : {
    },
    "id_str" : "272142130766561280",
    "text" : "\"Git\u2019s overloaded, confusing language is absolutely the only part of it that sucks.\" http://t.co/RhR2J69p",
    "id" : 272142130766561280,
    "created_at" : "Sat Nov 24 00:58:34 +0000 2012",
    "user" : {
      "name" : "Unix tool tip",
      "screen_name" : "UnixToolTip",
      "protected" : false,
      "id_str" : "363210621",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/1516185858/SedAwk_normal.png",
      "id" : 363210621,
      "verified" : false
    }
  },
  "id" : 272304139566997504,
  "created_at" : "Sat Nov 24 11:42:20 +0000 2012",
  "user" : {
    "name" : "Felix",
    "screen_name" : "nicidienase",
    "protected" : false,
    "id_str" : "22396883",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3125784966/8223a4c5c9535be22d15c82ec829c2df_normal.jpeg",
    "id" : 22396883,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "psy",
      "screen_name" : "psycon",
      "indices" : [ 0, 7 ],
      "id_str" : "87286054",
      "id" : 87286054
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "271928973703925760",
  "geo" : {
  },
  "id_str" : "271940393334079488",
  "in_reply_to_user_id" : 87286054,
  "text" : "@psycon Rauchen ja, Zigaretten nein",
  "id" : 271940393334079488,
  "in_reply_to_status_id" : 271928973703925760,
  "created_at" : "Fri Nov 23 11:36:56 +0000 2012",
  "in_reply_to_screen_name" : "psycon",
  "in_reply_to_user_id_str" : "87286054",
  "user" : {
    "name" : "Felix",
    "screen_name" : "nicidienase",
    "protected" : false,
    "id_str" : "22396883",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3125784966/8223a4c5c9535be22d15c82ec829c2df_normal.jpeg",
    "id" : 22396883,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "psy",
      "screen_name" : "psycon",
      "indices" : [ 0, 7 ],
      "id_str" : "87286054",
      "id" : 87286054
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "271655622729154560",
  "geo" : {
  },
  "id_str" : "271708360087318529",
  "in_reply_to_user_id" : 87286054,
  "text" : "@psycon Ich auch schon den ganzen Tag.",
  "id" : 271708360087318529,
  "in_reply_to_status_id" : 271655622729154560,
  "created_at" : "Thu Nov 22 20:14:55 +0000 2012",
  "in_reply_to_screen_name" : "psycon",
  "in_reply_to_user_id_str" : "87286054",
  "user" : {
    "name" : "Felix",
    "screen_name" : "nicidienase",
    "protected" : false,
    "id_str" : "22396883",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3125784966/8223a4c5c9535be22d15c82ec829c2df_normal.jpeg",
    "id" : 22396883,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.echofon.com/\" rel=\"nofollow\">Echofon</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Koffeinentzug",
      "indices" : [ 79, 93 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "271538935346380800",
  "text" : "Kaffe intus und immer noch m\u00FCde. Mate hilft auch noch nicht. Ich muss echt mal #Koffeinentzug machen, dass das Zeug wieder wirkt.",
  "id" : 271538935346380800,
  "created_at" : "Thu Nov 22 09:01:41 +0000 2012",
  "user" : {
    "name" : "Felix",
    "screen_name" : "nicidienase",
    "protected" : false,
    "id_str" : "22396883",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3125784966/8223a4c5c9535be22d15c82ec829c2df_normal.jpeg",
    "id" : 22396883,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Will Kerslake",
      "screen_name" : "wkerslake",
      "indices" : [ 3, 13 ],
      "id_str" : "57477810",
      "id" : 57477810
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 54, 74 ],
      "url" : "http://t.co/wvEohn74",
      "expanded_url" : "http://i.imgur.com/p6tda.jpg",
      "display_url" : "i.imgur.com/p6tda.jpg"
    } ]
  },
  "geo" : {
  },
  "id_str" : "271530242169004032",
  "text" : "RT @wkerslake: Well played online comic, well played: http://t.co/wvEohn74",
  "retweeted_status" : {
    "source" : "<a href=\"http://www.tweetdeck.com\" rel=\"nofollow\">TweetDeck</a>",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 39, 59 ],
        "url" : "http://t.co/wvEohn74",
        "expanded_url" : "http://i.imgur.com/p6tda.jpg",
        "display_url" : "i.imgur.com/p6tda.jpg"
      } ]
    },
    "geo" : {
    },
    "id_str" : "270061068343193600",
    "text" : "Well played online comic, well played: http://t.co/wvEohn74",
    "id" : 270061068343193600,
    "created_at" : "Sun Nov 18 07:09:10 +0000 2012",
    "user" : {
      "name" : "Will Kerslake",
      "screen_name" : "wkerslake",
      "protected" : false,
      "id_str" : "57477810",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/2584760646/dxw5ot08uxrrly8cegpp_normal.jpeg",
      "id" : 57477810,
      "verified" : false
    }
  },
  "id" : 271530242169004032,
  "created_at" : "Thu Nov 22 08:27:09 +0000 2012",
  "user" : {
    "name" : "Felix",
    "screen_name" : "nicidienase",
    "protected" : false,
    "id_str" : "22396883",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3125784966/8223a4c5c9535be22d15c82ec829c2df_normal.jpeg",
    "id" : 22396883,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "271011936337031168",
  "geo" : {
  },
  "id_str" : "271042741297889280",
  "in_reply_to_user_id" : 121226933,
  "text" : "@NervengiftC Was den f\u00FCr eine? Trage mich grade auch mit dem Gedanken mir eine neue zuzulegen.",
  "id" : 271042741297889280,
  "in_reply_to_status_id" : 271011936337031168,
  "created_at" : "Wed Nov 21 00:09:59 +0000 2012",
  "in_reply_to_screen_name" : "nervengiftlabs",
  "in_reply_to_user_id_str" : "121226933",
  "user" : {
    "name" : "Felix",
    "screen_name" : "nicidienase",
    "protected" : false,
    "id_str" : "22396883",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3125784966/8223a4c5c9535be22d15c82ec829c2df_normal.jpeg",
    "id" : 22396883,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "b2m",
      "screen_name" : "Balzac2m",
      "indices" : [ 3, 12 ],
      "id_str" : "75023957",
      "id" : 75023957
    }, {
      "name" : "Eva Eichhorn",
      "screen_name" : "MamsellChaos",
      "indices" : [ 18, 31 ],
      "id_str" : "140774041",
      "id" : 140774041
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "270528616771751937",
  "text" : "RT @Balzac2m: Bei @MamsellChaos besgeisterter Suche nach dem heiligen BH-Gral w\u00FCnscht man sich direkt Br\u00FCste",
  "retweeted_status" : {
    "source" : "web",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Eva Eichhorn",
        "screen_name" : "MamsellChaos",
        "indices" : [ 4, 17 ],
        "id_str" : "140774041",
        "id" : 140774041
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : {
    },
    "id_str" : "270485964114235392",
    "text" : "Bei @MamsellChaos besgeisterter Suche nach dem heiligen BH-Gral w\u00FCnscht man sich direkt Br\u00FCste",
    "id" : 270485964114235392,
    "created_at" : "Mon Nov 19 11:17:33 +0000 2012",
    "user" : {
      "name" : "b2m",
      "screen_name" : "Balzac2m",
      "protected" : false,
      "id_str" : "75023957",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/2856265523/7f14e31568e85e800761eeed3bef98a0_normal.png",
      "id" : 75023957,
      "verified" : false
    }
  },
  "id" : 270528616771751937,
  "created_at" : "Mon Nov 19 14:07:03 +0000 2012",
  "user" : {
    "name" : "Felix",
    "screen_name" : "nicidienase",
    "protected" : false,
    "id_str" : "22396883",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3125784966/8223a4c5c9535be22d15c82ec829c2df_normal.jpeg",
    "id" : 22396883,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "m.",
      "screen_name" : "ohaimareiki",
      "indices" : [ 0, 12 ],
      "id_str" : "14732096",
      "id" : 14732096
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "269863806648324096",
  "geo" : {
  },
  "id_str" : "269865497225490432",
  "in_reply_to_user_id" : 14732096,
  "text" : "@ohaimareiki blaues Mett? Klingt nicht grade nach ne Verkaufsschlager.",
  "id" : 269865497225490432,
  "in_reply_to_status_id" : 269863806648324096,
  "created_at" : "Sat Nov 17 18:12:03 +0000 2012",
  "in_reply_to_screen_name" : "ohaimareiki",
  "in_reply_to_user_id_str" : "14732096",
  "user" : {
    "name" : "Felix",
    "screen_name" : "nicidienase",
    "protected" : false,
    "id_str" : "22396883",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3125784966/8223a4c5c9535be22d15c82ec829c2df_normal.jpeg",
    "id" : 22396883,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.echofon.com/\" rel=\"nofollow\">Echofon</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "ESA auf Deutsch",
      "screen_name" : "ESA_de",
      "indices" : [ 3, 10 ],
      "id_str" : "19766517",
      "id" : 19766517
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "100000stars",
      "indices" : [ 125, 137 ]
    } ],
    "urls" : [ {
      "indices" : [ 83, 103 ],
      "url" : "http://t.co/g3TgAOs5",
      "expanded_url" : "http://workshop.chromeexperiments.com/stars/",
      "display_url" : "workshop.chromeexperiments.com/stars/"
    } ]
  },
  "geo" : {
  },
  "id_str" : "269392437745709056",
  "text" : "RT @ESA_de: Wir lieben diese Visualisierung: Unsere n\u00E4chsten 119.617 Nachbarsterne http://t.co/g3TgAOs5  (f\u00FCr Google Chrome) #100000stars",
  "retweeted_status" : {
    "source" : "<a href=\"http://www.tweetdeck.com\" rel=\"nofollow\">TweetDeck</a>",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "100000stars",
        "indices" : [ 113, 125 ]
      } ],
      "urls" : [ {
        "indices" : [ 71, 91 ],
        "url" : "http://t.co/g3TgAOs5",
        "expanded_url" : "http://workshop.chromeexperiments.com/stars/",
        "display_url" : "workshop.chromeexperiments.com/stars/"
      } ]
    },
    "geo" : {
    },
    "id_str" : "269381561076551680",
    "text" : "Wir lieben diese Visualisierung: Unsere n\u00E4chsten 119.617 Nachbarsterne http://t.co/g3TgAOs5  (f\u00FCr Google Chrome) #100000stars",
    "id" : 269381561076551680,
    "created_at" : "Fri Nov 16 10:09:03 +0000 2012",
    "user" : {
      "name" : "ESA auf Deutsch",
      "screen_name" : "ESA_de",
      "protected" : false,
      "id_str" : "19766517",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/1799158700/esa_DE_twitter_avatar_normal.png",
      "id" : 19766517,
      "verified" : true
    }
  },
  "id" : 269392437745709056,
  "created_at" : "Fri Nov 16 10:52:16 +0000 2012",
  "user" : {
    "name" : "Felix",
    "screen_name" : "nicidienase",
    "protected" : false,
    "id_str" : "22396883",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3125784966/8223a4c5c9535be22d15c82ec829c2df_normal.jpeg",
    "id" : 22396883,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "MEEDIA",
      "screen_name" : "MEEDIA",
      "indices" : [ 3, 10 ],
      "id_str" : "14497517",
      "id" : 14497517
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 114, 134 ],
      "url" : "http://t.co/s4dHGqwi",
      "expanded_url" : "http://meedia.de/internet/alligator-lebt-in-google-serverzentrum/2012/11/16.html",
      "display_url" : "meedia.de/internet/allig\u2026"
    } ]
  },
  "geo" : {
  },
  "id_str" : "269380138200862720",
  "text" : "RT @MEEDIA: In einem Google-Serverzentrum in den USA hat sich ein Alligator im K\u00FChlbecken h\u00E4uslich eingerichtet - http://t.co/s4dHGqwi",
  "retweeted_status" : {
    "source" : "<a href=\"http://tapbots.com/software/tweetbot/mac\" rel=\"nofollow\">Tweetbot for Mac</a>",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 102, 122 ],
        "url" : "http://t.co/s4dHGqwi",
        "expanded_url" : "http://meedia.de/internet/alligator-lebt-in-google-serverzentrum/2012/11/16.html",
        "display_url" : "meedia.de/internet/allig\u2026"
      } ]
    },
    "geo" : {
    },
    "id_str" : "269362796653838336",
    "text" : "In einem Google-Serverzentrum in den USA hat sich ein Alligator im K\u00FChlbecken h\u00E4uslich eingerichtet - http://t.co/s4dHGqwi",
    "id" : 269362796653838336,
    "created_at" : "Fri Nov 16 08:54:29 +0000 2012",
    "user" : {
      "name" : "MEEDIA",
      "screen_name" : "MEEDIA",
      "protected" : false,
      "id_str" : "14497517",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/71252699/logo_normal.jpg",
      "id" : 14497517,
      "verified" : false
    }
  },
  "id" : 269380138200862720,
  "created_at" : "Fri Nov 16 10:03:24 +0000 2012",
  "user" : {
    "name" : "Felix",
    "screen_name" : "nicidienase",
    "protected" : false,
    "id_str" : "22396883",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3125784966/8223a4c5c9535be22d15c82ec829c2df_normal.jpeg",
    "id" : 22396883,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "insa. oh insa.",
      "screen_name" : "inschka",
      "indices" : [ 3, 11 ],
      "id_str" : "14108955",
      "id" : 14108955
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 13, 33 ],
      "url" : "http://t.co/z9BeoEvW",
      "expanded_url" : "http://youtu.be/dql26ssMcVI",
      "display_url" : "youtu.be/dql26ssMcVI"
    } ]
  },
  "geo" : {
  },
  "id_str" : "269196607579373568",
  "text" : "RT @inschka: http://t.co/z9BeoEvW Wie gut ist das denn bitte? Die Crew von Big Bang Theory startet einen Flash Mob im Studio.",
  "retweeted_status" : {
    "source" : "web",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 0, 20 ],
        "url" : "http://t.co/z9BeoEvW",
        "expanded_url" : "http://youtu.be/dql26ssMcVI",
        "display_url" : "youtu.be/dql26ssMcVI"
      } ]
    },
    "geo" : {
    },
    "id_str" : "269192934681890816",
    "text" : "http://t.co/z9BeoEvW Wie gut ist das denn bitte? Die Crew von Big Bang Theory startet einen Flash Mob im Studio.",
    "id" : 269192934681890816,
    "created_at" : "Thu Nov 15 21:39:31 +0000 2012",
    "user" : {
      "name" : "insa. oh insa.",
      "screen_name" : "inschka",
      "protected" : false,
      "id_str" : "14108955",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/2514132704/jdm9cigujl3rgxj7ad66_normal.jpeg",
      "id" : 14108955,
      "verified" : false
    }
  },
  "id" : 269196607579373568,
  "created_at" : "Thu Nov 15 21:54:07 +0000 2012",
  "user" : {
    "name" : "Felix",
    "screen_name" : "nicidienase",
    "protected" : false,
    "id_str" : "22396883",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3125784966/8223a4c5c9535be22d15c82ec829c2df_normal.jpeg",
    "id" : 22396883,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jens Ohlig",
      "screen_name" : "johl",
      "indices" : [ 3, 8 ],
      "id_str" : "1147751",
      "id" : 1147751
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "269194727776194560",
  "text" : "RT @johl: OH: \"wer zuerst pusht muss nicht mergen\"",
  "retweeted_status" : {
    "source" : "<a href=\"http://itunes.apple.com/us/app/twitter/id409789998?mt=12\" rel=\"nofollow\">Twitter for Mac</a>",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : {
    },
    "id_str" : "269132882075869186",
    "text" : "OH: \"wer zuerst pusht muss nicht mergen\"",
    "id" : 269132882075869186,
    "created_at" : "Thu Nov 15 17:40:53 +0000 2012",
    "user" : {
      "name" : "Jens Ohlig",
      "screen_name" : "johl",
      "protected" : false,
      "id_str" : "1147751",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/2396409791/oeym506iih2iyj0e80f9_normal.png",
      "id" : 1147751,
      "verified" : false
    }
  },
  "id" : 269194727776194560,
  "created_at" : "Thu Nov 15 21:46:39 +0000 2012",
  "user" : {
    "name" : "Felix",
    "screen_name" : "nicidienase",
    "protected" : false,
    "id_str" : "22396883",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3125784966/8223a4c5c9535be22d15c82ec829c2df_normal.jpeg",
    "id" : 22396883,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lilly W.",
      "screen_name" : "dielilly",
      "indices" : [ 0, 9 ],
      "id_str" : "19603003",
      "id" : 19603003
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "269121539956436994",
  "geo" : {
  },
  "id_str" : "269192649603436544",
  "in_reply_to_user_id" : 19603003,
  "text" : "@dielilly das schaffe ich wochenlang",
  "id" : 269192649603436544,
  "in_reply_to_status_id" : 269121539956436994,
  "created_at" : "Thu Nov 15 21:38:23 +0000 2012",
  "in_reply_to_screen_name" : "dielilly",
  "in_reply_to_user_id_str" : "19603003",
  "user" : {
    "name" : "Felix",
    "screen_name" : "nicidienase",
    "protected" : false,
    "id_str" : "22396883",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3125784966/8223a4c5c9535be22d15c82ec829c2df_normal.jpeg",
    "id" : 22396883,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sex Facts Of Life",
      "screen_name" : "SexFactsOfLife",
      "indices" : [ 3, 18 ],
      "id_str" : "264257750",
      "id" : 264257750
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "268866111431385089",
  "text" : "RT @SexFactsOfLife: If you type \"coughing\" into Google images, it looks like a bunch of people giving blowjobs to an invisible man.",
  "retweeted_status" : {
    "source" : "<a href=\"http://www.tweetdeck.com\" rel=\"nofollow\">TweetDeck</a>",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : {
    },
    "id_str" : "268493695823773696",
    "text" : "If you type \"coughing\" into Google images, it looks like a bunch of people giving blowjobs to an invisible man.",
    "id" : 268493695823773696,
    "created_at" : "Tue Nov 13 23:21:00 +0000 2012",
    "user" : {
      "name" : "Sex Facts Of Life",
      "screen_name" : "SexFactsOfLife",
      "protected" : false,
      "id_str" : "264257750",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/1713005106/image_normal.jpg",
      "id" : 264257750,
      "verified" : true
    }
  },
  "id" : 268866111431385089,
  "created_at" : "Thu Nov 15 00:00:50 +0000 2012",
  "user" : {
    "name" : "Felix",
    "screen_name" : "nicidienase",
    "protected" : false,
    "id_str" : "22396883",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3125784966/8223a4c5c9535be22d15c82ec829c2df_normal.jpeg",
    "id" : 22396883,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "*andy",
      "screen_name" : "derGeruhn",
      "indices" : [ 0, 10 ],
      "id_str" : "936437276",
      "id" : 936437276
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "268314556013613056",
  "geo" : {
  },
  "id_str" : "268315233012047872",
  "in_reply_to_user_id" : 936437276,
  "text" : "@derGeruhn f\u00FCr Handschriftliches will man glaub ich nen Stift.",
  "id" : 268315233012047872,
  "in_reply_to_status_id" : 268314556013613056,
  "created_at" : "Tue Nov 13 11:31:51 +0000 2012",
  "in_reply_to_screen_name" : "derGeruhn",
  "in_reply_to_user_id_str" : "936437276",
  "user" : {
    "name" : "Felix",
    "screen_name" : "nicidienase",
    "protected" : false,
    "id_str" : "22396883",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3125784966/8223a4c5c9535be22d15c82ec829c2df_normal.jpeg",
    "id" : 22396883,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "*andy",
      "screen_name" : "derGeruhn",
      "indices" : [ 0, 10 ],
      "id_str" : "936437276",
      "id" : 936437276
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "268310556325318656",
  "geo" : {
  },
  "id_str" : "268311353322786816",
  "in_reply_to_user_id" : 936437276,
  "text" : "@derGeruhn es liegt gut in der Hand. Aber wenn du es nur daheim benutzen willst wurde ich ein 10' nehmen. F\u00FCr unterwegs sind 7' ganz gut.",
  "id" : 268311353322786816,
  "in_reply_to_status_id" : 268310556325318656,
  "created_at" : "Tue Nov 13 11:16:26 +0000 2012",
  "in_reply_to_screen_name" : "derGeruhn",
  "in_reply_to_user_id_str" : "936437276",
  "user" : {
    "name" : "Felix",
    "screen_name" : "nicidienase",
    "protected" : false,
    "id_str" : "22396883",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3125784966/8223a4c5c9535be22d15c82ec829c2df_normal.jpeg",
    "id" : 22396883,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "*andy",
      "screen_name" : "derGeruhn",
      "indices" : [ 0, 10 ],
      "id_str" : "936437276",
      "id" : 936437276
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "268310071002411009",
  "geo" : {
  },
  "id_str" : "268310380521062400",
  "in_reply_to_user_id" : 936437276,
  "text" : "@derGeruhn ich hab halt schon ein 10' Tablet. Aber das hat kein UMTS.",
  "id" : 268310380521062400,
  "in_reply_to_status_id" : 268310071002411009,
  "created_at" : "Tue Nov 13 11:12:34 +0000 2012",
  "in_reply_to_screen_name" : "derGeruhn",
  "in_reply_to_user_id_str" : "936437276",
  "user" : {
    "name" : "Felix",
    "screen_name" : "nicidienase",
    "protected" : false,
    "id_str" : "22396883",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3125784966/8223a4c5c9535be22d15c82ec829c2df_normal.jpeg",
    "id" : 22396883,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.echofon.com/\" rel=\"nofollow\">Echofon</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "268292217683202049",
  "text" : "Hmm, will ich ein Nexus7 mit UMTS?",
  "id" : 268292217683202049,
  "created_at" : "Tue Nov 13 10:00:23 +0000 2012",
  "user" : {
    "name" : "Felix",
    "screen_name" : "nicidienase",
    "protected" : false,
    "id_str" : "22396883",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3125784966/8223a4c5c9535be22d15c82ec829c2df_normal.jpeg",
    "id" : 22396883,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/tweetbutton\" rel=\"nofollow\">Tweet Button</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "YouTube",
      "screen_name" : "YouTube",
      "indices" : [ 92, 100 ],
      "id_str" : "10228272",
      "id" : 10228272
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 67, 87 ],
      "url" : "http://t.co/AwMRq7aF",
      "expanded_url" : "http://youtu.be/3Fe-a2gUccs",
      "display_url" : "youtu.be/3Fe-a2gUccs"
    } ]
  },
  "geo" : {
  },
  "id_str" : "268104021800275969",
  "text" : "Science Slam Uni Mannheim, Platz 1: \u201EFrauentheorie\" (Robert Idel): http://t.co/AwMRq7aF via @youtube",
  "id" : 268104021800275969,
  "created_at" : "Mon Nov 12 21:32:34 +0000 2012",
  "user" : {
    "name" : "Felix",
    "screen_name" : "nicidienase",
    "protected" : false,
    "id_str" : "22396883",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3125784966/8223a4c5c9535be22d15c82ec829c2df_normal.jpeg",
    "id" : 22396883,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "psy",
      "screen_name" : "psycon",
      "indices" : [ 0, 7 ],
      "id_str" : "87286054",
      "id" : 87286054
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "267974303327326208",
  "geo" : {
  },
  "id_str" : "267974525914857472",
  "in_reply_to_user_id" : 87286054,
  "text" : "@psycon Ja.",
  "id" : 267974525914857472,
  "in_reply_to_status_id" : 267974303327326208,
  "created_at" : "Mon Nov 12 12:58:00 +0000 2012",
  "in_reply_to_screen_name" : "psycon",
  "in_reply_to_user_id_str" : "87286054",
  "user" : {
    "name" : "Felix",
    "screen_name" : "nicidienase",
    "protected" : false,
    "id_str" : "22396883",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3125784966/8223a4c5c9535be22d15c82ec829c2df_normal.jpeg",
    "id" : 22396883,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "psy",
      "screen_name" : "psycon",
      "indices" : [ 0, 7 ],
      "id_str" : "87286054",
      "id" : 87286054
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "267973995830312960",
  "geo" : {
  },
  "id_str" : "267974464053075968",
  "in_reply_to_user_id" : 87286054,
  "text" : "@psycon Das is so der \"falls gerade sonst nix passt\"-Paragraph.",
  "id" : 267974464053075968,
  "in_reply_to_status_id" : 267973995830312960,
  "created_at" : "Mon Nov 12 12:57:45 +0000 2012",
  "in_reply_to_screen_name" : "psycon",
  "in_reply_to_user_id_str" : "87286054",
  "user" : {
    "name" : "Felix",
    "screen_name" : "nicidienase",
    "protected" : false,
    "id_str" : "22396883",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3125784966/8223a4c5c9535be22d15c82ec829c2df_normal.jpeg",
    "id" : 22396883,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.echofon.com/\" rel=\"nofollow\">Echofon</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "psy",
      "screen_name" : "psycon",
      "indices" : [ 0, 7 ],
      "id_str" : "87286054",
      "id" : 87286054
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "267690489183084545",
  "geo" : {
  },
  "id_str" : "267970065922662401",
  "in_reply_to_user_id" : 87286054,
  "text" : "@psycon Besch\u00E4digung eines anderen Verkehrsteilnehmers.",
  "id" : 267970065922662401,
  "in_reply_to_status_id" : 267690489183084545,
  "created_at" : "Mon Nov 12 12:40:17 +0000 2012",
  "in_reply_to_screen_name" : "psycon",
  "in_reply_to_user_id_str" : "87286054",
  "user" : {
    "name" : "Felix",
    "screen_name" : "nicidienase",
    "protected" : false,
    "id_str" : "22396883",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3125784966/8223a4c5c9535be22d15c82ec829c2df_normal.jpeg",
    "id" : 22396883,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/tweetbutton\" rel=\"nofollow\">Tweet Button</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 88, 108 ],
      "url" : "http://t.co/Ul8l4IPX",
      "expanded_url" : "http://thatcan.be/my/next/tweet",
      "display_url" : "thatcan.be/my/next/tweet"
    } ]
  },
  "geo" : {
  },
  "id_str" : "267969794517630977",
  "text" : "AK-Zeitplan im Kopf. B\u00E4\u00E4\u00E4h. Mir is half empty, the optimist says the physicist ducks. \u2014 http://t.co/Ul8l4IPX",
  "id" : 267969794517630977,
  "created_at" : "Mon Nov 12 12:39:12 +0000 2012",
  "user" : {
    "name" : "Felix",
    "screen_name" : "nicidienase",
    "protected" : false,
    "id_str" : "22396883",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3125784966/8223a4c5c9535be22d15c82ec829c2df_normal.jpeg",
    "id" : 22396883,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "psy",
      "screen_name" : "psycon",
      "indices" : [ 0, 7 ],
      "id_str" : "87286054",
      "id" : 87286054
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "267689902626439168",
  "geo" : {
  },
  "id_str" : "267690171422613504",
  "in_reply_to_user_id" : 87286054,
  "text" : "@psycon Weil ich gegen ein parkendes Auto gefahren bin.",
  "id" : 267690171422613504,
  "in_reply_to_status_id" : 267689902626439168,
  "created_at" : "Sun Nov 11 18:08:04 +0000 2012",
  "in_reply_to_screen_name" : "psycon",
  "in_reply_to_user_id_str" : "87286054",
  "user" : {
    "name" : "Felix",
    "screen_name" : "nicidienase",
    "protected" : false,
    "id_str" : "22396883",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3125784966/8223a4c5c9535be22d15c82ec829c2df_normal.jpeg",
    "id" : 22396883,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "kif405",
      "indices" : [ 102, 109 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "267687397913944065",
  "text" : "Schei\u00DF Karma. Alles wunderbar geklappt und auf den letzten Metern ein Parkrempler und 35\u20AC Verwarnung. #kif405",
  "id" : 267687397913944065,
  "created_at" : "Sun Nov 11 17:57:03 +0000 2012",
  "user" : {
    "name" : "Felix",
    "screen_name" : "nicidienase",
    "protected" : false,
    "id_str" : "22396883",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3125784966/8223a4c5c9535be22d15c82ec829c2df_normal.jpeg",
    "id" : 22396883,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "kif405",
      "indices" : [ 21, 28 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "267578582069551104",
  "text" : "A29 Bahn frei. -Kami #kif405",
  "id" : 267578582069551104,
  "created_at" : "Sun Nov 11 10:44:39 +0000 2012",
  "user" : {
    "name" : "Felix",
    "screen_name" : "nicidienase",
    "protected" : false,
    "id_str" : "22396883",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3125784966/8223a4c5c9535be22d15c82ec829c2df_normal.jpeg",
    "id" : 22396883,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "kif405",
      "indices" : [ 93, 100 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "267557487870357505",
  "text" : "Im KIF-Cafe is viel zu hell. Man kann die Twitterwall nicht mehr lesen. Ich prangere das an! #kif405",
  "id" : 267557487870357505,
  "created_at" : "Sun Nov 11 09:20:50 +0000 2012",
  "user" : {
    "name" : "Felix",
    "screen_name" : "nicidienase",
    "protected" : false,
    "id_str" : "22396883",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3125784966/8223a4c5c9535be22d15c82ec829c2df_normal.jpeg",
    "id" : 22396883,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.echofon.com/\" rel=\"nofollow\">Echofon</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Benedikt Haug",
      "screen_name" : "gna582",
      "indices" : [ 54, 61 ],
      "id_str" : "935270006",
      "id" : 935270006
    }, {
      "name" : "kamikaze.de",
      "screen_name" : "lonkamikaze",
      "indices" : [ 62, 74 ],
      "id_str" : "935331409",
      "id" : 935331409
    }, {
      "name" : "*andy",
      "screen_name" : "derGeruhn",
      "indices" : [ 75, 85 ],
      "id_str" : "936437276",
      "id" : 936437276
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "kif405",
      "indices" : [ 86, 93 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "267556182581981184",
  "text" : "An alle Karlsruher: Anvisierte Abfahrtszeit ist 11Uhr @gna582 @lonkamikaze @derGeruhn #kif405",
  "id" : 267556182581981184,
  "created_at" : "Sun Nov 11 09:15:39 +0000 2012",
  "user" : {
    "name" : "Felix",
    "screen_name" : "nicidienase",
    "protected" : false,
    "id_str" : "22396883",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3125784966/8223a4c5c9535be22d15c82ec829c2df_normal.jpeg",
    "id" : 22396883,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.echofon.com/\" rel=\"nofollow\">Echofon</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "kif405",
      "indices" : [ 76, 83 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "267442516754825216",
  "text" : "Zweite Reso ist durch. Dieses Mal nicht mehr ganz so enthusiastisches Yeah. #kif405",
  "id" : 267442516754825216,
  "created_at" : "Sun Nov 11 01:43:59 +0000 2012",
  "user" : {
    "name" : "Felix",
    "screen_name" : "nicidienase",
    "protected" : false,
    "id_str" : "22396883",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3125784966/8223a4c5c9535be22d15c82ec829c2df_normal.jpeg",
    "id" : 22396883,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.echofon.com/\" rel=\"nofollow\">Echofon</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "kif405",
      "indices" : [ 44, 51 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "267425910108585985",
  "text" : "Erste Reso verabschiedet. Und alle so YEAH! #kif405",
  "id" : 267425910108585985,
  "created_at" : "Sun Nov 11 00:38:00 +0000 2012",
  "user" : {
    "name" : "Felix",
    "screen_name" : "nicidienase",
    "protected" : false,
    "id_str" : "22396883",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3125784966/8223a4c5c9535be22d15c82ec829c2df_normal.jpeg",
    "id" : 22396883,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "kif405",
      "indices" : [ 25, 32 ]
    }, {
      "text" : "kneipentour",
      "indices" : [ 33, 45 ]
    }, {
      "text" : "gutenacht",
      "indices" : [ 46, 56 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "267120024290992129",
  "text" : "Hilfe! Alles dreht sich. #kif405 #kneipentour #gutenacht",
  "id" : 267120024290992129,
  "created_at" : "Sat Nov 10 04:22:31 +0000 2012",
  "user" : {
    "name" : "Felix",
    "screen_name" : "nicidienase",
    "protected" : false,
    "id_str" : "22396883",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3125784966/8223a4c5c9535be22d15c82ec829c2df_normal.jpeg",
    "id" : 22396883,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "kif405",
      "indices" : [ 49, 56 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "267094358627586048",
  "text" : "Br\u00FCste sind praktisch. Z.B. um Bier abzustellen. #kif405",
  "id" : 267094358627586048,
  "created_at" : "Sat Nov 10 02:40:32 +0000 2012",
  "user" : {
    "name" : "Felix",
    "screen_name" : "nicidienase",
    "protected" : false,
    "id_str" : "22396883",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3125784966/8223a4c5c9535be22d15c82ec829c2df_normal.jpeg",
    "id" : 22396883,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "kif405",
      "indices" : [ 0, 7 ]
    }, {
      "text" : "kneipentour",
      "indices" : [ 8, 20 ]
    }, {
      "text" : "awesome",
      "indices" : [ 21, 29 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "267083355189813248",
  "text" : "#kif405 #kneipentour #awesome",
  "id" : 267083355189813248,
  "created_at" : "Sat Nov 10 01:56:48 +0000 2012",
  "user" : {
    "name" : "Felix",
    "screen_name" : "nicidienase",
    "protected" : false,
    "id_str" : "22396883",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3125784966/8223a4c5c9535be22d15c82ec829c2df_normal.jpeg",
    "id" : 22396883,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http://twitter.com/nicidienase/status/267057879943634944/photo/1",
      "indices" : [ 69, 89 ],
      "url" : "http://t.co/O3OZx7gR",
      "media_url" : "http://pbs.twimg.com/media/A7THuhTCYAI4aY5.jpg",
      "id_str" : "267057879947829250",
      "id" : 267057879947829250,
      "media_url_https" : "https://pbs.twimg.com/media/A7THuhTCYAI4aY5.jpg",
      "sizes" : [ {
        "h" : 450,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 1920,
        "resize" : "fit",
        "w" : 2560
      }, {
        "h" : 768,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 255,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com/O3OZx7gR"
    } ],
    "hashtags" : [ {
      "text" : "kif405",
      "indices" : [ 48, 55 ]
    }, {
      "text" : "awesome",
      "indices" : [ 56, 64 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "267057879943634944",
  "text" : "In Oldenburg gibts Pangalaktische Donnergurgler #kif405 #awesome #42 http://t.co/O3OZx7gR",
  "id" : 267057879943634944,
  "created_at" : "Sat Nov 10 00:15:36 +0000 2012",
  "user" : {
    "name" : "Felix",
    "screen_name" : "nicidienase",
    "protected" : false,
    "id_str" : "22396883",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3125784966/8223a4c5c9535be22d15c82ec829c2df_normal.jpeg",
    "id" : 22396883,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.echofon.com/\" rel=\"nofollow\">Echofon</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "kif405",
      "indices" : [ 111, 118 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "266914989988773888",
  "text" : "Beim Mittagessen gelernt: Das Motto zum 800-j\u00E4hrigen Jublil\u00E4um von Bielefeld ist: \"Das gibt's doch gar nicht\". #kif405",
  "id" : 266914989988773888,
  "created_at" : "Fri Nov 09 14:47:47 +0000 2012",
  "user" : {
    "name" : "Felix",
    "screen_name" : "nicidienase",
    "protected" : false,
    "id_str" : "22396883",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3125784966/8223a4c5c9535be22d15c82ec829c2df_normal.jpeg",
    "id" : 22396883,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.echofon.com/\" rel=\"nofollow\">Echofon</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Kaffe",
      "indices" : [ 51, 57 ]
    }, {
      "text" : "Boden",
      "indices" : [ 58, 64 ]
    }, {
      "text" : "kif405",
      "indices" : [ 65, 72 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "266910850697289728",
  "text" : "Das G\u00E4stebuch ist jetzt ein bisschen koffeinhaltig #Kaffe #Boden #kif405",
  "id" : 266910850697289728,
  "created_at" : "Fri Nov 09 14:31:20 +0000 2012",
  "user" : {
    "name" : "Felix",
    "screen_name" : "nicidienase",
    "protected" : false,
    "id_str" : "22396883",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3125784966/8223a4c5c9535be22d15c82ec829c2df_normal.jpeg",
    "id" : 22396883,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.echofon.com/\" rel=\"nofollow\">Echofon</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "catcontent",
      "indices" : [ 0, 11 ]
    }, {
      "text" : "twitterwall",
      "indices" : [ 12, 24 ]
    }, {
      "text" : "kif405",
      "indices" : [ 25, 32 ]
    } ],
    "urls" : [ {
      "indices" : [ 33, 53 ],
      "url" : "http://t.co/0UJjx8eD",
      "expanded_url" : "http://octodex.github.com/images/nyantocat.gif",
      "display_url" : "octodex.github.com/images/nyantoc\u2026"
    } ]
  },
  "geo" : {
  },
  "id_str" : "266902715467182081",
  "text" : "#catcontent #twitterwall #kif405 http://t.co/0UJjx8eD",
  "id" : 266902715467182081,
  "created_at" : "Fri Nov 09 13:59:00 +0000 2012",
  "user" : {
    "name" : "Felix",
    "screen_name" : "nicidienase",
    "protected" : false,
    "id_str" : "22396883",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3125784966/8223a4c5c9535be22d15c82ec829c2df_normal.jpeg",
    "id" : 22396883,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.echofon.com/\" rel=\"nofollow\">Echofon</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "kif405",
      "indices" : [ 0, 7 ]
    } ],
    "urls" : [ {
      "indices" : [ 8, 28 ],
      "url" : "http://t.co/AFVvqETM",
      "expanded_url" : "http://lh5.googleusercontent.com/-qhOrCA0YOcs/T88ahvVjlpI/AAAAAAAAGYY/nqntKXC9fic/s372/92.gif",
      "display_url" : "lh5.googleusercontent.com/-qhOrCA0YOcs/T\u2026"
    } ]
  },
  "geo" : {
  },
  "id_str" : "266888579073077249",
  "text" : "#kif405 http://t.co/AFVvqETM",
  "id" : 266888579073077249,
  "created_at" : "Fri Nov 09 13:02:50 +0000 2012",
  "user" : {
    "name" : "Felix",
    "screen_name" : "nicidienase",
    "protected" : false,
    "id_str" : "22396883",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3125784966/8223a4c5c9535be22d15c82ec829c2df_normal.jpeg",
    "id" : 22396883,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.echofon.com/\" rel=\"nofollow\">Echofon</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "kif405",
      "indices" : [ 13, 20 ]
    } ],
    "urls" : [ {
      "indices" : [ 21, 41 ],
      "url" : "http://t.co/npby8m0Q",
      "expanded_url" : "http://lh4.googleusercontent.com/-U8qtM6Igf8s/UIpQ1BGp7MI/AAAAAAAAGkU/J2fuBmmgZH8/s240/111.gif",
      "display_url" : "lh4.googleusercontent.com/-U8qtM6Igf8s/U\u2026"
    } ]
  },
  "geo" : {
  },
  "id_str" : "266807773621284864",
  "text" : "Guten Morgen #kif405 http://t.co/npby8m0Q",
  "id" : 266807773621284864,
  "created_at" : "Fri Nov 09 07:41:44 +0000 2012",
  "user" : {
    "name" : "Felix",
    "screen_name" : "nicidienase",
    "protected" : false,
    "id_str" : "22396883",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3125784966/8223a4c5c9535be22d15c82ec829c2df_normal.jpeg",
    "id" : 22396883,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Command Line Magic",
      "screen_name" : "climagic",
      "indices" : [ 0, 9 ],
      "id_str" : "91333167",
      "id" : 91333167
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "266671296438489088",
  "geo" : {
  },
  "id_str" : "266693726657736705",
  "in_reply_to_user_id" : 91333167,
  "text" : "@climagic you can use tsocks to make programmes use it.",
  "id" : 266693726657736705,
  "in_reply_to_status_id" : 266671296438489088,
  "created_at" : "Fri Nov 09 00:08:34 +0000 2012",
  "in_reply_to_screen_name" : "climagic",
  "in_reply_to_user_id_str" : "91333167",
  "user" : {
    "name" : "Felix",
    "screen_name" : "nicidienase",
    "protected" : false,
    "id_str" : "22396883",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3125784966/8223a4c5c9535be22d15c82ec829c2df_normal.jpeg",
    "id" : 22396883,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "sputnik",
      "screen_name" : "sp_utnik",
      "indices" : [ 0, 9 ],
      "id_str" : "854363641",
      "id" : 854363641
    }, {
      "name" : "i42n",
      "screen_name" : "i42n",
      "indices" : [ 10, 15 ],
      "id_str" : "22298116",
      "id" : 22298116
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "266692688206757889",
  "text" : "@sp_utnik @i42n Muss ich auch mal machen!",
  "id" : 266692688206757889,
  "created_at" : "Fri Nov 09 00:04:26 +0000 2012",
  "user" : {
    "name" : "Felix",
    "screen_name" : "nicidienase",
    "protected" : false,
    "id_str" : "22396883",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3125784966/8223a4c5c9535be22d15c82ec829c2df_normal.jpeg",
    "id" : 22396883,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mathias Meyer",
      "screen_name" : "roidrage",
      "indices" : [ 1, 10 ],
      "id_str" : "14658472",
      "id" : 14658472
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "kif405",
      "indices" : [ 34, 41 ]
    } ],
    "urls" : [ {
      "indices" : [ 12, 32 ],
      "url" : "http://t.co/8KxXtY9F",
      "expanded_url" : "http://i.imgur.com/GpUQh.gif",
      "display_url" : "i.imgur.com/GpUQh.gif"
    } ]
  },
  "geo" : {
  },
  "id_str" : "266621301882490880",
  "text" : "\"@roidrage: http://t.co/8KxXtY9F\" #kif405",
  "id" : 266621301882490880,
  "created_at" : "Thu Nov 08 19:20:46 +0000 2012",
  "user" : {
    "name" : "Felix",
    "screen_name" : "nicidienase",
    "protected" : false,
    "id_str" : "22396883",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3125784966/8223a4c5c9535be22d15c82ec829c2df_normal.jpeg",
    "id" : 22396883,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.echofon.com/\" rel=\"nofollow\">Echofon</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "kif405",
      "indices" : [ 24, 31 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "266456301830303744",
  "text" : "Wer das liest ist doof! #kif405 :P",
  "id" : 266456301830303744,
  "created_at" : "Thu Nov 08 08:25:07 +0000 2012",
  "user" : {
    "name" : "Felix",
    "screen_name" : "nicidienase",
    "protected" : false,
    "id_str" : "22396883",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3125784966/8223a4c5c9535be22d15c82ec829c2df_normal.jpeg",
    "id" : 22396883,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.echofon.com/\" rel=\"nofollow\">Echofon</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dave K.",
      "screen_name" : "anathem",
      "indices" : [ 0, 8 ],
      "id_str" : "287761908",
      "id" : 287761908
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "266454048398508032",
  "geo" : {
  },
  "id_str" : "266454752504709121",
  "in_reply_to_user_id" : 287761908,
  "text" : "@anathem Im Zweifel der Offline-Plan w\u00FCrde ich sagen.",
  "id" : 266454752504709121,
  "in_reply_to_status_id" : 266454048398508032,
  "created_at" : "Thu Nov 08 08:18:58 +0000 2012",
  "in_reply_to_screen_name" : "anathem",
  "in_reply_to_user_id_str" : "287761908",
  "user" : {
    "name" : "Felix",
    "screen_name" : "nicidienase",
    "protected" : false,
    "id_str" : "22396883",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3125784966/8223a4c5c9535be22d15c82ec829c2df_normal.jpeg",
    "id" : 22396883,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.echofon.com/\" rel=\"nofollow\">Echofon</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "kif405",
      "indices" : [ 42, 49 ]
    } ],
    "urls" : [ {
      "indices" : [ 21, 41 ],
      "url" : "http://t.co/g28BOnUB",
      "expanded_url" : "http://kif.fsinf.de/wiki/KIF405:Zeitplan",
      "display_url" : "kif.fsinf.de/wiki/KIF405:Ze\u2026"
    } ]
  },
  "geo" : {
  },
  "id_str" : "266453373493051393",
  "text" : "AK-Zeitplan im Wiki: http://t.co/g28BOnUB #kif405",
  "id" : 266453373493051393,
  "created_at" : "Thu Nov 08 08:13:29 +0000 2012",
  "user" : {
    "name" : "Felix",
    "screen_name" : "nicidienase",
    "protected" : false,
    "id_str" : "22396883",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3125784966/8223a4c5c9535be22d15c82ec829c2df_normal.jpeg",
    "id" : 22396883,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.echofon.com/\" rel=\"nofollow\">Echofon</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ilja Schwarz",
      "screen_name" : "blackbilbao",
      "indices" : [ 0, 12 ],
      "id_str" : "29192765",
      "id" : 29192765
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "266451211274813440",
  "geo" : {
  },
  "id_str" : "266451526409650176",
  "in_reply_to_user_id" : 29192765,
  "text" : "@blackbilbao gestern!",
  "id" : 266451526409650176,
  "in_reply_to_status_id" : 266451211274813440,
  "created_at" : "Thu Nov 08 08:06:08 +0000 2012",
  "in_reply_to_screen_name" : "blackbilbao",
  "in_reply_to_user_id_str" : "29192765",
  "user" : {
    "name" : "Felix",
    "screen_name" : "nicidienase",
    "protected" : false,
    "id_str" : "22396883",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3125784966/8223a4c5c9535be22d15c82ec829c2df_normal.jpeg",
    "id" : 22396883,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.echofon.com/\" rel=\"nofollow\">Echofon</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "kif405",
      "indices" : [ 0, 7 ]
    } ],
    "urls" : [ {
      "indices" : [ 8, 28 ],
      "url" : "http://t.co/2E5jTZOw",
      "expanded_url" : "http://images.wikia.com/nonsensopedia/images/5/58/Rickroll.gif",
      "display_url" : "images.wikia.com/nonsensopedia/\u2026"
    } ]
  },
  "geo" : {
  },
  "id_str" : "266451349598785536",
  "text" : "#kif405 http://t.co/2E5jTZOw",
  "id" : 266451349598785536,
  "created_at" : "Thu Nov 08 08:05:26 +0000 2012",
  "user" : {
    "name" : "Felix",
    "screen_name" : "nicidienase",
    "protected" : false,
    "id_str" : "22396883",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3125784966/8223a4c5c9535be22d15c82ec829c2df_normal.jpeg",
    "id" : 22396883,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.echofon.com/\" rel=\"nofollow\">Echofon</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "kif405",
      "indices" : [ 0, 7 ]
    }, {
      "text" : "twitterwall",
      "indices" : [ 8, 20 ]
    } ],
    "urls" : [ {
      "indices" : [ 21, 41 ],
      "url" : "http://t.co/gEBxnMJw",
      "expanded_url" : "http://chzgifs.files.wordpress.com/2012/03/funny-gifs-the-magic-melon.gif",
      "display_url" : "chzgifs.files.wordpress.com/2012/03/funny-\u2026"
    } ]
  },
  "geo" : {
  },
  "id_str" : "266450454504939520",
  "text" : "#kif405 #twitterwall http://t.co/gEBxnMJw",
  "id" : 266450454504939520,
  "created_at" : "Thu Nov 08 08:01:53 +0000 2012",
  "user" : {
    "name" : "Felix",
    "screen_name" : "nicidienase",
    "protected" : false,
    "id_str" : "22396883",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3125784966/8223a4c5c9535be22d15c82ec829c2df_normal.jpeg",
    "id" : 22396883,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "kif405",
      "indices" : [ 4, 11 ]
    } ],
    "urls" : [ {
      "indices" : [ 12, 32 ],
      "url" : "http://t.co/nrY5WqIy",
      "expanded_url" : "http://www.youtube.com/watch?v=QH2-TGUlwu4",
      "display_url" : "youtube.com/watch?v=QH2-TG\u2026"
    } ]
  },
  "geo" : {
  },
  "id_str" : "266441600496975872",
  "text" : "*g* #kif405 http://t.co/nrY5WqIy",
  "id" : 266441600496975872,
  "created_at" : "Thu Nov 08 07:26:42 +0000 2012",
  "user" : {
    "name" : "Felix",
    "screen_name" : "nicidienase",
    "protected" : false,
    "id_str" : "22396883",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3125784966/8223a4c5c9535be22d15c82ec829c2df_normal.jpeg",
    "id" : 22396883,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "kif405",
      "indices" : [ 45, 52 ]
    } ],
    "urls" : [ {
      "indices" : [ 53, 73 ],
      "url" : "http://t.co/paEk8rAS",
      "expanded_url" : "http://bit.ly/qH3Ahd",
      "display_url" : "bit.ly/qH3Ahd"
    }, {
      "indices" : [ 74, 94 ],
      "url" : "http://t.co/hsAHfnBe",
      "expanded_url" : "http://twitter.com/Geruhn/status/266320339926138880/photo/1",
      "display_url" : "pic.twitter.com/hsAHfnBe"
    } ]
  },
  "geo" : {
  },
  "id_str" : "266321341152624641",
  "text" : "RT @Geruhn: Ist die Twitter wall nicht toll? #kif405 http://t.co/paEk8rAS http://t.co/hsAHfnBe",
  "retweeted_status" : {
    "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "http://twitter.com/keinGeruhn/status/266320339926138880/photo/1",
        "indices" : [ 62, 82 ],
        "url" : "http://t.co/hsAHfnBe",
        "media_url" : "http://pbs.twimg.com/media/A7Io8CpCQAArDwK.jpg",
        "id_str" : "266320339934527488",
        "id" : 266320339934527488,
        "media_url_https" : "https://pbs.twimg.com/media/A7Io8CpCQAArDwK.jpg",
        "sizes" : [ {
          "h" : 1365,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 3264,
          "resize" : "fit",
          "w" : 2448
        }, {
          "h" : 453,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 800,
          "resize" : "fit",
          "w" : 600
        } ],
        "display_url" : "pic.twitter.com/hsAHfnBe"
      } ],
      "hashtags" : [ {
        "text" : "kif405",
        "indices" : [ 33, 40 ]
      } ],
      "urls" : [ {
        "indices" : [ 41, 61 ],
        "url" : "http://t.co/paEk8rAS",
        "expanded_url" : "http://bit.ly/qH3Ahd",
        "display_url" : "bit.ly/qH3Ahd"
      } ]
    },
    "geo" : {
    },
    "id_str" : "266320339926138880",
    "text" : "Ist die Twitter wall nicht toll? #kif405 http://t.co/paEk8rAS http://t.co/hsAHfnBe",
    "id" : 266320339926138880,
    "created_at" : "Wed Nov 07 23:24:53 +0000 2012",
    "user" : {
      "name" : "Andy P.",
      "screen_name" : "keinGeruhn",
      "protected" : false,
      "id_str" : "20689932",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/2532717078/sqf75a6eqiayl7c6idu7_normal.jpeg",
      "id" : 20689932,
      "verified" : false
    }
  },
  "id" : 266321341152624641,
  "created_at" : "Wed Nov 07 23:28:50 +0000 2012",
  "user" : {
    "name" : "Felix",
    "screen_name" : "nicidienase",
    "protected" : false,
    "id_str" : "22396883",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3125784966/8223a4c5c9535be22d15c82ec829c2df_normal.jpeg",
    "id" : 22396883,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.echofon.com/\" rel=\"nofollow\">Echofon</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "nfoonf",
      "screen_name" : "nfoonf",
      "indices" : [ 3, 10 ],
      "id_str" : "31473644",
      "id" : 31473644
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "29c3",
      "indices" : [ 128, 133 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "265790516673802240",
  "text" : "RT @nfoonf: wer klebt eigentlich das \"wir sind umgezogen\"-Schild nach Weihnachten ans BCC? (und wer stellt die webcam daneben?) #29c3",
  "retweeted_status" : {
    "source" : "web",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "29c3",
        "indices" : [ 116, 121 ]
      } ],
      "urls" : [ ]
    },
    "geo" : {
    },
    "id_str" : "265466190569283585",
    "text" : "wer klebt eigentlich das \"wir sind umgezogen\"-Schild nach Weihnachten ans BCC? (und wer stellt die webcam daneben?) #29c3",
    "id" : 265466190569283585,
    "created_at" : "Mon Nov 05 14:50:46 +0000 2012",
    "user" : {
      "name" : "nfoonf",
      "screen_name" : "nfoonf",
      "protected" : false,
      "id_str" : "31473644",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/139380799/schrauben_normal.jpg",
      "id" : 31473644,
      "verified" : false
    }
  },
  "id" : 265790516673802240,
  "created_at" : "Tue Nov 06 12:19:31 +0000 2012",
  "user" : {
    "name" : "Felix",
    "screen_name" : "nicidienase",
    "protected" : false,
    "id_str" : "22396883",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3125784966/8223a4c5c9535be22d15c82ec829c2df_normal.jpeg",
    "id" : 22396883,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.echofon.com/\" rel=\"nofollow\">Echofon</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Eva Eichhorn",
      "screen_name" : "MamsellChaos",
      "indices" : [ 3, 16 ],
      "id_str" : "140774041",
      "id" : 140774041
    }, {
      "name" : "Detmud",
      "screen_name" : "Detmud",
      "indices" : [ 78, 85 ],
      "id_str" : "15587623",
      "id" : 15587623
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "265774991138775040",
  "text" : "RT @MamsellChaos: So, wer hat Bedarf an einem 2008er 13\u201D Unibody MacBook? Der @Detmud hat es ganz liebevoll gepflegt bisher :D http://t. ...",
  "retweeted_status" : {
    "source" : "<a href=\"http://tapbots.com/software/tweetbot/mac\" rel=\"nofollow\">Tweetbot for Mac</a>",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Detmud",
        "screen_name" : "Detmud",
        "indices" : [ 60, 67 ],
        "id_str" : "15587623",
        "id" : 15587623
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 109, 129 ],
        "url" : "http://t.co/f9nOWlfC",
        "expanded_url" : "http://www.ebay.de/itm/300811127649?ssPageName=STRK:MESELX:IT&_trksid=p3984.m1555.l2649",
        "display_url" : "ebay.de/itm/3008111276\u2026"
      } ]
    },
    "geo" : {
    },
    "id_str" : "265747655798448128",
    "text" : "So, wer hat Bedarf an einem 2008er 13\u201D Unibody MacBook? Der @Detmud hat es ganz liebevoll gepflegt bisher :D http://t.co/f9nOWlfC",
    "id" : 265747655798448128,
    "created_at" : "Tue Nov 06 09:29:13 +0000 2012",
    "user" : {
      "name" : "Eva Eichhorn",
      "screen_name" : "MamsellChaos",
      "protected" : false,
      "id_str" : "140774041",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/3231510280/b59cd7b5771078fb646882e5e5882940_normal.jpeg",
      "id" : 140774041,
      "verified" : false
    }
  },
  "id" : 265774991138775040,
  "created_at" : "Tue Nov 06 11:17:50 +0000 2012",
  "user" : {
    "name" : "Felix",
    "screen_name" : "nicidienase",
    "protected" : false,
    "id_str" : "22396883",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3125784966/8223a4c5c9535be22d15c82ec829c2df_normal.jpeg",
    "id" : 22396883,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.echofon.com/\" rel=\"nofollow\">Echofon</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tobias Wolter",
      "screen_name" : "towo",
      "indices" : [ 3, 8 ],
      "id_str" : "14095571",
      "id" : 14095571
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "265751191886106624",
  "text" : "RT @towo: Netzteilvergesser ist der moderne Turnbeutelvergesser.",
  "retweeted_status" : {
    "source" : "web",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : {
    },
    "id_str" : "265597682293276674",
    "text" : "Netzteilvergesser ist der moderne Turnbeutelvergesser.",
    "id" : 265597682293276674,
    "created_at" : "Mon Nov 05 23:33:16 +0000 2012",
    "user" : {
      "name" : "Tobias Wolter",
      "screen_name" : "towo",
      "protected" : false,
      "id_str" : "14095571",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/2928571431/00c131893b78f2934383aebdec551034_normal.jpeg",
      "id" : 14095571,
      "verified" : false
    }
  },
  "id" : 265751191886106624,
  "created_at" : "Tue Nov 06 09:43:16 +0000 2012",
  "user" : {
    "name" : "Felix",
    "screen_name" : "nicidienase",
    "protected" : false,
    "id_str" : "22396883",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3125784966/8223a4c5c9535be22d15c82ec829c2df_normal.jpeg",
    "id" : 22396883,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.echofon.com/\" rel=\"nofollow\">Echofon</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Graham Sutherland",
      "screen_name" : "gsuberland",
      "indices" : [ 3, 14 ],
      "id_str" : "432513392",
      "id" : 432513392
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 71, 92 ],
      "url" : "https://t.co/sfpg0XPt",
      "expanded_url" : "https://code.google.com/p/xee/source/browse/XeePhotoshopLoader.m#102",
      "display_url" : "code.google.com/p/xee/source/b\u2026"
    } ]
  },
  "geo" : {
  },
  "id_str" : "265461392524582912",
  "text" : "RT @gsuberland: Epic comment... \"PSD is not my favourite file format.\" https://t.co/sfpg0XPt",
  "retweeted_status" : {
    "source" : "web",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 55, 76 ],
        "url" : "https://t.co/sfpg0XPt",
        "expanded_url" : "https://code.google.com/p/xee/source/browse/XeePhotoshopLoader.m#102",
        "display_url" : "code.google.com/p/xee/source/b\u2026"
      } ]
    },
    "geo" : {
    },
    "id_str" : "265416760734404608",
    "text" : "Epic comment... \"PSD is not my favourite file format.\" https://t.co/sfpg0XPt",
    "id" : 265416760734404608,
    "created_at" : "Mon Nov 05 11:34:21 +0000 2012",
    "user" : {
      "name" : "Graham Sutherland",
      "screen_name" : "gsuberland",
      "protected" : false,
      "id_str" : "432513392",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/1683001651/2011-12-09_13.54.24_normal.jpg",
      "id" : 432513392,
      "verified" : false
    }
  },
  "id" : 265461392524582912,
  "created_at" : "Mon Nov 05 14:31:42 +0000 2012",
  "user" : {
    "name" : "Felix",
    "screen_name" : "nicidienase",
    "protected" : false,
    "id_str" : "22396883",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3125784966/8223a4c5c9535be22d15c82ec829c2df_normal.jpeg",
    "id" : 22396883,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "29c3",
      "indices" : [ 32, 37 ]
    }, {
      "text" : "merchandise",
      "indices" : [ 38, 50 ]
    }, {
      "text" : "firstworldproblems",
      "indices" : [ 51, 70 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "265364750043594752",
  "text" : "Aaaah, Hilfe! Too many choices! #29c3 #merchandise #firstworldproblems",
  "id" : 265364750043594752,
  "created_at" : "Mon Nov 05 08:07:41 +0000 2012",
  "user" : {
    "name" : "Felix",
    "screen_name" : "nicidienase",
    "protected" : false,
    "id_str" : "22396883",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3125784966/8223a4c5c9535be22d15c82ec829c2df_normal.jpeg",
    "id" : 22396883,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "29c3",
      "indices" : [ 37, 42 ]
    }, {
      "text" : "firstworldproblems",
      "indices" : [ 44, 63 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "265363894774669313",
  "text" : "Hmm, will ich Zipper oder Hoodie vom #29c3? #firstworldproblems",
  "id" : 265363894774669313,
  "created_at" : "Mon Nov 05 08:04:17 +0000 2012",
  "user" : {
    "name" : "Felix",
    "screen_name" : "nicidienase",
    "protected" : false,
    "id_str" : "22396883",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3125784966/8223a4c5c9535be22d15c82ec829c2df_normal.jpeg",
    "id" : 22396883,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tobias Wolter",
      "screen_name" : "towo",
      "indices" : [ 3, 8 ],
      "id_str" : "14095571",
      "id" : 14095571
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "265359297976868864",
  "text" : "RT @towo: Remember, remember, the fifth of November...",
  "retweeted_status" : {
    "source" : "web",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : {
    },
    "id_str" : "265227164209799168",
    "text" : "Remember, remember, the fifth of November...",
    "id" : 265227164209799168,
    "created_at" : "Sun Nov 04 23:00:58 +0000 2012",
    "user" : {
      "name" : "Tobias Wolter",
      "screen_name" : "towo",
      "protected" : false,
      "id_str" : "14095571",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/2928571431/00c131893b78f2934383aebdec551034_normal.jpeg",
      "id" : 14095571,
      "verified" : false
    }
  },
  "id" : 265359297976868864,
  "created_at" : "Mon Nov 05 07:46:01 +0000 2012",
  "user" : {
    "name" : "Felix",
    "screen_name" : "nicidienase",
    "protected" : false,
    "id_str" : "22396883",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3125784966/8223a4c5c9535be22d15c82ec829c2df_normal.jpeg",
    "id" : 22396883,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "psy",
      "screen_name" : "psycon",
      "indices" : [ 0, 7 ],
      "id_str" : "87286054",
      "id" : 87286054
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "264860213130186752",
  "geo" : {
  },
  "id_str" : "265056064444182528",
  "in_reply_to_user_id" : 87286054,
  "text" : "@psycon Wohnung w\u00E4r komfortabler als Turnhalle",
  "id" : 265056064444182528,
  "in_reply_to_status_id" : 264860213130186752,
  "created_at" : "Sun Nov 04 11:41:04 +0000 2012",
  "in_reply_to_screen_name" : "psycon",
  "in_reply_to_user_id_str" : "87286054",
  "user" : {
    "name" : "Felix",
    "screen_name" : "nicidienase",
    "protected" : false,
    "id_str" : "22396883",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3125784966/8223a4c5c9535be22d15c82ec829c2df_normal.jpeg",
    "id" : 22396883,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "i42n",
      "screen_name" : "i42n",
      "indices" : [ 3, 8 ],
      "id_str" : "22298116",
      "id" : 22298116
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 19, 39 ],
      "url" : "http://t.co/Hd0Ye3Ro",
      "expanded_url" : "http://youtube.com/watch?v=yFU774q6eVM",
      "display_url" : "youtube.com/watch?v=yFU774\u2026"
    } ]
  },
  "geo" : {
  },
  "id_str" : "265054213304897536",
  "text" : "RT @i42n: Awesome! http://t.co/Hd0Ye3Ro",
  "retweeted_status" : {
    "source" : "<a href=\"http://www.apple.com\" rel=\"nofollow\">iOS</a>",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 9, 29 ],
        "url" : "http://t.co/Hd0Ye3Ro",
        "expanded_url" : "http://youtube.com/watch?v=yFU774q6eVM",
        "display_url" : "youtube.com/watch?v=yFU774\u2026"
      } ]
    },
    "geo" : {
    },
    "id_str" : "264844173138612224",
    "text" : "Awesome! http://t.co/Hd0Ye3Ro",
    "id" : 264844173138612224,
    "created_at" : "Sat Nov 03 21:39:06 +0000 2012",
    "user" : {
      "name" : "i42n",
      "screen_name" : "i42n",
      "protected" : false,
      "id_str" : "22298116",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/3129115691/3c2e9123db7f498d478ace57a0ac1b69_normal.png",
      "id" : 22298116,
      "verified" : false
    }
  },
  "id" : 265054213304897536,
  "created_at" : "Sun Nov 04 11:33:43 +0000 2012",
  "user" : {
    "name" : "Felix",
    "screen_name" : "nicidienase",
    "protected" : false,
    "id_str" : "22396883",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3125784966/8223a4c5c9535be22d15c82ec829c2df_normal.jpeg",
    "id" : 22396883,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sasa \u2665",
      "screen_name" : "Sasamaaus",
      "indices" : [ 3, 13 ],
      "id_str" : "726601968",
      "id" : 726601968
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "264785279414571008",
  "text" : "RT @Sasamaaus: Egal wie alt ich bin, ich werde immer das ABC im Kopf singen um herauszufinden, welcher Buchstabe als n\u00E4chstes kommt.",
  "retweeted_status" : {
    "source" : "web",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : {
    },
    "id_str" : "232210160301535232",
    "text" : "Egal wie alt ich bin, ich werde immer das ABC im Kopf singen um herauszufinden, welcher Buchstabe als n\u00E4chstes kommt.",
    "id" : 232210160301535232,
    "created_at" : "Sun Aug 05 20:23:11 +0000 2012",
    "user" : {
      "name" : "Sasa \u2665",
      "screen_name" : "Sasamaaus",
      "protected" : false,
      "id_str" : "726601968",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/3274241566/a23b345500d24e2427b0e98cd37aa47e_normal.jpeg",
      "id" : 726601968,
      "verified" : false
    }
  },
  "id" : 264785279414571008,
  "created_at" : "Sat Nov 03 17:45:04 +0000 2012",
  "user" : {
    "name" : "Felix",
    "screen_name" : "nicidienase",
    "protected" : false,
    "id_str" : "22396883",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3125784966/8223a4c5c9535be22d15c82ec829c2df_normal.jpeg",
    "id" : 22396883,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Holger Klein",
      "screen_name" : "holgi",
      "indices" : [ 46, 52 ],
      "id_str" : "3068271",
      "id" : 3068271
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "264732293791354881",
  "text" : "Gibts eigentlich Globuli gegen Diabetes? //cc @holgi",
  "id" : 264732293791354881,
  "created_at" : "Sat Nov 03 14:14:31 +0000 2012",
  "user" : {
    "name" : "Felix",
    "screen_name" : "nicidienase",
    "protected" : false,
    "id_str" : "22396883",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3125784966/8223a4c5c9535be22d15c82ec829c2df_normal.jpeg",
    "id" : 22396883,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "i42n",
      "screen_name" : "i42n",
      "indices" : [ 0, 5 ],
      "id_str" : "22298116",
      "id" : 22298116
    }, {
      "name" : "psy",
      "screen_name" : "psycon",
      "indices" : [ 6, 13 ],
      "id_str" : "87286054",
      "id" : 87286054
    }, {
      "name" : "punycode",
      "screen_name" : "punycode",
      "indices" : [ 14, 23 ],
      "id_str" : "14328131",
      "id" : 14328131
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "264689807177953280",
  "geo" : {
  },
  "id_str" : "264724968733044737",
  "in_reply_to_user_id" : 22298116,
  "text" : "@i42n @psycon @punycode Zum Gl\u00FCck is ICMP f\u00FCr IPv6 verpflichtend. Und in den n\u00E4chsten Dekaden m\u00FCssen die Hochschulen v6 einf\u00FChren.",
  "id" : 264724968733044737,
  "in_reply_to_status_id" : 264689807177953280,
  "created_at" : "Sat Nov 03 13:45:25 +0000 2012",
  "in_reply_to_screen_name" : "i42n",
  "in_reply_to_user_id_str" : "22298116",
  "user" : {
    "name" : "Felix",
    "screen_name" : "nicidienase",
    "protected" : false,
    "id_str" : "22396883",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3125784966/8223a4c5c9535be22d15c82ec829c2df_normal.jpeg",
    "id" : 22396883,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.echofon.com/\" rel=\"nofollow\">Echofon</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 40, 60 ],
      "url" : "http://t.co/IrecNA5E",
      "expanded_url" : "http://nicidienase.github.com/blog/2012/11/03/mensaplane-in-karlsruhe/",
      "display_url" : "nicidienase.github.com/blog/2012/11/0\u2026"
    } ]
  },
  "geo" : {
  },
  "id_str" : "264520199837990913",
  "text" : "Neuer Blogpost: Mensapl\u00E4ne in Karlsruhe http://t.co/IrecNA5E",
  "id" : 264520199837990913,
  "created_at" : "Sat Nov 03 00:11:44 +0000 2012",
  "user" : {
    "name" : "Felix",
    "screen_name" : "nicidienase",
    "protected" : false,
    "id_str" : "22396883",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3125784966/8223a4c5c9535be22d15c82ec829c2df_normal.jpeg",
    "id" : 22396883,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Clemens Hopfer",
      "screen_name" : "data_cop",
      "indices" : [ 0, 9 ],
      "id_str" : "61772791",
      "id" : 61772791
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "264363517912682496",
  "geo" : {
  },
  "id_str" : "264389934612377600",
  "in_reply_to_user_id" : 61772791,
  "text" : "@data_cop I don't know. What kind of chip are they using? Ours has a mifare classic.",
  "id" : 264389934612377600,
  "in_reply_to_status_id" : 264363517912682496,
  "created_at" : "Fri Nov 02 15:34:07 +0000 2012",
  "in_reply_to_screen_name" : "data_cop",
  "in_reply_to_user_id_str" : "61772791",
  "user" : {
    "name" : "Felix",
    "screen_name" : "nicidienase",
    "protected" : false,
    "id_str" : "22396883",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3125784966/8223a4c5c9535be22d15c82ec829c2df_normal.jpeg",
    "id" : 22396883,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.echofon.com/\" rel=\"nofollow\">Echofon</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Clemens Hopfer",
      "screen_name" : "data_cop",
      "indices" : [ 0, 9 ],
      "id_str" : "61772791",
      "id" : 61772791
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "264306852421042177",
  "in_reply_to_user_id" : 61772791,
  "text" : "@data_cop Those are used in Karlsruhe for quite some time, but they stopped using the thermo-field though.",
  "id" : 264306852421042177,
  "created_at" : "Fri Nov 02 10:03:58 +0000 2012",
  "in_reply_to_screen_name" : "data_cop",
  "in_reply_to_user_id_str" : "61772791",
  "user" : {
    "name" : "Felix",
    "screen_name" : "nicidienase",
    "protected" : false,
    "id_str" : "22396883",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3125784966/8223a4c5c9535be22d15c82ec829c2df_normal.jpeg",
    "id" : 22396883,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.echofon.com/\" rel=\"nofollow\">Echofon</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "264066795286175744",
  "text" : "Zum Fr\u00FChst\u00FCck Eggs und Bacon, jetzt Lasagne und nachher macht der Mitbewohner noch Pfannkuchen. Aus kulinarisch l\u00E4uft der Tag ganz gut.",
  "id" : 264066795286175744,
  "created_at" : "Thu Nov 01 18:10:04 +0000 2012",
  "user" : {
    "name" : "Felix",
    "screen_name" : "nicidienase",
    "protected" : false,
    "id_str" : "22396883",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3125784966/8223a4c5c9535be22d15c82ec829c2df_normal.jpeg",
    "id" : 22396883,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http://twitter.com/nicidienase/status/263841826312691712/photo/1",
      "indices" : [ 17, 37 ],
      "url" : "http://t.co/79vbzYo2",
      "media_url" : "http://pbs.twimg.com/media/A6lavj6CIAA2jVN.jpg",
      "id_str" : "263841826316886016",
      "id" : 263841826316886016,
      "media_url_https" : "https://pbs.twimg.com/media/A6lavj6CIAA2jVN.jpg",
      "sizes" : [ {
        "h" : 1365,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 2560,
        "resize" : "fit",
        "w" : 1920
      }, {
        "h" : 453,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 800,
        "resize" : "fit",
        "w" : 600
      } ],
      "display_url" : "pic.twitter.com/79vbzYo2"
    } ],
    "hashtags" : [ {
      "text" : "Z10",
      "indices" : [ 12, 16 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "263841826312691712",
  "text" : "Wikinger im #Z10 http://t.co/79vbzYo2",
  "id" : 263841826312691712,
  "created_at" : "Thu Nov 01 03:16:09 +0000 2012",
  "user" : {
    "name" : "Felix",
    "screen_name" : "nicidienase",
    "protected" : false,
    "id_str" : "22396883",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3125784966/8223a4c5c9535be22d15c82ec829c2df_normal.jpeg",
    "id" : 22396883,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Felix Arndt",
      "screen_name" : "silsha",
      "indices" : [ 0, 7 ],
      "id_str" : "14823325",
      "id" : 14823325
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "263807846540513280",
  "geo" : {
  },
  "id_str" : "263822406131539968",
  "in_reply_to_user_id" : 14823325,
  "text" : "@silsha Was f\u00FCr Parties feiert ihr den die um diese Zeit schon rum sind?",
  "id" : 263822406131539968,
  "in_reply_to_status_id" : 263807846540513280,
  "created_at" : "Thu Nov 01 01:58:57 +0000 2012",
  "in_reply_to_screen_name" : "silsha",
  "in_reply_to_user_id_str" : "14823325",
  "user" : {
    "name" : "Felix",
    "screen_name" : "nicidienase",
    "protected" : false,
    "id_str" : "22396883",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3125784966/8223a4c5c9535be22d15c82ec829c2df_normal.jpeg",
    "id" : 22396883,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Eva ",
      "screen_name" : "SchokoPralini",
      "indices" : [ 0, 14 ],
      "id_str" : "575695094",
      "id" : 575695094
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "263817099724599296",
  "geo" : {
  },
  "id_str" : "263821871118700544",
  "in_reply_to_user_id" : 575695094,
  "text" : "@SchokoPralini Bei mir auch!",
  "id" : 263821871118700544,
  "in_reply_to_status_id" : 263817099724599296,
  "created_at" : "Thu Nov 01 01:56:50 +0000 2012",
  "in_reply_to_screen_name" : "SchokoPralini",
  "in_reply_to_user_id_str" : "575695094",
  "user" : {
    "name" : "Felix",
    "screen_name" : "nicidienase",
    "protected" : false,
    "id_str" : "22396883",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3125784966/8223a4c5c9535be22d15c82ec829c2df_normal.jpeg",
    "id" : 22396883,
    "verified" : false
  }
} ]