Grailbird.data.tweets_2013_04 = 
[ {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "*andy",
      "screen_name" : "derGeruhn",
      "indices" : [ 0, 10 ],
      "id_str" : "936437276",
      "id" : 936437276
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "323113215988994050",
  "geo" : {
  },
  "id_str" : "323114065855672321",
  "in_reply_to_user_id" : 936437276,
  "text" : "@derGeruhn Ich wollt gleich noch ne Runde los und schaun das ich mal auf Level 4 komm. Willst du mit oder bist du schon verplant?",
  "id" : 323114065855672321,
  "in_reply_to_status_id" : 323113215988994050,
  "created_at" : "Sat Apr 13 16:42:51 +0000 2013",
  "in_reply_to_screen_name" : "derGeruhn",
  "in_reply_to_user_id_str" : "936437276",
  "user" : {
    "name" : "Felix",
    "screen_name" : "nicidienase",
    "protected" : false,
    "id_str" : "22396883",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3125784966/8223a4c5c9535be22d15c82ec829c2df_normal.jpeg",
    "id" : 22396883,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "*andy",
      "screen_name" : "derGeruhn",
      "indices" : [ 0, 10 ],
      "id_str" : "936437276",
      "id" : 936437276
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "323090896449052673",
  "geo" : {
  },
  "id_str" : "323110921033633793",
  "in_reply_to_user_id" : 936437276,
  "text" : "@derGeruhn Wie weit bist du den L2 oder schon L3?",
  "id" : 323110921033633793,
  "in_reply_to_status_id" : 323090896449052673,
  "created_at" : "Sat Apr 13 16:30:21 +0000 2013",
  "in_reply_to_screen_name" : "derGeruhn",
  "in_reply_to_user_id_str" : "936437276",
  "user" : {
    "name" : "Felix",
    "screen_name" : "nicidienase",
    "protected" : false,
    "id_str" : "22396883",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3125784966/8223a4c5c9535be22d15c82ec829c2df_normal.jpeg",
    "id" : 22396883,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "$(RandomName)",
      "screen_name" : "Ik4ru5",
      "indices" : [ 0, 7 ],
      "id_str" : "48294441",
      "id" : 48294441
    }, {
      "name" : "Jens Ohlig",
      "screen_name" : "johl",
      "indices" : [ 11, 16 ],
      "id_str" : "1147751",
      "id" : 1147751
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 35, 57 ],
      "url" : "http://t.co/ZMbF1QQ7eK",
      "expanded_url" : "http://i.imgur.com/oWkHvar.gif",
      "display_url" : "i.imgur.com/oWkHvar.gif"
    } ]
  },
  "geo" : {
  },
  "id_str" : "322703679868260352",
  "in_reply_to_user_id" : 48294441,
  "text" : "@Ik4ru5 RT\"@johl: Okay, I laughed: http://t.co/ZMbF1QQ7eK\"",
  "id" : 322703679868260352,
  "created_at" : "Fri Apr 12 13:32:07 +0000 2013",
  "in_reply_to_screen_name" : "Ik4ru5",
  "in_reply_to_user_id_str" : "48294441",
  "user" : {
    "name" : "Felix",
    "screen_name" : "nicidienase",
    "protected" : false,
    "id_str" : "22396883",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3125784966/8223a4c5c9535be22d15c82ec829c2df_normal.jpeg",
    "id" : 22396883,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Caffeine Security",
      "screen_name" : "CaffSec",
      "indices" : [ 3, 11 ],
      "id_str" : "47211120",
      "id" : 47211120
    } ],
    "media" : [ {
      "expanded_url" : "http://twitter.com/MichaelGrant_/status/322404028829007872/photo/1",
      "indices" : [ 85, 107 ],
      "url" : "http://t.co/Cpc285bhCs",
      "media_url" : "http://pbs.twimg.com/media/BHlowYzCAAARDB2.jpg",
      "id_str" : "322404028833202176",
      "id" : 322404028833202176,
      "media_url_https" : "https://pbs.twimg.com/media/BHlowYzCAAARDB2.jpg",
      "sizes" : [ {
        "h" : 600,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 612,
        "resize" : "fit",
        "w" : 612
      }, {
        "h" : 340,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 612,
        "resize" : "fit",
        "w" : 612
      } ],
      "display_url" : "pic.twitter.com/Cpc285bhCs"
    } ],
    "hashtags" : [ {
      "text" : "Security",
      "indices" : [ 13, 22 ]
    }, {
      "text" : "Protip",
      "indices" : [ 23, 30 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "322678642964561920",
  "text" : "RT @CaffSec: #Security #Protip: Change your default passwords...or this will happen. http://t.co/Cpc285bhCs",
  "retweeted_status" : {
    "source" : "web",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "http://twitter.com/MichaelGrant_/status/322404028829007872/photo/1",
        "indices" : [ 72, 94 ],
        "url" : "http://t.co/Cpc285bhCs",
        "media_url" : "http://pbs.twimg.com/media/BHlowYzCAAARDB2.jpg",
        "id_str" : "322404028833202176",
        "id" : 322404028833202176,
        "media_url_https" : "https://pbs.twimg.com/media/BHlowYzCAAARDB2.jpg",
        "sizes" : [ {
          "h" : 600,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 612,
          "resize" : "fit",
          "w" : 612
        }, {
          "h" : 340,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 612,
          "resize" : "fit",
          "w" : 612
        } ],
        "display_url" : "pic.twitter.com/Cpc285bhCs"
      } ],
      "hashtags" : [ {
        "text" : "Security",
        "indices" : [ 0, 9 ]
      }, {
        "text" : "Protip",
        "indices" : [ 10, 17 ]
      } ],
      "urls" : [ ]
    },
    "geo" : {
    },
    "id_str" : "322543488812085248",
    "text" : "#Security #Protip: Change your default passwords...or this will happen. http://t.co/Cpc285bhCs",
    "id" : 322543488812085248,
    "created_at" : "Fri Apr 12 02:55:34 +0000 2013",
    "user" : {
      "name" : "Caffeine Security",
      "screen_name" : "CaffSec",
      "protected" : false,
      "id_str" : "47211120",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/2407191745/r4qxvhn2c0go8roncoyx_normal.png",
      "id" : 47211120,
      "verified" : false
    }
  },
  "id" : 322678642964561920,
  "created_at" : "Fri Apr 12 11:52:38 +0000 2013",
  "user" : {
    "name" : "Felix",
    "screen_name" : "nicidienase",
    "protected" : false,
    "id_str" : "22396883",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3125784966/8223a4c5c9535be22d15c82ec829c2df_normal.jpeg",
    "id" : 22396883,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "$(RandomName)",
      "screen_name" : "Ik4ru5",
      "indices" : [ 0, 7 ],
      "id_str" : "48294441",
      "id" : 48294441
    } ],
    "media" : [ {
      "expanded_url" : "http://twitter.com/nicidienase/status/321002008268136450/photo/1",
      "indices" : [ 19, 41 ],
      "url" : "http://t.co/tY2YZgM3tS",
      "media_url" : "http://pbs.twimg.com/media/BHRtoDOCQAE8GNs.jpg",
      "id_str" : "321002008276516865",
      "id" : 321002008276516865,
      "media_url_https" : "https://pbs.twimg.com/media/BHRtoDOCQAE8GNs.jpg",
      "sizes" : [ {
        "h" : 600,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 1024,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 340,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 1920,
        "resize" : "fit",
        "w" : 1920
      } ],
      "display_url" : "pic.twitter.com/tY2YZgM3tS"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "321002008268136450",
  "in_reply_to_user_id" : 48294441,
  "text" : "@Ik4ru5 Nachtisch! http://t.co/tY2YZgM3tS",
  "id" : 321002008268136450,
  "created_at" : "Sun Apr 07 20:50:17 +0000 2013",
  "in_reply_to_screen_name" : "Ik4ru5",
  "in_reply_to_user_id_str" : "48294441",
  "user" : {
    "name" : "Felix",
    "screen_name" : "nicidienase",
    "protected" : false,
    "id_str" : "22396883",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3125784966/8223a4c5c9535be22d15c82ec829c2df_normal.jpeg",
    "id" : 22396883,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://hotot.org\" rel=\"nofollow\">Hotot</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "GPN13 @ HfG",
      "screen_name" : "entropiagpn",
      "indices" : [ 0, 12 ],
      "id_str" : "27639193",
      "id" : 27639193
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "320964652962021376",
  "geo" : {
  },
  "id_str" : "320967779190714369",
  "in_reply_to_user_id" : 27639193,
  "text" : "@entropiagpn Gibts schon nen Graph mit den Anmeldungen? ;)",
  "id" : 320967779190714369,
  "in_reply_to_status_id" : 320964652962021376,
  "created_at" : "Sun Apr 07 18:34:16 +0000 2013",
  "in_reply_to_screen_name" : "entropiagpn",
  "in_reply_to_user_id_str" : "27639193",
  "user" : {
    "name" : "Felix",
    "screen_name" : "nicidienase",
    "protected" : false,
    "id_str" : "22396883",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3125784966/8223a4c5c9535be22d15c82ec829c2df_normal.jpeg",
    "id" : 22396883,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://hotot.org\" rel=\"nofollow\">Hotot</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "GPN13 @ HfG",
      "screen_name" : "entropiagpn",
      "indices" : [ 3, 15 ],
      "id_str" : "27639193",
      "id" : 27639193
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "GPN13",
      "indices" : [ 71, 77 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "320965533870723072",
  "text" : "RT @entropiagpn: Noch etwas ungeschminkt, aber endlich da: Der CfP zur #GPN13! Ihr k\u00F6nnt euch anmelden \u2013 oder noch besser, mitmachen! ht ...",
  "retweeted_status" : {
    "source" : "<a href=\"http://itunes.apple.com/us/app/twitter/id409789998?mt=12\" rel=\"nofollow\">Twitter for Mac</a>",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "GPN13",
        "indices" : [ 54, 60 ]
      } ],
      "urls" : [ {
        "indices" : [ 117, 140 ],
        "url" : "https://t.co/cXMI3fsGX6",
        "expanded_url" : "https://entropia.de/GPN13:CfP",
        "display_url" : "entropia.de/GPN13:CfP"
      } ]
    },
    "geo" : {
    },
    "id_str" : "320961774205685760",
    "text" : "Noch etwas ungeschminkt, aber endlich da: Der CfP zur #GPN13! Ihr k\u00F6nnt euch anmelden \u2013 oder noch besser, mitmachen! https://t.co/cXMI3fsGX6",
    "id" : 320961774205685760,
    "created_at" : "Sun Apr 07 18:10:24 +0000 2013",
    "user" : {
      "name" : "GPN13 @ HfG",
      "screen_name" : "entropiagpn",
      "protected" : false,
      "id_str" : "27639193",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/3491198089/e1a5e779a3cea215770bd0b42748c444_normal.png",
      "id" : 27639193,
      "verified" : false
    }
  },
  "id" : 320965533870723072,
  "created_at" : "Sun Apr 07 18:25:21 +0000 2013",
  "user" : {
    "name" : "Felix",
    "screen_name" : "nicidienase",
    "protected" : false,
    "id_str" : "22396883",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3125784966/8223a4c5c9535be22d15c82ec829c2df_normal.jpeg",
    "id" : 22396883,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.echofon.com/\" rel=\"nofollow\">Echofon</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "makefu",
      "screen_name" : "makefoo",
      "indices" : [ 3, 11 ],
      "id_str" : "194108210",
      "id" : 194108210
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 45, 67 ],
      "url" : "http://t.co/kWsIWSGKvU",
      "expanded_url" : "http://web.media.mit.edu/~pliam/res/blog_1.html",
      "display_url" : "web.media.mit.edu/~pliam/res/blo\u2026"
    } ]
  },
  "geo" : {
  },
  "id_str" : "320162426211418113",
  "text" : "RT @makefoo: Is HTML a programming language? http://t.co/kWsIWSGKvU",
  "retweeted_status" : {
    "source" : "web",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 32, 54 ],
        "url" : "http://t.co/kWsIWSGKvU",
        "expanded_url" : "http://web.media.mit.edu/~pliam/res/blog_1.html",
        "display_url" : "web.media.mit.edu/~pliam/res/blo\u2026"
      } ]
    },
    "geo" : {
    },
    "id_str" : "320154843576676352",
    "text" : "Is HTML a programming language? http://t.co/kWsIWSGKvU",
    "id" : 320154843576676352,
    "created_at" : "Fri Apr 05 12:43:57 +0000 2013",
    "user" : {
      "name" : "makefu",
      "screen_name" : "makefoo",
      "protected" : false,
      "id_str" : "194108210",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/1129550049/3480_-_bowser_koopa_mario_realistic_normal.jpg",
      "id" : 194108210,
      "verified" : false
    }
  },
  "id" : 320162426211418113,
  "created_at" : "Fri Apr 05 13:14:05 +0000 2013",
  "user" : {
    "name" : "Felix",
    "screen_name" : "nicidienase",
    "protected" : false,
    "id_str" : "22396883",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3125784966/8223a4c5c9535be22d15c82ec829c2df_normal.jpeg",
    "id" : 22396883,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Eva Eichhorn",
      "screen_name" : "MamsellChaos",
      "indices" : [ 0, 13 ],
      "id_str" : "140774041",
      "id" : 140774041
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "319928865344602113",
  "geo" : {
  },
  "id_str" : "319942573441560576",
  "in_reply_to_user_id" : 140774041,
  "text" : "@MamsellChaos Ich fand die Episoden mit den Walen auch beeindruckend. Tolle Serie auf jeden Fall!",
  "id" : 319942573441560576,
  "in_reply_to_status_id" : 319928865344602113,
  "created_at" : "Thu Apr 04 22:40:28 +0000 2013",
  "in_reply_to_screen_name" : "MamsellChaos",
  "in_reply_to_user_id_str" : "140774041",
  "user" : {
    "name" : "Felix",
    "screen_name" : "nicidienase",
    "protected" : false,
    "id_str" : "22396883",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3125784966/8223a4c5c9535be22d15c82ec829c2df_normal.jpeg",
    "id" : 22396883,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lars Weiler",
      "screen_name" : "PylonC",
      "indices" : [ 0, 7 ],
      "id_str" : "14804411",
      "id" : 14804411
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "319906788109606913",
  "geo" : {
  },
  "id_str" : "319940266360442880",
  "in_reply_to_user_id" : 14804411,
  "text" : "@PylonC Hatte ich w\u00E4hrend dem Easterhegg vorgeschlagen. Aber es hatte sich niemand gefunden der mitschaun wollte.",
  "id" : 319940266360442880,
  "in_reply_to_status_id" : 319906788109606913,
  "created_at" : "Thu Apr 04 22:31:18 +0000 2013",
  "in_reply_to_screen_name" : "PylonC",
  "in_reply_to_user_id_str" : "14804411",
  "user" : {
    "name" : "Felix",
    "screen_name" : "nicidienase",
    "protected" : false,
    "id_str" : "22396883",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3125784966/8223a4c5c9535be22d15c82ec829c2df_normal.jpeg",
    "id" : 22396883,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://hotot.org\" rel=\"nofollow\">Hotot</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Andreas J\u00E4gle",
      "screen_name" : "ajaegle",
      "indices" : [ 0, 8 ],
      "id_str" : "78735610",
      "id" : 78735610
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "319793156893839361",
  "geo" : {
  },
  "id_str" : "319827412978368515",
  "in_reply_to_user_id" : 78735610,
  "text" : "@ajaegle hei\u00DFen die Vortragsr\u00E4ume auf der bedcon eigentlich bedrooms?",
  "id" : 319827412978368515,
  "in_reply_to_status_id" : 319793156893839361,
  "created_at" : "Thu Apr 04 15:02:52 +0000 2013",
  "in_reply_to_screen_name" : "ajaegle",
  "in_reply_to_user_id_str" : "78735610",
  "user" : {
    "name" : "Felix",
    "screen_name" : "nicidienase",
    "protected" : false,
    "id_str" : "22396883",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3125784966/8223a4c5c9535be22d15c82ec829c2df_normal.jpeg",
    "id" : 22396883,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://hotot.org\" rel=\"nofollow\">Hotot</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Andreas J\u00E4gle",
      "screen_name" : "ajaegle",
      "indices" : [ 0, 8 ],
      "id_str" : "78735610",
      "id" : 78735610
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "bedcon",
      "indices" : [ 9, 16 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "319780493476364288",
  "geo" : {
  },
  "id_str" : "319792271027482624",
  "in_reply_to_user_id" : 78735610,
  "text" : "@ajaegle #bedcon klingt gem\u00FCtlich.",
  "id" : 319792271027482624,
  "in_reply_to_status_id" : 319780493476364288,
  "created_at" : "Thu Apr 04 12:43:13 +0000 2013",
  "in_reply_to_screen_name" : "ajaegle",
  "in_reply_to_user_id_str" : "78735610",
  "user" : {
    "name" : "Felix",
    "screen_name" : "nicidienase",
    "protected" : false,
    "id_str" : "22396883",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3125784966/8223a4c5c9535be22d15c82ec829c2df_normal.jpeg",
    "id" : 22396883,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.tweetlanes.com\" rel=\"nofollow\">Tweet Lanes</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Max Winde",
      "screen_name" : "343max",
      "indices" : [ 3, 10 ],
      "id_str" : "2284151",
      "id" : 2284151
    } ],
    "media" : [ {
      "expanded_url" : "http://twitter.com/343max/status/319095523485315074/photo/1",
      "indices" : [ 68, 90 ],
      "url" : "http://t.co/HpN19fbnxJ",
      "media_url" : "http://pbs.twimg.com/media/BG2nsB9CcAEo_oX.jpg",
      "id_str" : "319095523493703681",
      "id" : 319095523493703681,
      "media_url_https" : "https://pbs.twimg.com/media/BG2nsB9CcAEo_oX.jpg",
      "sizes" : [ {
        "h" : 450,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 768,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 768,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 255,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com/HpN19fbnxJ"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "319113653624389632",
  "text" : "RT @343max: BurgerKing ist offensichtlich von Twitter unterwandert. http://t.co/HpN19fbnxJ",
  "retweeted_status" : {
    "source" : "<a href=\"http://tapbots.com/tweetbot\" rel=\"nofollow\">Tweetbot for iOS</a>",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "http://twitter.com/343max/status/319095523485315074/photo/1",
        "indices" : [ 56, 78 ],
        "url" : "http://t.co/HpN19fbnxJ",
        "media_url" : "http://pbs.twimg.com/media/BG2nsB9CcAEo_oX.jpg",
        "id_str" : "319095523493703681",
        "id" : 319095523493703681,
        "media_url_https" : "https://pbs.twimg.com/media/BG2nsB9CcAEo_oX.jpg",
        "sizes" : [ {
          "h" : 450,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 768,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 768,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 255,
          "resize" : "fit",
          "w" : 340
        } ],
        "display_url" : "pic.twitter.com/HpN19fbnxJ"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : {
    },
    "id_str" : "319095523485315074",
    "text" : "BurgerKing ist offensichtlich von Twitter unterwandert. http://t.co/HpN19fbnxJ",
    "id" : 319095523485315074,
    "created_at" : "Tue Apr 02 14:34:36 +0000 2013",
    "user" : {
      "name" : "Max Winde",
      "screen_name" : "343max",
      "protected" : false,
      "id_str" : "2284151",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/1573654380/edween_normal.png",
      "id" : 2284151,
      "verified" : false
    }
  },
  "id" : 319113653624389632,
  "created_at" : "Tue Apr 02 15:46:38 +0000 2013",
  "user" : {
    "name" : "Felix",
    "screen_name" : "nicidienase",
    "protected" : false,
    "id_str" : "22396883",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3125784966/8223a4c5c9535be22d15c82ec829c2df_normal.jpeg",
    "id" : 22396883,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://hotot.org\" rel=\"nofollow\">Hotot</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "psy",
      "screen_name" : "psycon",
      "indices" : [ 3, 10 ],
      "id_str" : "87286054",
      "id" : 87286054
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 40, 62 ],
      "url" : "http://t.co/JrVvYK9Qhv",
      "expanded_url" : "http://www.asta-ka.de/asta",
      "display_url" : "asta-ka.de/asta"
    } ]
  },
  "geo" : {
  },
  "id_str" : "318696154089013248",
  "text" : "RT @psycon: DAS macht der AStA also :-) http://t.co/JrVvYK9Qhv",
  "retweeted_status" : {
    "source" : "<a href=\"http://hotot.org\" rel=\"nofollow\">Hotot</a>",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 28, 50 ],
        "url" : "http://t.co/JrVvYK9Qhv",
        "expanded_url" : "http://www.asta-ka.de/asta",
        "display_url" : "asta-ka.de/asta"
      } ]
    },
    "geo" : {
    },
    "id_str" : "318694734749130752",
    "text" : "DAS macht der AStA also :-) http://t.co/JrVvYK9Qhv",
    "id" : 318694734749130752,
    "created_at" : "Mon Apr 01 12:02:00 +0000 2013",
    "user" : {
      "name" : "psy",
      "screen_name" : "psycon",
      "protected" : false,
      "id_str" : "87286054",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/2620981046/xkjfqh2iy0xp1lxx6cl1_normal.jpeg",
      "id" : 87286054,
      "verified" : false
    }
  },
  "id" : 318696154089013248,
  "created_at" : "Mon Apr 01 12:07:38 +0000 2013",
  "user" : {
    "name" : "Felix",
    "screen_name" : "nicidienase",
    "protected" : false,
    "id_str" : "22396883",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3125784966/8223a4c5c9535be22d15c82ec829c2df_normal.jpeg",
    "id" : 22396883,
    "verified" : false
  }
} ]