Grailbird.data.tweets_2010_09 = 
 [ {
  "source" : "<a href=\"http://tweed.pivotallabs.com\" rel=\"nofollow\">Tweed webOS</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 49.008609, 8.412124 ]
  },
  "id_str" : "25818982592",
  "text" : "Chips mit Zuckerglasur. Mega Kalorienbombe, schmeckt aber irgendwie ganz geil. http://twitpic.com/2svoup",
  "id" : 25818982592,
  "created_at" : "Tue Sep 28 20:51:44 +0000 2010",
  "user" : {
    "name" : "Felix",
    "screen_name" : "nicidienase",
    "protected" : false,
    "id_str" : "22396883",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3125784966/8223a4c5c9535be22d15c82ec829c2df_normal.jpeg",
    "id" : 22396883,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://tweed.pivotallabs.com\" rel=\"nofollow\">Tweed webOS</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Udo Vetter",
      "screen_name" : "udovetter",
      "indices" : [ 3, 13 ],
      "id_str" : "15998669",
      "id" : 15998669
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "25589180655",
  "text" : "RT @udovetter: Der beste Journalismus, den wir je hatten, fand auf Steintafeln und vielleicht noch Tierh\u00E4uten statt. Danach ging's abw\u00E4rts.",
  "retweeted_status" : {
    "source" : "<a href=\"http://www.tweetdeck.com\" rel=\"nofollow\">TweetDeck</a>",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : {
    },
    "id_str" : "25402899694",
    "text" : "Der beste Journalismus, den wir je hatten, fand auf Steintafeln und vielleicht noch Tierh\u00E4uten statt. Danach ging's abw\u00E4rts.",
    "id" : 25402899694,
    "created_at" : "Fri Sep 24 13:19:29 +0000 2010",
    "user" : {
      "name" : "Udo Vetter",
      "screen_name" : "udovetter",
      "protected" : false,
      "id_str" : "15998669",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/809406216/Cartoon_normal.jpg",
      "id" : 15998669,
      "verified" : true
    }
  },
  "id" : 25589180655,
  "created_at" : "Sun Sep 26 13:22:15 +0000 2010",
  "user" : {
    "name" : "Felix",
    "screen_name" : "nicidienase",
    "protected" : false,
    "id_str" : "22396883",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3125784966/8223a4c5c9535be22d15c82ec829c2df_normal.jpeg",
    "id" : 22396883,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "25190788813",
  "text" : "Buy a Laptop, get a Geek!\nhttp://www.youtube.com/watch?v=xmrHsMnM3yc",
  "id" : 25190788813,
  "created_at" : "Wed Sep 22 06:59:19 +0000 2010",
  "user" : {
    "name" : "Felix",
    "screen_name" : "nicidienase",
    "protected" : false,
    "id_str" : "22396883",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3125784966/8223a4c5c9535be22d15c82ec829c2df_normal.jpeg",
    "id" : 22396883,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://tweed.pivotallabs.com\" rel=\"nofollow\">Tweed webOS</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Eve",
      "screen_name" : "ChiisanaIchigo",
      "indices" : [ 0, 15 ],
      "id_str" : "187553346",
      "id" : 187553346
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "25102936155",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 49.01522, 8.390028 ]
  },
  "id_str" : "25103540650",
  "in_reply_to_user_id" : 187553346,
  "text" : "@ChiisanaIchigo Schaff was! *dirindenallerwertestentret* Hilft das? ;-)",
  "id" : 25103540650,
  "in_reply_to_status_id" : 25102936155,
  "created_at" : "Tue Sep 21 09:38:40 +0000 2010",
  "in_reply_to_screen_name" : "ChiisanaIchigo",
  "in_reply_to_user_id_str" : "187553346",
  "user" : {
    "name" : "Felix",
    "screen_name" : "nicidienase",
    "protected" : false,
    "id_str" : "22396883",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3125784966/8223a4c5c9535be22d15c82ec829c2df_normal.jpeg",
    "id" : 22396883,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://tweed.pivotallabs.com\" rel=\"nofollow\">Tweed webOS</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Miss Jane Doe",
      "screen_name" : "FrauMustermann",
      "indices" : [ 3, 18 ],
      "id_str" : "238678833",
      "id" : 238678833
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "25099546915",
  "text" : "RT @FrauMustermann: Bill Gates wird demn\u00E4chst in \u201CWetten da\u00DF\u2026\u201D auftreten. Er will 8 von 10 Windows Vista-Fehlern an den Wutausbr\u00FCchen de ...",
  "retweeted_status" : {
    "source" : "<a href=\"http://83degrees.com/to/powertwitter\" rel=\"nofollow\">Power Twitter</a>",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : {
    },
    "id_str" : "25034040785",
    "text" : "Bill Gates wird demn\u00E4chst in \u201CWetten da\u00DF\u2026\u201D auftreten. Er will 8 von 10 Windows Vista-Fehlern an den Wutausbr\u00FCchen der Anwender erkennen\u2026",
    "id" : 25034040785,
    "created_at" : "Mon Sep 20 15:21:16 +0000 2010",
    "user" : {
      "name" : "\u2665 twisted mind \u2665",
      "screen_name" : "Dorf_Diva",
      "protected" : false,
      "id_str" : "23740641",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/3515622857/1fa792bea6c8bbe9794cc0772a50a0c9_normal.jpeg",
      "id" : 23740641,
      "verified" : false
    }
  },
  "id" : 25099546915,
  "created_at" : "Tue Sep 21 08:02:52 +0000 2010",
  "user" : {
    "name" : "Felix",
    "screen_name" : "nicidienase",
    "protected" : false,
    "id_str" : "22396883",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3125784966/8223a4c5c9535be22d15c82ec829c2df_normal.jpeg",
    "id" : 22396883,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://tweed.pivotallabs.com\" rel=\"nofollow\">Tweed webOS</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Bulo",
      "screen_name" : "DerBulo",
      "indices" : [ 3, 11 ],
      "id_str" : "42403765",
      "id" : 42403765
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "25099499749",
  "text" : "RT @DerBulo: L\u00F6rrach - Erste Ger\u00FCchte... http://twitpic.com/2qczte",
  "retweeted_status" : {
    "source" : "<a href=\"http://twitpic.com\" rel=\"nofollow\">Twitpic</a>",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : {
    },
    "id_str" : "25042391278",
    "text" : "L\u00F6rrach - Erste Ger\u00FCchte... http://twitpic.com/2qczte",
    "id" : 25042391278,
    "created_at" : "Mon Sep 20 17:07:10 +0000 2010",
    "user" : {
      "name" : "Bulo",
      "screen_name" : "DerBulo",
      "protected" : false,
      "id_str" : "42403765",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/2220075801/SW_3_normal.jpg",
      "id" : 42403765,
      "verified" : false
    }
  },
  "id" : 25099499749,
  "created_at" : "Tue Sep 21 08:01:37 +0000 2010",
  "user" : {
    "name" : "Felix",
    "screen_name" : "nicidienase",
    "protected" : false,
    "id_str" : "22396883",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3125784966/8223a4c5c9535be22d15c82ec829c2df_normal.jpeg",
    "id" : 22396883,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "24321296483",
  "text" : "Irgendwie mochte mich Tweed net, zwei twitpics aus M sind irgendwie nicht angekommen. http://twitpic.com/2mzirv http://twitpic.com/2n4v6b",
  "id" : 24321296483,
  "created_at" : "Sun Sep 12 22:23:31 +0000 2010",
  "user" : {
    "name" : "Felix",
    "screen_name" : "nicidienase",
    "protected" : false,
    "id_str" : "22396883",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3125784966/8223a4c5c9535be22d15c82ec829c2df_normal.jpeg",
    "id" : 22396883,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://tweed.pivotallabs.com\" rel=\"nofollow\">Tweed webOS</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 48.176381, 11.554232 ]
  },
  "id_str" : "24275238943",
  "text" : "Hoch oben auf dem Fernsehturm! http://twitpic.com/2nq1d4",
  "id" : 24275238943,
  "created_at" : "Sun Sep 12 11:06:11 +0000 2010",
  "user" : {
    "name" : "Felix",
    "screen_name" : "nicidienase",
    "protected" : false,
    "id_str" : "22396883",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3125784966/8223a4c5c9535be22d15c82ec829c2df_normal.jpeg",
    "id" : 22396883,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://tweed.pivotallabs.com\" rel=\"nofollow\">Tweed webOS</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "M\u00FCnchen",
      "indices" : [ 7, 15 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 48.138778, 11.565304 ]
  },
  "id_str" : "24032374398",
  "text" : "KFC in #M\u00FCnchen, der erste gro\u00DFe Einsatz f\u00FCr mein TV-Be-Gone http://twitpic.com/2mrynm",
  "id" : 24032374398,
  "created_at" : "Thu Sep 09 18:12:42 +0000 2010",
  "user" : {
    "name" : "Felix",
    "screen_name" : "nicidienase",
    "protected" : false,
    "id_str" : "22396883",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3125784966/8223a4c5c9535be22d15c82ec829c2df_normal.jpeg",
    "id" : 22396883,
    "verified" : false
  }
} ]