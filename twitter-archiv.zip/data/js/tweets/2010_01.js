Grailbird.data.tweets_2010_01 = 
 [ {
  "source" : "<a href=\"http://pivotallabs.com/landing/tweed\" rel=\"nofollow\">Tweed</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Google",
      "indices" : [ 36, 43 ]
    }, {
      "text" : "Wave",
      "indices" : [ 44, 49 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "8416497160",
  "text" : "Ich merk grad das ich inzwischen 25 #Google #Wave Invites zu verteilen hab. Braucht/Will irgendwer noch eine?",
  "id" : 8416497160,
  "created_at" : "Sat Jan 30 16:29:36 +0000 2010",
  "user" : {
    "name" : "Felix",
    "screen_name" : "nicidienase",
    "protected" : false,
    "id_str" : "22396883",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3125784966/8223a4c5c9535be22d15c82ec829c2df_normal.jpeg",
    "id" : 22396883,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://pivotallabs.com/landing/tweed\" rel=\"nofollow\">Tweed</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Edward",
      "screen_name" : "twitgeridoo",
      "indices" : [ 3, 15 ],
      "id_str" : "46379961",
      "id" : 46379961
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Kindernet",
      "indices" : [ 79, 89 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "8378137773",
  "text" : "RT @Twitgeridoo: http://twitpic.com/108j2l - Nur das Beste f\u00FCr die Kleinen! :) #Kindernet | thx @marax79!",
  "id" : 8378137773,
  "created_at" : "Fri Jan 29 18:17:59 +0000 2010",
  "user" : {
    "name" : "Felix",
    "screen_name" : "nicidienase",
    "protected" : false,
    "id_str" : "22396883",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3125784966/8223a4c5c9535be22d15c82ec829c2df_normal.jpeg",
    "id" : 22396883,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitpic.com/\" rel=\"nofollow\">TwitPic</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "8372154305",
  "text" : "http://twitpic.com/10bnh6 - Hi Hi Hi, Knubbelfolie die 10-mal gr\u00F6\u00DFere Knubbel hat knallt auch 10-mal so laut.",
  "id" : 8372154305,
  "created_at" : "Fri Jan 29 15:40:32 +0000 2010",
  "user" : {
    "name" : "Felix",
    "screen_name" : "nicidienase",
    "protected" : false,
    "id_str" : "22396883",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3125784966/8223a4c5c9535be22d15c82ec829c2df_normal.jpeg",
    "id" : 22396883,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitpic.com/\" rel=\"nofollow\">TwitPic</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Karlsruhe",
      "indices" : [ 54, 64 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "8365486830",
  "text" : "http://twitpic.com/10avbn - H\u00E4ssliches Wetter hier in #Karlsruhe, da sollte man eigentlich gar net ausm Haus gehen.",
  "id" : 8365486830,
  "created_at" : "Fri Jan 29 12:23:06 +0000 2010",
  "user" : {
    "name" : "Felix",
    "screen_name" : "nicidienase",
    "protected" : false,
    "id_str" : "22396883",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3125784966/8223a4c5c9535be22d15c82ec829c2df_normal.jpeg",
    "id" : 22396883,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://pivotallabs.com/landing/tweed\" rel=\"nofollow\">Tweed</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Bulo",
      "screen_name" : "DerBulo",
      "indices" : [ 3, 11 ],
      "id_str" : "42403765",
      "id" : 42403765
    }, {
      "name" : "CDU-Info",
      "screen_name" : "kristinakoehler",
      "indices" : [ 71, 87 ],
      "id_str" : "76971822",
      "id" : 76971822
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "8206696501",
  "text" : "RT @DerBulo: http://twitpic.com/zqql3 - Zur\u00FCck, Frau K\u00F6hler, zur\u00FCck!!! @kristinakoehler",
  "id" : 8206696501,
  "created_at" : "Mon Jan 25 21:00:29 +0000 2010",
  "user" : {
    "name" : "Felix",
    "screen_name" : "nicidienase",
    "protected" : false,
    "id_str" : "22396883",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3125784966/8223a4c5c9535be22d15c82ec829c2df_normal.jpeg",
    "id" : 22396883,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://pivotallabs.com/landing/tweed\" rel=\"nofollow\">Tweed</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Anne Roth",
      "screen_name" : "annnalist",
      "indices" : [ 3, 13 ],
      "id_str" : "492617849",
      "id" : 492617849
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "8155401532",
  "text" : "RT @annnalist: Angewandte Nacktscanner - A Message From Transport Canada http://bit.ly/7Vg5JT",
  "id" : 8155401532,
  "created_at" : "Sun Jan 24 17:05:20 +0000 2010",
  "user" : {
    "name" : "Felix",
    "screen_name" : "nicidienase",
    "protected" : false,
    "id_str" : "22396883",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3125784966/8223a4c5c9535be22d15c82ec829c2df_normal.jpeg",
    "id" : 22396883,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://pivotallabs.com/landing/tweed\" rel=\"nofollow\">Tweed</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Edward",
      "screen_name" : "twitgeridoo",
      "indices" : [ 3, 15 ],
      "id_str" : "46379961",
      "id" : 46379961
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "8150390695",
  "text" : "RT @Twitgeridoo: Er\u00F6ffnung des Apple-Store in Frankfurt http://j.mp/6axz0W \u00DCbel! Auf welchen Drogen sind die bitte?",
  "id" : 8150390695,
  "created_at" : "Sun Jan 24 14:08:33 +0000 2010",
  "user" : {
    "name" : "Felix",
    "screen_name" : "nicidienase",
    "protected" : false,
    "id_str" : "22396883",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3125784966/8223a4c5c9535be22d15c82ec829c2df_normal.jpeg",
    "id" : 22396883,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://pivotallabs.com/landing/tweed\" rel=\"nofollow\">Tweed</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "8109015945",
  "text" : "... Und der kommt erst n\u00E4chste Woche und wir nach PF geliefert. Damn you Mindfactory.",
  "id" : 8109015945,
  "created_at" : "Sat Jan 23 12:19:06 +0000 2010",
  "user" : {
    "name" : "Felix",
    "screen_name" : "nicidienase",
    "protected" : false,
    "id_str" : "22396883",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3125784966/8223a4c5c9535be22d15c82ec829c2df_normal.jpeg",
    "id" : 22396883,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitpic.com/\" rel=\"nofollow\">TwitPic</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "8108951280",
  "text" : "http://twitpic.com/zcsru - Neue Grafikkarte und RAM, gestern bestellt, heute geliefert. Rest v on meinem neuen Rechner fehlt leider noch. ..",
  "id" : 8108951280,
  "created_at" : "Sat Jan 23 12:16:02 +0000 2010",
  "user" : {
    "name" : "Felix",
    "screen_name" : "nicidienase",
    "protected" : false,
    "id_str" : "22396883",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3125784966/8223a4c5c9535be22d15c82ec829c2df_normal.jpeg",
    "id" : 22396883,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://pivotallabs.com/landing/tweed\" rel=\"nofollow\">Tweed</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sunday8pm",
      "screen_name" : "sunday_8pm",
      "indices" : [ 0, 11 ],
      "id_str" : "80762004",
      "id" : 80762004
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "8036752718",
  "geo" : {
  },
  "id_str" : "8044669731",
  "in_reply_to_user_id" : 80762004,
  "text" : "@Sunday_8pm Die exposionsartige Zunahme von Fahrg\u00E4sten im \u00D6PNV nennt sich Feierabendverkehr (gibts da auch ein \u00C4quivalent f\u00FCr morgends?)",
  "id" : 8044669731,
  "in_reply_to_status_id" : 8036752718,
  "created_at" : "Thu Jan 21 22:42:39 +0000 2010",
  "in_reply_to_screen_name" : "sunday_8pm",
  "in_reply_to_user_id_str" : "80762004",
  "user" : {
    "name" : "Felix",
    "screen_name" : "nicidienase",
    "protected" : false,
    "id_str" : "22396883",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3125784966/8223a4c5c9535be22d15c82ec829c2df_normal.jpeg",
    "id" : 22396883,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://pivotallabs.com/landing/tweed\" rel=\"nofollow\">Tweed</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "KIT brennt",
      "screen_name" : "KITbrennt",
      "indices" : [ 3, 13 ],
      "id_str" : "91079620",
      "id" : 91079620
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "8044518434",
  "text" : "RT @KITbrennt: Auch hier in KA geht's weiter: AK Freie Bildung trifft sich Di 26.01. 19:00 im UStA. N\u00E4chstes Plenum am 11.02. 18 Uhr [...]",
  "id" : 8044518434,
  "created_at" : "Thu Jan 21 22:38:11 +0000 2010",
  "user" : {
    "name" : "Felix",
    "screen_name" : "nicidienase",
    "protected" : false,
    "id_str" : "22396883",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3125784966/8223a4c5c9535be22d15c82ec829c2df_normal.jpeg",
    "id" : 22396883,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://pivotallabs.com/landing/tweed\" rel=\"nofollow\">Tweed</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sunday8pm",
      "screen_name" : "sunday_8pm",
      "indices" : [ 0, 11 ],
      "id_str" : "80762004",
      "id" : 80762004
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "nichtpendler",
      "indices" : [ 79, 92 ]
    }, {
      "text" : "WIN",
      "indices" : [ 93, 97 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "8029627492",
  "geo" : {
  },
  "id_str" : "8034582668",
  "in_reply_to_user_id" : 80762004,
  "text" : "@Sunday_8pm Solche Bahnen sind einer der Gr\u00FCnde warum ich nach KA gezogen bin. #nichtpendler #WIN ;-)",
  "id" : 8034582668,
  "in_reply_to_status_id" : 8029627492,
  "created_at" : "Thu Jan 21 17:24:06 +0000 2010",
  "in_reply_to_screen_name" : "sunday_8pm",
  "in_reply_to_user_id_str" : "80762004",
  "user" : {
    "name" : "Felix",
    "screen_name" : "nicidienase",
    "protected" : false,
    "id_str" : "22396883",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3125784966/8223a4c5c9535be22d15c82ec829c2df_normal.jpeg",
    "id" : 22396883,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitpic.com/\" rel=\"nofollow\">TwitPic</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sunday8pm",
      "screen_name" : "sunday_8pm",
      "indices" : [ 27, 38 ],
      "id_str" : "80762004",
      "id" : 80762004
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Karlsruhe",
      "indices" : [ 42, 52 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "8021354717",
  "text" : "http://twitpic.com/z1kbt - @Sunday_8pm In #Karlsruhe liegt auch n bissl Schnee, die frage is n ur wie lang.",
  "id" : 8021354717,
  "created_at" : "Thu Jan 21 09:18:03 +0000 2010",
  "user" : {
    "name" : "Felix",
    "screen_name" : "nicidienase",
    "protected" : false,
    "id_str" : "22396883",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3125784966/8223a4c5c9535be22d15c82ec829c2df_normal.jpeg",
    "id" : 22396883,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://pivotallabs.com/landing/tweed\" rel=\"nofollow\">Tweed</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Max Winde",
      "screen_name" : "343max",
      "indices" : [ 3, 10 ],
      "id_str" : "2284151",
      "id" : 2284151
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "7984714342",
  "text" : "RT @343max: Unglaublich grandioser Rickroll: http://bit.ly/61YPTl",
  "id" : 7984714342,
  "created_at" : "Wed Jan 20 13:12:41 +0000 2010",
  "user" : {
    "name" : "Felix",
    "screen_name" : "nicidienase",
    "protected" : false,
    "id_str" : "22396883",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3125784966/8223a4c5c9535be22d15c82ec829c2df_normal.jpeg",
    "id" : 22396883,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://pivotallabs.com/landing/tweed\" rel=\"nofollow\">Tweed</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dsch\u00E4ikop",
      "screen_name" : "jakob_bl",
      "indices" : [ 3, 12 ],
      "id_str" : "75007992",
      "id" : 75007992
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "GEZ",
      "indices" : [ 70, 74 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "7953585502",
  "text" : "RT @jakob_bl: Schon GEZahlt? http://is.gd/6ANKX gute Anleitung um die #GEZ legal zu \u00E4rgern.",
  "id" : 7953585502,
  "created_at" : "Tue Jan 19 17:52:11 +0000 2010",
  "user" : {
    "name" : "Felix",
    "screen_name" : "nicidienase",
    "protected" : false,
    "id_str" : "22396883",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3125784966/8223a4c5c9535be22d15c82ec829c2df_normal.jpeg",
    "id" : 22396883,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://pivotallabs.com/landing/tweed\" rel=\"nofollow\">Tweed</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "KIT brennt",
      "screen_name" : "KITbrennt",
      "indices" : [ 3, 13 ],
      "id_str" : "91079620",
      "id" : 91079620
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "7938459394",
  "text" : "RT @KITbrennt: U-Modell Wahl! \n\nW\u00E4hlen gehen! \n\n18. bis 22. Januar",
  "id" : 7938459394,
  "created_at" : "Tue Jan 19 08:14:32 +0000 2010",
  "user" : {
    "name" : "Felix",
    "screen_name" : "nicidienase",
    "protected" : false,
    "id_str" : "22396883",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3125784966/8223a4c5c9535be22d15c82ec829c2df_normal.jpeg",
    "id" : 22396883,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://pivotallabs.com/landing/tweed\" rel=\"nofollow\">Tweed</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "KIT brennt",
      "screen_name" : "KITbrennt",
      "indices" : [ 3, 13 ],
      "id_str" : "91079620",
      "id" : 91079620
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "7938455155",
  "text" : "RT @KITbrennt: Plenum am Dienstag Abend. \n18.00 Uhr im HMO (Daimler H\u00F6rsaal).",
  "id" : 7938455155,
  "created_at" : "Tue Jan 19 08:14:18 +0000 2010",
  "user" : {
    "name" : "Felix",
    "screen_name" : "nicidienase",
    "protected" : false,
    "id_str" : "22396883",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3125784966/8223a4c5c9535be22d15c82ec829c2df_normal.jpeg",
    "id" : 22396883,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitpic.com/\" rel=\"nofollow\">TwitPic</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "7896269501",
  "text" : "http://twitpic.com/ymjud - Schei\u00DF Wetter. Der ganze sch\u00F6ne Schnee is weg.",
  "id" : 7896269501,
  "created_at" : "Mon Jan 18 07:32:09 +0000 2010",
  "user" : {
    "name" : "Felix",
    "screen_name" : "nicidienase",
    "protected" : false,
    "id_str" : "22396883",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3125784966/8223a4c5c9535be22d15c82ec829c2df_normal.jpeg",
    "id" : 22396883,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://pivotallabs.com/landing/tweed\" rel=\"nofollow\">Tweed</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sunday8pm",
      "screen_name" : "sunday_8pm",
      "indices" : [ 0, 11 ],
      "id_str" : "80762004",
      "id" : 80762004
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "7848795989",
  "geo" : {
  },
  "id_str" : "7850058045",
  "in_reply_to_user_id" : 80762004,
  "text" : "@Sunday_8pm M\u00FCde und alkoholisiert Twittern is net so gut, da \u00FCbersieht man so Sachen wie fehlende Hs bei Worten wie Thermometer.#drunk#fail",
  "id" : 7850058045,
  "in_reply_to_status_id" : 7848795989,
  "created_at" : "Sun Jan 17 03:14:50 +0000 2010",
  "in_reply_to_screen_name" : "sunday_8pm",
  "in_reply_to_user_id_str" : "80762004",
  "user" : {
    "name" : "Felix",
    "screen_name" : "nicidienase",
    "protected" : false,
    "id_str" : "22396883",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3125784966/8223a4c5c9535be22d15c82ec829c2df_normal.jpeg",
    "id" : 22396883,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://pivotallabs.com/landing/tweed\" rel=\"nofollow\">Tweed</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sunday8pm",
      "screen_name" : "sunday_8pm",
      "indices" : [ 0, 11 ],
      "id_str" : "80762004",
      "id" : 80762004
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "7848795989",
  "geo" : {
  },
  "id_str" : "7849926791",
  "in_reply_to_user_id" : 80762004,
  "text" : "@Sunday_8pm Nochmal danke f\u00FCr die coole Party. Aber die 4\u00B0 auf deinem Termometer ham net so ganz gestimmt. Mein Heimweg war sau glatt.",
  "id" : 7849926791,
  "in_reply_to_status_id" : 7848795989,
  "created_at" : "Sun Jan 17 03:10:35 +0000 2010",
  "in_reply_to_screen_name" : "sunday_8pm",
  "in_reply_to_user_id_str" : "80762004",
  "user" : {
    "name" : "Felix",
    "screen_name" : "nicidienase",
    "protected" : false,
    "id_str" : "22396883",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3125784966/8223a4c5c9535be22d15c82ec829c2df_normal.jpeg",
    "id" : 22396883,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitpic.com/\" rel=\"nofollow\">TwitPic</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "boarden",
      "indices" : [ 45, 53 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "7830229157",
  "text" : "http://twitpic.com/yc8wz - Wieder daheim vom #boarden/Ski fahren am Mehliskopf, Wetter und Pis te war gut und die Liftschlang net zu lang.",
  "id" : 7830229157,
  "created_at" : "Sat Jan 16 16:01:18 +0000 2010",
  "user" : {
    "name" : "Felix",
    "screen_name" : "nicidienase",
    "protected" : false,
    "id_str" : "22396883",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3125784966/8223a4c5c9535be22d15c82ec829c2df_normal.jpeg",
    "id" : 22396883,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://pivotallabs.com/landing/tweed\" rel=\"nofollow\">Tweed</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sunday8pm",
      "screen_name" : "sunday_8pm",
      "indices" : [ 0, 11 ],
      "id_str" : "80762004",
      "id" : 80762004
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "7659003807",
  "geo" : {
  },
  "id_str" : "7669866656",
  "in_reply_to_user_id" : 80762004,
  "text" : "@Sunday_8pm Die lassen sich aber Zeit. Gabs wenigstens n sch\u00F6nes Ersatzhandy?",
  "id" : 7669866656,
  "in_reply_to_status_id" : 7659003807,
  "created_at" : "Tue Jan 12 14:11:54 +0000 2010",
  "in_reply_to_screen_name" : "sunday_8pm",
  "in_reply_to_user_id_str" : "80762004",
  "user" : {
    "name" : "Felix",
    "screen_name" : "nicidienase",
    "protected" : false,
    "id_str" : "22396883",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3125784966/8223a4c5c9535be22d15c82ec829c2df_normal.jpeg",
    "id" : 22396883,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://pivotallabs.com/landing/tweed\" rel=\"nofollow\">Tweed</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "WebOS",
      "indices" : [ 0, 6 ]
    }, {
      "text" : "palm",
      "indices" : [ 69, 74 ]
    }, {
      "text" : "pre",
      "indices" : [ 75, 79 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "7654019729",
  "text" : "#WebOS 1.3.5.2 ist verf\u00FCgbar! Warum hat mir das noch niemand gesagt? #palm #pre",
  "id" : 7654019729,
  "created_at" : "Tue Jan 12 02:46:49 +0000 2010",
  "user" : {
    "name" : "Felix",
    "screen_name" : "nicidienase",
    "protected" : false,
    "id_str" : "22396883",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3125784966/8223a4c5c9535be22d15c82ec829c2df_normal.jpeg",
    "id" : 22396883,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://pivotallabs.com/landing/tweed\" rel=\"nofollow\">Tweed</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Holger Klein",
      "screen_name" : "holgi",
      "indices" : [ 3, 9 ],
      "id_str" : "3068271",
      "id" : 3068271
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "7614738028",
  "text" : "RT @holgi: Wenn das Darth Vader w\u00FCsste! http://www.youtube.com/watch?v=G2aIjPJtsv4",
  "id" : 7614738028,
  "created_at" : "Mon Jan 11 02:36:09 +0000 2010",
  "user" : {
    "name" : "Felix",
    "screen_name" : "nicidienase",
    "protected" : false,
    "id_str" : "22396883",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3125784966/8223a4c5c9535be22d15c82ec829c2df_normal.jpeg",
    "id" : 22396883,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitpic.com/\" rel=\"nofollow\">TwitPic</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "7543070511",
  "text" : "http://twitpic.com/xajsa - N\u00E4chtliche Schneewanderung durch Karlsruhe.",
  "id" : 7543070511,
  "created_at" : "Sat Jan 09 02:54:26 +0000 2010",
  "user" : {
    "name" : "Felix",
    "screen_name" : "nicidienase",
    "protected" : false,
    "id_str" : "22396883",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3125784966/8223a4c5c9535be22d15c82ec829c2df_normal.jpeg",
    "id" : 22396883,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://pivotallabs.com/landing/tweed\" rel=\"nofollow\">Tweed</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "netzpolitik",
      "screen_name" : "netzpolitik",
      "indices" : [ 3, 15 ],
      "id_str" : "9655032",
      "id" : 9655032
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "7503003461",
  "text" : "RT @netzpolitik: Unglaublich: iPhone-Killer f\u00FCr unter 20 Euro! http://bit.ly/8gZnX6",
  "id" : 7503003461,
  "created_at" : "Fri Jan 08 02:48:18 +0000 2010",
  "user" : {
    "name" : "Felix",
    "screen_name" : "nicidienase",
    "protected" : false,
    "id_str" : "22396883",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3125784966/8223a4c5c9535be22d15c82ec829c2df_normal.jpeg",
    "id" : 22396883,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://pivotallabs.com/landing/tweed\" rel=\"nofollow\">Tweed</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Bulo",
      "screen_name" : "DerBulo",
      "indices" : [ 3, 11 ],
      "id_str" : "42403765",
      "id" : 42403765
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Nacktscanner",
      "indices" : [ 39, 52 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "7439567099",
  "text" : "RT @DerBulo: Warum auf einmal alle den #Nacktscanner gutfinden: http://arm.in/9wh",
  "id" : 7439567099,
  "created_at" : "Wed Jan 06 12:49:40 +0000 2010",
  "user" : {
    "name" : "Felix",
    "screen_name" : "nicidienase",
    "protected" : false,
    "id_str" : "22396883",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3125784966/8223a4c5c9535be22d15c82ec829c2df_normal.jpeg",
    "id" : 22396883,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://pivotallabs.com/landing/tweed\" rel=\"nofollow\">Tweed</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Edward",
      "screen_name" : "twitgeridoo",
      "indices" : [ 3, 15 ],
      "id_str" : "46379961",
      "id" : 46379961
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "7378952447",
  "text" : "RT @Twitgeridoo: http://twitpic.com/wnz4i -Das Verh\u00E4ltnis von tats\u00E4chlicher Gefahr und \u00F6ffentlicher Wahrnehmung liegt oft Fern der Realit\u00E4t!",
  "id" : 7378952447,
  "created_at" : "Mon Jan 04 21:06:38 +0000 2010",
  "user" : {
    "name" : "Felix",
    "screen_name" : "nicidienase",
    "protected" : false,
    "id_str" : "22396883",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3125784966/8223a4c5c9535be22d15c82ec829c2df_normal.jpeg",
    "id" : 22396883,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://pivotallabs.com/landing/tweed\" rel=\"nofollow\">Tweed</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "7272883600",
  "text" : "Da legt man sich mal ne Weile hin um sich von der Silvesterparty zu erholen und kaum wacht man wieder auf liegt drau\u00DFen Schnee.",
  "id" : 7272883600,
  "created_at" : "Fri Jan 01 16:43:33 +0000 2010",
  "user" : {
    "name" : "Felix",
    "screen_name" : "nicidienase",
    "protected" : false,
    "id_str" : "22396883",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3125784966/8223a4c5c9535be22d15c82ec829c2df_normal.jpeg",
    "id" : 22396883,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://pivotallabs.com/landing/tweed\" rel=\"nofollow\">Tweed</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "7266381482",
  "text" : "Frohes Neues Jahr euch allen!!",
  "id" : 7266381482,
  "created_at" : "Fri Jan 01 10:20:01 +0000 2010",
  "user" : {
    "name" : "Felix",
    "screen_name" : "nicidienase",
    "protected" : false,
    "id_str" : "22396883",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3125784966/8223a4c5c9535be22d15c82ec829c2df_normal.jpeg",
    "id" : 22396883,
    "verified" : false
  }
} ]