Grailbird.data.tweets_2012_10 = 
 [ {
  "source" : "<a href=\"http://www.echofon.com/\" rel=\"nofollow\">Echofon</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "HAL 9000",
      "screen_name" : "HAL9000_",
      "indices" : [ 3, 12 ],
      "id_str" : "29038088",
      "id" : 29038088
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "DisneyStarWarsMovies",
      "indices" : [ 66, 87 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "263550050435739648",
  "text" : "RT @HAL9000_: In Disney's version of Star Wars, Goofy shot first. #DisneyStarWarsMovies",
  "retweeted_status" : {
    "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "DisneyStarWarsMovies",
        "indices" : [ 52, 73 ]
      } ],
      "urls" : [ ]
    },
    "geo" : {
    },
    "id_str" : "263420224018210816",
    "text" : "In Disney's version of Star Wars, Goofy shot first. #DisneyStarWarsMovies",
    "id" : 263420224018210816,
    "created_at" : "Tue Oct 30 23:20:50 +0000 2012",
    "user" : {
      "name" : "HAL 9000",
      "screen_name" : "HAL9000_",
      "protected" : false,
      "id_str" : "29038088",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/1788506913/HAL-MC2_normal.png",
      "id" : 29038088,
      "verified" : false
    }
  },
  "id" : 263550050435739648,
  "created_at" : "Wed Oct 31 07:56:43 +0000 2012",
  "user" : {
    "name" : "Felix",
    "screen_name" : "nicidienase",
    "protected" : false,
    "id_str" : "22396883",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3125784966/8223a4c5c9535be22d15c82ec829c2df_normal.jpeg",
    "id" : 22396883,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "i42n",
      "screen_name" : "i42n",
      "indices" : [ 3, 8 ],
      "id_str" : "22298116",
      "id" : 22298116
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Normalzeit",
      "indices" : [ 10, 21 ]
    } ],
    "urls" : [ {
      "indices" : [ 24, 44 ],
      "url" : "http://t.co/YkVgzEx3",
      "expanded_url" : "http://is.gd/winterzeit",
      "display_url" : "is.gd/winterzeit"
    } ]
  },
  "geo" : {
  },
  "id_str" : "262499177928466432",
  "text" : "RT @i42n: #Normalzeit!! http://t.co/YkVgzEx3",
  "retweeted_status" : {
    "source" : "<a href=\"http://tapbots.com/tweetbot\" rel=\"nofollow\">Tweetbot for iOS</a>",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "Normalzeit",
        "indices" : [ 0, 11 ]
      } ],
      "urls" : [ {
        "indices" : [ 14, 34 ],
        "url" : "http://t.co/YkVgzEx3",
        "expanded_url" : "http://is.gd/winterzeit",
        "display_url" : "is.gd/winterzeit"
      } ]
    },
    "geo" : {
    },
    "id_str" : "262492678707609600",
    "text" : "#Normalzeit!! http://t.co/YkVgzEx3",
    "id" : 262492678707609600,
    "created_at" : "Sun Oct 28 09:55:06 +0000 2012",
    "user" : {
      "name" : "i42n",
      "screen_name" : "i42n",
      "protected" : false,
      "id_str" : "22298116",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/3129115691/3c2e9123db7f498d478ace57a0ac1b69_normal.png",
      "id" : 22298116,
      "verified" : false
    }
  },
  "id" : 262499177928466432,
  "created_at" : "Sun Oct 28 10:20:55 +0000 2012",
  "user" : {
    "name" : "Felix",
    "screen_name" : "nicidienase",
    "protected" : false,
    "id_str" : "22396883",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3125784966/8223a4c5c9535be22d15c82ec829c2df_normal.jpeg",
    "id" : 22396883,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http://twitter.com/nicidienase/status/261846798472187904/photo/1",
      "indices" : [ 15, 35 ],
      "url" : "http://t.co/iTxpt1RN",
      "media_url" : "http://pbs.twimg.com/media/A6JERqECEAEEPmR.jpg",
      "id_str" : "261846798480576513",
      "id" : 261846798480576513,
      "media_url_https" : "https://pbs.twimg.com/media/A6JERqECEAEEPmR.jpg",
      "sizes" : [ {
        "h" : 1365,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 2560,
        "resize" : "fit",
        "w" : 1920
      }, {
        "h" : 453,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 800,
        "resize" : "fit",
        "w" : 600
      } ],
      "display_url" : "pic.twitter.com/iTxpt1RN"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "261846798472187904",
  "text" : "Wochenende \\o/ http://t.co/iTxpt1RN",
  "id" : 261846798472187904,
  "created_at" : "Fri Oct 26 15:08:37 +0000 2012",
  "user" : {
    "name" : "Felix",
    "screen_name" : "nicidienase",
    "protected" : false,
    "id_str" : "22396883",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3125784966/8223a4c5c9535be22d15c82ec829c2df_normal.jpeg",
    "id" : 22396883,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/tweetbutton\" rel=\"nofollow\">Tweet Button</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "YouTube",
      "screen_name" : "YouTube",
      "indices" : [ 38, 46 ],
      "id_str" : "10228272",
      "id" : 10228272
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 13, 33 ],
      "url" : "http://t.co/p2u9LvuD",
      "expanded_url" : "http://youtu.be/bFW7VQpY-Ik",
      "display_url" : "youtu.be/bFW7VQpY-Ik"
    } ]
  },
  "geo" : {
  },
  "id_str" : "261816070074159104",
  "text" : "Cooles Teil: http://t.co/p2u9LvuD via @youtube",
  "id" : 261816070074159104,
  "created_at" : "Fri Oct 26 13:06:30 +0000 2012",
  "user" : {
    "name" : "Felix",
    "screen_name" : "nicidienase",
    "protected" : false,
    "id_str" : "22396883",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3125784966/8223a4c5c9535be22d15c82ec829c2df_normal.jpeg",
    "id" : 22396883,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.echofon.com/\" rel=\"nofollow\">Echofon</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sm\u00E1ri McCarthy",
      "screen_name" : "smarimc",
      "indices" : [ 3, 11 ],
      "id_str" : "18031814",
      "id" : 18031814
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 105, 125 ],
      "url" : "http://t.co/OArMBNt7",
      "expanded_url" : "http://grapevine.is/News/ReadArticle/Teletubbies-Get-Sopranos-Subtitles-Hilarity-Ensues",
      "display_url" : "grapevine.is/News/ReadArtic\u2026"
    } ]
  },
  "geo" : {
  },
  "id_str" : "261801677395488768",
  "text" : "RT @smarimc: Teletubbies aired with Sopranos subtitles in Iceland. They will never be seen the same way. http://t.co/OArMBNt7",
  "retweeted_status" : {
    "source" : "<a href=\"http://www.tweetdeck.com\" rel=\"nofollow\">TweetDeck</a>",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 92, 112 ],
        "url" : "http://t.co/OArMBNt7",
        "expanded_url" : "http://grapevine.is/News/ReadArticle/Teletubbies-Get-Sopranos-Subtitles-Hilarity-Ensues",
        "display_url" : "grapevine.is/News/ReadArtic\u2026"
      } ]
    },
    "geo" : {
    },
    "id_str" : "261793807702585344",
    "text" : "Teletubbies aired with Sopranos subtitles in Iceland. They will never be seen the same way. http://t.co/OArMBNt7",
    "id" : 261793807702585344,
    "created_at" : "Fri Oct 26 11:38:02 +0000 2012",
    "user" : {
      "name" : "Sm\u00E1ri McCarthy",
      "screen_name" : "smarimc",
      "protected" : false,
      "id_str" : "18031814",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/3485553746/a852bda24135ae24894d058fbc3ddaeb_normal.jpeg",
      "id" : 18031814,
      "verified" : false
    }
  },
  "id" : 261801677395488768,
  "created_at" : "Fri Oct 26 12:09:18 +0000 2012",
  "user" : {
    "name" : "Felix",
    "screen_name" : "nicidienase",
    "protected" : false,
    "id_str" : "22396883",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3125784966/8223a4c5c9535be22d15c82ec829c2df_normal.jpeg",
    "id" : 22396883,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.echofon.com/\" rel=\"nofollow\">Echofon</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Eva Eichhorn",
      "screen_name" : "MamsellChaos",
      "indices" : [ 0, 13 ],
      "id_str" : "140774041",
      "id" : 140774041
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "261797228006494209",
  "geo" : {
  },
  "id_str" : "261798073943064576",
  "in_reply_to_user_id" : 140774041,
  "text" : "@MamsellChaos Mein Kopf ging eher Richtung Wikinger, aber Lady Eva of House Chaos klingt auch net schlecht.",
  "id" : 261798073943064576,
  "in_reply_to_status_id" : 261797228006494209,
  "created_at" : "Fri Oct 26 11:54:59 +0000 2012",
  "in_reply_to_screen_name" : "MamsellChaos",
  "in_reply_to_user_id_str" : "140774041",
  "user" : {
    "name" : "Felix",
    "screen_name" : "nicidienase",
    "protected" : false,
    "id_str" : "22396883",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3125784966/8223a4c5c9535be22d15c82ec829c2df_normal.jpeg",
    "id" : 22396883,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.echofon.com/\" rel=\"nofollow\">Echofon</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "261797208381333504",
  "text" : "Ich krieg Mails von in einer halben Stunde.",
  "id" : 261797208381333504,
  "created_at" : "Fri Oct 26 11:51:33 +0000 2012",
  "user" : {
    "name" : "Felix",
    "screen_name" : "nicidienase",
    "protected" : false,
    "id_str" : "22396883",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3125784966/8223a4c5c9535be22d15c82ec829c2df_normal.jpeg",
    "id" : 22396883,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.echofon.com/\" rel=\"nofollow\">Echofon</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Eva Eichhorn",
      "screen_name" : "MamsellChaos",
      "indices" : [ 0, 13 ],
      "id_str" : "140774041",
      "id" : 140774041
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "boobwarrior",
      "indices" : [ 106, 118 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "261793388809056256",
  "geo" : {
  },
  "id_str" : "261794830127071232",
  "in_reply_to_user_id" : 140774041,
  "text" : "@MamsellChaos Irgendwie hab ich jetzt einen gepanzerten BH, lange Z\u00F6pfe und einen beh\u00F6rnten Helm im Kopf. #boobwarrior",
  "id" : 261794830127071232,
  "in_reply_to_status_id" : 261793388809056256,
  "created_at" : "Fri Oct 26 11:42:06 +0000 2012",
  "in_reply_to_screen_name" : "MamsellChaos",
  "in_reply_to_user_id_str" : "140774041",
  "user" : {
    "name" : "Felix",
    "screen_name" : "nicidienase",
    "protected" : false,
    "id_str" : "22396883",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3125784966/8223a4c5c9535be22d15c82ec829c2df_normal.jpeg",
    "id" : 22396883,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.echofon.com/\" rel=\"nofollow\">Echofon</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "marcus engert",
      "screen_name" : "marcusengert",
      "indices" : [ 3, 16 ],
      "id_str" : "331598085",
      "id" : 331598085
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "261780239707959297",
  "text" : "RT @marcusengert: \"werden viele Firmen bei Windows 7 bleiben &amp;\nPrivatnutzer gehen solange ihren Nachbarschafts-ITlern auf den Sack b ...",
  "retweeted_status" : {
    "source" : "web",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : {
    },
    "id_str" : "261778312140054528",
    "text" : "\"werden viele Firmen bei Windows 7 bleiben &amp;\nPrivatnutzer gehen solange ihren Nachbarschafts-ITlern auf den Sack bis Win8 aussieht wie Win7\"",
    "id" : 261778312140054528,
    "created_at" : "Fri Oct 26 10:36:27 +0000 2012",
    "user" : {
      "name" : "marcus engert",
      "screen_name" : "marcusengert",
      "protected" : false,
      "id_str" : "331598085",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/3382867166/ba847df8c07316e26fef5282c5e97ff1_normal.jpeg",
      "id" : 331598085,
      "verified" : false
    }
  },
  "id" : 261780239707959297,
  "created_at" : "Fri Oct 26 10:44:07 +0000 2012",
  "user" : {
    "name" : "Felix",
    "screen_name" : "nicidienase",
    "protected" : false,
    "id_str" : "22396883",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3125784966/8223a4c5c9535be22d15c82ec829c2df_normal.jpeg",
    "id" : 22396883,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "261756231537020928",
  "text" : "B\u00E4\u00E4\u00E4h. Mir is kalt und ich bin m\u00FCde. Wo ist mein Bett?",
  "id" : 261756231537020928,
  "created_at" : "Fri Oct 26 09:08:43 +0000 2012",
  "user" : {
    "name" : "Felix",
    "screen_name" : "nicidienase",
    "protected" : false,
    "id_str" : "22396883",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3125784966/8223a4c5c9535be22d15c82ec829c2df_normal.jpeg",
    "id" : 22396883,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Michael Pearson",
      "screen_name" : "mipearson",
      "indices" : [ 3, 13 ],
      "id_str" : "15630518",
      "id" : 15630518
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "261566345668345859",
  "text" : "RT @mipearson: OH \"Apple has introduced 'Thunderbolt' and 'Lightning', will the next technology be 'Very Very Frightening'?\"",
  "retweeted_status" : {
    "source" : "<a href=\"http://itunes.apple.com/us/app/twitter/id409789998?mt=12\" rel=\"nofollow\">Twitter for Mac</a>",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : {
    },
    "id_str" : "261306702673113088",
    "text" : "OH \"Apple has introduced 'Thunderbolt' and 'Lightning', will the next technology be 'Very Very Frightening'?\"",
    "id" : 261306702673113088,
    "created_at" : "Thu Oct 25 03:22:27 +0000 2012",
    "user" : {
      "name" : "Michael Pearson",
      "screen_name" : "mipearson",
      "protected" : false,
      "id_str" : "15630518",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/3492088778/f03ac09dd84aa00efb242038f99b463e_normal.jpeg",
      "id" : 15630518,
      "verified" : false
    }
  },
  "id" : 261566345668345859,
  "created_at" : "Thu Oct 25 20:34:11 +0000 2012",
  "user" : {
    "name" : "Felix",
    "screen_name" : "nicidienase",
    "protected" : false,
    "id_str" : "22396883",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3125784966/8223a4c5c9535be22d15c82ec829c2df_normal.jpeg",
    "id" : 22396883,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "i42n",
      "screen_name" : "i42n",
      "indices" : [ 0, 5 ],
      "id_str" : "22298116",
      "id" : 22298116
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "261467768296206337",
  "geo" : {
  },
  "id_str" : "261558004137205760",
  "in_reply_to_user_id" : 22298116,
  "text" : "@i42n Du hast zu weit gebl\u00E4ttert, der LaTeX-Kurs is eine Seite weiter vorne im Studium Generale Heft.",
  "id" : 261558004137205760,
  "in_reply_to_status_id" : 261467768296206337,
  "created_at" : "Thu Oct 25 20:01:02 +0000 2012",
  "in_reply_to_screen_name" : "i42n",
  "in_reply_to_user_id_str" : "22298116",
  "user" : {
    "name" : "Felix",
    "screen_name" : "nicidienase",
    "protected" : false,
    "id_str" : "22396883",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3125784966/8223a4c5c9535be22d15c82ec829c2df_normal.jpeg",
    "id" : 22396883,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "DLR_next",
      "screen_name" : "DLR_next",
      "indices" : [ 3, 12 ],
      "id_str" : "69248730",
      "id" : 69248730
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "260855507420594176",
  "text" : "RT @DLR_next: Wir warnen aber hiermit aus juristischen Gr\u00FCnden und rein prophylaktisch vor allen denkbaren Asteroideneinschl\u00E4gen u.a. We ...",
  "retweeted_status" : {
    "source" : "web",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : {
    },
    "id_str" : "260740731789008896",
    "text" : "Wir warnen aber hiermit aus juristischen Gr\u00FCnden und rein prophylaktisch vor allen denkbaren Asteroideneinschl\u00E4gen u.a. Weltunterg\u00E4ngen.",
    "id" : 260740731789008896,
    "created_at" : "Tue Oct 23 13:53:29 +0000 2012",
    "user" : {
      "name" : "DLR_next",
      "screen_name" : "DLR_next",
      "protected" : false,
      "id_str" : "69248730",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/1148712876/DLR_next-Twitter-Icon_02_normal.jpg",
      "id" : 69248730,
      "verified" : true
    }
  },
  "id" : 260855507420594176,
  "created_at" : "Tue Oct 23 21:29:34 +0000 2012",
  "user" : {
    "name" : "Felix",
    "screen_name" : "nicidienase",
    "protected" : false,
    "id_str" : "22396883",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3125784966/8223a4c5c9535be22d15c82ec829c2df_normal.jpeg",
    "id" : 22396883,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.echofon.com/\" rel=\"nofollow\">Echofon</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "i42n",
      "screen_name" : "i42n",
      "indices" : [ 0, 5 ],
      "id_str" : "22298116",
      "id" : 22298116
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "260679348707807232",
  "geo" : {
  },
  "id_str" : "260702136634060800",
  "in_reply_to_user_id" : 22298116,
  "text" : "@i42n Die musst du unbedingt machen! Die sind genial.",
  "id" : 260702136634060800,
  "in_reply_to_status_id" : 260679348707807232,
  "created_at" : "Tue Oct 23 11:20:07 +0000 2012",
  "in_reply_to_screen_name" : "i42n",
  "in_reply_to_user_id_str" : "22298116",
  "user" : {
    "name" : "Felix",
    "screen_name" : "nicidienase",
    "protected" : false,
    "id_str" : "22396883",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3125784966/8223a4c5c9535be22d15c82ec829c2df_normal.jpeg",
    "id" : 22396883,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.echofon.com/\" rel=\"nofollow\">Echofon</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 16, 36 ],
      "url" : "http://t.co/V3HKW6WK",
      "expanded_url" : "http://theprofoundprogrammer.com/",
      "display_url" : "theprofoundprogrammer.com"
    } ]
  },
  "geo" : {
  },
  "id_str" : "260701304375083008",
  "text" : "Nette Wallpaper http://t.co/V3HKW6WK",
  "id" : 260701304375083008,
  "created_at" : "Tue Oct 23 11:16:49 +0000 2012",
  "user" : {
    "name" : "Felix",
    "screen_name" : "nicidienase",
    "protected" : false,
    "id_str" : "22396883",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3125784966/8223a4c5c9535be22d15c82ec829c2df_normal.jpeg",
    "id" : 22396883,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.echofon.com/\" rel=\"nofollow\">Echofon</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Command Line Magic",
      "screen_name" : "climagic",
      "indices" : [ 3, 12 ],
      "id_str" : "91333167",
      "id" : 91333167
    }, {
      "name" : "matt",
      "screen_name" : "brimston3",
      "indices" : [ 87, 97 ],
      "id_str" : "14302589",
      "id" : 14302589
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 14, 34 ],
      "url" : "http://t.co/Gtiv1uJz",
      "expanded_url" : "http://stedolan.github.com/jq/",
      "display_url" : "stedolan.github.com/jq/"
    } ]
  },
  "geo" : {
  },
  "id_str" : "260393271904333826",
  "text" : "RT @climagic: http://t.co/Gtiv1uJz # jq is a command line processor for JSON data. Thx @brimston3",
  "retweeted_status" : {
    "source" : "<a href=\"http://suso.suso.org/xulu/Command_Line_Magic\" rel=\"nofollow\">CLI Magic poster</a>",
    "entities" : {
      "user_mentions" : [ {
        "name" : "matt",
        "screen_name" : "brimston3",
        "indices" : [ 73, 83 ],
        "id_str" : "14302589",
        "id" : 14302589
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 0, 20 ],
        "url" : "http://t.co/Gtiv1uJz",
        "expanded_url" : "http://stedolan.github.com/jq/",
        "display_url" : "stedolan.github.com/jq/"
      } ]
    },
    "geo" : {
    },
    "id_str" : "260391887163232256",
    "text" : "http://t.co/Gtiv1uJz # jq is a command line processor for JSON data. Thx @brimston3",
    "id" : 260391887163232256,
    "created_at" : "Mon Oct 22 14:47:18 +0000 2012",
    "user" : {
      "name" : "Command Line Magic",
      "screen_name" : "climagic",
      "protected" : false,
      "id_str" : "91333167",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/535876218/climagic-icon_normal.png",
      "id" : 91333167,
      "verified" : false
    }
  },
  "id" : 260393271904333826,
  "created_at" : "Mon Oct 22 14:52:48 +0000 2012",
  "user" : {
    "name" : "Felix",
    "screen_name" : "nicidienase",
    "protected" : false,
    "id_str" : "22396883",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3125784966/8223a4c5c9535be22d15c82ec829c2df_normal.jpeg",
    "id" : 22396883,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.echofon.com/\" rel=\"nofollow\">Echofon</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sebastian Nebel",
      "screen_name" : "nebelicious",
      "indices" : [ 3, 15 ],
      "id_str" : "1346702814",
      "id" : 1346702814
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 32, 52 ],
      "url" : "http://t.co/FoVnRRWd",
      "expanded_url" : "http://twitter.com/nebelicious/status/260054381259530240/photo/1",
      "display_url" : "pic.twitter.com/FoVnRRWd"
    } ]
  },
  "geo" : {
  },
  "id_str" : "260361603105574912",
  "text" : "RT @nebelicious: Palimm-palimm! http://t.co/FoVnRRWd",
  "retweeted_status" : {
    "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "http://twitter.com/SebastianNebel/status/260054381259530240/photo/1",
        "indices" : [ 15, 35 ],
        "url" : "http://t.co/FoVnRRWd",
        "media_url" : "http://pbs.twimg.com/media/A5vmFPlCIAI1G7N.jpg",
        "id_str" : "260054381259530242",
        "id" : 260054381259530242,
        "media_url_https" : "https://pbs.twimg.com/media/A5vmFPlCIAI1G7N.jpg",
        "sizes" : [ {
          "h" : 575,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 191,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 337,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 1456,
          "resize" : "fit",
          "w" : 2592
        } ],
        "display_url" : "pic.twitter.com/FoVnRRWd"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : {
    },
    "id_str" : "260054381259530240",
    "text" : "Palimm-palimm! http://t.co/FoVnRRWd",
    "id" : 260054381259530240,
    "created_at" : "Sun Oct 21 16:26:11 +0000 2012",
    "user" : {
      "name" : "Sebastian Nebel",
      "screen_name" : "SebastianNebel",
      "protected" : false,
      "id_str" : "34238967",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/3362864216/236b21c2946b4f3c06f7f54c54a1912e_normal.jpeg",
      "id" : 34238967,
      "verified" : false
    }
  },
  "id" : 260361603105574912,
  "created_at" : "Mon Oct 22 12:46:58 +0000 2012",
  "user" : {
    "name" : "Felix",
    "screen_name" : "nicidienase",
    "protected" : false,
    "id_str" : "22396883",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3125784966/8223a4c5c9535be22d15c82ec829c2df_normal.jpeg",
    "id" : 22396883,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.echofon.com/\" rel=\"nofollow\">Echofon</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Holger Klein",
      "screen_name" : "holgi",
      "indices" : [ 3, 9 ],
      "id_str" : "3068271",
      "id" : 3068271
    }, {
      "name" : "Chris Sickendieck",
      "screen_name" : "csickendieck",
      "indices" : [ 55, 68 ],
      "id_str" : "146188405",
      "id" : 146188405
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "259644546839896064",
  "text" : "RT @holgi: Die Mutter der Dummen ist immer schwanger. \u201C@csickendieck: Postillon \u00FCber Reaktionen auf deren Baumgartner-Artikel http://t.c ...",
  "retweeted_status" : {
    "source" : "<a href=\"http://tapbots.com/tweetbot\" rel=\"nofollow\">Tweetbot for iOS</a>",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Chris Sickendieck",
        "screen_name" : "csickendieck",
        "indices" : [ 44, 57 ],
        "id_str" : "146188405",
        "id" : 146188405
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 115, 135 ],
        "url" : "http://t.co/nERsCwqD",
        "expanded_url" : "http://lallus.net/9ci",
        "display_url" : "lallus.net/9ci"
      } ]
    },
    "geo" : {
    },
    "id_str" : "259640024281255936",
    "text" : "Die Mutter der Dummen ist immer schwanger. \u201C@csickendieck: Postillon \u00FCber Reaktionen auf deren Baumgartner-Artikel http://t.co/nERsCwqD\u201D",
    "id" : 259640024281255936,
    "created_at" : "Sat Oct 20 12:59:40 +0000 2012",
    "user" : {
      "name" : "Holger Klein",
      "screen_name" : "holgi",
      "protected" : false,
      "id_str" : "3068271",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/14606372/ich1_normal.jpg",
      "id" : 3068271,
      "verified" : false
    }
  },
  "id" : 259644546839896064,
  "created_at" : "Sat Oct 20 13:17:38 +0000 2012",
  "user" : {
    "name" : "Felix",
    "screen_name" : "nicidienase",
    "protected" : false,
    "id_str" : "22396883",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3125784966/8223a4c5c9535be22d15c82ec829c2df_normal.jpeg",
    "id" : 22396883,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "259402210193047553",
  "text" : "OH: \"Zeig mal das Foto. Ach ne is so weit. Schicks per Bluetooth.\"",
  "id" : 259402210193047553,
  "created_at" : "Fri Oct 19 21:14:41 +0000 2012",
  "user" : {
    "name" : "Felix",
    "screen_name" : "nicidienase",
    "protected" : false,
    "id_str" : "22396883",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3125784966/8223a4c5c9535be22d15c82ec829c2df_normal.jpeg",
    "id" : 22396883,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Nathan Fillion",
      "screen_name" : "NathanFillion",
      "indices" : [ 0, 14 ],
      "id_str" : "31353077",
      "id" : 31353077
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 59, 79 ],
      "url" : "http://t.co/ql15Doe0",
      "expanded_url" : "http://www.mail4us.pl/img.php?type=2&img=/upload/85023800247.jpg",
      "display_url" : "mail4us.pl/img.php?type=2\u2026"
    } ]
  },
  "geo" : {
  },
  "id_str" : "259075430764662786",
  "in_reply_to_user_id" : 31353077,
  "text" : "@NathanFillion Did you see this? Serenity on a porn cover: http://t.co/ql15Doe0",
  "id" : 259075430764662786,
  "created_at" : "Thu Oct 18 23:36:10 +0000 2012",
  "in_reply_to_screen_name" : "NathanFillion",
  "in_reply_to_user_id_str" : "31353077",
  "user" : {
    "name" : "Felix",
    "screen_name" : "nicidienase",
    "protected" : false,
    "id_str" : "22396883",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3125784966/8223a4c5c9535be22d15c82ec829c2df_normal.jpeg",
    "id" : 22396883,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.echofon.com/\" rel=\"nofollow\">Echofon</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 64, 84 ],
      "url" : "http://t.co/vC9uvs0v",
      "expanded_url" : "http://img.pr0gramm.com/2012/10/258032392-1-123-60lo.jpg",
      "display_url" : "img.pr0gramm.com/2012/10/258032\u2026"
    } ]
  },
  "geo" : {
  },
  "id_str" : "259069476128034817",
  "text" : "WTF? Eine Duke Nukem Porno-Parodie mit Serenity auf dem Cover?? http://t.co/vC9uvs0v",
  "id" : 259069476128034817,
  "created_at" : "Thu Oct 18 23:12:31 +0000 2012",
  "user" : {
    "name" : "Felix",
    "screen_name" : "nicidienase",
    "protected" : false,
    "id_str" : "22396883",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3125784966/8223a4c5c9535be22d15c82ec829c2df_normal.jpeg",
    "id" : 22396883,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "October Jones",
      "screen_name" : "OctoberJones",
      "indices" : [ 3, 16 ],
      "id_str" : "96738801",
      "id" : 96738801
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 79, 99 ],
      "url" : "http://t.co/6uAUmBGv",
      "expanded_url" : "http://twitter.com/OctoberJones/status/258456375053647872/photo/1",
      "display_url" : "pic.twitter.com/6uAUmBGv"
    } ]
  },
  "geo" : {
  },
  "id_str" : "258465452680949761",
  "text" : "RT @OctoberJones: THOR. THIS HULK. HULK BE LATE TO OFFICE. NO EAT HULK'S BAGEL http://t.co/6uAUmBGv",
  "retweeted_status" : {
    "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "http://twitter.com/OctoberJones/status/258456375053647872/photo/1",
        "indices" : [ 61, 81 ],
        "url" : "http://t.co/6uAUmBGv",
        "media_url" : "http://pbs.twimg.com/media/A5Y4tClCAAAkfpn.jpg",
        "id_str" : "258456375057842176",
        "id" : 258456375057842176,
        "media_url_https" : "https://pbs.twimg.com/media/A5Y4tClCAAAkfpn.jpg",
        "sizes" : [ {
          "h" : 1024,
          "resize" : "fit",
          "w" : 765
        }, {
          "h" : 455,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 1024,
          "resize" : "fit",
          "w" : 765
        }, {
          "h" : 803,
          "resize" : "fit",
          "w" : 600
        } ],
        "display_url" : "pic.twitter.com/6uAUmBGv"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : {
    },
    "id_str" : "258456375053647872",
    "text" : "THOR. THIS HULK. HULK BE LATE TO OFFICE. NO EAT HULK'S BAGEL http://t.co/6uAUmBGv",
    "id" : 258456375053647872,
    "created_at" : "Wed Oct 17 06:36:16 +0000 2012",
    "user" : {
      "name" : "October Jones",
      "screen_name" : "OctoberJones",
      "protected" : false,
      "id_str" : "96738801",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/1972318929/photo-1_1__1__normal.jpg",
      "id" : 96738801,
      "verified" : false
    }
  },
  "id" : 258465452680949761,
  "created_at" : "Wed Oct 17 07:12:20 +0000 2012",
  "user" : {
    "name" : "Felix",
    "screen_name" : "nicidienase",
    "protected" : false,
    "id_str" : "22396883",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3125784966/8223a4c5c9535be22d15c82ec829c2df_normal.jpeg",
    "id" : 22396883,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http://twitter.com/nicidienase/status/258284827957149697/photo/1",
      "indices" : [ 14, 34 ],
      "url" : "http://t.co/w3vIaTeq",
      "media_url" : "http://pbs.twimg.com/media/A5Wcrr2CQAEc5wf.png",
      "id_str" : "258284827961344001",
      "id" : 258284827961344001,
      "media_url_https" : "https://pbs.twimg.com/media/A5Wcrr2CQAEc5wf.png",
      "sizes" : [ {
        "h" : 800,
        "resize" : "fit",
        "w" : 480
      }, {
        "h" : 567,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 800,
        "resize" : "fit",
        "w" : 480
      }, {
        "h" : 800,
        "resize" : "fit",
        "w" : 480
      } ],
      "display_url" : "pic.twitter.com/w3vIaTeq"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "258284827957149697",
  "text" : "Yeay! Update! http://t.co/w3vIaTeq",
  "id" : 258284827957149697,
  "created_at" : "Tue Oct 16 19:14:36 +0000 2012",
  "user" : {
    "name" : "Felix",
    "screen_name" : "nicidienase",
    "protected" : false,
    "id_str" : "22396883",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3125784966/8223a4c5c9535be22d15c82ec829c2df_normal.jpeg",
    "id" : 22396883,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.echofon.com/\" rel=\"nofollow\">Echofon</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 48, 68 ],
      "url" : "http://t.co/TyrkigWy",
      "expanded_url" : "http://chris.photobooks.com/json/default.htm",
      "display_url" : "chris.photobooks.com/json/default.h\u2026"
    } ]
  },
  "geo" : {
  },
  "id_str" : "258192001596542976",
  "text" : "Nettes Tool um JSON \u00FCbersichtlich darzustellen: http://t.co/TyrkigWy",
  "id" : 258192001596542976,
  "created_at" : "Tue Oct 16 13:05:44 +0000 2012",
  "user" : {
    "name" : "Felix",
    "screen_name" : "nicidienase",
    "protected" : false,
    "id_str" : "22396883",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3125784966/8223a4c5c9535be22d15c82ec829c2df_normal.jpeg",
    "id" : 22396883,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.echofon.com/\" rel=\"nofollow\">Echofon</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Michael Seemann",
      "screen_name" : "mspro",
      "indices" : [ 3, 9 ],
      "id_str" : "5751892",
      "id" : 5751892
    }, {
      "name" : "Wolfgang Michal",
      "screen_name" : "WolfgangMichal",
      "indices" : [ 105, 120 ],
      "id_str" : "153097184",
      "id" : 153097184
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 80, 100 ],
      "url" : "http://t.co/7SFvlTkA",
      "expanded_url" : "http://www.der-postillon.com/2012/10/linie-ubertreten-rekordsprung-aus-39.html",
      "display_url" : "der-postillon.com/2012/10/linie-\u2026"
    } ]
  },
  "geo" : {
  },
  "id_str" : "257823248786542592",
  "text" : "RT @mspro: ach \u00E4rgerlich! der stratossprung gestern wurde f\u00FCr ung\u00FCltig erkl\u00E4rt: http://t.co/7SFvlTkA via @WolfgangMichal",
  "retweeted_status" : {
    "source" : "<a href=\"http://itunes.apple.com/us/app/twitter/id409789998?mt=12\" rel=\"nofollow\">Twitter for Mac</a>",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Wolfgang Michal",
        "screen_name" : "WolfgangMichal",
        "indices" : [ 94, 109 ],
        "id_str" : "153097184",
        "id" : 153097184
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 69, 89 ],
        "url" : "http://t.co/7SFvlTkA",
        "expanded_url" : "http://www.der-postillon.com/2012/10/linie-ubertreten-rekordsprung-aus-39.html",
        "display_url" : "der-postillon.com/2012/10/linie-\u2026"
      } ]
    },
    "geo" : {
    },
    "id_str" : "257822842329124864",
    "text" : "ach \u00E4rgerlich! der stratossprung gestern wurde f\u00FCr ung\u00FCltig erkl\u00E4rt: http://t.co/7SFvlTkA via @WolfgangMichal",
    "id" : 257822842329124864,
    "created_at" : "Mon Oct 15 12:38:50 +0000 2012",
    "user" : {
      "name" : "Michael Seemann",
      "screen_name" : "mspro",
      "protected" : false,
      "id_str" : "5751892",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/3408641243/2edf38d3c995612edf5b3d2e20d74861_normal.jpeg",
      "id" : 5751892,
      "verified" : false
    }
  },
  "id" : 257823248786542592,
  "created_at" : "Mon Oct 15 12:40:27 +0000 2012",
  "user" : {
    "name" : "Felix",
    "screen_name" : "nicidienase",
    "protected" : false,
    "id_str" : "22396883",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3125784966/8223a4c5c9535be22d15c82ec829c2df_normal.jpeg",
    "id" : 22396883,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Alexander Dommes",
      "screen_name" : "veloc1ty",
      "indices" : [ 3, 12 ],
      "id_str" : "19052653",
      "id" : 19052653
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 14, 34 ],
      "url" : "http://t.co/9mHApC31",
      "expanded_url" : "http://twitter.com/veloc1ty/status/257239226066817024/photo/1",
      "display_url" : "pic.twitter.com/9mHApC31"
    } ]
  },
  "geo" : {
  },
  "id_str" : "257501826033799168",
  "text" : "RT @veloc1ty: http://t.co/9mHApC31",
  "retweeted_status" : {
    "source" : "<a href=\"http://www.tweetdeck.com\" rel=\"nofollow\">TweetDeck</a>",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "http://twitter.com/veloc1ty/status/257239226066817024/photo/1",
        "indices" : [ 0, 20 ],
        "url" : "http://t.co/9mHApC31",
        "media_url" : "http://pbs.twimg.com/media/A5HltpRCUAA7wDw.png",
        "id_str" : "257239226071011328",
        "id" : 257239226071011328,
        "media_url_https" : "https://pbs.twimg.com/media/A5HltpRCUAA7wDw.png",
        "sizes" : [ {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 361,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 373,
          "resize" : "fit",
          "w" : 620
        }, {
          "h" : 373,
          "resize" : "fit",
          "w" : 620
        }, {
          "h" : 205,
          "resize" : "fit",
          "w" : 340
        } ],
        "display_url" : "pic.twitter.com/9mHApC31"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : {
    },
    "id_str" : "257239226066817024",
    "text" : "http://t.co/9mHApC31",
    "id" : 257239226066817024,
    "created_at" : "Sat Oct 13 21:59:45 +0000 2012",
    "user" : {
      "name" : "Alexander Dommes",
      "screen_name" : "veloc1ty",
      "protected" : false,
      "id_str" : "19052653",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/2190938457/twitter_normal.jpg",
      "id" : 19052653,
      "verified" : false
    }
  },
  "id" : 257501826033799168,
  "created_at" : "Sun Oct 14 15:23:14 +0000 2012",
  "user" : {
    "name" : "Felix",
    "screen_name" : "nicidienase",
    "protected" : false,
    "id_str" : "22396883",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3125784966/8223a4c5c9535be22d15c82ec829c2df_normal.jpeg",
    "id" : 22396883,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ideenkopierer",
      "screen_name" : "Ideenkopierer",
      "indices" : [ 3, 17 ],
      "id_str" : "464636978",
      "id" : 464636978
    }, {
      "name" : "Chris Brugger-Burg",
      "screen_name" : "monomo111",
      "indices" : [ 24, 34 ],
      "id_str" : "23109429",
      "id" : 23109429
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 72, 92 ],
      "url" : "http://t.co/s8sEznKR",
      "expanded_url" : "http://twitpic.com/b3hknv",
      "display_url" : "twitpic.com/b3hknv"
    } ]
  },
  "geo" : {
  },
  "id_str" : "256875071602307072",
  "text" : "RT @Ideenkopierer: Laut @monomo111 meinte David McAllister es wohl so:  http://t.co/s8sEznKR",
  "retweeted_status" : {
    "source" : "<a href=\"http://www.tweetdeck.com\" rel=\"nofollow\">TweetDeck</a>",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Chris Brugger-Burg",
        "screen_name" : "monomo111",
        "indices" : [ 5, 15 ],
        "id_str" : "23109429",
        "id" : 23109429
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 53, 73 ],
        "url" : "http://t.co/s8sEznKR",
        "expanded_url" : "http://twitpic.com/b3hknv",
        "display_url" : "twitpic.com/b3hknv"
      } ]
    },
    "geo" : {
    },
    "id_str" : "256819370301480960",
    "text" : "Laut @monomo111 meinte David McAllister es wohl so:  http://t.co/s8sEznKR",
    "id" : 256819370301480960,
    "created_at" : "Fri Oct 12 18:11:24 +0000 2012",
    "user" : {
      "name" : "Ideenkopierer",
      "screen_name" : "Ideenkopierer",
      "protected" : false,
      "id_str" : "464636978",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/2510642374/myhnqqqpp6i9d50utpk1_normal.png",
      "id" : 464636978,
      "verified" : false
    }
  },
  "id" : 256875071602307072,
  "created_at" : "Fri Oct 12 21:52:44 +0000 2012",
  "user" : {
    "name" : "Felix",
    "screen_name" : "nicidienase",
    "protected" : false,
    "id_str" : "22396883",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3125784966/8223a4c5c9535be22d15c82ec829c2df_normal.jpeg",
    "id" : 22396883,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ideenkopierer",
      "screen_name" : "Ideenkopierer",
      "indices" : [ 3, 17 ],
      "id_str" : "464636978",
      "id" : 464636978
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 51, 71 ],
      "url" : "http://t.co/l6HA5ofP",
      "expanded_url" : "http://twitpic.com/b3ghmy",
      "display_url" : "twitpic.com/b3ghmy"
    } ]
  },
  "geo" : {
  },
  "id_str" : "256874507342598145",
  "text" : "RT @Ideenkopierer: Nein, David.. irgendwie nicht.. http://t.co/l6HA5ofP",
  "retweeted_status" : {
    "source" : "<a href=\"http://tapbots.com/tweetbot\" rel=\"nofollow\">Tweetbot for iOS</a>",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 32, 52 ],
        "url" : "http://t.co/l6HA5ofP",
        "expanded_url" : "http://twitpic.com/b3ghmy",
        "display_url" : "twitpic.com/b3ghmy"
      } ]
    },
    "geo" : {
    },
    "id_str" : "256787263462178816",
    "text" : "Nein, David.. irgendwie nicht.. http://t.co/l6HA5ofP",
    "id" : 256787263462178816,
    "created_at" : "Fri Oct 12 16:03:49 +0000 2012",
    "user" : {
      "name" : "Ideenkopierer",
      "screen_name" : "Ideenkopierer",
      "protected" : false,
      "id_str" : "464636978",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/2510642374/myhnqqqpp6i9d50utpk1_normal.png",
      "id" : 464636978,
      "verified" : false
    }
  },
  "id" : 256874507342598145,
  "created_at" : "Fri Oct 12 21:50:29 +0000 2012",
  "user" : {
    "name" : "Felix",
    "screen_name" : "nicidienase",
    "protected" : false,
    "id_str" : "22396883",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3125784966/8223a4c5c9535be22d15c82ec829c2df_normal.jpeg",
    "id" : 22396883,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.echofon.com/\" rel=\"nofollow\">Echofon</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Command Line Magic",
      "screen_name" : "climagic",
      "indices" : [ 3, 12 ],
      "id_str" : "91333167",
      "id" : 91333167
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 14, 34 ],
      "url" : "http://t.co/LpqCljfg",
      "expanded_url" : "http://twitpic.com/8mjnfa",
      "display_url" : "twitpic.com/8mjnfa"
    } ]
  },
  "geo" : {
  },
  "id_str" : "256763730321350656",
  "text" : "RT @climagic: http://t.co/LpqCljfg # What the world thinks of command line users. A repost, but many of you missed it.",
  "retweeted_status" : {
    "source" : "<a href=\"http://suso.suso.org/xulu/Command_Line_Magic\" rel=\"nofollow\">CLI Magic poster</a>",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 0, 20 ],
        "url" : "http://t.co/LpqCljfg",
        "expanded_url" : "http://twitpic.com/8mjnfa",
        "display_url" : "twitpic.com/8mjnfa"
      } ]
    },
    "geo" : {
    },
    "id_str" : "256762842219433984",
    "text" : "http://t.co/LpqCljfg # What the world thinks of command line users. A repost, but many of you missed it.",
    "id" : 256762842219433984,
    "created_at" : "Fri Oct 12 14:26:46 +0000 2012",
    "user" : {
      "name" : "Command Line Magic",
      "screen_name" : "climagic",
      "protected" : false,
      "id_str" : "91333167",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/535876218/climagic-icon_normal.png",
      "id" : 91333167,
      "verified" : false
    }
  },
  "id" : 256763730321350656,
  "created_at" : "Fri Oct 12 14:30:18 +0000 2012",
  "user" : {
    "name" : "Felix",
    "screen_name" : "nicidienase",
    "protected" : false,
    "id_str" : "22396883",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3125784966/8223a4c5c9535be22d15c82ec829c2df_normal.jpeg",
    "id" : 22396883,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.echofon.com/\" rel=\"nofollow\">Echofon</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "tante",
      "screen_name" : "tante",
      "indices" : [ 3, 9 ],
      "id_str" : "14179278",
      "id" : 14179278
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 52, 72 ],
      "url" : "http://t.co/ZSPsBNOf",
      "expanded_url" : "http://i.imgur.com/TJT47.jpg",
      "display_url" : "i.imgur.com/TJT47.jpg"
    } ]
  },
  "geo" : {
  },
  "id_str" : "256713302862856192",
  "text" : "RT @tante: Und pl\u00F6tzlich waren Macs nicht mehr hip. http://t.co/ZSPsBNOf",
  "retweeted_status" : {
    "source" : "<a href=\"http://hotot.org\" rel=\"nofollow\">Hotot</a>",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 41, 61 ],
        "url" : "http://t.co/ZSPsBNOf",
        "expanded_url" : "http://i.imgur.com/TJT47.jpg",
        "display_url" : "i.imgur.com/TJT47.jpg"
      } ]
    },
    "geo" : {
    },
    "id_str" : "256687395049725952",
    "text" : "Und pl\u00F6tzlich waren Macs nicht mehr hip. http://t.co/ZSPsBNOf",
    "id" : 256687395049725952,
    "created_at" : "Fri Oct 12 09:26:58 +0000 2012",
    "user" : {
      "name" : "tante",
      "screen_name" : "tante",
      "protected" : false,
      "id_str" : "14179278",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/2135062566/phayres_leaf_monkey_1_normal.jpg",
      "id" : 14179278,
      "verified" : false
    }
  },
  "id" : 256713302862856192,
  "created_at" : "Fri Oct 12 11:09:55 +0000 2012",
  "user" : {
    "name" : "Felix",
    "screen_name" : "nicidienase",
    "protected" : false,
    "id_str" : "22396883",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3125784966/8223a4c5c9535be22d15c82ec829c2df_normal.jpeg",
    "id" : 22396883,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 0, 20 ],
      "url" : "http://t.co/MaiSREBJ",
      "expanded_url" : "http://theoatmeal.com/comics/cats_actually_kill",
      "display_url" : "theoatmeal.com/comics/cats_ac\u2026"
    } ]
  },
  "geo" : {
  },
  "id_str" : "255589966304907264",
  "text" : "http://t.co/MaiSREBJ man's adorable little serial killers",
  "id" : 255589966304907264,
  "created_at" : "Tue Oct 09 08:46:11 +0000 2012",
  "user" : {
    "name" : "Felix",
    "screen_name" : "nicidienase",
    "protected" : false,
    "id_str" : "22396883",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3125784966/8223a4c5c9535be22d15c82ec829c2df_normal.jpeg",
    "id" : 22396883,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mario Sixtus",
      "screen_name" : "sixtus",
      "indices" : [ 0, 7 ],
      "id_str" : "9334352",
      "id" : 9334352
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "255221344298487808",
  "geo" : {
  },
  "id_str" : "255224199373807616",
  "in_reply_to_user_id" : 9334352,
  "text" : "@sixtus in S\u00FCddeutschland wird laufen oft synonym zu gehen verwendet. Hier geht der Fuss manchmal auch bis zur H\u00FCfte.",
  "id" : 255224199373807616,
  "in_reply_to_status_id" : 255221344298487808,
  "created_at" : "Mon Oct 08 08:32:45 +0000 2012",
  "in_reply_to_screen_name" : "sixtus",
  "in_reply_to_user_id_str" : "9334352",
  "user" : {
    "name" : "Felix",
    "screen_name" : "nicidienase",
    "protected" : false,
    "id_str" : "22396883",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3125784966/8223a4c5c9535be22d15c82ec829c2df_normal.jpeg",
    "id" : 22396883,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Wil Wheaton",
      "screen_name" : "wilw",
      "indices" : [ 0, 5 ],
      "id_str" : "1183041",
      "id" : 1183041
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "255059736389615616",
  "geo" : {
  },
  "id_str" : "255072597383995393",
  "in_reply_to_user_id" : 1183041,
  "text" : "@wilw It could probably tell lots of stories about lots of different wallets.",
  "id" : 255072597383995393,
  "in_reply_to_status_id" : 255059736389615616,
  "created_at" : "Sun Oct 07 22:30:20 +0000 2012",
  "in_reply_to_screen_name" : "wilw",
  "in_reply_to_user_id_str" : "1183041",
  "user" : {
    "name" : "Felix",
    "screen_name" : "nicidienase",
    "protected" : false,
    "id_str" : "22396883",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3125784966/8223a4c5c9535be22d15c82ec829c2df_normal.jpeg",
    "id" : 22396883,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http://twitter.com/nicidienase/status/254947329621229568/photo/1",
      "indices" : [ 41, 61 ],
      "url" : "http://t.co/o0yv3NAA",
      "media_url" : "http://pbs.twimg.com/media/A4nBPtrCAAAbqWq.jpg",
      "id_str" : "254947329625423872",
      "id" : 254947329625423872,
      "media_url_https" : "https://pbs.twimg.com/media/A4nBPtrCAAAbqWq.jpg",
      "sizes" : [ {
        "h" : 450,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 1920,
        "resize" : "fit",
        "w" : 2560
      }, {
        "h" : 768,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 255,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com/o0yv3NAA"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "254947329621229568",
  "text" : "Die Bolognese koch flei\u00DFig vor sich hin. http://t.co/o0yv3NAA",
  "id" : 254947329621229568,
  "created_at" : "Sun Oct 07 14:12:36 +0000 2012",
  "user" : {
    "name" : "Felix",
    "screen_name" : "nicidienase",
    "protected" : false,
    "id_str" : "22396883",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3125784966/8223a4c5c9535be22d15c82ec829c2df_normal.jpeg",
    "id" : 22396883,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kate H.",
      "screen_name" : "elaoe7",
      "indices" : [ 0, 7 ],
      "id_str" : "149650777",
      "id" : 149650777
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "254945896255606785",
  "geo" : {
  },
  "id_str" : "254946578656280576",
  "in_reply_to_user_id" : 149650777,
  "text" : "@elaoe7 Schau doch mal bei PirateBay oder so. Ne Lizenz hast du ja.",
  "id" : 254946578656280576,
  "in_reply_to_status_id" : 254945896255606785,
  "created_at" : "Sun Oct 07 14:09:35 +0000 2012",
  "in_reply_to_screen_name" : "elaoe7",
  "in_reply_to_user_id_str" : "149650777",
  "user" : {
    "name" : "Felix",
    "screen_name" : "nicidienase",
    "protected" : false,
    "id_str" : "22396883",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3125784966/8223a4c5c9535be22d15c82ec829c2df_normal.jpeg",
    "id" : 22396883,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kate H.",
      "screen_name" : "elaoe7",
      "indices" : [ 0, 7 ],
      "id_str" : "149650777",
      "id" : 149650777
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "254923218983469056",
  "geo" : {
  },
  "id_str" : "254945243663847424",
  "in_reply_to_user_id" : 149650777,
  "text" : "@elaoe7 Wof\u00FCr zur H\u00F6lle braucht man Windoof 2000?!?",
  "id" : 254945243663847424,
  "in_reply_to_status_id" : 254923218983469056,
  "created_at" : "Sun Oct 07 14:04:17 +0000 2012",
  "in_reply_to_screen_name" : "elaoe7",
  "in_reply_to_user_id_str" : "149650777",
  "user" : {
    "name" : "Felix",
    "screen_name" : "nicidienase",
    "protected" : false,
    "id_str" : "22396883",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3125784966/8223a4c5c9535be22d15c82ec829c2df_normal.jpeg",
    "id" : 22396883,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tim Weber",
      "screen_name" : "scy",
      "indices" : [ 3, 7 ],
      "id_str" : "8308632",
      "id" : 8308632
    }, {
      "name" : "neingeist",
      "screen_name" : "neingeist",
      "indices" : [ 9, 19 ],
      "id_str" : "11193712",
      "id" : 11193712
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "254375637177999360",
  "text" : "RT @scy: @neingeist DA. FACKING. F\u00DCR.",
  "retweeted_status" : {
    "source" : "<a href=\"http://www.tweetdeck.com\" rel=\"nofollow\">TweetDeck</a>",
    "entities" : {
      "user_mentions" : [ {
        "name" : "neingeist",
        "screen_name" : "neingeist",
        "indices" : [ 0, 10 ],
        "id_str" : "11193712",
        "id" : 11193712
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "in_reply_to_status_id_str" : "254325141507543040",
    "geo" : {
    },
    "id_str" : "254325263381458945",
    "in_reply_to_user_id" : 11193712,
    "text" : "@neingeist DA. FACKING. F\u00DCR.",
    "id" : 254325263381458945,
    "in_reply_to_status_id" : 254325141507543040,
    "created_at" : "Fri Oct 05 21:00:42 +0000 2012",
    "in_reply_to_screen_name" : "neingeist",
    "in_reply_to_user_id_str" : "11193712",
    "user" : {
      "name" : "Tim Weber",
      "screen_name" : "scy",
      "protected" : false,
      "id_str" : "8308632",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/424137519/avatar184_normal.jpg",
      "id" : 8308632,
      "verified" : false
    }
  },
  "id" : 254375637177999360,
  "created_at" : "Sat Oct 06 00:20:52 +0000 2012",
  "user" : {
    "name" : "Felix",
    "screen_name" : "nicidienase",
    "protected" : false,
    "id_str" : "22396883",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3125784966/8223a4c5c9535be22d15c82ec829c2df_normal.jpeg",
    "id" : 22396883,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "254236295591776256",
  "text" : "Liebe Firmen die bei mir mit gesponserten Tweets Werbung machen wollen: Ihr wisst schon das der einzige Effekt ist das ich euch spamblocke?",
  "id" : 254236295591776256,
  "created_at" : "Fri Oct 05 15:07:11 +0000 2012",
  "user" : {
    "name" : "Felix",
    "screen_name" : "nicidienase",
    "protected" : false,
    "id_str" : "22396883",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3125784966/8223a4c5c9535be22d15c82ec829c2df_normal.jpeg",
    "id" : 22396883,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http://twitter.com/nicidienase/status/254235722104586240/photo/1",
      "indices" : [ 42, 62 ],
      "url" : "http://t.co/zRbLVsMa",
      "media_url" : "http://pbs.twimg.com/media/A4c6CtGCQAABc4M.jpg",
      "id_str" : "254235722108780544",
      "id" : 254235722108780544,
      "media_url_https" : "https://pbs.twimg.com/media/A4c6CtGCQAABc4M.jpg",
      "sizes" : [ {
        "h" : 450,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 1920,
        "resize" : "fit",
        "w" : 2560
      }, {
        "h" : 768,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 255,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com/zRbLVsMa"
    } ],
    "hashtags" : [ {
      "text" : "hska",
      "indices" : [ 30, 35 ]
    }, {
      "text" : "fail",
      "indices" : [ 36, 41 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "254235722104586240",
  "text" : "Wer passt nicht in die Reihe? #hska #fail http://t.co/zRbLVsMa",
  "id" : 254235722104586240,
  "created_at" : "Fri Oct 05 15:04:55 +0000 2012",
  "user" : {
    "name" : "Felix",
    "screen_name" : "nicidienase",
    "protected" : false,
    "id_str" : "22396883",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3125784966/8223a4c5c9535be22d15c82ec829c2df_normal.jpeg",
    "id" : 22396883,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.echofon.com/\" rel=\"nofollow\">Echofon</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "254230458504732672",
  "geo" : {
  },
  "id_str" : "254231461052416001",
  "in_reply_to_user_id" : 20689932,
  "text" : "@Geruhn oooh Pandy*   *Pervert Andy",
  "id" : 254231461052416001,
  "in_reply_to_status_id" : 254230458504732672,
  "created_at" : "Fri Oct 05 14:47:58 +0000 2012",
  "in_reply_to_screen_name" : "keinGeruhn",
  "in_reply_to_user_id_str" : "20689932",
  "user" : {
    "name" : "Felix",
    "screen_name" : "nicidienase",
    "protected" : false,
    "id_str" : "22396883",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3125784966/8223a4c5c9535be22d15c82ec829c2df_normal.jpeg",
    "id" : 22396883,
    "verified" : false
  }
}, {
  "source" : "<a href=\"https://play.google.com/store/apps/details?id=org.mariotaku.twidere\" rel=\"nofollow\">Twidere for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "punycode",
      "screen_name" : "punycode",
      "indices" : [ 3, 12 ],
      "id_str" : "14328131",
      "id" : 14328131
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "253479986261004288",
  "text" : "RT @punycode: Tag der flauschigen Einheit. Mein Bett und ich.",
  "retweeted_status" : {
    "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : {
    },
    "id_str" : "253449684331421696",
    "text" : "Tag der flauschigen Einheit. Mein Bett und ich.",
    "id" : 253449684331421696,
    "created_at" : "Wed Oct 03 11:01:28 +0000 2012",
    "user" : {
      "name" : "punycode",
      "screen_name" : "punycode",
      "protected" : false,
      "id_str" : "14328131",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/52551181/max_normal.gif",
      "id" : 14328131,
      "verified" : false
    }
  },
  "id" : 253479986261004288,
  "created_at" : "Wed Oct 03 13:01:52 +0000 2012",
  "user" : {
    "name" : "Felix",
    "screen_name" : "nicidienase",
    "protected" : false,
    "id_str" : "22396883",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3125784966/8223a4c5c9535be22d15c82ec829c2df_normal.jpeg",
    "id" : 22396883,
    "verified" : false
  }
}, {
  "source" : "<a href=\"https://play.google.com/store/apps/details?id=org.mariotaku.twidere\" rel=\"nofollow\">Twidere for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "i42n",
      "screen_name" : "i42n",
      "indices" : [ 0, 5 ],
      "id_str" : "22298116",
      "id" : 22298116
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "253435695115427840",
  "geo" : {
  },
  "id_str" : "253479102907035648",
  "in_reply_to_user_id" : 22298116,
  "text" : "@i42n Versuchs mal mit einer zweiten Identity f\u00FCr eine bestehende Inbox.",
  "id" : 253479102907035648,
  "in_reply_to_status_id" : 253435695115427840,
  "created_at" : "Wed Oct 03 12:58:22 +0000 2012",
  "in_reply_to_screen_name" : "i42n",
  "in_reply_to_user_id_str" : "22298116",
  "user" : {
    "name" : "Felix",
    "screen_name" : "nicidienase",
    "protected" : false,
    "id_str" : "22396883",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3125784966/8223a4c5c9535be22d15c82ec829c2df_normal.jpeg",
    "id" : 22396883,
    "verified" : false
  }
} ]